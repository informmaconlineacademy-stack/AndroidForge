package dev.toe3autopilot.core.calibration

import dev.toe3autopilot.core.vision.Frame
import dev.toe3autopilot.core.vision.GrayImage
import dev.toe3autopilot.core.vision.Roi
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Proposes which fixed on-screen element is which driving control, from evidence in the pictures.
 *
 * It works on the elements [HudAnalyzer] separated from the moving scenery and uses only what those elements show:
 *
 *  - Pedals: two TALL elements standing side by side with aligned bottoms. The left one is proposed as the brake and the
 *    right one as the accelerator (the arrangement of real pedals and of Truckers of Europe 3). A taller right element
 *    strengthens the proposal.
 *  - Steering buttons: two elements of the same size on one line whose pictures are MIRROR IMAGES of each other
 *    (a left and a right arrow). Measured with normalised cross-correlation of the time-averaged pictures.
 *  - Steering wheel: one large element whose outline lies on a circle (ring-ness), when no button pair was found.
 *  - Minimap: a map-sized framed element whose INSIDE keeps changing (the map scrolls) and/or holds a vivid route colour.
 *
 * Position on the screen is only ever a small extra weight, never a reason on its own. Nothing here is trusted: every
 * proposal is NEEDS_CONFIRMATION with source [DetectionSource.SHAPE] and a confidence capped at
 * [ControlDetection.SHAPE_MAX_CONFIDENCE]. The person confirms, moves or replaces each one. A control without evidence
 * (reverse gear in particular, which looks like any other small button) is reported as not found, never invented.
 *
 * It does NOT assume a control changes its look when pressed. If a pressed-state analysis of the same pictures exists
 * ([VideoCalibrationResult]) and agrees, that is added as supporting evidence.
 */
object ControlCandidateDetector {
    data class Result(
        val detections: Map<CalibRole, ControlDetection>,
        val minimap: MinimapSuggestion?,
        /** Plain-language findings for the analysis report. */
        val notes: List<String>,
    )

    fun detect(hud: HudAnalysis, frames: List<Frame>, pressedEvidence: VideoCalibrationResult? = null): Result {
        val w = hud.frameWidth
        val h = hud.frameHeight
        val usable = frames.filter { it.width == w && it.height == h }
        val notes = ArrayList<String>()
        val out = LinkedHashMap<CalibRole, ControlDetection>()
        if (!hud.ok || usable.isEmpty()) {
            val why = hud.problem ?: "no pictures to analyse"
            for (r in ROLES) out[r] = ControlDetection.none(r, why).copy(source = DetectionSource.SHAPE)
            return Result(out, null, listOf("No fixed on-screen elements could be separated from the scenery: $why"))
        }
        val stats = TemporalStats.of(usable)
        val els = hud.elements
        val used = HashSet<HudElement>()
        val short = min(w, h).toFloat()

        fun pxW(e: HudElement) = (e.box.right - e.box.left) * w
        fun pxH(e: HudElement) = (e.box.bottom - e.box.top) * h
        fun side(e: HudElement) = max(pxW(e), pxH(e)) / short

        // ---- pedals -----------------------------------------------------------------------------------------------
        val pedalLike = els.filter { e -> e.aspect in 0.30f..0.90f && e.cy >= 0.45f && side(e) in 0.12f..0.70f && e.areaFraction <= 0.06f }
        var bestPedals: Pair<Pair<HudElement, HudElement>, Pair<Float, List<String>>>? = null
        for (a in pedalLike) for (b in pedalLike) {
            if (a === b || a.cx >= b.cx) continue
            val maxW = max(a.box.right - a.box.left, b.box.right - b.box.left)
            val gap = b.box.left - a.box.right
            if (gap < -0.01f || gap > 2.0f * maxW) continue
            val widthRatio = max(pxW(a), pxW(b)) / max(1f, min(pxW(a), pxW(b)))
            if (widthRatio > 1.8f) continue
            val overlap = min(a.box.bottom, b.box.bottom) - max(a.box.top, b.box.top)
            if (overlap < 0.5f * min(a.box.bottom - a.box.top, b.box.bottom - b.box.top)) continue
            val ev = ArrayList<String>()
            var s = 0.25f
            ev += "two tall fixed elements stand side by side (aspect ${fmt2(a.aspect)} and ${fmt2(b.aspect)}): the shape of a pedal pair"
            val bottomDiff = abs(a.box.bottom - b.box.bottom)
            if (bottomDiff <= 0.03f) {
                s += 0.10f
                ev += "their bottoms are aligned (within ${(bottomDiff * 100).toInt()}% of the screen height)"
            }
            if (pxH(b) > pxH(a) * 1.05f) {
                s += 0.07f
                ev += "the right one is taller, as an accelerator usually is"
            }
            if (b.cx > 0.5f) {
                s += 0.06f
                ev += "on the right side of the screen (a small extra weight only)"
            }
            if (bestPedals == null || s > bestPedals.second.first) bestPedals = (a to b) to (s to ev)
        }
        val pressedAcc = pressedEvidence?.detections?.get(CalibRole.ACCELERATOR)?.takeIf { it.status == DetectionStatus.NEEDS_CONFIRMATION && it.source == DetectionSource.VIDEO }
        val pressedBrake = pressedEvidence?.detections?.get(CalibRole.BRAKE)?.takeIf { it.status == DetectionStatus.NEEDS_CONFIRMATION && it.source == DetectionSource.VIDEO }
        val pedals = bestPedals
        if (pedals != null) {
            val (brake, acc) = pedals.first
            val (s, ev) = pedals.second
            used += brake
            used += acc
            out[CalibRole.ACCELERATOR] = shape(CalibRole.ACCELERATOR, acc, s + supportBonus(acc, pressedAcc), ev + "proposed as the ACCELERATOR because it is the right-hand pedal" + supportNote(acc, pressedAcc))
            out[CalibRole.BRAKE] = shape(CalibRole.BRAKE, brake, s + supportBonus(brake, pressedBrake), ev + "proposed as the BRAKE because it is the left-hand pedal" + supportNote(brake, pressedBrake))
            notes += "Found a pedal pair: brake on the left, accelerator on the right."
        } else {
            val single = pedalLike.filter { it.cx > 0.5f }.maxByOrNull { pxH(it) }
            if (single != null) {
                used += single
                out[CalibRole.ACCELERATOR] = shape(
                    CalibRole.ACCELERATOR, single, 0.22f,
                    listOf("a single tall fixed element on the right; it may be the accelerator, but no second pedal was seen next to it", "WEAK candidate: check it carefully"),
                )
                notes += "Only one pedal-shaped element was found; the brake must be placed by hand."
            } else {
                out[CalibRole.ACCELERATOR] = none(CalibRole.ACCELERATOR, "no tall pedal-shaped element was found in the lower part of the screen")
                notes += "No pedal-shaped elements were found; place the accelerator and brake by hand."
            }
            out[CalibRole.BRAKE] = none(CalibRole.BRAKE, "no pair of pedals was found, so the brake cannot be told apart")
        }

        // ---- steering buttons: a mirror-image pair -------------------------------------------------------------------
        val buttonLike = els.filter { e -> e !in used && e.cy >= 0.45f && e.aspect in 0.55f..1.7f && side(e) in 0.08f..0.45f && e.areaFraction <= 0.05f }
        var bestPair: Triple<HudElement, HudElement, Pair<Float, List<String>>>? = null
        for (a in buttonLike) for (b in buttonLike) {
            if (a === b || a.cx >= b.cx) continue
            if (abs(a.cy - b.cy) > 0.06f) continue
            val rw = max(pxW(a), pxW(b)) / max(1f, min(pxW(a), pxW(b)))
            val rh = max(pxH(a), pxH(b)) / max(1f, min(pxH(a), pxH(b)))
            if (rw > 1.35f || rh > 1.35f) continue
            val gap = b.box.left - a.box.right
            if (gap > 2.5f * max(a.box.right - a.box.left, b.box.right - b.box.left)) continue
            val mirror = stats.ncc(a.box, b.box, mirrorSecond = true)
            val plain = stats.ncc(a.box, b.box, mirrorSecond = false)
            if (mirror < 0.45f) continue
            val ev = ArrayList<String>()
            var s = 0.20f + 0.30f * ((mirror - 0.45f) / 0.55f).coerceIn(0f, 1f)
            ev += "two equal-sized fixed elements on one line whose pictures are mirror images (mirror match ${pct(mirror)}%, plain match ${pct(plain)}%): a left/right pair"
            if (mirror > plain + 0.1f) {
                s += 0.06f
                ev += "they match better mirrored than as they are, as left and right arrows do"
            }
            if (b.cx < 0.5f) {
                s += 0.04f
                ev += "on the left side of the screen (a small extra weight only)"
            }
            if (bestPair == null || s > bestPair.third.first) bestPair = Triple(a, b, s to ev)
        }

        // ---- steering wheel: one large ring --------------------------------------------------------------------------
        val wheel = els
            .filter { e -> e !in used && e.ringness >= 0.85f && e.aspect in 0.8f..1.25f && side(e) >= 0.22f && e.cy >= 0.40f }
            .maxByOrNull { it.ringness * side(it) }
        val pair = bestPair
        val wheelScore = wheel?.let { 0.25f + 0.25f * ((it.ringness - 0.85f) / 0.15f).coerceIn(0f, 1f) + if (it.cx < 0.5f) 0.04f else 0f }
        if (pair != null && (wheelScore == null || pair.third.first >= wheelScore)) {
            used += pair.first
            used += pair.second
            val (s, ev) = pair.third
            out[CalibRole.STEER_LEFT] = shape(CalibRole.STEER_LEFT, pair.first, s, ev + "proposed as STEER LEFT because it is the left one of the pair")
            out[CalibRole.STEER_RIGHT] = shape(CalibRole.STEER_RIGHT, pair.second, s, ev + "proposed as STEER RIGHT because it is the right one of the pair")
            out[CalibRole.STEER_WHEEL] = none(CalibRole.STEER_WHEEL, "a pair of steering buttons was found instead of a wheel")
            notes += "Found two mirror-image buttons: steering left and right."
        } else if (wheel != null && wheelScore != null) {
            used += wheel
            out[CalibRole.STEER_WHEEL] = shape(
                CalibRole.STEER_WHEEL, wheel, wheelScore,
                listOf(
                    "a large fixed element whose outline lies on a circle (ring-ness ${pct(wheel.ringness)}%): the shape of a steering wheel",
                    "steering is then done by holding the wheel and dragging sideways; check the steering range afterwards",
                ),
            )
            out[CalibRole.STEER_LEFT] = none(CalibRole.STEER_LEFT, "a steering wheel was found instead of left/right buttons")
            out[CalibRole.STEER_RIGHT] = none(CalibRole.STEER_RIGHT, "a steering wheel was found instead of left/right buttons")
            notes += "Found a round steering wheel."
        } else {
            out[CalibRole.STEER_WHEEL] = none(CalibRole.STEER_WHEEL, "no large round element was found")
            out[CalibRole.STEER_LEFT] = none(CalibRole.STEER_LEFT, "no pair of mirror-image buttons was found")
            out[CalibRole.STEER_RIGHT] = none(CalibRole.STEER_RIGHT, "no pair of mirror-image buttons was found")
            notes += "No steering control was recognised; place the steering wheel or the left/right buttons by hand."
        }

        // ---- reverse: never guessed ----------------------------------------------------------------------------------
        out[CalibRole.GEAR_REVERSE] = none(
            CalibRole.GEAR_REVERSE,
            "a reverse button looks like any other small button in a picture, so it is not guessed; place it by hand (only needed for parking)",
        )

        // ---- minimap ---------------------------------------------------------------------------------------------------
        var bestMap: Triple<HudElement, Float, List<String>>? = null
        for (e in els) {
            if (e in used) continue
            if (e.areaFraction !in 0.012f..0.25f || e.aspect !in 0.6f..2.2f) continue
            val inner = shrink(e.box, 0.15f) ?: continue
            val dynamic = stats.meanStd(inner)
            val vivid = stats.vividShare(usable.last(), inner)
            val ev = ArrayList<String>()
            var s = 0.15f
            if (dynamic >= 8f) {
                s += 0.18f
                ev += "a framed element whose inside keeps changing (average change ${dynamic.toInt()} grey levels) while its frame stays put, as a scrolling map does"
            }
            if (vivid >= 0.004f) {
                s += 0.17f
                ev += "it contains a vivid colour (${(vivid * 1000).toInt() / 10f}% of its inside), as a route line does"
            }
            if (ev.isEmpty()) continue
            if ((e.cx < 0.35f || e.cx > 0.65f) && (e.cy < 0.35f || e.cy > 0.65f)) {
                s += 0.04f
                ev += "near a corner of the screen (a small extra weight only)"
            }
            if (bestMap == null || s > bestMap.second) bestMap = Triple(e, s, ev)
        }
        val minimap = bestMap?.let { (e, s, ev) ->
            val inner = shrink(e.box, 0.08f) ?: e.box
            MinimapSuggestion(
                e.box, CalibrationGuesses.routeColorGuess(usable.last(), inner),
                "Minimap candidate (${pct(min(s, ControlDetection.SHAPE_MAX_CONFIDENCE))}% evidence): " + ev.joinToString("; ") + ". Check the box covers the whole map.",
            )
        }
        notes += if (minimap != null) "Found a minimap candidate." else "No minimap was recognised; mark it by hand (the other steps do not depend on it)."
        return Result(out, minimap, notes)
    }

    val ROLES = listOf(CalibRole.ACCELERATOR, CalibRole.BRAKE, CalibRole.STEER_LEFT, CalibRole.STEER_RIGHT, CalibRole.STEER_WHEEL, CalibRole.GEAR_REVERSE)

    private fun shape(role: CalibRole, e: HudElement, score: Float, evidence: List<String>) = ControlDetection(
        role = role, x = e.cx, y = e.cy, box = e.box,
        confidence = score.coerceIn(0f, ControlDetection.SHAPE_MAX_CONFIDENCE),
        status = DetectionStatus.NEEDS_CONFIRMATION, source = DetectionSource.SHAPE,
        evidence = evidence + "found from the pictures only: please confirm it is the ${role.label.lowercase()}",
    )

    private fun none(role: CalibRole, why: String) = ControlDetection.none(role, why).copy(source = DetectionSource.SHAPE)

    private fun supportBonus(e: HudElement, d: ControlDetection?): Float {
        val b = d?.box ?: return 0f
        return if (iou(b, e.box) >= 0.5f) 0.10f else 0f
    }

    private fun supportNote(e: HudElement, d: ControlDetection?): List<String> {
        val b = d?.box ?: return emptyList()
        return if (iou(b, e.box) >= 0.5f) listOf("its look also changed together with the scenery speed (supporting evidence)") else emptyList()
    }

    private fun shrink(r: Roi, f: Float): Roi? {
        val dx = (r.right - r.left) * f
        val dy = (r.bottom - r.top) * f
        val l = r.left + dx
        val t = r.top + dy
        val rr = r.right - dx
        val b = r.bottom - dy
        return if (rr > l && b > t) Roi(l, t, rr, b) else null
    }

    internal fun iou(a: Roi, b: Roi): Float {
        val l = max(a.left, b.left)
        val t = max(a.top, b.top)
        val r = min(a.right, b.right)
        val bt = min(a.bottom, b.bottom)
        if (r <= l || bt <= t) return 0f
        val inter = (r - l) * (bt - t)
        val union = (a.right - a.left) * (a.bottom - a.top) + (b.right - b.left) * (b.bottom - b.top) - inter
        return if (union <= 0f) 0f else inter / union
    }

    private fun fmt2(v: Float) = String.format(java.util.Locale.ROOT, "%.2f", v)
    private fun pct(v: Float) = (v * 100).toInt()
}

/** Per-pixel temporal mean and standard deviation of a set of same-sized frames (grey levels). */
class TemporalStats private constructor(val width: Int, val height: Int, val mean: FloatArray, val std: FloatArray) {
    /** Mean of the temporal standard deviation inside [r]. High = the content there keeps changing. */
    fun meanStd(r: Roi): Float {
        val p = r.toRect(width, height)
        var s = 0.0
        var n = 0
        for (y in p.y0 until p.y1) for (x in p.x0 until p.x1) {
            s += std[y * width + x]
            n++
        }
        return if (n == 0) 0f else (s / n).toFloat()
    }

    /** Share of pixels inside [r] of [frame] that are a vivid (saturated, bright) colour. */
    fun vividShare(frame: Frame, r: Roi): Float {
        val p = r.toRect(frame.width, frame.height)
        var v = 0
        var n = 0
        for (y in p.y0 until p.y1) for (x in p.x0 until p.x1) {
            val c = frame.argb[y * frame.width + x]
            val rr = (c shr 16) and 0xFF
            val gg = (c shr 8) and 0xFF
            val bb = c and 0xFF
            val mx = max(rr, max(gg, bb))
            val mn = min(rr, min(gg, bb))
            if (mx >= 128 && (mx - mn).toFloat() / mx >= 0.5f) v++
            n++
        }
        return if (n == 0) 0f else v.toFloat() / n
    }

    /**
     * Normalised cross-correlation of the time-averaged pictures inside [a] and [b] (both resized to a common size);
     * with [mirrorSecond] the second picture is flipped left-right first. -1..1, 0 when either is flat.
     */
    fun ncc(a: Roi, b: Roi, mirrorSecond: Boolean): Float {
        val pa = patch(a) ?: return 0f
        val pb = patch(b) ?: return 0f
        val n = PATCH * PATCH
        var ma = 0.0
        var mb = 0.0
        for (i in 0 until n) {
            ma += pa.px[i]
            mb += pb.px[i]
        }
        ma /= n
        mb /= n
        var sab = 0.0
        var saa = 0.0
        var sbb = 0.0
        for (y in 0 until PATCH) for (x in 0 until PATCH) {
            val va = pa.px[y * PATCH + x] - ma
            val vb = pb.px[y * PATCH + (if (mirrorSecond) PATCH - 1 - x else x)] - mb
            sab += va * vb
            saa += va * va
            sbb += vb * vb
        }
        if (saa < 1e-6 || sbb < 1e-6) return 0f
        return (sab / sqrt(saa * sbb)).toFloat()
    }

    private fun patch(r: Roi): GrayImage? {
        val p = r.toRect(width, height)
        if (p.width < 3 || p.height < 3) return null
        val px = IntArray(p.width * p.height)
        for (y in 0 until p.height) for (x in 0 until p.width) px[y * p.width + x] = mean[(p.y0 + y) * width + p.x0 + x].toInt()
        return GrayImage(p.width, p.height, px).resize(PATCH, PATCH)
    }

    companion object {
        private const val PATCH = 24

        fun of(frames: List<Frame>): TemporalStats {
            val f0 = frames.first()
            val w = f0.width
            val h = f0.height
            val n = w * h
            val sum = DoubleArray(n)
            val sq = DoubleArray(n)
            var k = 0
            for (f in frames) {
                if (f.width != w || f.height != h) continue
                k++
                val g = f.toGray().px
                for (i in 0 until n) {
                    val v = g[i].toDouble()
                    sum[i] += v
                    sq[i] += v * v
                }
            }
            val mean = FloatArray(n)
            val std = FloatArray(n)
            for (i in 0 until n) {
                val m = sum[i] / k
                mean[i] = m.toFloat()
                std[i] = sqrt(max(0.0, sq[i] / k - m * m)).toFloat()
            }
            return TemporalStats(w, h, mean, std)
        }
    }
}
