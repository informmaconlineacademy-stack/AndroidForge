package dev.toe3autopilot.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.toe3autopilot.app.AutopilotRuntime
import dev.toe3autopilot.app.Brand
import dev.toe3autopilot.core.calibration.CalibRole
import dev.toe3autopilot.core.capture.LinkState
import dev.toe3autopilot.core.session.SessionStatus
import kotlinx.coroutines.CoroutineScope

/** Things the UI asks the Activity to do (they need an Activity context or result launchers). */
class Actions(
    val connectCapture: () -> Unit,
    val disconnectCapture: () -> Unit,
    val openAccessibilitySettings: () -> Unit,
    val openAppDetails: () -> Unit,
    /** Brings the game to the front. False if it could not be opened. */
    val launchGame: () -> Boolean,
    val installedLaunchables: () -> List<Pair<String, String>>,
    val requestNotifications: () -> Unit,
    val openNotificationSettings: () -> Unit,
    val openBatterySettings: () -> Unit,
    val pickScreenshots: () -> Unit,
    /** Android's Photo Picker for a gameplay video (no storage permission needed). */
    val pickVideo: () -> Unit,
    /** The system file browser for a video, for when the Photo Picker does not show it. */
    val browseVideo: () -> Unit,
    /** Saves profile [id] as a .zip the person chooses. */
    val exportProfile: (String) -> Unit,
    val importProfile: () -> Unit,
    /** Notifications may be shown (always true below Android 13 unless switched off in settings). */
    val notificationsAllowed: () -> Boolean,
    /** Android's share sheet for a piece of text (subject, text). */
    val shareText: (String, String) -> Unit,
)

/** The four main destinations. */
enum class Tab(val label: String, val glyph: Glyph) {
    DASHBOARD("Dashboard", Glyph.DASHBOARD),
    SETUP("Smart Setup", Glyph.SETUP),
    PROFILES("Profiles", Glyph.PROFILES),
    SETTINGS("Settings", Glyph.SETTINGS),
}

enum class SettingsPage(val title: String) {
    HOME("Settings"),
    PERMISSIONS("Permissions & connection"),
    CAPTURE("Game & screen capture"),
    TOUCH("Touch & coordinates"),
    SAFETY("Automation & safety"),
    DIAGNOSTICS("Diagnostics & logs"),
    RESET("Reset"),
    ABOUT("About"),
}

/** What the full-screen placement editor is doing. */
enum class EditorMode { CONTROL, MINIMAP_BOX, ROUTE_COLOR, TRUCK, DESTINATION, MARKER }

data class EditorRequest(val mode: EditorMode, val role: CalibRole? = null)

/** Navigation state shared by all screens. */
class Nav(
    private val tabState: androidx.compose.runtime.MutableIntState,
    private val pageState: androidx.compose.runtime.MutableIntState,
    private val stepState: androidx.compose.runtime.MutableIntState,
    private val editorState: androidx.compose.runtime.MutableState<EditorRequest?>,
) {
    var tab: Tab
        get() = Tab.entries[tabState.intValue.coerceIn(0, Tab.entries.size - 1)]
        set(v) {
            tabState.intValue = v.ordinal
        }
    var settingsPage: SettingsPage
        get() = SettingsPage.entries[pageState.intValue.coerceIn(0, SettingsPage.entries.size - 1)]
        set(v) {
            pageState.intValue = v.ordinal
        }

    /** 0-based index of the Smart Setup step on screen. */
    var setupStep: Int
        get() = stepState.intValue
        set(v) {
            stepState.intValue = v.coerceIn(0, 9)
        }
    var editor: EditorRequest?
        get() = editorState.value
        set(v) {
            editorState.value = v
        }

    fun open(tab: Tab, page: SettingsPage? = null) {
        this.tab = tab
        if (page != null) settingsPage = page
    }

    fun openSetup(step: Int) {
        tab = Tab.SETUP
        setupStep = step
    }
}

/** Everything a screen needs besides the state flows. */
class UiEnv(val actions: Actions, val nav: Nav, val snackbar: SnackbarHostState, val scope: CoroutineScope)

@Composable
fun AppRoot(rawActions: Actions) {
    val tab = rememberSaveable { mutableIntStateOf(0) }
    val page = rememberSaveable { mutableIntStateOf(0) }
    val step = rememberSaveable { mutableIntStateOf(0) }
    val editor = remember { mutableStateOf<EditorRequest?>(null) }
    val nav = remember { Nav(tab, page, step, editor) }
    val snackbar = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val options by AutopilotRuntime.options.collectAsStateWithLifecycle()
    var showDisclosure by rememberSaveable { mutableStateOf(false) }

    // Google Play requires an in-app disclosure with an explicit choice before the Accessibility service is switched on.
    val actions = remember(rawActions, options.accessibilityDisclosureAccepted) {
        if (options.accessibilityDisclosureAccepted) rawActions else Actions(
            rawActions.connectCapture, rawActions.disconnectCapture, { showDisclosure = true }, rawActions.openAppDetails,
            rawActions.launchGame, rawActions.installedLaunchables, rawActions.requestNotifications, rawActions.openNotificationSettings,
            rawActions.openBatterySettings, rawActions.pickScreenshots, rawActions.pickVideo, rawActions.browseVideo,
            rawActions.exportProfile, rawActions.importProfile, rawActions.notificationsAllowed, rawActions.shareText,
        )
    }
    val env = remember(actions) { UiEnv(actions, nav, snackbar, scope) }

    val notice by AutopilotRuntime.notice.collectAsStateWithLifecycle()
    LaunchedEffect(notice) {
        val n = notice ?: return@LaunchedEffect
        AutopilotRuntime.notice.value = null
        snackbar.showSnackbar(n)
    }

    BackHandler(enabled = nav.editor != null) { nav.editor = null }
    BackHandler(enabled = nav.editor == null && nav.tab == Tab.SETTINGS && nav.settingsPage != SettingsPage.HOME) { nav.settingsPage = SettingsPage.HOME }
    BackHandler(enabled = nav.editor == null && nav.tab != Tab.DASHBOARD && !(nav.tab == Tab.SETTINGS && nav.settingsPage != SettingsPage.HOME)) {
        nav.tab = Tab.DASHBOARD
    }

    Box(Modifier.fillMaxSize().background(Hp.Bg)) {
        Scaffold(
            containerColor = Hp.Bg,
            contentColor = Hp.Text,
            topBar = { TopBar(env) },
            bottomBar = {
                Column {
                    EmergencyBar()
                    BottomNav(nav)
                }
            },
            snackbarHost = { SnackbarHost(snackbar) },
        ) { padding ->
            Box(Modifier.padding(padding).fillMaxSize()) {
                when (nav.tab) {
                    Tab.DASHBOARD -> DashboardScreen(env)
                    Tab.SETUP -> SmartSetupScreen(env)
                    Tab.PROFILES -> ProfilesScreen(env)
                    Tab.SETTINGS -> SettingsScreen(env)
                }
            }
        }
        val req = nav.editor
        if (req != null) PlacementEditor(req, onClose = { nav.editor = null }, onSwitch = { nav.editor = it })
    }

    if (showDisclosure) {
        AccessibilityDisclosureDialog(
            onAccept = {
                showDisclosure = false
                AutopilotRuntime.updateOptions { it.copy(accessibilityDisclosureAccepted = true) }
                rawActions.openAccessibilitySettings()
            },
            onDecline = { showDisclosure = false },
        )
    }
}

@Composable
private fun TopBar(env: UiEnv) {
    val link by AutopilotRuntime.link.collectAsStateWithLifecycle()
    val access by AutopilotRuntime.accessibilityConnected.collectAsStateWithLifecycle()
    val settings by AutopilotRuntime.settings.collectAsStateWithLifecycle()
    val nav = env.nav
    val title = when (nav.tab) {
        Tab.SETTINGS -> nav.settingsPage.title
        else -> nav.tab.label
    }
    Row(
        Modifier
            .fillMaxWidth()
            .background(Hp.Bg)
            .windowInsetsPadding(WindowInsets.statusBars)
            .heightIn(min = 60.dp)
            .padding(horizontal = Sp.s),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(Sp.xs),
    ) {
        if (nav.tab == Tab.SETTINGS && nav.settingsPage != SettingsPage.HOME) {
            IconAction(Glyph.BACK, "Back to Settings", { nav.settingsPage = SettingsPage.HOME })
        } else {
            Box(Modifier.padding(start = Sp.s, end = Sp.xs)) { BrandMark(30.dp) }
        }
        Text(title, Modifier.weight(1f), style = MaterialTheme.typography.titleLarge, color = Hp.Text, maxLines = 1, overflow = TextOverflow.Ellipsis)
        val linkTone = when (link.state) {
            LinkState.CONNECTED -> if (link.receivingGame) Tone.GOOD else Tone.ACTIVE
            LinkState.WAITING_FOR_PERMISSION -> Tone.ATTENTION
            LinkState.FAILED -> Tone.BAD
            LinkState.NOT_CONNECTED -> Tone.NEUTRAL
        }
        Box(
            Modifier
                .clip(RoundedCornerShape(50))
                .clickable(role = Role.Button) { nav.open(Tab.SETTINGS, SettingsPage.PERMISSIONS) }
                .semantics { contentDescription = "Screen: ${link.state.label}. Touch control: ${if (access) "on" else "off"}. Opens connection settings." },
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(Sp.xs), modifier = Modifier.padding(end = Sp.s)) {
                StatusPill(
                    when (link.state) {
                        LinkState.CONNECTED -> if (link.receivingGame) "Live" else "Connected"
                        LinkState.WAITING_FOR_PERMISSION -> "Waiting"
                        LinkState.FAILED -> "Capture failed"
                        LinkState.NOT_CONNECTED -> "Offline"
                    },
                    linkTone,
                )
                if (!access && !settings.assistedMode) StatusPill("Touch off", Tone.ATTENTION)
            }
        }
    }
}

/** Always visible on every screen (the editor included) while automation is live or arming: one tap stops everything. */
@Composable
fun EmergencyBar() {
    val snap by AutopilotRuntime.snapshot.collectAsStateWithLifecycle()
    val armed by AutopilotRuntime.armedMessage.collectAsStateWithLifecycle()
    val live = snap.status.isActiveLoop || snap.status == SessionStatus.PAUSED || snap.status == SessionStatus.NEEDS_ASSIST || armed != null
    if (!live) return
    Row(
        Modifier
            .fillMaxWidth()
            .background(Hp.DangerFill)
            .clickable(role = Role.Button) { AutopilotRuntime.emergencyStop("Emergency stop pressed in the app") }
            .heightIn(min = 56.dp)
            .padding(horizontal = Sp.l)
            .semantics(mergeDescendants = true) {
                contentDescription = "Emergency stop. Releases every automated touch now."
                liveRegion = LiveRegionMode.Polite
            },
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(Sp.m),
    ) {
        HpIcon(Glyph.STOP, tint = androidx.compose.ui.graphics.Color.White, size = 22.dp)
        Column(Modifier.weight(1f)) {
            Text("EMERGENCY STOP", style = MaterialTheme.typography.titleMedium, color = androidx.compose.ui.graphics.Color.White)
            Text(armed ?: snap.status.label, style = MaterialTheme.typography.bodySmall, color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.85f), maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
private fun BottomNav(nav: Nav) {
    val setup by AutopilotRuntime.setup.state.collectAsStateWithLifecycle()
    NavigationBar(containerColor = Hp.Surface, contentColor = Hp.Text, tonalElevation = 0.dp) {
        Tab.entries.forEach { t ->
            val selected = nav.tab == t
            NavigationBarItem(
                selected = selected,
                onClick = {
                    if (t == Tab.SETTINGS && nav.tab == Tab.SETTINGS) nav.settingsPage = SettingsPage.HOME
                    nav.tab = t
                },
                icon = {
                    Box {
                        HpIcon(t.glyph, tint = if (selected) Hp.Primary else Hp.TextSecondary, size = 24.dp)
                        if (t == Tab.SETUP && (setup.phase.busy || setup.draft.pendingCandidates.isNotEmpty())) {
                            Box(Modifier.align(Alignment.TopEnd).size(8.dp).clip(RoundedCornerShape(50)).background(Hp.Accent))
                        }
                    }
                },
                label = { Text(t.label, style = MaterialTheme.typography.labelMedium, maxLines = 1) },
                alwaysShowLabel = true,
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Hp.Primary,
                    selectedTextColor = Hp.Text,
                    indicatorColor = Hp.Primary.copy(alpha = 0.14f),
                    unselectedIconColor = Hp.TextSecondary,
                    unselectedTextColor = Hp.TextMuted,
                ),
            )
        }
    }
}

/** HaulPilot's mark: a rounded tile with the road-and-chevron sign (same drawing as the floating button). */
@Composable
fun BrandMark(size: androidx.compose.ui.unit.Dp) {
    androidx.compose.foundation.Canvas(Modifier.size(size)) {
        val r = this.size.minDimension
        drawRoundRect(Hp.Raised, cornerRadius = androidx.compose.ui.geometry.CornerRadius(r * 0.28f, r * 0.28f))
        val s = r * 0.26f
        val cx = r / 2f
        val cy = r / 2f
        val w = r * 0.07f
        drawLine(Hp.Text, androidx.compose.ui.geometry.Offset(cx - s, cy + s * 0.9f), androidx.compose.ui.geometry.Offset(cx - s * 0.28f, cy - s * 0.9f), w, androidx.compose.ui.graphics.StrokeCap.Round)
        drawLine(Hp.Text, androidx.compose.ui.geometry.Offset(cx + s, cy + s * 0.9f), androidx.compose.ui.geometry.Offset(cx + s * 0.28f, cy - s * 0.9f), w, androidx.compose.ui.graphics.StrokeCap.Round)
        drawLine(Hp.Primary, androidx.compose.ui.geometry.Offset(cx - s * 0.42f, cy + s * 0.35f), androidx.compose.ui.geometry.Offset(cx, cy - s * 0.15f), w * 1.2f, androidx.compose.ui.graphics.StrokeCap.Round)
        drawLine(Hp.Primary, androidx.compose.ui.geometry.Offset(cx, cy - s * 0.15f), androidx.compose.ui.geometry.Offset(cx + s * 0.42f, cy + s * 0.35f), w * 1.2f, androidx.compose.ui.graphics.StrokeCap.Round)
    }
}

/**
 * In-app disclosure shown before the accessibility settings are opened, as Google Play requires for apps that use the
 * Accessibility API without being an accessibility tool: what it accesses, what for, what it does not do, and a choice.
 */
@Composable
fun AccessibilityDisclosureDialog(onAccept: () -> Unit, onDecline: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDecline,
        containerColor = Hp.Surface,
        title = { Text("Use of the Accessibility service", color = Hp.Text) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(Sp.s)) {
                BodyText("${Brand.APP_NAME} uses Android's Accessibility service to:", color = Hp.Text)
                BodyText(
                    "• press the on-screen driving controls you confirmed (accelerator, brake, steering, reverse) while Auto Drive runs;\n" +
                        "• know which app is in front (package name only), so it only acts while the game is showing;\n" +
                        "• show the small floating control button over the game.",
                )
                BodyText("It does not:", color = Hp.Text)
                BodyText(
                    "• read the text or content of other apps;\n" +
                        "• record your touches, keystrokes or passwords;\n" +
                        "• send any data off your phone (the app has no internet permission).",
                )
                BodyText("You can switch it off at any time in Android's Accessibility settings. Without it, Assisted mode still shows what to do but sends no touches.")
            }
        },
        confirmButton = { HpButton("I agree, open settings", onAccept) },
        dismissButton = { HpButton("Not now", onDecline, kind = BtnKind.GHOST) },
    )
}
