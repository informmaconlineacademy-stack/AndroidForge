package dev.toe3autopilot.core.status

import dev.toe3autopilot.core.session.SessionSnapshot
import dev.toe3autopilot.core.session.SessionStatus

/** One thing that must be true before Start Auto Drive may be offered. */
enum class PrereqKey(val title: String) {
    PROFILE("An active calibration profile"),
    SETUP_COMPLETE("Controls, driving screen and minimap set up"),
    TOUCH("Touch control on (or Assisted mode)"),
    GAME("The game is selected"),
    CAPTURE("Screen capture connected"),
    SETUP_IDLE("Smart Setup is not collecting or analysing"),
}

/** What the person can do about an unmet prerequisite; the UI maps each to a real action. */
enum class PrereqAction { NONE, OPEN_PROFILES, OPEN_SETUP, ENABLE_ACCESSIBILITY, CHOOSE_GAME, CONNECT_CAPTURE }

data class Prereq(val key: PrereqKey, val ok: Boolean, val detail: String, val action: PrereqAction, val actionLabel: String?)

enum class ReadinessTone { GOOD, ATTENTION, BAD, ACTIVE, NEUTRAL }

data class ReadinessInputs(
    val snapshot: SessionSnapshot,
    /** Countdown or "switching to the game" before the session proper starts. */
    val armed: Boolean,
    val profileCount: Int,
    val activeProfileName: String?,
    /** What prevents a drive with the active profile (from ProfileReadiness; empty = complete). */
    val profileProblems: List<String>,
    val accessibilityOn: Boolean,
    val assistedMode: Boolean,
    val gamePackage: String,
    val captureOn: Boolean,
    val setupBusy: Boolean,
)

data class DriveReadinessView(
    val items: List<Prereq>,
    /** Start Auto Drive may be offered (every prerequisite met, nothing running). */
    val canStart: Boolean,
    val canResume: Boolean,
    /** A drive is running, arming, paused or waiting for help: show Emergency Stop. */
    val live: Boolean,
    val headline: String,
    val detail: String,
    val tone: ReadinessTone,
) {
    val unmet: List<Prereq> get() = items.filter { !it.ok }
}

/**
 * The Dashboard's verdict. "Ready" is only ever said when EVERY prerequisite holds; a connected screen alone is never
 * enough (the root cause of the old "Ready" status that appeared as soon as capture started). Pure, unit-tested.
 */
object DriveReadiness {
    fun of(i: ReadinessInputs): DriveReadinessView {
        val items = ArrayList<Prereq>()
        val hasProfile = i.activeProfileName != null
        items += Prereq(
            PrereqKey.PROFILE, hasProfile,
            when {
                hasProfile -> "\"${i.activeProfileName}\" is active."
                i.profileCount > 0 -> "No profile is active, or the active one cannot be read. Choose one in Profiles."
                else -> "Create one with Smart Setup."
            },
            if (hasProfile) PrereqAction.NONE else if (i.profileCount > 0) PrereqAction.OPEN_PROFILES else PrereqAction.OPEN_SETUP,
            if (hasProfile) null else if (i.profileCount > 0) "Open Profiles" else "Start Smart Setup",
        )
        val complete = hasProfile && i.profileProblems.isEmpty()
        items += Prereq(
            PrereqKey.SETUP_COMPLETE, complete,
            when {
                !hasProfile -> "Needs a profile first."
                complete -> "Everything automatic driving needs is confirmed."
                else -> i.profileProblems.take(2).joinToString("; ") + (if (i.profileProblems.size > 2) "; and ${i.profileProblems.size - 2} more." else ".")
            },
            if (complete) PrereqAction.NONE else PrereqAction.OPEN_SETUP, if (complete) null else "Finish Smart Setup",
        )
        val touch = i.accessibilityOn || i.assistedMode
        items += Prereq(
            PrereqKey.TOUCH, touch,
            when {
                i.assistedMode -> "Assisted mode: HaulPilot only shows what to do and sends no touches."
                i.accessibilityOn -> "The accessibility service is on and can press the confirmed controls."
                else -> "Turn on the HaulPilot accessibility service, or switch on Assisted mode in Settings."
            },
            if (touch) PrereqAction.NONE else PrereqAction.ENABLE_ACCESSIBILITY, if (touch) null else "Turn on",
        )
        val game = i.gamePackage.isNotBlank()
        items += Prereq(
            PrereqKey.GAME, game, if (game) i.gamePackage else "Choose the game in Settings → Game & screen capture.",
            if (game) PrereqAction.NONE else PrereqAction.CHOOSE_GAME, if (game) null else "Choose the game",
        )
        items += Prereq(
            PrereqKey.CAPTURE, i.captureOn,
            if (i.captureOn) "HaulPilot can see the screen." else "Android asks for permission to share the screen; choose \"Entire screen\".",
            if (i.captureOn) PrereqAction.NONE else PrereqAction.CONNECT_CAPTURE, if (i.captureOn) null else "Connect screen",
        )
        items += Prereq(
            PrereqKey.SETUP_IDLE, !i.setupBusy,
            if (i.setupBusy) "Finish or cancel the picture collection / analysis first." else "Nothing else is using the screen pictures.",
            if (i.setupBusy) PrereqAction.OPEN_SETUP else PrereqAction.NONE, if (i.setupBusy) "Open Smart Setup" else null,
        )

        val status = i.snapshot.status
        val live = i.armed || status.isActiveLoop || status == SessionStatus.PAUSED || status == SessionStatus.NEEDS_ASSIST
        val allOk = items.all { it.ok }
        val canResume = (status == SessionStatus.PAUSED || status == SessionStatus.NEEDS_ASSIST) && !i.armed && allOk
        val unmet = items.count { !it.ok }
        val (headline, tone) = when {
            i.armed -> "Starting" to ReadinessTone.ACTIVE
            status == SessionStatus.STARTING -> "Starting" to ReadinessTone.ACTIVE
            status == SessionStatus.RUNNING -> "Driving" to ReadinessTone.ACTIVE
            status == SessionStatus.PAUSED -> "Paused" to ReadinessTone.ATTENTION
            status == SessionStatus.NEEDS_ASSIST -> "Needs your help" to ReadinessTone.ATTENTION
            status == SessionStatus.EMERGENCY_STOPPED && !allOk -> "Stopped" to ReadinessTone.BAD
            status == SessionStatus.ERROR && !allOk -> "Stopped with an error" to ReadinessTone.BAD
            i.setupBusy -> "Setting up" to ReadinessTone.ACTIVE
            allOk -> "Ready to drive" to ReadinessTone.GOOD
            !hasProfile -> "Setup needed" to ReadinessTone.NEUTRAL
            else -> "Not ready" to ReadinessTone.ATTENTION
        }
        val detail = when {
            live -> i.snapshot.lastError ?: i.snapshot.task
            allOk -> "All ${items.size} checks passed. Start Auto Drive switches to the game and counts down first."
            else -> "$unmet of ${items.size} checks still open."
        }
        return DriveReadinessView(items, allOk && !live, canResume, live, headline, detail, tone)
    }
}
