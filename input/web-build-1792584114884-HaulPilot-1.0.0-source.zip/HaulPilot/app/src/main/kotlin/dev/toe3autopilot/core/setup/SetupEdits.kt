package dev.toe3autopilot.core.setup

import dev.toe3autopilot.core.Point
import dev.toe3autopilot.core.calibration.CalibRole
import dev.toe3autopilot.core.calibration.ControlCandidateDetector
import dev.toe3autopilot.core.calibration.ControlDetection
import dev.toe3autopilot.core.calibration.DetectionSource
import dev.toe3autopilot.core.calibration.DetectionStatus
import dev.toe3autopilot.core.calibration.GuidedSetup
import dev.toe3autopilot.core.calibration.HudAnalyzer
import dev.toe3autopilot.core.calibration.LayoutSignature
import dev.toe3autopilot.core.calibration.TemporalStats
import dev.toe3autopilot.core.calibration.VideoCalibrationAnalyzer
import dev.toe3autopilot.core.calibration.VideoInfo
import dev.toe3autopilot.core.calibration.VideoValidator
import dev.toe3autopilot.core.profile.SteeringMode
import dev.toe3autopilot.core.vision.ColorTarget
import dev.toe3autopilot.core.vision.Frame
import dev.toe3autopilot.core.vision.Roi
import kotlin.math.max

/** Pure edits of a [SetupDraft]. Every function returns a new draft; nothing is changed in place. */
object DraftEdits {
    const val DEFAULT_STEER_RADIUS = 0.12f

    /** The person accepts a candidate. A wheel or a button decides the steering style. */
    fun confirm(d: SetupDraft, role: CalibRole): SetupDraft {
        val c = d.controls[role] ?: return d
        if (c.status == DetectionStatus.NONE) return d
        val confirmed = c.copy(status = DetectionStatus.CONFIRMED, evidence = c.evidence.filter { it != CONFIRMED_NOTE } + CONFIRMED_NOTE)
        return withSteeringFor(d.copy(controls = d.controls + (role to confirmed)), role)
    }

    fun reject(d: SetupDraft, role: CalibRole): SetupDraft {
        val c = d.controls[role] ?: return d
        return d.copy(controls = d.controls + (role to c.copy(status = DetectionStatus.REJECTED, evidence = c.evidence + "rejected by you")))
    }

    /** Back to "missing" for one control (the others are untouched). */
    fun reset(d: SetupDraft, role: CalibRole): SetupDraft = d.copy(controls = d.controls - role)

    /** The person put the control at ([x], [y]); with [box] its region too. Counts as their confirmation. */
    fun place(d: SetupDraft, role: CalibRole, x: Float, y: Float, box: Roi? = null): SetupDraft {
        val px = x.coerceIn(0f, 1f)
        val py = y.coerceIn(0f, 1f)
        val c = ControlDetection(role, px, py, box, 1f, DetectionStatus.CONFIRMED, DetectionSource.USER, listOf("placed by you"))
        return withSteeringFor(d.copy(controls = d.controls + (role to c)), role)
    }

    fun chooseSteering(d: SetupDraft, mode: SteeringMode): SetupDraft = d.copy(
        steering = mode,
        steerRadius = if (mode == SteeringMode.SLIDER) d.steerRadius ?: wheelRadius(d) else d.steerRadius,
    )

    fun setSteerRadius(d: SetupDraft, radius: Float): SetupDraft = d.copy(steerRadius = radius.coerceIn(0.02f, 0.4f))

    fun selectDrivingFrame(d: SetupDraft, entry: FrameEntry): SetupDraft {
        val sig = LayoutSignature(entry.frame.width, entry.frame.height)
        val changed = d.layout != null && kotlin.math.abs(d.layout.aspect - sig.aspect) / sig.aspect > 0.03f
        // A picture of a different shape (rotation, another screen) makes every placed position meaningless.
        val base = if (changed) SetupDraft.EMPTY else d
        return base.copy(layout = sig, drivingFrameId = entry.id, drivingConfirmed = true)
    }

    fun setMinimapBox(d: SetupDraft, box: Roi): SetupDraft =
        d.copy(minimap = d.minimap.copy(box = box, boxConfirmed = true, skipped = false))

    fun confirmMinimapBox(d: SetupDraft): SetupDraft =
        if (d.minimap.box == null) d else d.copy(minimap = d.minimap.copy(boxConfirmed = true, skipped = false))

    fun setRouteColor(d: SetupDraft, c: ColorTarget): SetupDraft = d.copy(minimap = d.minimap.copy(routeColor = c))

    /** Optional destination-marker colour (null removes it). */
    fun setDestinationColor(d: SetupDraft, c: ColorTarget?): SetupDraft = d.copy(minimap = d.minimap.copy(destinationColor = c))

    fun setTruck(d: SetupDraft, p: Point): SetupDraft = d.copy(minimap = d.minimap.copy(truck = Point(p.x.coerceIn(0f, 1f), p.y.coerceIn(0f, 1f))))

    fun skipMinimap(d: SetupDraft): SetupDraft = d.copy(minimap = d.minimap.copy(skipped = true))

    fun clearMinimap(d: SetupDraft): SetupDraft = d.copy(minimap = MinimapDraft())

    fun setMarker(d: SetupDraft, box: Roi): SetupDraft = d.copy(marker = box, markerSource = DetectionSource.USER)

    /**
     * Merges an analysis into the draft. What the person already decided wins: a confirmed or placed control is never
     * replaced, a rejected one stays rejected when the analysis proposes the same spot again, and a minimap box the
     * person confirmed is kept.
     */
    fun applyAnalysis(d: SetupDraft, r: AnalysisResult): SetupDraft {
        val controls = LinkedHashMap(d.controls)
        for ((role, det) in r.detections) {
            val old = controls[role]
            if (old != null && old.status.usable) continue
            if (old != null && old.status == DetectionStatus.REJECTED && old.box != null && det.box != null &&
                ControlCandidateDetector.iou(old.box, det.box) > 0.5f
            ) continue
            if (det.status == DetectionStatus.NONE) {
                if (old == null || old.status == DetectionStatus.NEEDS_CONFIRMATION) controls[role] = det
            } else {
                controls[role] = det
            }
        }
        val mm = d.minimap
        val minimap = if (mm.boxConfirmed || r.minimap == null) mm else mm.copy(
            box = r.minimap.box,
            boxConfirmed = false,
            routeColor = mm.routeColor ?: r.minimap.routeColorRgb?.let { ColorTarget((it shr 16) and 0xFF, (it shr 8) and 0xFF, it and 0xFF, 45) },
            truck = mm.truck ?: Point((r.minimap.box.left + r.minimap.box.right) / 2f, r.minimap.box.top + (r.minimap.box.bottom - r.minimap.box.top) * 0.75f),
            note = r.minimap.note,
        )
        val keepMarker = d.markerSource == DetectionSource.USER
        return d.copy(
            controls = controls,
            minimap = minimap,
            marker = if (keepMarker) d.marker else r.marker ?: d.marker,
            markerSource = if (keepMarker) d.markerSource else if (r.marker != null) DetectionSource.SHAPE else d.markerSource,
            analysed = true,
            analysisSkipped = false,
        )
    }

    private fun withSteeringFor(d: SetupDraft, role: CalibRole): SetupDraft = when (role) {
        CalibRole.STEER_WHEEL -> d.copy(steering = SteeringMode.SLIDER, steerRadius = d.steerRadius ?: wheelRadius(d))
        CalibRole.STEER_LEFT, CalibRole.STEER_RIGHT -> d.copy(steering = SteeringMode.BUTTONS)
        else -> d
    }

    /** Half the confirmed wheel's width (dragging from the centre to the rim), else a typical value. */
    private fun wheelRadius(d: SetupDraft): Float {
        val b = d.controls[CalibRole.STEER_WHEEL]?.box ?: return DEFAULT_STEER_RADIUS
        return max(0.03f, (b.right - b.left) / 2f).coerceAtMost(0.3f)
    }

    private const val CONFIRMED_NOTE = "confirmed by you"
}

/** The analysis behind step 4. Pure and deterministic; the host runs it on a background thread. */
object SetupAnalysis {
    /**
     * @param frames the collected pictures (only those with the selected picture's size are used)
     * @param selectedId the picture chosen as the driving screen (decides which size is analysed)
     * @param isCancelled checked between stages; when it returns true the analysis stops and returns null
     */
    fun run(frames: List<FrameEntry>, selectedId: Int?, isCancelled: () -> Boolean = { false }): AnalysisResult? {
        val selected = frames.firstOrNull { it.id == selectedId } ?: frames.lastOrNull() ?: return null
        val same = frames.filter { it.frame.width == selected.frame.width && it.frame.height == selected.frame.height }
        val pics = same.map { it.frame }
        val hud = HudAnalyzer.analyse(pics)
        if (isCancelled()) return null
        val pressed = if (hud.ok && pics.size >= HudAnalyzer.MIN_FRAMES) {
            val usable = VideoValidator.usableFrames(pics)
            VideoCalibrationAnalyzer.analyse(VideoInfo(max(VideoValidator.MIN_DURATION_MS, pics.size * 330L), selected.frame.width, selected.frame.height), usable.size, usable)
        } else null
        if (isCancelled()) return null
        val cand = ControlCandidateDetector.detect(hud, pics, pressed)
        if (isCancelled()) return null
        val visibility = HashMap<Int, Float>()
        var marker: Roi? = null
        if (hud.ok) {
            val stats = TemporalStats.of(pics)
            for (e in same) visibility[e.id] = hudVisibility(stats, e.frame, hud.elements.map { it.box })
            val avoid = cand.detections.values.mapNotNull { if (it.status == DetectionStatus.NONE) null else it.box } + listOfNotNull(cand.minimap?.box)
            marker = GuidedSetup.pickDrivingMarker(hud, avoid)?.box
        }
        val notes = ArrayList<String>()
        if (!hud.ok) {
            notes += hud.problem ?: "No fixed on-screen elements were found."
            notes += "You can still place every control by hand on the chosen picture."
        } else {
            notes += "${hud.elements.size} fixed on-screen elements were separated from the moving scenery in ${hud.framesUsed} pictures."
        }
        notes += cand.notes
        if (hud.ok) notes += if (marker != null) "A steady part of the dashboard was found to recognise the driving screen." else "No steady dashboard part was found to recognise the driving screen; a confirmed pedal will be used instead."
        return AnalysisResult(hud, cand.detections, cand.minimap, marker, visibility, notes)
    }

    /** Share of [boxes] whose picture in [frame] looks like the time-averaged picture (NCC >= 0.5). */
    fun hudVisibility(stats: TemporalStats, frame: Frame, boxes: List<Roi>): Float {
        if (boxes.isEmpty()) return 0f
        val g = frame.toGray()
        var visible = 0
        for (b in boxes) {
            val r = b.toRect(frame.width, frame.height)
            var sa = 0.0
            var sb = 0.0
            var n = 0
            for (y in r.y0 until r.y1) for (x in r.x0 until r.x1) {
                sa += g.px[y * frame.width + x]
                sb += stats.mean[y * frame.width + x]
                n++
            }
            if (n == 0) continue
            val ma = sa / n
            val mb = sb / n
            var sab = 0.0
            var saa = 0.0
            var sbb = 0.0
            for (y in r.y0 until r.y1) for (x in r.x0 until r.x1) {
                val va = g.px[y * frame.width + x] - ma
                val vb = stats.mean[y * frame.width + x] - mb
                sab += va * vb
                saa += va * va
                sbb += vb * vb
            }
            if (saa > 1e-6 && sbb > 1e-6 && sab / kotlin.math.sqrt(saa * sbb) >= 0.5) visible++
        }
        return visible.toFloat() / boxes.size
    }
}
