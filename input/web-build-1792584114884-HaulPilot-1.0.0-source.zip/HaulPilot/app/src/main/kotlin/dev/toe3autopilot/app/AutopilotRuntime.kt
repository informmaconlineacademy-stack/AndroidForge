package dev.toe3autopilot.app

import android.content.Context
import android.content.Intent
import android.hardware.display.DisplayManager
import android.util.DisplayMetrics
import android.view.Display
import dev.toe3autopilot.app.capture.SampleRecorder
import dev.toe3autopilot.app.capture.ScreenFrameSource
import dev.toe3autopilot.app.data.AndroidImageCodec
import dev.toe3autopilot.app.data.AppOptions
import dev.toe3autopilot.app.data.LogFile
import dev.toe3autopilot.app.data.OptionsStore
import dev.toe3autopilot.app.data.SessionHistoryStore
import dev.toe3autopilot.app.data.SettingsStore
import dev.toe3autopilot.app.data.SetupDraftStore
import dev.toe3autopilot.app.input.AccessibilityGameMonitor
import dev.toe3autopilot.app.input.AutopilotAccessibilityService
import dev.toe3autopilot.app.input.GestureInputController
import dev.toe3autopilot.app.setup.SetupController
import dev.toe3autopilot.core.AutomationSettings
import dev.toe3autopilot.core.WallClock
import dev.toe3autopilot.core.capture.CaptureDiagnosis
import dev.toe3autopilot.core.capture.CaptureFault
import dev.toe3autopilot.core.capture.CaptureHealthMonitor
import dev.toe3autopilot.core.capture.DiagnosisKind
import dev.toe3autopilot.core.capture.FrameContext
import dev.toe3autopilot.core.capture.FrameGate
import dev.toe3autopilot.core.capture.FrameOrigin
import dev.toe3autopilot.core.capture.LinkState
import dev.toe3autopilot.core.capture.LinkStatus
import dev.toe3autopilot.core.capture.ScreenLink
import dev.toe3autopilot.core.profile.GameProfile
import dev.toe3autopilot.core.profile.ProfileReadiness
import dev.toe3autopilot.core.profile.ProfileRepository
import dev.toe3autopilot.core.profile.ProfileSummary
import dev.toe3autopilot.core.session.AssistInputController
import dev.toe3autopilot.core.session.InputController
import dev.toe3autopilot.core.session.LogEntry
import dev.toe3autopilot.core.session.LogLevel
import dev.toe3autopilot.core.session.SessionLog
import dev.toe3autopilot.core.session.SessionManager
import dev.toe3autopilot.core.session.SessionRecord
import dev.toe3autopilot.core.session.SessionRecorder
import dev.toe3autopilot.core.session.SessionSnapshot
import dev.toe3autopilot.core.session.SessionStatus
import dev.toe3autopilot.core.session.StartResult
import dev.toe3autopilot.core.vision.Frame
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File

/**
 * Process-wide glue between the Android components (activity, capture service, accessibility service) and the
 * Android-free core. All state the UI shows is exposed as StateFlows; every flow is fed from one owner, so no screen keeps
 * a second, inconsistent copy of a status.
 */
object AutopilotRuntime {
    /** Long side of the processing frame in pixels. Smaller = less battery/CPU, but small icons get harder to match. */
    const val PROCESSING_LONG_SIDE = 480
    private const val GAME_VIEW_INTERVAL_MS = 500L

    private var initialised = false
    private lateinit var appContext: Context
    private lateinit var settingsStore: SettingsStore
    private lateinit var logFile: LogFile
    private lateinit var optionsStore: OptionsStore
    private lateinit var historyStore: SessionHistoryStore

    /** All calibration profiles (crash-safe store). The active one drives. */
    lateinit var profiles: ProfileRepository
        private set

    lateinit var recorder: SampleRecorder
        private set

    /** Smart Setup (the single source of truth for calibration). Created by [init]. */
    lateinit var setup: SetupController
        private set

    private val _options = MutableStateFlow(AppOptions())
    val options: StateFlow<AppOptions> = _options.asStateFlow()

    /** True while this app's own screen is visible. Frames taken then show this app, not the game, and are never analysed. */
    @Volatile
    var appVisible: Boolean = false

    /** Background scope for file and analysis work started from the UI. */
    val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    /** One-line result of the last action that has no screen of its own (export, import...), shown as a snackbar. */
    val notice = MutableStateFlow<String?>(null)

    /** Why screen capture last ended (system "stop sharing", screen lock, user), shown on the Dashboard. */
    val captureEndReason = MutableStateFlow<String?>(null)

    private val _settings = MutableStateFlow(AutomationSettings())
    val settings: StateFlow<AutomationSettings> = _settings.asStateFlow()

    private val _gamePackage = MutableStateFlow("")
    val gamePackage: StateFlow<String> = _gamePackage.asStateFlow()

    private val _profile = MutableStateFlow<GameProfile?>(null)

    /** The active profile, or null when there is none or it cannot be read. */
    val profile: StateFlow<GameProfile?> = _profile.asStateFlow()

    private val _profileList = MutableStateFlow<List<ProfileSummary>>(emptyList())
    val profileList: StateFlow<List<ProfileSummary>> = _profileList.asStateFlow()

    private val _readiness = MutableStateFlow<List<String>>(listOf("No calibration profile yet"))

    /** What prevents a drive with the active profile right now (empty = ready). */
    val readiness: StateFlow<List<String>> = _readiness.asStateFlow()

    private val _snapshot = MutableStateFlow(SessionSnapshot())
    val snapshot: StateFlow<SessionSnapshot> = _snapshot.asStateFlow()

    private val _logs = MutableStateFlow<List<LogEntry>>(emptyList())
    val logs: StateFlow<List<LogEntry>> = _logs.asStateFlow()

    private val _history = MutableStateFlow<List<SessionRecord>>(emptyList())

    /** Recent drives, newest last. */
    val history: StateFlow<List<SessionRecord>> = _history.asStateFlow()
    private val recorderOfSessions = SessionRecorder()

    /** True while a MediaProjection is active. */
    val captureActive = MutableStateFlow(false)

    /** True while the accessibility service is connected. */
    val accessibilityConnected = MutableStateFlow(false)

    /**
     * Explains whether capture is usable and, if not, why: permission, stopped projection, display / image-reader errors,
     * black or protected-looking game frames, or no frames at all. Updated about once a second while capture is connected.
     */
    val captureHealth = CaptureHealthMonitor(WallClock)

    private val _captureDiagnosis = MutableStateFlow(captureHealth.diagnose())
    val captureDiagnosis: StateFlow<CaptureDiagnosis> = _captureDiagnosis.asStateFlow()
    private var lastDiagnosisKind: DiagnosisKind? = null

    /** True while Android's screen-sharing permission dialog is open (set by the Activity). */
    val awaitingPermission = MutableStateFlow(false)

    @Volatile
    private var lastFrameAt = 0L

    @Volatile
    private var gameViewAt = 0L

    private val _gameView = MutableStateFlow<Frame?>(null)

    /** Latest picture of the game (never of HaulPilot or another app), at most twice a second, for previews and the test. */
    val gameView: StateFlow<Frame?> = _gameView.asStateFlow()

    private val _link = MutableStateFlow(ScreenLink.status(false, false, captureHealth.diagnose(), null, null, null))

    /** "Screen not connected" / "Waiting for permission" / "Screen connected" / "Capture failed", with the reason. */
    val link: StateFlow<LinkStatus> = _link.asStateFlow()

    val frameSource = ScreenFrameSource()

    private val log: SessionLog by lazy {
        SessionLog(sink = { entry ->
            _logs.value = log.entries()
            if (initialised) logFile.append(entry)
        })
    }

    @Volatile
    var session: SessionManager? = null
        private set

    private val gestureInput by lazy { GestureInputController() }
    private val assistInput by lazy { AssistInputController() }
    private val monitor by lazy { AccessibilityGameMonitor { _gamePackage.value } }

    // ---- start-up ---------------------------------------------------------------------------------------------------

    @Synchronized
    fun init(context: Context) {
        if (initialised) return
        appContext = context.applicationContext
        settingsStore = SettingsStore(appContext)
        logFile = LogFile(appContext)
        optionsStore = OptionsStore(appContext)
        historyStore = SessionHistoryStore(appContext)
        recorder = SampleRecorder(appContext)
        profiles = ProfileRepository(File(appContext.filesDir, "profiles"), AndroidImageCodec, WallClock)
        _settings.value = settingsStore.load()
        _options.value = optionsStore.load()
        _gamePackage.value = settingsStore.gamePackage()
        _history.value = historyStore.load()
        initialised = true
        // Repair an interrupted save, then bring over the single profile of older versions (left in place as a backup).
        try {
            profiles.recover().forEach { logWarn(it) }
            profiles.migrateLegacy(File(appContext.filesDir, "profile"))?.let { logInfo("Your earlier calibration was moved into the profile list ($it).") }
            profiles.purgeTrash()
        } catch (e: Exception) {
            logWarn("Profile storage check failed: ${e.javaClass.simpleName}: ${e.message}")
        }
        refreshProfiles()
        setup = SetupController(
            appContext = appContext,
            repo = profiles,
            draftStore = SetupDraftStore(appContext),
            scope = ioScope,
            log = { level, msg -> log.add(WallClock.nowMs(), level, msg) },
            gamePackage = { _gamePackage.value },
            settings = { _settings.value },
            latestGameFrame = { latestGameFrame() },
            onProfilesChanged = { refreshProfiles() },
        )
        detectInstalledGame()
    }

    /** Re-reads the profile list and the active profile (small files; safe on any thread). */
    fun refreshProfiles() {
        if (!initialised) return
        try {
            _profileList.value = profiles.list(_settings.value)
            _profile.value = profiles.active()
        } catch (e: Exception) {
            logWarn("Profiles could not be read: ${e.javaClass.simpleName}")
        }
        refreshReadiness()
    }

    private fun refreshReadiness() {
        val p = _profile.value
        _readiness.value = when {
            p == null && _profileList.value.isEmpty() -> listOf("No calibration profile yet")
            p == null -> listOf("The active profile cannot be read; choose or repair one in Profiles")
            else -> ProfileReadiness.problems(p, _settings.value, profiles)
        }
    }

    // ---- frames, link, diagnosis -------------------------------------------------------------------------------------

    /** Called by the capture service for every converted frame (capture thread). */
    fun onCapturedFrame(frame: Frame) {
        val origin = frameOrigin()
        val now = WallClock.nowMs()
        lastFrameAt = now
        captureHealth.onFrame(frame, FrameContext(ownAppInFront = appVisible, gameInFront = gameInFront()))
        if (FrameGate.analysable(origin)) {
            if (now - gameViewAt >= GAME_VIEW_INTERVAL_MS) {
                gameViewAt = now
                _gameView.value = frame
            }
            if (::setup.isInitialized) setup.onFrame(frame, origin)
        }
    }

    /** Newest picture of the game when it is fresh enough to stand for "now" (used by the safe test). */
    fun latestGameFrame(): Frame? {
        val f = _gameView.value ?: return null
        return if (WallClock.nowMs() - f.timestampMs <= 15_000L) f else null
    }

    fun foregroundPackage(): String? = AutopilotAccessibilityService.foregroundPackage

    fun frameOrigin(): FrameOrigin = FrameGate.classify(appVisible, isAccessibilityRunning(), foregroundPackage(), _gamePackage.value)

    fun setAwaitingPermission(v: Boolean) {
        awaitingPermission.value = v
        refreshLink()
    }

    /** Called by the capture service when a new projection starts: no picture has arrived yet. */
    fun noteCaptureStarted() {
        lastFrameAt = 0L
        awaitingPermission.value = false
        refreshLink()
    }

    fun refreshLink() {
        val on = captureActive.value
        val age = if (lastFrameAt == 0L) null else WallClock.nowMs() - lastFrameAt
        _link.value = ScreenLink.status(awaitingPermission.value, on, _captureDiagnosis.value, if (on) frameOrigin() else null, if (on) age else null, foregroundPackage())
    }

    /** From the capture loop about once a second: link facts for Smart Setup's collection. */
    fun pumpSetup() {
        if (!::setup.isInitialized) return
        val l = _link.value
        setup.onLink(captureActive.value, if (l.state == LinkState.FAILED) l.detail else null, if (captureActive.value) frameOrigin() else null)
    }

    /** Screen capture ended (any reason): a running collection stops at once with a reconnect option. */
    fun captureEnded(reason: String) {
        if (!::setup.isInitialized) return
        setup.onLink(false, "screen capture ended ($reason)", null)
    }

    fun setupBusy(): Boolean = ::setup.isInitialized && setup.state.value.phase.busy

    /** "This is the game": the app currently in front becomes the game. Null on success, otherwise why not. */
    fun adoptForegroundAsGame(): String? {
        val fg = foregroundPackage() ?: return "HaulPilot cannot see which app is in front. Turn on the accessibility service."
        if (!FrameGate.couldBeGame(fg, appContext.packageName)) return "The app in front ($fg) cannot be the game."
        setGamePackage(fg)
        logInfo("Game set to $fg from the floating button")
        refreshLink()
        return null
    }

    /** Starts collecting pictures for Smart Setup; from the floating button the app in front becomes the game if needed. */
    fun startSetupCapture(fromOverlay: Boolean): String? {
        if (session?.currentSnapshot()?.status?.isActiveLoop == true) return "Stop the drive before collecting pictures."
        var note: String? = null
        if (fromOverlay) {
            val fg = foregroundPackage()
            if (fg != null && fg != _gamePackage.value && FrameGate.couldBeGame(fg, appContext.packageName)) {
                setGamePackage(fg)
                note = "HaulPilot now treats the app in front ($fg) as the game."
                logInfo("Game set to $fg (collection started from the floating button while it was in front)")
            }
        }
        val err = setup.startCapture(keepPictures = false)
        return err ?: note
    }

    /** If the saved game package is not installed (it started as a guess), look for the installed game by its name. */
    private fun detectInstalledGame() {
        try {
            val pm = appContext.packageManager
            if (_gamePackage.value.isNotBlank() && pm.getLaunchIntentForPackage(_gamePackage.value) != null) return
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val apps = pm.queryIntentActivities(i, 0).map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
            val found = FrameGate.findInstalledGame(apps) ?: return
            setGamePackage(found)
            logInfo("Game found on this phone: $found")
        } catch (e: Exception) {
            logWarn("Could not look for the installed game: ${e.javaClass.simpleName}")
        }
    }

    /** Recomputes the diagnosis and writes a diagnostic log line whenever its kind changes. */
    fun refreshCaptureDiagnosis() {
        val d = captureHealth.diagnose()
        _captureDiagnosis.value = d
        refreshLink()
        if (d.kind != lastDiagnosisKind) {
            lastDiagnosisKind = d.kind
            if (initialised) log.add(WallClock.nowMs(), if (d.isProblem) LogLevel.WARN else LogLevel.INFO, "Capture: ${d.title}")
        }
    }

    /** A failure reported by the Android layer (not a guess from pictures). Shown on the Dashboard and in the log. */
    fun reportCaptureFault(fault: CaptureFault, note: String? = null) {
        captureHealth.onFault(fault, note)
        captureActive.value = false
        awaitingPermission.value = false
        if (initialised) log.add(WallClock.nowMs(), LogLevel.ERROR, "Capture fault: ${fault.title}${note?.let { " ($it)" } ?: ""}")
        refreshCaptureDiagnosis()
    }

    /** Plain-text diagnostic lines (states only, no pictures) for the diagnostics page. */
    fun captureDiagnosticLines(): List<String> = captureHealth.history()

    // ---- settings ---------------------------------------------------------------------------------------------------------

    fun updateSettings(transform: (AutomationSettings) -> AutomationSettings) {
        val s = transform(_settings.value).sanitized()
        _settings.value = s
        settingsStore.save(s)
        refreshReadiness()
    }

    fun updateOptions(transform: (AppOptions) -> AppOptions) {
        val o = transform(_options.value).sanitized()
        _options.value = o
        optionsStore.save(o)
    }

    fun setGamePackage(pkg: String) {
        _gamePackage.value = pkg.trim()
        settingsStore.saveGamePackage(pkg)
    }

    // ---- driving ----------------------------------------------------------------------------------------------------------

    /** Builds a fresh session for the current settings and starts it. The loop itself runs in ScreenCaptureService. */
    fun startSession(): StartResult {
        session?.let { if (it.currentSnapshot().status.isActiveLoop) return StartResult(false, listOf("A session is already running")) }
        if (setupBusy()) return StartResult(false, listOf("Smart Setup is collecting or analysing pictures; finish or cancel it first"))
        val s = _settings.value
        gestureInput.resetHealth()
        val input: InputController = if (s.assistedMode) assistInput else gestureInput
        lastAlertedStatus = null
        val mgr = SessionManager(
            frames = frameSource,
            monitor = monitor,
            input = input,
            profileProvider = { _profile.value },
            templateStore = profiles,
            settingsProvider = { _settings.value },
            clock = WallClock,
            log = log,
            listener = { snap -> onSnapshot(snap) },
        )
        session = mgr
        return mgr.start()
    }

    /** What Start Auto Drive is doing before the session proper begins (null = nothing). */
    val armedMessage = MutableStateFlow<String?>(null)
    private var armJob: Job? = null

    /** Things that make Start impossible, checked BEFORE the person is sent to the game. Empty = good to go. */
    fun prestartProblems(): List<String> {
        val p = ArrayList<String>()
        p += _readiness.value
        val s = _settings.value
        if (!s.assistedMode && !accessibilityConnected.value) p += "The accessibility service is not enabled (Settings → Permissions), or use Assisted mode"
        if (setupBusy()) p += "Smart Setup is collecting or analysing pictures"
        return p.distinct()
    }

    /**
     * Start Auto Drive. The person is in this app, the game is behind it, so: bring the game to the front, wait until it is
     * really in front and a fresh picture of it has arrived, count down three seconds (with vibration) and only then start the
     * session, which itself still verifies that the driving screen is recognised before any input is sent.
     * With [resume] it continues a paused / stopped-for-help session the same way. Requires screen capture to be connected
     * already. Returns the problems that prevent starting (empty = armed).
     */
    fun startDriving(launchGame: () -> Boolean, resume: Boolean = false): List<String> {
        val problems = prestartProblems()
        if (problems.isNotEmpty()) return problems
        if (!captureActive.value) return listOf("Screen capture is not connected")
        val status = session?.currentSnapshot()?.status
        if (resume) {
            if (status != SessionStatus.PAUSED && status != SessionStatus.NEEDS_ASSIST) return listOf("Nothing to resume")
        } else if (status?.isActiveLoop == true) {
            return listOf("A drive is already running")
        }
        cancelArmed()
        val front = gameInFront() == true
        if (!front && !launchGame()) return listOf("Could not open the game (check the game in Settings → Game)")
        armedMessage.value = if (front) "Getting ready…" else "Switching to the game…"
        armJob = ioScope.launch {
            try {
                var waited = 0L
                // Without the accessibility service the foreground app cannot be known; Assisted mode accepts that.
                while (!((gameInFront() == true || (gameInFront() == null && _settings.value.assistedMode)) && !appVisible)) {
                    delay(250)
                    waited += 250
                    if (waited > 15_000) return@launch armFailed("The game did not come to the front. Open it yourself, then use Start on the floating button’s panel.")
                }
                val t0 = System.currentTimeMillis()
                while (true) {
                    val f = frameSource.latest()
                    if (f != null && f.timestampMs > t0 + 300) break
                    delay(150)
                    if (System.currentTimeMillis() - t0 > 8_000) return@launch armFailed("No picture of the game arrived. Is screen sharing still on?")
                }
                for (n in 3 downTo 1) {
                    armedMessage.value = "Starting in $n… (press the red button to cancel)"
                    if (_options.value.vibrateCues) Notifier.buzz(appContext, 120)
                    delay(1000)
                }
                armedMessage.value = null
                val r = if (resume) resume() else startSession()
                if (!r.ok) armFailed("Cannot ${if (resume) "resume" else "start"}: ${r.problems.firstOrNull() ?: "unknown reason"}")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                armFailed("Could not start: ${e.javaClass.simpleName}")
            }
        }
        return emptyList()
    }

    private fun armFailed(message: String) {
        armedMessage.value = null
        log.add(WallClock.nowMs(), LogLevel.WARN, message)
        _snapshot.value = _snapshot.value.copy(lastError = message)
        Notifier.alert(appContext, _snapshot.value.copy(status = SessionStatus.NEEDS_ASSIST, lastError = message), _options.value.vibrateCues)
    }

    fun cancelArmed() {
        armJob?.cancel()
        armJob = null
        armedMessage.value = null
    }

    private var lastAlertedStatus: SessionStatus? = null

    /** Called by the session on every change. Records the drive and tells the person when it ends or needs them. */
    private fun onSnapshot(snap: SessionSnapshot) {
        _snapshot.value = snap
        val name = _profile.value?.name ?: ""
        recorderOfSessions.onSnapshot(snap, WallClock.nowMs(), name)?.let { rec ->
            ioScope.launch {
                try {
                    _history.value = historyStore.append(rec)
                } catch (_: Exception) {
                }
            }
        }
        val status = snap.status
        if (status == lastAlertedStatus) return
        lastAlertedStatus = status
        when (status) {
            SessionStatus.FINISHED, SessionStatus.NEEDS_ASSIST, SessionStatus.ERROR, SessionStatus.EMERGENCY_STOPPED ->
                if (initialised) Notifier.alert(appContext, snap, _options.value.vibrateCues)
            SessionStatus.STARTING -> if (initialised) Notifier.clear(appContext)
            else -> {}
        }
    }

    fun clearHistory() {
        historyStore.clear()
        _history.value = emptyList()
    }

    fun pause() {
        session?.pause()
    }

    /**
     * A session that has ended must not be ticked again after a new screen-capture grant (it would immediately ask the
     * service to release the capture). Called when capture is (re)connected.
     */
    fun discardEndedSession() {
        val s = session ?: return
        if (!s.currentSnapshot().status.isActiveLoop) {
            session = null
            _snapshot.value = SessionSnapshot()
        }
    }

    /** The screen turned off: pause the automation (never resumed automatically) and stop collecting pictures. */
    fun onScreenOff() {
        cancelArmed()
        session?.let { if (it.currentSnapshot().status.isActiveLoop) it.pause("Paused: the screen was turned off. Resume when you are back in the game.") }
        if (setupBusy()) setup.cancel()
        log.add(WallClock.nowMs(), LogLevel.INFO, "Screen turned off")
    }

    /** true = the game is in front, false = something else is, null = cannot tell (accessibility service not connected). */
    fun gameInFront(): Boolean? = monitor.isGameForeground()

    fun logInfo(message: String) {
        log.add(WallClock.nowMs(), LogLevel.INFO, message)
    }

    fun logWarn(message: String) {
        log.add(WallClock.nowMs(), LogLevel.WARN, message)
    }

    fun resume(): StartResult = session?.resume() ?: StartResult(false, listOf("No session"))

    fun stopSession() {
        cancelArmed()
        session?.stop()
    }

    /** Safe to call from any thread, including the overlay button and the notification action. */
    fun emergencyStop(reason: String) {
        cancelArmed()
        val s = session
        if (s != null) s.emergencyStop(reason) else gestureInput.releaseAll()
    }

    /** Records a problem with the input channel in the session log. */
    fun noteInputFailure(message: String) {
        log.add(WallClock.nowMs(), LogLevel.WARN, message)
    }

    /** The accessibility service disappeared; any touches it held were cancelled by the system. */
    fun onInputServiceGone() {
        gestureInput.onServiceGone()
    }

    fun clearLogs() {
        log.clear()
        logFile.clear()
        _logs.value = emptyList()
    }

    fun logTail(): String = logFile.readTail()

    /** Real display size in pixels (rotation-aware). Works from any Context, including the application context. */
    @Suppress("DEPRECATION")
    fun realDisplaySize(context: Context): Pair<Int, Int> {
        val dm = DisplayMetrics()
        context.getSystemService(DisplayManager::class.java).getDisplay(Display.DEFAULT_DISPLAY)?.getRealMetrics(dm)
        return dm.widthPixels to dm.heightPixels
    }

    fun isAccessibilityRunning(): Boolean = AutopilotAccessibilityService.instance != null
}
