package dev.toe3autopilot.core.setup

import dev.toe3autopilot.core.AutomationSettings
import dev.toe3autopilot.core.calibration.LayoutCheck
import dev.toe3autopilot.core.profile.GameProfile
import dev.toe3autopilot.core.profile.ProfileReadiness
import dev.toe3autopilot.core.profile.TemplateStore
import dev.toe3autopilot.core.state.GameState
import dev.toe3autopilot.core.state.StateDetector
import dev.toe3autopilot.core.vision.Frame
import dev.toe3autopilot.core.vision.ProfileVision
import dev.toe3autopilot.core.vision.RouteEstimator
import dev.toe3autopilot.core.vision.TemplateProvider

/**
 * Step 10: tests a saved profile against a live picture WITHOUT sending any touch. Each check is something the
 * automation itself relies on, measured the same way the automation measures it.
 */
object SetupVerifier {
    fun verify(profile: GameProfile, store: TemplateStore, frame: Frame?, nowMs: Long, settings: AutomationSettings = AutomationSettings()): SetupTestReport {
        val checks = ArrayList<TestCheck>()
        val readiness = ProfileReadiness.problems(profile, settings, store)
        checks += TestCheck(
            "Everything needed for driving is set up",
            readiness.isEmpty(),
            if (readiness.isEmpty()) "Accelerator, brake, steering, driving screen and minimap are all set." else readiness.joinToString("; "),
        )
        if (frame == null) {
            checks += TestCheck("A live picture of the game is available", false, "Connect the screen and show the game's driving view, then test again.")
            return SetupTestReport(checks, nowMs)
        }
        checks += TestCheck("A live picture of the game is available", true, "${frame.width}x${frame.height} picture, ${(nowMs - frame.timestampMs).coerceAtLeast(0) / 1000} s old.")
        val geometry = LayoutCheck.layoutProblem(profile, frame.width, frame.height)
        checks += TestCheck("The screen has the shape the profile was made for", geometry == null, geometry ?: "Matches.")
        if (geometry != null) return SetupTestReport(checks, nowMs)

        val provider = TemplateProvider(store, profile.referenceWidth)
        val detector = StateDetector(profile)
        val vision = ProfileVision(profile, provider, frame, { 0f }, profile.nav?.let { RouteEstimator(it) })
        detector.update(vision)
        val est = detector.update(vision) // the detector needs two agreeing looks
        val recognised = est.state.drivingLike && est.confidence >= MIN_CONFIDENCE
        checks += TestCheck(
            "The driving screen is recognised",
            recognised,
            if (recognised) "Recognised as ${est.state.label} (match ${(est.confidence * 100).toInt()}%)."
            else "Seen as \"${est.candidate.label}\" (match ${(est.confidence * 100).toInt()}%). Show the normal driving view, or mark a steadier dashboard part.",
        )
        val v = LayoutCheck.verifyControls(profile, frame.toGray(), provider, frame.width)
        checks += if (v.evaluated < 2) {
            TestCheck("The controls are where they were saved", true, "Fewer than two control pictures are stored; not checked.", required = false)
        } else {
            TestCheck("The controls are where they were saved", !v.stale, "${v.matched} of ${v.evaluated} controls found at their saved positions.")
        }
        val nav = profile.nav
        if (nav != null) {
            val r = RouteEstimator(nav).read(frame)
            checks += TestCheck(
                "The route line is visible on the minimap",
                r != null && r.confidence >= 0.2f,
                if (r == null) "No route-coloured pixels were found ahead of the truck. With an active job the route must be visible; otherwise this is expected."
                else "Route seen (evidence ${(r.confidence * 100).toInt()}%, offset ${"%+.2f".format(java.util.Locale.ROOT, r.offset)}).",
                required = false,
            )
        }
        return SetupTestReport(checks, nowMs)
    }

    /** Same threshold the session uses before it sends any input. */
    const val MIN_CONFIDENCE = 0.7f

    /** True when the picture would be classified as the driving view (used by the Test step's quick status). */
    fun recognisesDriving(profile: GameProfile, store: TemplateStore, frame: Frame): Boolean {
        val provider = TemplateProvider(store, profile.referenceWidth)
        val d = StateDetector(profile)
        val v = ProfileVision(profile, provider, frame, { 0f }, null)
        d.update(v)
        val e = d.update(v)
        return e.state == GameState.DRIVING && e.confidence >= MIN_CONFIDENCE
    }
}
