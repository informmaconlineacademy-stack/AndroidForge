package dev.toe3autopilot.core.setup

import dev.toe3autopilot.core.AutomationSettings
import dev.toe3autopilot.core.Control
import dev.toe3autopilot.core.Point
import dev.toe3autopilot.core.calibration.CalibRole
import dev.toe3autopilot.core.calibration.ControlDetection
import dev.toe3autopilot.core.calibration.DetectionSource
import dev.toe3autopilot.core.calibration.DetectionStatus
import dev.toe3autopilot.core.calibration.LayoutCheck
import dev.toe3autopilot.core.calibration.LayoutSignature
import dev.toe3autopilot.core.profile.GameProfile
import dev.toe3autopilot.core.profile.NavProfile
import dev.toe3autopilot.core.profile.ProfileEditing
import dev.toe3autopilot.core.profile.ProfileReadiness
import dev.toe3autopilot.core.profile.SteeringMode
import dev.toe3autopilot.core.profile.TemplateSpec
import dev.toe3autopilot.core.profile.TemplateStore
import dev.toe3autopilot.core.state.GameState
import dev.toe3autopilot.core.vision.Frame
import dev.toe3autopilot.core.vision.GrayImage
import dev.toe3autopilot.core.vision.Roi
import java.util.Locale
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Turns a [SetupDraft] into a [GameProfile] (and back, for editing). The safety rule lives here: ONLY controls whose
 * status is usable (confirmed or placed by the person) become controls the automation can press. Candidates, rejected and
 * missing controls are listed as skipped, never copied.
 */
object DraftApply {
    data class Result(
        val profile: GameProfile?,
        /** Template pictures to store with the profile, keyed by template name. */
        val patches: Map<String, GrayImage>,
        val applied: List<String>,
        val skipped: List<String>,
        val warnings: List<String>,
        /** What still prevents automatic driving (saving is allowed anyway; driving is not). */
        val notReadyToDrive: List<String>,
        val problem: String?,
        /** True when nothing of the base profile was kept (no base, or one made for another screen): old pictures can go. */
        val fresh: Boolean = true,
    ) {
        val ok: Boolean get() = profile != null && problem == null
    }

    const val MARKER = ProfileReadiness.HUD_MARKER

    /** Colour region the delivery detection looks for (see DeliveryAreaDetector). */
    const val DESTINATION = "destination_marker"
    const val SETUP_VERSION = "2"

    /**
     * @param base the profile being replaced or extended (null = a new profile)
     * @param picture the chosen driving-screen picture (its size must match the draft's layout)
     */
    fun apply(
        base: GameProfile?,
        draft: SetupDraft,
        picture: Frame?,
        name: String,
        gamePackage: String,
        nowMs: Long,
        store: TemplateStore? = null,
    ): Result {
        val issues = DraftValidator.validate(draft)
        issues.firstOrNull { it.severity == IssueSeverity.ERROR }?.let { return fail(it.message) }
        val layout = draft.layout ?: return fail("There is no picture to calibrate on.")
        if (picture == null) return fail("The chosen driving-screen picture is missing. Choose it again.")
        if (picture.width != layout.width || picture.height != layout.height) {
            return fail("The chosen picture (${picture.width}x${picture.height}) does not match the setup (${layout.width}x${layout.height}). Choose the driving screen again.")
        }
        val warnings = ArrayList<String>()
        warnings += issues.filter { it.severity == IssueSeverity.WARNING }.map { it.message }
        val compatible = base != null && compatible(base, layout)
        if (base != null && !compatible) {
            warnings += "The earlier settings of \"${base.name}\" were made for a different screen shape or size and were not carried over."
        }
        var p = if (compatible) base!!.copy(name = name) else GameProfile.EMPTY.copy(name = name, gamePackage = gamePackage)
        if (p.gamePackage.isBlank()) p = p.copy(gamePackage = gamePackage)
        p = p.copy(
            referenceWidth = layout.width,
            extras = p.extras + mapOf(
                LayoutCheck.HEIGHT_KEY to layout.height.toString(),
                "setup.version" to SETUP_VERSION,
                "meta.updatedMs" to nowMs.toString(),
            ),
        )
        val gray = picture.toGray()
        val patches = LinkedHashMap<String, GrayImage>()
        val applied = ArrayList<String>()
        val skipped = ArrayList<String>()

        for ((role, d) in draft.controls) {
            if (!d.status.usable) {
                if (d.status != DetectionStatus.NONE) skipped += "${role.label}: ${statusWord(d.status)} (not saved)"
                continue
            }
            if (role == CalibRole.STEER_WHEEL && draft.steering == SteeringMode.BUTTONS) {
                skipped += "${role.label}: steering uses buttons, so the wheel is not saved"
                continue
            }
            if ((role == CalibRole.STEER_LEFT || role == CalibRole.STEER_RIGHT) && draft.steering == SteeringMode.SLIDER) {
                skipped += "${role.label}: steering uses the wheel, so this button is not saved"
                continue
            }
            val pt = Point(d.x.coerceIn(0f, 1f), d.y.coerceIn(0f, 1f))
            val c = role.control
            p = if (c != null) p.copy(controls = p.controls + (c to pt))
            else p.copy(extras = p.extras + ("calib." + role.name.lowercase() to "${fmt(pt.x)},${fmt(pt.y)}"))
            applied += "${role.label} at (${fmt(pt.x)}, ${fmt(pt.y)})"
            val box = d.box ?: squareAround(pt, layout)
            cut(gray, box)?.let { img ->
                val name0 = LayoutCheck.patchName(role)
                patches[name0] = img
                p = p.copy(templates = p.templates + (name0 to TemplateSpec(name0, ProfileEditing.searchRoi(box, 0.06f), 0.7f)))
            }
        }

        when (draft.steering) {
            SteeringMode.SLIDER -> {
                val r = (draft.steerRadius ?: DraftEdits.DEFAULT_STEER_RADIUS).coerceIn(0.02f, 0.4f)
                p = p.copy(steeringMode = SteeringMode.SLIDER, steerRadius = r)
                applied += "Steering: wheel/slider, range ${(r * 100).toInt()}% of the screen width each side"
            }
            SteeringMode.BUTTONS -> {
                p = p.copy(steeringMode = SteeringMode.BUTTONS)
                applied += "Steering: left/right buttons"
            }
            null -> skipped += "Steering type not chosen"
        }

        // Driving-screen marker: a steady dashboard part, else the confirmed accelerator or brake (always visible while driving).
        val markerBox = draft.marker
            ?: draft.controls[CalibRole.ACCELERATOR]?.takeIf { it.status.usable }?.let { it.box ?: squareAround(Point(it.x, it.y), layout) }
            ?: draft.controls[CalibRole.BRAKE]?.takeIf { it.status.usable }?.let { it.box ?: squareAround(Point(it.x, it.y), layout) }
        if (markerBox != null) {
            val img = cut(gray, markerBox)
            if (img != null) {
                patches[MARKER] = img
                p = ProfileEditing.withTemplate(p, MARKER, ProfileEditing.searchRoi(markerBox), layout.width, 0.8f, layout.height)
                val rule = if (p.templates.containsKey("parking_hud")) "$MARKER, !parking_hud" else MARKER
                val (p2, err) = ProfileEditing.withStateRule(p, GameState.DRIVING, rule)
                if (err == null) {
                    p = p2
                    applied += when {
                        draft.marker != null && draft.markerSource == DetectionSource.USER -> "Driving screen: recognised by the part you marked"
                        draft.marker != null -> "Driving screen: recognised by a steady part of the dashboard"
                        else -> "Driving screen: recognised by the confirmed pedal (no steady dashboard part was available)"
                    }
                } else {
                    warnings += err
                }
            }
        } else if (p.stateRules[GameState.DRIVING].isNullOrEmpty()) {
            warnings += "The driving screen cannot be recognised yet: confirm the accelerator or mark a steady dashboard part."
        }

        val mm = draft.minimap
        if (mm.complete) {
            p = p.copy(
                nav = NavProfile(mm.box!!, mm.routeColor!!, mm.truck!!.x, mm.truck.y, p.nav?.lookahead ?: 0.6f),
                extras = p.extras + mapOf("setup.route" to "1", "setup.truck" to "1"),
            )
            applied += "Minimap, route colour and truck position"
            // The draft is authoritative for the whole minimap, the optional destination marker included.
            val dest = mm.destinationColor
            if (dest != null) {
                p = ProfileEditing.withColor(p, DESTINATION, mm.box, dest)
                applied += "Destination marker colour (the truck slows down near the destination and stops there)"
            } else if (p.colors.containsKey(DESTINATION)) {
                p = p.copy(colors = p.colors - DESTINATION)
                warnings += "The destination marker of the earlier version was removed because it is not set in this setup."
            }
        } else if (mm.skipped || mm.box == null) {
            if (p.nav == null) warnings += "No minimap is set up: automatic driving needs it (it follows the route line on the minimap)."
            else applied += "Minimap: kept from the earlier settings"
        } else {
            skipped += "Minimap: not finished (" + listOfNotNull(
                "box not confirmed".takeIf { !mm.boxConfirmed }, "route colour missing".takeIf { mm.routeColor == null }, "truck position missing".takeIf { mm.truck == null },
            ).joinToString() + ")"
        }

        val readinessStore = store?.let { s -> PatchedStore(s, patches) } ?: PatchedStore(null, patches)
        val notReady = ProfileReadiness.problems(p, AutomationSettings(), readinessStore)
        return Result(p, patches, applied, skipped, warnings, notReady, null, fresh = !compatible)
    }

    /** The setup of a saved profile, as a draft that can be edited (every saved control counts as confirmed). */
    fun fromProfile(p: GameProfile): SetupDraft {
        val controls = LinkedHashMap<CalibRole, ControlDetection>()
        for (role in CalibRole.entries) {
            val pt = LayoutCheck.locationOf(p, role) ?: continue
            if (role == CalibRole.SPEED_READOUT) continue
            if (role == CalibRole.STEER_WHEEL && p.steeringMode != SteeringMode.SLIDER) continue
            if ((role == CalibRole.STEER_LEFT || role == CalibRole.STEER_RIGHT) && p.steeringMode != SteeringMode.BUTTONS) continue
            controls[role] = ControlDetection(role, pt.x, pt.y, null, 1f, DetectionStatus.CONFIRMED, DetectionSource.USER, listOf("saved in profile \"${p.name}\""))
        }
        val nav = p.nav
        val layout = LayoutCheck.referenceSize(p)
        return SetupDraft(
            layout = layout,
            steering = if (controls.isEmpty()) null else p.steeringMode,
            steerRadius = p.steerRadius,
            controls = controls,
            minimap = if (nav != null) {
                MinimapDraft(nav.minimapRoi, true, nav.routeColor, Point(nav.truckX, nav.truckY), destinationColor = p.colors[DESTINATION]?.target)
            } else {
                MinimapDraft()
            },
        )
    }

    private fun compatible(base: GameProfile, layout: LayoutSignature): Boolean {
        val ref = LayoutCheck.referenceSize(base)
        if (ref != null && abs(ref.aspect - layout.aspect) / layout.aspect > LayoutCheck.ASPECT_TOLERANCE) return false
        if (base.referenceWidth != 0 && base.templates.isNotEmpty() && base.referenceWidth != layout.width) return false
        return true
    }

    private fun squareAround(p: Point, layout: LayoutSignature): Roi {
        val half = 0.05f * min(layout.width, layout.height)
        val hx = half / layout.width
        val hy = half / layout.height
        return Roi(max(0f, p.x - hx), max(0f, p.y - hy), min(1f, p.x + hx), min(1f, p.y + hy))
    }

    private fun cut(g: GrayImage, box: Roi): GrayImage? {
        val r = box.toRect(g.width, g.height)
        if (r.width < 4 || r.height < 4) return null
        return g.crop(r.x0, r.y0, r.x1, r.y1)
    }

    private fun statusWord(s: DetectionStatus) = when (s) {
        DetectionStatus.NEEDS_CONFIRMATION -> "not confirmed"
        DetectionStatus.REJECTED -> "rejected"
        else -> s.name.lowercase()
    }

    private fun fail(why: String) = Result(null, emptyMap(), emptyList(), emptyList(), emptyList(), emptyList(), why)

    private fun fmt(v: Float) = String.format(Locale.ROOT, "%.3f", v)

    /** Lets the readiness check see the template pictures that are about to be stored. */
    private class PatchedStore(val inner: TemplateStore?, val extra: Map<String, GrayImage>) : TemplateStore {
        override fun gray(name: String): GrayImage? = extra[name] ?: inner?.gray(name)
    }
}

/** Status of each of the ten steps, for the step list. Pure. */
object SetupSteps {
    /**
     * @param receivingGame live pictures of the game are arriving right now
     * @param tested the safe test has run since the last save
     */
    fun of(s: SetupState, receivingGame: Boolean): List<StepState> {
        val d = s.draft
        val haveFrames = s.frames.isNotEmpty()
        val imported = s.frames.any { it.origin != FrameOriginKind.LIVE }
        val sel = s.selectedFrame
        val out = ArrayList<StepState>()
        out += when {
            receivingGame -> StepState(SetupStep.CONNECT, StepStatus.DONE, "Receiving live pictures of the game.")
            imported && haveFrames -> StepState(SetupStep.CONNECT, StepStatus.SKIPPED, "Using imported pictures. Live driving still needs the screen connected.")
            else -> StepState(SetupStep.CONNECT, StepStatus.TODO, "Connect the screen while the game is open.")
        }
        out += when {
            s.phase == SetupPhase.CAPTURING -> StepState(SetupStep.CAPTURE, StepStatus.TODO, "${s.collected} of ${s.target} pictures…")
            s.phase == SetupPhase.FAILED && !haveFrames -> StepState(SetupStep.CAPTURE, StepStatus.ATTENTION, s.problem ?: "Capture stopped.")
            haveFrames -> StepState(SetupStep.CAPTURE, StepStatus.DONE, "${s.frames.size} picture(s) available.")
            else -> StepState(SetupStep.CAPTURE, if (receivingGame) StepStatus.TODO else StepStatus.BLOCKED, if (receivingGame) "Drive for about 15 seconds while HaulPilot collects pictures." else "Connect first, or import screenshots or a clip.")
        }
        out += when {
            !haveFrames -> StepState(SetupStep.SELECT_SCREEN, StepStatus.BLOCKED, "No pictures yet.")
            sel != null && d.drivingConfirmed -> StepState(SetupStep.SELECT_SCREEN, if (sel.evidence == ScreenEvidence.HUD_MISSING) StepStatus.ATTENTION else StepStatus.DONE, "Picture #${sel.id}: ${sel.evidence.label}.")
            else -> StepState(SetupStep.SELECT_SCREEN, StepStatus.TODO, "Pick the picture that shows the normal driving view.")
        }
        out += when {
            s.phase == SetupPhase.ANALYZING -> StepState(SetupStep.ANALYZE, StepStatus.TODO, "Analysing…")
            d.analysed -> StepState(SetupStep.ANALYZE, StepStatus.DONE, s.analysisNotes.firstOrNull() ?: "Analysed.")
            d.analysisSkipped -> StepState(SetupStep.ANALYZE, StepStatus.SKIPPED, "Skipped: controls are placed by hand.")
            s.phase == SetupPhase.FAILED && haveFrames -> StepState(SetupStep.ANALYZE, StepStatus.ATTENTION, s.problem ?: "The analysis stopped.")
            sel == null || !d.drivingConfirmed -> StepState(SetupStep.ANALYZE, StepStatus.BLOCKED, "Choose the driving screen first.")
            else -> StepState(SetupStep.ANALYZE, StepStatus.TODO, "Find candidate controls automatically, or skip and place them by hand.")
        }
        val pending = d.pendingCandidates
        out += when {
            !d.analysed -> StepState(SetupStep.REVIEW, if (d.analysisSkipped) StepStatus.SKIPPED else StepStatus.BLOCKED, if (d.analysisSkipped) "Nothing to review." else "Runs after the analysis.")
            pending.isNotEmpty() -> StepState(SetupStep.REVIEW, StepStatus.TODO, "${pending.size} candidate(s) to confirm or reject.")
            else -> StepState(SetupStep.REVIEW, StepStatus.DONE, "No candidates left to review.")
        }
        val missing = d.missingRequired
        out += when {
            sel == null && d.confirmedCount == 0 -> StepState(SetupStep.PLACE, StepStatus.BLOCKED, "Choose the driving screen first.")
            missing.isEmpty() -> StepState(SetupStep.PLACE, StepStatus.DONE, "Accelerator, brake and steering are confirmed.")
            else -> StepState(SetupStep.PLACE, StepStatus.TODO, "Still needed: ${missing.joinToString()}.")
        }
        val mm = d.minimap
        out += when {
            mm.complete -> StepState(SetupStep.MINIMAP, StepStatus.DONE, "Minimap, route colour and truck position set.")
            mm.skipped -> StepState(SetupStep.MINIMAP, StepStatus.SKIPPED, "Skipped. Automatic driving needs it; the other steps do not.")
            sel == null -> StepState(SetupStep.MINIMAP, StepStatus.BLOCKED, "Choose the driving screen first.")
            mm.box != null && !mm.boxConfirmed -> StepState(SetupStep.MINIMAP, StepStatus.TODO, "A minimap candidate was found: check the box.")
            else -> StepState(SetupStep.MINIMAP, StepStatus.TODO, "Mark the minimap, then tap the route line and your truck.")
        }
        val errors = s.issues.count { it.severity == IssueSeverity.ERROR }
        out += when {
            !s.validatedCurrent -> StepState(SetupStep.VALIDATE, if (d.confirmedCount > 0 || mm.complete) StepStatus.TODO else StepStatus.BLOCKED, if (d.confirmedCount > 0 || mm.complete) "Check the setup for mistakes." else "Confirm or place at least one control first.")
            errors > 0 -> StepState(SetupStep.VALIDATE, StepStatus.ATTENTION, "$errors problem(s) to fix.")
            else -> StepState(SetupStep.VALIDATE, StepStatus.DONE, if (s.issues.isEmpty()) "No problems found." else "${s.issues.size} warning(s), nothing blocking.")
        }
        out += when {
            s.phase == SetupPhase.CONFIRMED && !s.dirty -> StepState(SetupStep.SAVE, StepStatus.DONE, "Saved to \"${s.savedProfile}\".")
            s.canSave -> StepState(SetupStep.SAVE, StepStatus.TODO, "Ready to save.")
            else -> StepState(SetupStep.SAVE, StepStatus.BLOCKED, "Validate without errors first.")
        }
        val t = s.test
        out += when {
            s.phase != SetupPhase.CONFIRMED || s.dirty -> StepState(SetupStep.TEST, StepStatus.BLOCKED, "Save first.")
            t == null -> StepState(SetupStep.TEST, StepStatus.TODO, "Check recognition on a live picture. No touches are sent.")
            t.passed -> StepState(SetupStep.TEST, StepStatus.DONE, "All required checks passed.")
            else -> StepState(SetupStep.TEST, StepStatus.ATTENTION, "${t.checks.count { !it.ok && it.required }} required check(s) failed.")
        }
        return out
    }
}
