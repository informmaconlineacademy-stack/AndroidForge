package dev.toe3autopilot.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.toe3autopilot.BuildConfig
import dev.toe3autopilot.app.AutopilotRuntime
import dev.toe3autopilot.app.Brand
import dev.toe3autopilot.app.data.AppOptions
import dev.toe3autopilot.app.input.GestureInputController
import dev.toe3autopilot.core.AutomationSettings
import dev.toe3autopilot.core.Control
import dev.toe3autopilot.core.calibration.LayoutCheck
import dev.toe3autopilot.core.capture.LinkState
import dev.toe3autopilot.core.geometry.DisplaySpace
import dev.toe3autopilot.core.session.LogLevel
import dev.toe3autopilot.core.session.SessionStatus
import dev.toe3autopilot.core.setup.FrameOriginKind
import kotlin.math.abs
import kotlin.math.roundToInt

@Composable
fun SettingsScreen(env: UiEnv) {
    when (env.nav.settingsPage) {
        SettingsPage.HOME -> SettingsHome(env)
        SettingsPage.PERMISSIONS -> Page { PermissionsPage(env) }
        SettingsPage.CAPTURE -> Page { CapturePage(env) }
        SettingsPage.TOUCH -> Page { TouchPage(env) }
        SettingsPage.SAFETY -> Page { SafetyPage(env) }
        SettingsPage.DIAGNOSTICS -> Page { DiagnosticsPage(env) }
        SettingsPage.RESET -> Page { ResetPage(env) }
        SettingsPage.ABOUT -> Page { AboutPage() }
    }
}

@Composable
private fun Page(content: @Composable () -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = Sp.gutter, vertical = Sp.m),
        verticalArrangement = Arrangement.spacedBy(Sp.m),
    ) {
        content()
        Spacer(Modifier.height(Sp.l))
    }
}

/** Increases every time the app comes back to the front, so permission states are re-read after visiting Android settings. */
@Composable
fun rememberResumeTick(): Int {
    val owner = LocalLifecycleOwner.current
    var tick by remember { mutableIntStateOf(0) }
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    return tick
}

private fun liveDrive(): Boolean {
    val st = AutopilotRuntime.snapshot.value.status
    return st.isActiveLoop || st == SessionStatus.PAUSED || st == SessionStatus.NEEDS_ASSIST || AutopilotRuntime.armedMessage.value != null
}

// ---- home -------------------------------------------------------------------------------------------------------------

@Composable
private fun SettingsHome(env: UiEnv) {
    val access by AutopilotRuntime.accessibilityConnected.collectAsStateWithLifecycle()
    val captureOn by AutopilotRuntime.captureActive.collectAsStateWithLifecycle()
    val game by AutopilotRuntime.gamePackage.collectAsStateWithLifecycle()
    val settings by AutopilotRuntime.settings.collectAsStateWithLifecycle()
    val logs by AutopilotRuntime.logs.collectAsStateWithLifecycle()
    val nav = env.nav
    Page {
        HpCard(padding = androidx.compose.foundation.layout.PaddingValues(Sp.xs)) {
            NavRow(Glyph.SHIELD, "Permissions & connection", "Screen ${if (captureOn) "connected" else "not connected"} · touch control ${if (access) "on" else "off"}", { nav.settingsPage = SettingsPage.PERMISSIONS })
            NavRow(Glyph.CAMERA, "Game & screen capture", game.ifBlank { "No game chosen" }, { nav.settingsPage = SettingsPage.CAPTURE })
            NavRow(Glyph.TOUCH, "Touch & coordinates", if (settings.assistedMode) "Assisted mode: no touches are sent" else "Where touches go on this screen", { nav.settingsPage = SettingsPage.TOUCH })
            NavRow(Glyph.STOP, "Automation & safety", "Speed, steering and watchdog timeouts", { nav.settingsPage = SettingsPage.SAFETY })
            NavRow(Glyph.LOG, "Diagnostics & logs", "${logs.size} log line(s), drive history, sample recording", { nav.settingsPage = SettingsPage.DIAGNOSTICS })
            NavRow(Glyph.REFRESH, "Reset", "Start setup over, restore defaults. Profiles are kept.", { nav.settingsPage = SettingsPage.RESET })
            NavRow(Glyph.INFO, "About", "${Brand.APP_NAME} ${BuildConfig.VERSION_NAME}", { nav.settingsPage = SettingsPage.ABOUT })
        }
    }
}

// ---- permissions ---------------------------------------------------------------------------------------------------------

@Composable
private fun PermissionsPage(env: UiEnv) {
    val tick = rememberResumeTick()
    val access by AutopilotRuntime.accessibilityConnected.collectAsStateWithLifecycle()
    val link by AutopilotRuntime.link.collectAsStateWithLifecycle()
    val captureOn by AutopilotRuntime.captureActive.collectAsStateWithLifecycle()
    val notifications = remember(tick) { env.actions.notificationsAllowed() }
    BodyText("Each permission is asked for only when the feature that needs it is used. Here is what each one does and its state right now.")
    HpCard {
        SectionHeader("Screen capture", subtitle = "Lets HaulPilot see the game", trailing = {
            StatusPill(link.state.label, if (captureOn) Tone.GOOD else if (link.state == LinkState.FAILED) Tone.BAD else Tone.NEUTRAL)
        })
        BodyText(link.detail)
        SmallText("Granted for one sharing session at a time through Android's own dialog; Android shows it is on and you can stop it from the notification or the status bar.")
        if (captureOn) {
            HpButton("Stop screen capture", { if (liveDrive()) env.toast("Stop the drive first.") else env.actions.disconnectCapture() }, kind = BtnKind.SECONDARY)
        } else {
            HpButton("Connect screen", { env.actions.connectCapture() }, glyph = Glyph.LINK)
        }
    }
    HpCard {
        SectionHeader("Accessibility service", subtitle = "Presses the controls you confirmed; shows the floating button", trailing = {
            StatusPill(if (access) "On" else "Off", if (access) Tone.GOOD else Tone.ATTENTION)
        })
        BodyText("It only acts while Auto Drive runs, only on the controls you confirmed, and it cannot read the content of other apps.")
        HpButton(if (access) "Accessibility settings" else "Turn on", { env.actions.openAccessibilitySettings() }, kind = if (access) BtnKind.SECONDARY else BtnKind.PRIMARY)
        if (!access) SmallText("On some phones Android first asks you to allow \"restricted settings\" for HaulPilot in App info (⋮ menu) because it was not installed from a store.")
        HpButton("Open App info", { env.actions.openAppDetails() }, kind = BtnKind.GHOST)
    }
    HpCard {
        SectionHeader("Notifications", subtitle = "The capture notification with its Emergency Stop action, and alerts when a drive stops", trailing = {
            StatusPill(if (notifications) "Allowed" else "Blocked", if (notifications) Tone.GOOD else Tone.ATTENTION)
        })
        if (!notifications) {
            BodyText("Without them you are not told when a drive stops while the game is in front, and the notification's Emergency Stop is hidden. The floating button still works.")
            Row(horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
                HpButton("Allow", { env.actions.requestNotifications() }, kind = BtnKind.SECONDARY)
                HpButton("Notification settings", { env.actions.openNotificationSettings() }, kind = BtnKind.GHOST)
            }
        } else {
            HpButton("Notification settings", { env.actions.openNotificationSettings() }, kind = BtnKind.GHOST)
        }
    }
    HpCard {
        SectionHeader("Battery", subtitle = "Keeps screen capture running while the game is in front")
        BodyText("Some phones stop background work aggressively. If capture keeps stopping, allow HaulPilot to run without battery restrictions.")
        HpButton("Battery optimisation settings", { env.actions.openBatterySettings() }, kind = BtnKind.SECONDARY)
    }
}

// ---- game & capture ------------------------------------------------------------------------------------------------------

@Composable
private fun CapturePage(env: UiEnv) {
    val game by AutopilotRuntime.gamePackage.collectAsStateWithLifecycle()
    val diagnosis by AutopilotRuntime.captureDiagnosis.collectAsStateWithLifecycle()
    val options by AutopilotRuntime.options.collectAsStateWithLifecycle()
    val access by AutopilotRuntime.accessibilityConnected.collectAsStateWithLifecycle()
    var choosing by rememberSaveable { mutableStateOf(false) }
    val apps = remember(choosing) { if (choosing) env.actions.installedLaunchables() else emptyList() }
    val label = remember(game) { env.actions.installedLaunchables().firstOrNull { it.second == game }?.first }
    HpCard {
        SectionHeader("Game", subtitle = when {
            game.isBlank() -> "Not chosen"
            label != null -> "$label · $game"
            else -> "$game (not installed?)"
        })
        BodyText("Only pictures taken while this game is in front are analysed, and Auto Drive only acts while it is in front.")
        Row(horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
            HpButton("Choose the game", { if (liveDrive()) env.toast("Stop the drive first.") else choosing = true }, kind = BtnKind.SECONDARY)
            HpButton("Open it", { env.openGame() }, kind = BtnKind.GHOST, enabled = game.isNotBlank())
        }
    }
    HpCard {
        SectionHeader("Screen capture health", trailing = { StatusPill(if (diagnosis.healthy) "OK" else if (diagnosis.isProblem) "Problem" else "Info", if (diagnosis.healthy) Tone.GOOD else if (diagnosis.isProblem) Tone.BAD else Tone.INFO) })
        Text(diagnosis.title, style = MaterialTheme.typography.titleSmall, color = Hp.Text)
        BodyText(diagnosis.detail)
        InfoRow("Analysis picture size", "${AutopilotRuntime.PROCESSING_LONG_SIDE} px on the long side")
        SmallText("Pictures are scaled down for analysis and never leave the phone. The capture surface keeps the screen's exact shape, so no borders are added.")
    }
    HpCard {
        SectionHeader("Floating button")
        SwitchRow(
            "Show the floating button over the game", if (access) "Start, pause, stop and collect pictures without leaving the game." else "Needs the accessibility service (Settings → Permissions).",
            options.showPanel, { v -> AutopilotRuntime.updateOptions { it.copy(showPanel = v) } },
        )
        SwitchRow("Vibrate on countdowns and stops", "Useful when HaulPilot is not on screen.", options.vibrateCues, { v -> AutopilotRuntime.updateOptions { it.copy(vibrateCues = v) } })
    }
    if (choosing) {
        AlertDialog(
            onDismissRequest = { choosing = false },
            containerColor = Hp.Surface,
            title = { Text("Choose the game", color = Hp.Text) },
            text = {
                if (apps.isEmpty()) {
                    BodyText("No apps with a launcher icon were found.")
                } else {
                    LazyColumn(Modifier.heightIn(max = 420.dp)) {
                        items(apps, key = { it.second }) { (name, pkg) ->
                            Column(
                                Modifier
                                    .fillMaxWidth()
                                    .clickable(role = Role.Button) {
                                        AutopilotRuntime.setGamePackage(pkg)
                                        AutopilotRuntime.refreshLink()
                                        choosing = false
                                        env.toast("$name is now the game.")
                                    }
                                    .heightIn(min = 52.dp)
                                    .padding(vertical = Sp.xs),
                            ) {
                                Text(name, style = MaterialTheme.typography.titleSmall, color = if (pkg == game) Hp.Accent else Hp.Text)
                                SmallText(pkg)
                            }
                        }
                    }
                }
            },
            confirmButton = { HpButton("Close", { choosing = false }, kind = BtnKind.GHOST) },
        )
    }
}

// ---- touch & coordinates ------------------------------------------------------------------------------------------------

@Composable
private fun TouchPage(env: UiEnv) {
    val context = LocalContext.current
    val tick = rememberResumeTick()
    val settings by AutopilotRuntime.settings.collectAsStateWithLifecycle()
    val profile by AutopilotRuntime.profile.collectAsStateWithLifecycle()
    val (dw, dh) = remember(tick) { AutopilotRuntime.realDisplaySize(context) }
    val display = if (dw > 0 && dh > 0) DisplaySpace(dw, dh) else null
    val ref = profile?.let { LayoutCheck.referenceSize(it) }
    HpCard {
        SectionHeader("Assisted mode")
        SwitchRow(
            "Assisted mode", "HaulPilot shows what it would press and sends no touches at all.",
            settings.assistedMode, { v -> if (liveDrive()) env.toast("Stop the drive first.") else AutopilotRuntime.updateSettings { it.copy(assistedMode = v) } },
        )
    }
    HpCard {
        SectionHeader("This screen")
        if (display != null) {
            InfoRow("Display", "$dw × $dh px")
            InfoRow("Shape", String.format(java.util.Locale.US, "%.3f : 1", display.aspect))
        } else {
            BodyText("The display size could not be read.")
        }
        if (ref != null) {
            InfoRow("Active profile made on", "${ref.width} × ${ref.height} (${String.format(java.util.Locale.US, "%.3f", ref.aspect)} : 1)")
            if (display != null) {
                val off = abs(ref.aspect - display.aspect) / display.aspect
                if (off > 0.03f) {
                    Banner(Tone.ATTENTION, "The screen shape does not match the profile", "Rotate to the orientation the profile was made in, or make a profile for this shape in Smart Setup. Positions are never stretched to fit.")
                } else {
                    Banner(Tone.GOOD, "The screen shape matches the profile", null)
                }
            }
        }
        SmallText(
            "Positions are stored as fractions of the whole display (0 = left/top, 1 = right/bottom), the same reference the screen pictures and Android's touch gestures use, " +
                "so no status-bar or cut-out arithmetic is needed. They stay valid in both landscape directions but not after switching between portrait and landscape.",
        )
    }
    val p = profile
    if (p != null && display != null && p.controls.isNotEmpty()) {
        HpCard {
            SectionHeader("Where touches go", subtitle = "Active profile \"${p.name}\" on this display")
            Control.entries.forEach { c ->
                val pt = p.controls[c] ?: return@forEach
                val px = display.touchPoint(pt.x, pt.y)
                Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                    Text(controlName(c), Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium, color = Hp.TextSecondary)
                    Text(
                        String.format(java.util.Locale.US, "%.3f, %.3f → %d, %d px", pt.x, pt.y, px.x.roundToInt(), px.y.roundToInt()),
                        style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace), color = Hp.Text,
                    )
                }
            }
            if (p.controls.containsKey(Control.STEER_CENTER)) SmallText("Wheel: dragged up to ± ${pct(p.steerRadius)} of the width from its centre.")
        }
    }
    HpCard {
        SectionHeader("Touch safety")
        CheckLine(true, "Held touches are released automatically", "If the automation stops refreshing a held control for ${GestureInputController.DEADMAN_MS / 1000.0} s (stalled or crashed), every touch is let go.")
        CheckLine(true, "Emergency Stop releases everything at once", "From the red bar in the app, the floating button or the notification.")
        CheckLine(true, "Only confirmed controls are pressed", "Candidates from the analysis are never used until you confirm them.")
    }
}

private fun controlName(c: Control): String = when (c) {
    Control.ACCELERATOR -> "Accelerator"
    Control.BRAKE -> "Brake"
    Control.STEER_CENTER -> "Steering wheel"
    Control.STEER_LEFT -> "Steer left"
    Control.STEER_RIGHT -> "Steer right"
    Control.GEAR_DRIVE -> "Drive gear"
    Control.GEAR_REVERSE -> "Reverse gear"
}

// ---- automation & safety --------------------------------------------------------------------------------------------------

@Composable
private fun SafetyPage(env: UiEnv) {
    val s by AutopilotRuntime.settings.collectAsStateWithLifecycle()
    val snap by AutopilotRuntime.snapshot.collectAsStateWithLifecycle()
    val armed by AutopilotRuntime.armedMessage.collectAsStateWithLifecycle()
    val locked = snap.status.isActiveLoop || snap.status == SessionStatus.PAUSED || snap.status == SessionStatus.NEEDS_ASSIST || armed != null
    var confirmDefaults by rememberSaveable { mutableStateOf(false) }
    fun set(f: (AutomationSettings) -> AutomationSettings) {
        if (locked) env.toast("Stop the drive to change these.") else AutopilotRuntime.updateSettings(f)
    }
    if (locked) Banner(Tone.INFO, "A drive is running or paused", "These settings are locked until it is stopped, so the safety limits cannot change in the middle of a drive.")
    HpCard {
        SectionHeader("Driving")
        SliderRow("Cruise speed limit", pct(s.speedLevel), s.speedLevel, 0.1f..1f, steps = 8, subtitle = "Most the accelerator is pressed on open road.", enabled = !locked) { v -> set { it.copy(speedLevel = v) } }
        SliderRow("Approach speed limit", pct(s.approachSpeed), s.approachSpeed, 0.1f..0.5f, steps = 7, subtitle = "Near the delivery area.", enabled = !locked) { v -> set { it.copy(approachSpeed = v) } }
        SliderRow("Steering sensitivity", String.format(java.util.Locale.US, "%.1f×", s.sensitivity), s.sensitivity, 0.5f..2f, steps = 14, enabled = !locked) { v -> set { it.copy(sensitivity = v) } }
        SwitchRow("Try to park", "Off: the truck stops near the delivery area and you park.", s.tryParking, { v -> set { it.copy(tryParking = v) } }, enabled = !locked)
    }
    HpCard {
        SectionHeader("Watchdogs", subtitle = "When HaulPilot stops by itself and asks for you")
        SecondsSlider("Recognise the driving screen within", s.recognitionTimeoutSec, 5, 60, "After Start, nothing is pressed until the driving screen is recognised; it gives up after this.", !locked) { v -> set { it.copy(recognitionTimeoutSec = v) } }
        SecondsSlider("Frozen picture", s.frozenPictureSec, 2, 15, "No new picture while driving for this long (game or capture froze): the truck is stopped.", !locked) { v -> set { it.copy(frozenPictureSec = v) } }
        SecondsSlider("Game not in front", s.foregroundGraceSec, 1, 15, "Another app or a system screen in front for this long: driving pauses and all touches are released.", !locked) { v -> set { it.copy(foregroundGraceSec = v) } }
        SecondsSlider("Unknown screen", s.unknownScreenSec, 3, 30, "A screen that is not the driving view (dialog, crash, menu): the truck is stopped and you are asked.", !locked) { v -> set { it.copy(unknownScreenSec = v) } }
        SecondsSlider("Route lost", s.roadLostSec, 1, 10, "The route line cannot be seen (after braking): you are asked to help.", !locked) { v -> set { it.copy(roadLostSec = v) } }
    }
    HpCard {
        SectionHeader("Emergency Stop")
        BodyText("Releases every automated touch immediately and ends the drive. It never holds the brake or presses anything else. It is on the red bar in this app, on the floating button and in the notification.")
    }
    HpButton("Restore the safe defaults…", { if (locked) env.toast("Stop the drive first.") else confirmDefaults = true }, kind = BtnKind.SECONDARY)
    if (confirmDefaults) {
        ConfirmDialog("Restore the defaults?", "Speed, steering, parking and watchdog settings go back to their defaults. Assisted mode is kept as it is.", "Restore", { confirmDefaults = false }) {
            confirmDefaults = false
            AutopilotRuntime.updateSettings { AutomationSettings(assistedMode = it.assistedMode) }
            env.toast("Defaults restored.")
        }
    }
}

@Composable
private fun SecondsSlider(title: String, value: Int, min: Int, max: Int, subtitle: String, enabled: Boolean, onChange: (Int) -> Unit) {
    SliderRow(title, "$value s", value.toFloat(), min.toFloat()..max.toFloat(), steps = (max - min - 1).coerceAtLeast(0), subtitle = subtitle, enabled = enabled) { onChange(it.roundToInt()) }
}

// ---- diagnostics -----------------------------------------------------------------------------------------------------------

@Composable
private fun DiagnosticsPage(env: UiEnv) {
    val logs by AutopilotRuntime.logs.collectAsStateWithLifecycle()
    val history by AutopilotRuntime.history.collectAsStateWithLifecycle()
    val diagnosis by AutopilotRuntime.captureDiagnosis.collectAsStateWithLifecycle()
    val recording by AutopilotRuntime.recorder.recording.collectAsStateWithLifecycle()
    val snapshots by AutopilotRuntime.recorder.items.collectAsStateWithLifecycle()
    val options by AutopilotRuntime.options.collectAsStateWithLifecycle()
    val captureOn by AutopilotRuntime.captureActive.collectAsStateWithLifecycle()
    val access by AutopilotRuntime.accessibilityConnected.collectAsStateWithLifecycle()
    var confirm by remember { mutableStateOf<String?>(null) }
    var showAll by rememberSaveable { mutableStateOf(false) }

    HpCard {
        SectionHeader("Screen capture", subtitle = diagnosis.title)
        BodyText(diagnosis.detail)
        val lines = remember(diagnosis) { AutopilotRuntime.captureDiagnosticLines() }
        lines.takeLast(6).forEach { SmallText(it, maxLines = 2) }
    }

    HpCard {
        SectionHeader("Log", subtitle = "States and actions only; nothing from the screen", trailing = {
            HpButton("Share", { env.actions.shareText("${Brand.APP_NAME} log", AutopilotRuntime.logTail()) }, kind = BtnKind.GHOST, height = 40.dp, enabled = logs.isNotEmpty())
        })
        if (logs.isEmpty()) SmallText("Nothing logged yet.")
        val shown = if (showAll) logs.takeLast(200) else logs.takeLast(12)
        shown.reversed().forEach { e ->
            Row(horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
                Text(formatClock(e.timeMs), style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace), color = Hp.TextMuted)
                Text(
                    e.message + if (e.repeat > 1) " (×${e.repeat})" else "",
                    Modifier.weight(1f), style = MaterialTheme.typography.bodySmall,
                    color = when (e.level) {
                        LogLevel.ERROR -> Hp.Danger
                        LogLevel.WARN -> Hp.Warning
                        LogLevel.INFO -> Hp.TextSecondary
                    },
                )
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
            if (logs.size > 12) HpButton(if (showAll) "Show less" else "Show more", { showAll = !showAll }, kind = BtnKind.GHOST, height = 40.dp)
            HpButton("Clear log…", { confirm = "log" }, kind = BtnKind.GHOST, height = 40.dp, enabled = logs.isNotEmpty())
        }
    }

    HpCard {
        SectionHeader("Recent drives", subtitle = "${history.size} recorded")
        if (history.isEmpty()) SmallText("No drives yet.")
        history.takeLast(15).reversed().forEach { r ->
            Column {
                Text("${formatDateTime(r.startedMs)} · ${formatDuration(r.durationMs)} · ${r.outcome.label}", style = MaterialTheme.typography.bodyMedium, color = Hp.Text)
                SmallText(listOf(r.profile, r.reason).filter { it.isNotBlank() }.joinToString(" · "), maxLines = 2)
            }
        }
        if (history.isNotEmpty()) HpButton("Clear history…", { confirm = "history" }, kind = BtnKind.GHOST, height = 40.dp)
    }

    HpCard {
        SectionHeader("Sample recording", subtitle = "${snapshots.size} picture(s), ${formatBytes(snapshots.sumOf { it.bytes })}")
        BodyText("Saves a picture of the game every few seconds while it is in front, for troubleshooting or as Smart Setup pictures. Stored only on this phone; nothing is saved while another app is in front.")
        SliderRow("Every", "${options.recordIntervalSec} s", options.recordIntervalSec.toFloat(), 1f..60f, steps = 58) { v -> AutopilotRuntime.updateOptions { it.copy(recordIntervalSec = v.roundToInt()) } }
        SliderRow("Keep at most", "${options.recordMaxFrames}", options.recordMaxFrames.toFloat(), 10f..400f, steps = 38) { v -> AutopilotRuntime.updateOptions { it.copy(recordMaxFrames = (v / 10f).roundToInt() * 10) } }
        Row(horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
            if (recording) {
                HpButton("Stop recording", { AutopilotRuntime.recorder.stop() }, kind = BtnKind.SECONDARY, glyph = Glyph.STOP)
            } else {
                HpButton(
                    "Start recording", {
                        AutopilotRuntime.recorder.start(options.recordIntervalSec, options.recordMaxFrames)
                        env.toast("Recording while the game is in front.")
                    },
                    kind = BtnKind.SECONDARY, enabled = captureOn && access, glyph = Glyph.CAMERA,
                )
            }
            if (snapshots.isNotEmpty()) HpButton("Delete all…", { confirm = "snapshots" }, kind = BtnKind.GHOST)
        }
        if (!captureOn || !access) SmallText("Needs screen capture and the accessibility service (to know the game is in front).")
        if (snapshots.size >= 2) {
            HpButton(
                "Use them in Smart Setup",
                {
                    AutopilotRuntime.ioScope.launchSafely {
                        val frames = AutopilotRuntime.recorder.sampleForAnalysis(40)
                        val err = AutopilotRuntime.setup.importFrames(frames, FrameOriginKind.SCREENSHOT)
                        AutopilotRuntime.notice.value = err ?: "Added ${frames.size} recorded picture(s) to Smart Setup."
                    }
                    env.nav.openSetup(SETUP_STEP_SCREEN)
                },
                kind = BtnKind.GHOST,
            )
        }
    }

    when (confirm) {
        "log" -> ConfirmDialog("Clear the log?", "The in-app log and its file are deleted.", "Clear", { confirm = null }, danger = true) {
            confirm = null
            AutopilotRuntime.clearLogs()
        }
        "history" -> ConfirmDialog("Clear drive history?", "The list of recent drives is deleted. Profiles are not affected.", "Clear", { confirm = null }, danger = true) {
            confirm = null
            AutopilotRuntime.clearHistory()
        }
        "snapshots" -> ConfirmDialog("Delete all recorded pictures?", "${snapshots.size} picture(s) are deleted from this phone.", "Delete", { confirm = null }, danger = true) {
            confirm = null
            AutopilotRuntime.ioScope.launchSafely { AutopilotRuntime.recorder.deleteAll() }
        }
    }
}

// ---- reset ---------------------------------------------------------------------------------------------------------------------

@Composable
private fun ResetPage(env: UiEnv) {
    val setup by AutopilotRuntime.setup.state.collectAsStateWithLifecycle()
    var confirm by remember { mutableStateOf<String?>(null) }
    Banner(Tone.INFO, "Profiles are never deleted here", "Delete profiles one at a time in Profiles, where each deletion can be undone.")
    HpCard {
        SectionHeader("Smart Setup", subtitle = "${setup.frames.size} picture(s), ${setup.draft.confirmedCount} confirmed control(s)" + if (setup.dirty) ", unsaved changes" else "")
        BodyText("Clears the pictures and everything placed in the current setup, to start from step 1.")
        HpButton("Start Smart Setup over…", { confirm = "setup" }, kind = BtnKind.SECONDARY)
    }
    HpCard {
        SectionHeader("Settings")
        BodyText("Driving, safety and watchdog settings back to their defaults (Assisted mode is kept).")
        HpButton("Restore default settings…", { confirm = "settings" }, kind = BtnKind.SECONDARY)
        BodyText("App preferences back to their defaults: the welcome card, floating button, vibration, recording options and the accessibility explanation are shown again.")
        HpButton("Reset app preferences…", { confirm = "options" }, kind = BtnKind.SECONDARY)
    }
    when (confirm) {
        "setup" -> ConfirmDialog(
            "Start Smart Setup over?", "Pictures and everything placed or confirmed in the current setup are cleared" + (if (setup.phase.busy) ", and the running ${setup.phase.label.lowercase()} is cancelled" else "") + ". Saved profiles are not changed.",
            "Start over", { confirm = null }, danger = true,
        ) {
            confirm = null
            AutopilotRuntime.setup.resetAll()
            env.toast("Smart Setup cleared. Saved profiles were not changed.")
        }
        "settings" -> ConfirmDialog("Restore default settings?", "Speed, steering, parking and watchdog settings go back to their defaults.", "Restore", { confirm = null }) {
            confirm = null
            if (liveDrive()) {
                env.toast("Stop the drive first.")
            } else {
                AutopilotRuntime.updateSettings { AutomationSettings(assistedMode = it.assistedMode) }
                env.toast("Default settings restored.")
            }
        }
        "options" -> ConfirmDialog("Reset app preferences?", "Profiles, the setup and the log are not affected.", "Reset", { confirm = null }) {
            confirm = null
            AutopilotRuntime.updateOptions { AppOptions() }
            env.toast("App preferences reset.")
        }
    }
}

// ---- about ---------------------------------------------------------------------------------------------------------------------

@Composable
private fun AboutPage() {
    HpCard {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(Sp.m)) {
            BrandMark(48.dp)
            Column {
                Text(Brand.APP_NAME, style = MaterialTheme.typography.titleLarge, color = Hp.Text)
                SmallText(Brand.TAGLINE)
            }
        }
        InfoRow("Version", BuildConfig.VERSION_NAME)
        InfoRow("Build", "${BuildConfig.VERSION_CODE} · ${BuildConfig.BUILD_TYPE}")
        InfoRow("App id", BuildConfig.APPLICATION_ID)
        SmallText(Brand.CREDIT)
        Brand.SUPPORT_URL?.let { SmallText(it) }
    }
    HpCard {
        SectionHeader("What it does, and what it does not")
        CheckLine(true, "Learns the game's controls from pictures", "Evidence-based candidates that you confirm; nothing is guessed silently.")
        CheckLine(true, "Presses only controls you confirmed", "Through Android's accessibility service, which you can switch off at any time.")
        CheckLine(false, "It is not a reliable self-driving system", "It follows the minimap's route line and stops and asks you whenever it is unsure. Stay with the phone.")
        CheckLine(false, "It does not handle menus, jobs or payments", "Choosing jobs, unloading and paying stay with you.")
    }
    HpCard {
        SectionHeader("Privacy")
        BodyText("${Brand.APP_NAME} has no internet permission. Pictures, profiles and logs stay on this phone unless you export or share them yourself.")
    }
}
