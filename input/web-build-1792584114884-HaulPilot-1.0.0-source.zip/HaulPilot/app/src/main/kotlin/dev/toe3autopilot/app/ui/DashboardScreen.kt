package dev.toe3autopilot.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.toe3autopilot.app.AutopilotRuntime
import dev.toe3autopilot.app.Brand
import dev.toe3autopilot.core.capture.LinkState
import dev.toe3autopilot.core.session.SessionStatus
import dev.toe3autopilot.core.status.DriveReadiness
import dev.toe3autopilot.core.status.ReadinessInputs
import dev.toe3autopilot.core.status.StatusAdvice
import dev.toe3autopilot.core.status.StatusInputs

@Composable
fun DashboardScreen(env: UiEnv) {
    val snap by AutopilotRuntime.snapshot.collectAsStateWithLifecycle()
    val armed by AutopilotRuntime.armedMessage.collectAsStateWithLifecycle()
    val profile by AutopilotRuntime.profile.collectAsStateWithLifecycle()
    val profiles by AutopilotRuntime.profileList.collectAsStateWithLifecycle()
    val readiness by AutopilotRuntime.readiness.collectAsStateWithLifecycle()
    val access by AutopilotRuntime.accessibilityConnected.collectAsStateWithLifecycle()
    val settings by AutopilotRuntime.settings.collectAsStateWithLifecycle()
    val game by AutopilotRuntime.gamePackage.collectAsStateWithLifecycle()
    val captureOn by AutopilotRuntime.captureActive.collectAsStateWithLifecycle()
    val setup by AutopilotRuntime.setup.state.collectAsStateWithLifecycle()
    val diagnosis by AutopilotRuntime.captureDiagnosis.collectAsStateWithLifecycle()
    val endReason by AutopilotRuntime.captureEndReason.collectAsStateWithLifecycle()
    val link by AutopilotRuntime.link.collectAsStateWithLifecycle()
    val history by AutopilotRuntime.history.collectAsStateWithLifecycle()
    val options by AutopilotRuntime.options.collectAsStateWithLifecycle()

    val view = remember(snap, armed, profile, profiles, readiness, access, settings.assistedMode, game, captureOn, setup.phase) {
        DriveReadiness.of(
            ReadinessInputs(
                snapshot = snap, armed = armed != null, profileCount = profiles.size, activeProfileName = profile?.name,
                profileProblems = if (profile == null) emptyList() else readiness, accessibilityOn = access,
                assistedMode = settings.assistedMode, gamePackage = game, captureOn = captureOn, setupBusy = setup.phase.busy,
            ),
        )
    }
    val advice = remember(snap, captureOn, diagnosis, endReason, access, settings.assistedMode, setup, profile, readiness) {
        StatusAdvice.all(
            StatusInputs(snap, captureOn, diagnosis, endReason, access, settings.assistedMode, setup, profile != null, if (profile == null) emptyList() else readiness),
        )
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = Sp.gutter, vertical = Sp.m),
        verticalArrangement = Arrangement.spacedBy(Sp.m),
    ) {
        if (!options.welcomeDismissed && profiles.isEmpty()) WelcomeCard(env)

        // ---- status and the one main action ----
        HpCard(accent = toneColor(toneOf(view.tone))) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
                Overline("Drive status", Modifier.weight(1f).padding(top = 0.dp))
                StatusPill(if (settings.assistedMode) "Assisted mode" else "Touch control", if (settings.assistedMode) Tone.INFO else Tone.NEUTRAL)
            }
            Text(
                view.headline,
                Modifier.semantics {
                    heading()
                    liveRegion = LiveRegionMode.Polite
                },
                style = MaterialTheme.typography.headlineMedium, color = toneColor(toneOf(view.tone)),
            )
            BodyText(armed ?: view.detail)
            if (view.live && snap.status.isActiveLoop) LiveFacts(snap)
            if (settings.assistedMode && snap.assistHint != null && view.live) {
                Banner(Tone.INFO, "Do this in the game", snap.assistHint)
            }
            PrimaryDriveActions(env, view.canStart, view.canResume, view.live, snap.status)
            if (!view.live && !view.canStart) {
                SmallText("Start Auto Drive appears when every check below is met (${view.unmet.size} open).")
            }
        }

        // ---- what needs attention ----
        advice.take(3).forEach { a ->
            Banner(toneOf(a.severity), a.title, a.text, a.actionLabel, if (a.actionLabel != null) ({ env.runAdvice(a.action) }) else null)
        }

        // ---- prerequisites ----
        if (!view.live) {
            HpCard {
                SectionHeader("Before you drive", subtitle = "${view.items.count { it.ok }} of ${view.items.size} checks met")
                view.items.forEach { p ->
                    CheckLine(p.ok, p.key.title, p.detail, if (p.ok) null else p.actionLabel, if (p.ok) null else ({ env.runPrereq(p.action) }))
                }
            }
        }

        // ---- connection ----
        HpCard {
            SectionHeader(
                "Screen connection",
                trailing = {
                    StatusPill(
                        link.state.label,
                        when (link.state) {
                            LinkState.CONNECTED -> if (link.receivingGame) Tone.GOOD else Tone.ACTIVE
                            LinkState.WAITING_FOR_PERMISSION -> Tone.ATTENTION
                            LinkState.FAILED -> Tone.BAD
                            LinkState.NOT_CONNECTED -> Tone.NEUTRAL
                        },
                    )
                },
            )
            BodyText(link.detail)
            Row(horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
                link.actionLabel?.let { label -> HpButton(label, { env.runLink(link.action) }, kind = BtnKind.SECONDARY) }
                if (captureOn) {
                    HpButton(
                        "Disconnect", {
                            if (view.live) env.toast("Stop the drive first; disconnecting would also stop it.") else env.actions.disconnectCapture()
                        },
                        kind = BtnKind.GHOST,
                    )
                }
            }
            if (game.isNotBlank()) SmallText("Game: $game")
        }

        // ---- profile ----
        HpCard(onClick = { env.nav.open(Tab.PROFILES) }) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(Sp.m)) {
                HpIcon(Glyph.PROFILES, tint = Hp.Accent)
                Column(Modifier.weight(1f)) {
                    Text(profile?.name ?: "No active profile", style = MaterialTheme.typography.titleSmall, color = Hp.Text)
                    SmallText(
                        when {
                            profile == null && profiles.isEmpty() -> "Create one in Smart Setup."
                            profile == null -> "${profiles.size} profile(s); none active."
                            readiness.isEmpty() -> "Complete: controls, driving screen and minimap."
                            else -> "${readiness.size} item(s) missing for automatic driving."
                        },
                    )
                }
                HpIcon(Glyph.CHEVRON, tint = Hp.TextMuted, size = 18.dp)
            }
        }

        // ---- recent drives ----
        if (history.isNotEmpty()) {
            HpCard {
                SectionHeader("Recent drives", trailing = {
                    HpButton("All", { env.nav.open(Tab.SETTINGS, SettingsPage.DIAGNOSTICS) }, kind = BtnKind.GHOST, height = 40.dp)
                })
                history.takeLast(3).reversed().forEach { r ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(Sp.m)) {
                        HpIcon(Glyph.HISTORY, tint = Hp.TextMuted, size = 18.dp)
                        Column(Modifier.weight(1f)) {
                            Text("${formatDateTime(r.startedMs)} · ${formatDuration(r.durationMs)}", style = MaterialTheme.typography.bodyMedium, color = Hp.Text)
                            SmallText("${r.outcome.label}: ${r.reason}", maxLines = 2)
                        }
                    }
                }
            }
        }

        SmallText(
            "${Brand.APP_NAME} assists with driving in the game; it cannot drive reliably on its own. Stay with the phone while it runs, " +
                "and use the red Emergency Stop at any time.",
            Modifier.padding(horizontal = Sp.xs, vertical = Sp.s),
        )
        Spacer(Modifier.height(Sp.l))
    }
}

@Composable
private fun LiveFacts(snap: dev.toe3autopilot.core.session.SessionSnapshot) {
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(2.dp)) {
        InfoRow("Screen", snap.gameState.label + if (snap.confidence > 0f) " (${pct(snap.confidence)})" else "")
        snap.phase?.let { InfoRow("Part of the trip", it.label) }
        snap.road?.let { InfoRow("Route", it) }
        InfoRow("Doing", snap.task)
    }
}

@Composable
private fun PrimaryDriveActions(env: UiEnv, canStart: Boolean, canResume: Boolean, live: Boolean, status: SessionStatus) {
    when {
        status.isActiveLoop -> Row(horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
            HpButton("Pause", { AutopilotRuntime.pause() }, Modifier.weight(1f), kind = BtnKind.SECONDARY, glyph = Glyph.PAUSE)
            HpButton("Stop", { AutopilotRuntime.stopSession() }, Modifier.weight(1f), kind = BtnKind.SECONDARY, glyph = Glyph.STOP)
        }
        status == SessionStatus.PAUSED || status == SessionStatus.NEEDS_ASSIST -> Column(verticalArrangement = Arrangement.spacedBy(Sp.s)) {
            Row(horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
                HpButton("Resume", { env.startDrive(resume = true) }, Modifier.weight(1f), enabled = canResume, glyph = Glyph.PLAY)
                HpButton("Stop", { AutopilotRuntime.stopSession() }, Modifier.weight(1f), kind = BtnKind.SECONDARY, glyph = Glyph.STOP)
            }
            if (!canResume) SmallText("Resume needs the checks below to be met again.")
        }
        live -> HpButton("Cancel start", { AutopilotRuntime.cancelArmed() }, Modifier.fillMaxWidth(), kind = BtnKind.SECONDARY, glyph = Glyph.CLOSE)
        else -> HpButton(
            "Start Auto Drive", { env.startDrive() }, Modifier.fillMaxWidth(), enabled = canStart, glyph = Glyph.PLAY, height = 56.dp,
        )
    }
}

@Composable
private fun WelcomeCard(env: UiEnv) {
    HpCard(accent = Hp.Primary) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(Sp.m)) {
            BrandMark(40.dp)
            Column(Modifier.weight(1f)) {
                Text("Welcome to ${Brand.APP_NAME}", style = MaterialTheme.typography.titleLarge, color = Hp.Text)
                SmallText(Brand.TAGLINE)
            }
        }
        BodyText("Three things before the first drive:")
        Column(verticalArrangement = Arrangement.spacedBy(Sp.s)) {
            CheckLine(null, "1. Smart Setup", "Show HaulPilot the game's driving screen and confirm where the pedals, steering and minimap are.")
            CheckLine(null, "2. Touch control", "Turn on the accessibility service so HaulPilot can press the controls you confirmed (or use Assisted mode).")
            CheckLine(null, "3. Start Auto Drive", "Appears on this screen once everything is set. The red Emergency Stop is always one tap away.")
        }
        Row(horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
            HpButton("Start Smart Setup", { env.nav.openSetup(SETUP_STEP_CONNECT) }, Modifier.weight(1f))
            HpButton("Dismiss", { AutopilotRuntime.updateOptions { it.copy(welcomeDismissed = true) } }, kind = BtnKind.GHOST)
        }
    }
}
