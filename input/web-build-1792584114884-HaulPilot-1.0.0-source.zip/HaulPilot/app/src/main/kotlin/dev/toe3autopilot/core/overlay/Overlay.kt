package dev.toe3autopilot.core.overlay

import dev.toe3autopilot.core.capture.LinkAction
import dev.toe3autopilot.core.capture.LinkState
import dev.toe3autopilot.core.capture.LinkStatus
import dev.toe3autopilot.core.session.SessionSnapshot
import dev.toe3autopilot.core.session.SessionStatus
import dev.toe3autopilot.core.session.UserState
import dev.toe3autopilot.core.session.userState
import dev.toe3autopilot.core.setup.SetupPhase
import dev.toe3autopilot.core.setup.SetupState
import kotlin.math.abs
import kotlin.math.roundToInt

/** Colour family of the floating button's state dot (mapped to real colours by the Android layer). */
enum class OverlayTone { NEUTRAL, ACTIVE, CALIBRATING, WARNING, DANGER, DONE }

/** Everything the floating controls show, taken from the app's real state at one moment. */
data class OverlayInputs(
    val snapshot: SessionSnapshot,
    val captureOn: Boolean,
    /** Countdown / arming message while Start is preparing, null otherwise. */
    val armedMessage: String?,
    /** Smart Setup's own state (the overlay never keeps a separate calibration status). */
    val setup: SetupState = SetupState(),
    /** One-off message from the last button press on the panel (for example why Start was refused). */
    val note: String?,
    val recordingSnapshots: Boolean,
    /** The person's "show floating controls while capture is on" setting. */
    val showWhileCaptureOn: Boolean,
    /** Screen connection status (null = not known yet). */
    val link: LinkStatus? = null,
    /** The active profile has everything automatic driving needs (validated, confirmed controls). */
    val readyToDrive: Boolean = false,
    /** First reason the active profile is not ready, for the status line. */
    val notReadyReason: String? = null,
    /** The app in front could be the game but is not the selected one. */
    val canAdoptGame: Boolean = false,
)

/** Picture-collection block of the expanded panel. All numbers come from [SetupState]. */
data class OverlayCalibration(
    val stageTitle: String,
    val stageDetail: String,
    /** 0..100 */
    val percent: Int,
    /** Why setup cannot continue, null when it can. */
    val blocker: String?,
)

data class OverlayUi(
    val visible: Boolean,
    val state: UserState,
    val tone: OverlayTone,
    /** One or two lines: what is happening or what to do. */
    val status: String,
    val canStartDrive: Boolean,
    val canStartCalibration: Boolean,
    val canCancelCalibration: Boolean,
    val canPause: Boolean,
    val canResume: Boolean,
    /** Ends the drive or cancels the countdown. */
    val canEnd: Boolean,
    val endLabel: String,
    /** Emergency Stop is offered whenever the controls are visible. */
    val canEmergency: Boolean,
    /** Shown while pictures are collected or analysed, or when that stopped with a problem; null otherwise. */
    val calibration: OverlayCalibration?,
    /** Draws attention on the collapsed button (help needed, emergency stop) without expanding it. */
    val attention: Boolean,
    /** Progress ring on the collapsed button, 0..1, only while collecting pictures. */
    val ring: Float?,
    val recording: Boolean,
    /** "Screen connected" etc. */
    val linkLabel: String? = null,
    /** Live pictures of the game are arriving. */
    val linkOk: Boolean = false,
    val canAdoptGame: Boolean = false,
)

object OverlayModel {
    fun toneOf(s: UserState): OverlayTone = when (s) {
        UserState.DRIVING, UserState.APPROACHING_TURN, UserState.APPROACHING_DELIVERY, UserState.PARKING -> OverlayTone.ACTIVE
        UserState.PARKED -> OverlayTone.DONE
        UserState.NEEDS_ASSISTANCE, UserState.EMERGENCY_STOP -> OverlayTone.DANGER
        UserState.PAUSED, UserState.STARTING -> OverlayTone.WARNING
        UserState.CALIBRATING -> OverlayTone.CALIBRATING
        UserState.READY -> OverlayTone.NEUTRAL
    }

    fun build(i: OverlayInputs): OverlayUi {
        val snap = i.snapshot
        val st = snap.status
        val live = st == SessionStatus.STARTING || st == SessionStatus.RUNNING || st == SessionStatus.PAUSED || st == SessionStatus.NEEDS_ASSIST
        val setup = i.setup
        val calibrating = setup.phase.busy
        val armed = i.armedMessage != null
        val paused = st == SessionStatus.PAUSED || st == SessionStatus.NEEDS_ASSIST
        val state = when {
            live -> snap.userState(false)
            armed -> UserState.STARTING
            calibrating -> UserState.CALIBRATING
            else -> snap.userState(false)
        }
        val visible = live || armed || calibrating || (i.captureOn && i.showWhileCaptureOn)
        val status = when {
            i.note != null -> i.note
            setup.phase == SetupPhase.CAPTURING -> setup.message
            setup.phase == SetupPhase.ANALYZING -> "Analysing the pictures. Open HaulPilot to review the result."
            live -> snap.assistHint ?: snap.lastError?.takeIf { paused } ?: snap.task
            armed -> i.armedMessage!!
            st == SessionStatus.EMERGENCY_STOPPED -> "Emergency stop. All touches were released. Start again when ready."
            !i.captureOn -> "Screen capture is off. Open HaulPilot to connect it."
            setup.phase == SetupPhase.FAILED -> "Setup stopped: ${setup.problem ?: "open HaulPilot"}"
            !i.readyToDrive -> "Not ready to drive: ${i.notReadyReason ?: "finish Smart Setup in HaulPilot"}."
            else -> "Ready. Show the normal driving view, then Start."
        }
        val showCal = calibrating || setup.phase == SetupPhase.FAILED && setup.recovery != null && !live
        val cal = if (!showCal) null else OverlayCalibration(
            stageTitle = if (setup.phase == SetupPhase.ANALYZING) "Analysing" else if (setup.phase == SetupPhase.FAILED) "Stopped" else "Collecting pictures",
            stageDetail = setup.problem ?: setup.message,
            percent = when (setup.phase) {
                SetupPhase.CAPTURING -> ((setup.runCollected.toFloat() / setup.target.coerceAtLeast(1)) * 100f).roundToInt().coerceIn(0, 100)
                SetupPhase.ANALYZING -> 100
                else -> 0
            },
            blocker = setup.problem,
        )
        return OverlayUi(
            visible = visible,
            state = state,
            tone = toneOf(state),
            status = status,
            canStartDrive = i.captureOn && i.readyToDrive && !live && !calibrating && !armed,
            canStartCalibration = i.captureOn && !live && !armed && !calibrating,
            canCancelCalibration = calibrating && !live,
            canPause = st.isActiveLoop,
            canResume = paused,
            canEnd = live || armed,
            endLabel = if (armed && !live) "Cancel start" else "End drive",
            canEmergency = visible,
            calibration = cal,
            attention = state == UserState.NEEDS_ASSISTANCE || state == UserState.EMERGENCY_STOP,
            ring = if (setup.phase == SetupPhase.CAPTURING) (cal?.percent ?: 0) / 100f else null,
            recording = i.recordingSnapshots,
            linkLabel = i.link?.state?.label,
            linkOk = i.link?.let { it.state == LinkState.CONNECTED && it.receivingGame } ?: false,
            canAdoptGame = i.canAdoptGame && i.link?.action == LinkAction.CHOOSE_GAME && !live,
        )
    }
}

/**
 * Where the collapsed button sits. Stored as the screen side plus a fraction of the usable height, so the position survives
 * rotation and a different screen size instead of landing off-screen.
 */
data class DockPosition(val rightSide: Boolean, val yFraction: Float) {
    companion object {
        /** Default: right edge, a little above the middle, away from the usual bottom-corner pedals. */
        val DEFAULT = DockPosition(rightSide = true, yFraction = 0.30f)
    }
}

object OverlayPlacement {
    /** Pixel position of a button of [size] for [pos] on a [screenW] x [screenH] screen, [margin] from the edge. */
    fun place(pos: DockPosition, size: Int, screenW: Int, screenH: Int, margin: Int): Pair<Int, Int> {
        val x = if (pos.rightSide) maxOf(0, screenW - size - margin) else margin.coerceAtMost(maxOf(0, screenW - size))
        val usable = maxOf(0, screenH - size - 2 * margin)
        val y = margin + (pos.yFraction.coerceIn(0f, 1f) * usable).roundToInt()
        return x to y.coerceIn(0, maxOf(0, screenH - size))
    }

    /** After a drag ends at ([x], [y]) the button snaps to the nearer side edge. */
    fun snap(x: Int, y: Int, size: Int, screenW: Int, screenH: Int, margin: Int): DockPosition {
        val centre = x + size / 2f
        val right = centre >= screenW / 2f
        val usable = maxOf(1, screenH - size - 2 * margin)
        val frac = ((y - margin).toFloat() / usable).coerceIn(0f, 1f)
        return DockPosition(right, frac)
    }

    /**
     * Top-left of the expanded panel ([panelW] x [panelH]) next to the button at ([bx], [by]): on the inner side of the
     * button, vertically aligned with it and kept fully on screen.
     */
    fun panelAnchor(bx: Int, by: Int, size: Int, panelW: Int, panelH: Int, screenW: Int, screenH: Int, gap: Int): Pair<Int, Int> {
        val buttonOnRight = bx + size / 2 >= screenW / 2
        val px = if (buttonOnRight) bx - gap - panelW else bx + size + gap
        val py = by
        return px.coerceIn(0, maxOf(0, screenW - panelW)) to py.coerceIn(0, maxOf(0, screenH - panelH))
    }
}

/**
 * Tells a deliberate tap from the end of a drag, and ignores taps that arrive right after the panel opened (a quick
 * double-tap on the button must not land on Emergency Stop or Start in the panel that appears under the finger).
 */
class TapGuard(private val slopPx: Float, private val armDelayMs: Long = ARM_DELAY_MS) {
    private var openedAt = Long.MIN_VALUE / 2

    fun panelOpened(nowMs: Long) {
        openedAt = nowMs
    }

    fun isTap(downX: Float, downY: Float, upX: Float, upY: Float): Boolean =
        abs(upX - downX) <= slopPx && abs(upY - downY) <= slopPx

    /** True when a press on a panel button at [nowMs] should be acted on. */
    fun accepts(nowMs: Long): Boolean = nowMs - openedAt >= armDelayMs

    companion object {
        const val ARM_DELAY_MS = 350L
    }
}
