package dev.toe3autopilot.core

import dev.toe3autopilot.core.calibration.CalibRole
import dev.toe3autopilot.core.calibration.DetectionSource
import dev.toe3autopilot.core.calibration.DetectionStatus
import dev.toe3autopilot.core.calibration.LayoutCheck
import dev.toe3autopilot.core.capture.FrameOrigin
import dev.toe3autopilot.core.profile.ProfileCodec
import dev.toe3autopilot.core.profile.SteeringMode
import dev.toe3autopilot.core.setup.DraftApply
import dev.toe3autopilot.core.setup.DraftCodec
import dev.toe3autopilot.core.setup.DraftEdits
import dev.toe3autopilot.core.setup.DraftValidator
import dev.toe3autopilot.core.setup.FrameOriginKind
import dev.toe3autopilot.core.setup.IssueSeverity
import dev.toe3autopilot.core.setup.ScreenEvidence
import dev.toe3autopilot.core.setup.SetupAnalysis
import dev.toe3autopilot.core.setup.SetupDraft
import dev.toe3autopilot.core.setup.SetupPhase
import dev.toe3autopilot.core.setup.SetupRecovery
import dev.toe3autopilot.core.setup.SetupSession
import dev.toe3autopilot.core.setup.SetupStep
import dev.toe3autopilot.core.setup.SetupSteps
import dev.toe3autopilot.core.setup.SetupVerifier
import dev.toe3autopilot.core.setup.StepStatus
import dev.toe3autopilot.core.state.GameState
import dev.toe3autopilot.core.vision.ColorTarget
import dev.toe3autopilot.core.vision.Frame
import dev.toe3autopilot.core.vision.Roi
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import dev.toe3autopilot.core.profile.ProfileReadiness
import dev.toe3autopilot.core.AutomationSettings
import org.junit.Test
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

class SetupSessionTest {
    private val clock = FakeClock()

    private fun session(target: Int = 45) = SetupSession(clock, target = target)

    /** Feeds [n] live pictures of the scene, 400 ms apart. */
    private fun feed(s: SetupSession, scene: Toe3Scene, n: Int, origin: FrameOrigin = FrameOrigin.GAME, moving: Boolean = true) {
        repeat(n) { i ->
            clock.advance(400)
            s.onLink(true, null, origin)
            s.offer(scene.frame(i, moving, clock.now), origin)
        }
    }

    private fun analysed(scene: Toe3Scene = Toe3Scene()): SetupSession {
        val s = session()
        assertNull(s.startCapture())
        feed(s, scene, 45)
        assertEquals(SetupPhase.REVIEW_REQUIRED, s.state().phase)
        val sel = s.state().frames.last().id
        assertNull(s.selectDrivingFrame(sel))
        val job = s.beginAnalysis()!!
        val r = SetupAnalysis.run(job.frames, job.selectedId)!!
        assertTrue(s.completeAnalysis(job, r))
        return s
    }

    // ---- capture --------------------------------------------------------------------------------------------------

    @Test
    fun captureCollectsUntilTheTargetAndSuggestsButDoesNotConfirmADrivingScreen() {
        val s = session(target = 20)
        assertNull(s.startCapture())
        assertEquals(SetupPhase.CAPTURING, s.state().phase)
        feed(s, Toe3Scene(), 20)
        val st = s.state()
        assertEquals(SetupPhase.REVIEW_REQUIRED, st.phase)
        assertEquals(20, st.collected)
        assertNotNull(st.draft.drivingFrameId)
        assertFalse("a suggestion is never a confirmation", st.draft.drivingConfirmed)
        assertTrue(st.frames.drop(1).all { it.evidence == ScreenEvidence.MOVING })
    }

    @Test
    fun picturesAreSpacedAndOtherAppsAreIgnored() {
        val s = session()
        s.startCapture()
        val scene = Toe3Scene()
        clock.advance(400)
        s.offer(scene.frame(0), FrameOrigin.GAME)
        clock.advance(100)
        s.offer(scene.frame(1), FrameOrigin.GAME) // too soon
        clock.advance(400)
        s.offer(scene.frame(2), FrameOrigin.OTHER_APP) // not the game
        s.offer(scene.frame(3), FrameOrigin.OWN_APP) // HaulPilot itself
        assertEquals(1, s.state().collected)
    }

    @Test
    fun blankAndBlackPicturesAreRejectedAndCounted() {
        val s = session()
        s.startCapture()
        repeat(5) {
            clock.advance(400)
            s.offer(Frame.solid(480, 216, 0), FrameOrigin.GAME)
        }
        clock.advance(400)
        s.offer(Frame.solid(480, 216, 0x335577), FrameOrigin.GAME)
        assertEquals(0, s.state().collected)
        assertEquals(6, s.state().rejectedFrames)
        assertTrue(s.state().message.contains("ignored"))
    }

    @Test
    fun duplicateStartIsRefused() {
        val s = session()
        assertNull(s.startCapture())
        assertNotNull(s.startCapture())
        val job = run {
            s.stopCapture()
            s.state()
        }
        assertEquals(SetupPhase.CANCELLED, job.phase) // stopped before any picture
    }

    @Test
    fun captureDisconnectedFailsButKeepsWhatWasCollected() {
        val s = session()
        s.startCapture()
        feed(s, Toe3Scene(), 12)
        s.onLink(false, "Android stopped the screen capture", FrameOrigin.GAME)
        val st = s.state()
        assertEquals(SetupPhase.FAILED, st.phase)
        assertEquals(SetupRecovery.CONNECT_SCREEN, st.recovery)
        assertEquals(12, st.collected)
        assertNotNull("a picture is still offered for manual placement", st.draft.drivingFrameId)
        // Retry without restarting the app.
        assertNull(s.startCapture(keepPictures = true))
        assertEquals(SetupPhase.CAPTURING, s.state().phase)
    }

    @Test
    fun permissionRevokedBeforeAnyPictureFailsWithReconnect() {
        val s = session()
        s.startCapture()
        clock.advance(500)
        s.onLink(true, "Screen-capture permission was revoked", null)
        assertEquals(SetupPhase.FAILED, s.state().phase)
        assertEquals(SetupRecovery.CONNECT_SCREEN, s.state().recovery)
    }

    @Test
    fun noGamePicturesTimesOutWithTheRightRecovery() {
        val s = session()
        s.startCapture()
        clock.advance(SetupSession.NO_GAME_TIMEOUT_MS + 1)
        s.onLink(true, null, FrameOrigin.OTHER_APP)
        assertEquals(SetupPhase.FAILED, s.state().phase)
        assertEquals(SetupRecovery.CHOOSE_GAME, s.state().recovery)
    }

    @Test
    fun aScreenSizeChangeRestartsTheCollection() {
        val s = session()
        s.startCapture()
        feed(s, Toe3Scene(), 8)
        assertEquals(8, s.state().collected)
        clock.advance(400)
        s.offer(Toe3Scene(w = 216, h = 480).frame(1), FrameOrigin.GAME)
        assertEquals(1, s.state().collected)
        assertTrue(s.state().message.contains("size changed"))
    }

    @Test
    fun stillPicturesAreLabelledAsSuch() {
        val s = session(target = 6)
        s.startCapture()
        feed(s, Toe3Scene(), 6, moving = false)
        assertTrue(s.state().frames.drop(1).all { it.evidence == ScreenEvidence.STILL })
    }

    // ---- import ---------------------------------------------------------------------------------------------------

    @Test
    fun importingHandlesEmptyAndCorruptInput() {
        val s = session()
        assertNotNull(s.importFrames(emptyList(), FrameOriginKind.SCREENSHOT))
        assertNotNull(s.importFrames(listOf(Frame.solid(480, 216, 0), Frame.solid(480, 216, 0xFFFFFF)), FrameOriginKind.SCREENSHOT))
        assertEquals(2, s.state().rejectedFrames)
        assertEquals(0, s.state().frames.size)
        assertNull(s.importFrames(listOf(Toe3Scene().frame(1)), FrameOriginKind.SCREENSHOT))
        assertEquals(SetupPhase.REVIEW_REQUIRED, s.state().phase)
        assertEquals(ScreenEvidence.SINGLE, s.state().frames.single().evidence)
    }

    // ---- analysis ---------------------------------------------------------------------------------------------------

    @Test
    fun analysisOfEmptyCollectionIsRefused() {
        val s = session()
        assertNull(s.beginAnalysis())
        assertTrue(s.state().message.contains("no pictures", ignoreCase = true))
    }

    @Test
    fun analysisProposesCandidatesThatStayUnconfirmed() {
        val s = analysed()
        val d = s.state().draft
        assertEquals(DetectionStatus.NEEDS_CONFIRMATION, d.controls[CalibRole.ACCELERATOR]!!.status)
        assertEquals(DetectionStatus.NEEDS_CONFIRMATION, d.controls[CalibRole.BRAKE]!!.status)
        assertEquals(DetectionStatus.NEEDS_CONFIRMATION, d.controls[CalibRole.STEER_WHEEL]!!.status)
        assertEquals(0, d.confirmedCount)
        assertNull("steering is not chosen until confirmed", d.steering)
        assertNotNull(d.minimap.box)
        assertFalse("a detected minimap box is not confirmed", d.minimap.boxConfirmed)
        assertNotNull("a steady dashboard marker was found", d.marker)
        assertTrue(s.state().hudBoxes.isNotEmpty())
        assertTrue(s.state().frames.any { it.evidence == ScreenEvidence.DRIVING_LIKELY })
        assertEquals(SetupPhase.REVIEW_REQUIRED, s.state().phase)
    }

    @Test
    fun duplicateAnalysisJobsArePrevented() {
        val s = session()
        s.importFrames((0 until 12).map { Toe3Scene().frame(it) }, FrameOriginKind.CLIP)
        val a = s.beginAnalysis()
        assertNotNull(a)
        assertNull("a second job while one runs", s.beginAnalysis())
        assertFalse("no edits race with a running analysis", s.edit { DraftEdits.place(it, CalibRole.BRAKE, 0.5f, 0.5f) })
    }

    @Test
    fun cancelledAnalysisResultIsIgnored() {
        val s = session()
        s.importFrames((0 until 30).map { Toe3Scene().frame(it) }, FrameOriginKind.CLIP)
        val job = s.beginAnalysis()!!
        s.cancel()
        assertEquals(SetupPhase.CANCELLED, s.state().phase)
        val r = SetupAnalysis.run(job.frames, job.selectedId)!!
        assertFalse(s.completeAnalysis(job, r))
        assertEquals(0, s.state().draft.controls.size)
    }

    @Test
    fun concurrentCancellationDropsTheLateResult() {
        val s = session()
        s.importFrames((0 until 30).map { Toe3Scene().frame(it) }, FrameOriginKind.CLIP)
        val job = s.beginAnalysis()!!
        val started = CountDownLatch(1)
        val applied = AtomicBoolean(true)
        val worker = Thread {
            started.countDown()
            val r = SetupAnalysis.run(job.frames, job.selectedId)
            applied.set(r != null && s.completeAnalysis(job, r))
        }
        worker.start()
        assertTrue(started.await(5, TimeUnit.SECONDS))
        s.cancel()
        worker.join(30_000)
        assertFalse(applied.get())
        assertEquals(SetupPhase.CANCELLED, s.state().phase)
        // A new analysis afterwards works normally.
        val job2 = s.beginAnalysis()!!
        assertNotEquals(job.token, job2.token)
        assertTrue(s.completeAnalysis(job2, SetupAnalysis.run(job2.frames, job2.selectedId)!!))
    }

    @Test
    fun analysisCanBeCancelledCooperatively() {
        val frames = (0 until 20).map { Toe3Scene().frame(it) }
        val s = session()
        s.importFrames(frames, FrameOriginKind.CLIP)
        val job = s.beginAnalysis()!!
        assertNull(SetupAnalysis.run(job.frames, job.selectedId) { true })
    }

    @Test
    fun missingControlsStayMissingAfterAnalysis() {
        val s = analysed(Toe3Scene().also { it.showPedals = false })
        val d = s.state().draft
        assertEquals(DetectionStatus.NONE, d.controls[CalibRole.ACCELERATOR]!!.status)
        assertEquals(DetectionStatus.NONE, d.controls[CalibRole.BRAKE]!!.status)
        assertTrue(d.missingRequired.contains("Accelerator"))
        assertTrue(d.missingRequired.contains("Brake"))
    }

    @Test
    fun aFailedAnalysisLeavesManualPlacementPossible() {
        val s = session()
        s.importFrames(listOf(Toe3Scene().frame(1)), FrameOriginKind.SCREENSHOT)
        s.selectDrivingFrame(s.state().frames.single().id)
        val job = s.beginAnalysis()!!
        val r = SetupAnalysis.run(job.frames, job.selectedId)!! // one picture: nothing can be separated
        assertTrue(s.completeAnalysis(job, r))
        assertTrue(r.detections.values.all { it.status == DetectionStatus.NONE })
        assertTrue(s.edit { DraftEdits.place(it, CalibRole.ACCELERATOR, 0.88f, 0.75f) })
        assertTrue(s.state().draft.confirmed(CalibRole.ACCELERATOR))
    }

    // ---- review / placement / undo -----------------------------------------------------------------------------------

    @Test
    fun confirmingTheWheelChoosesSliderSteeringWithItsRadius() {
        val s = analysed()
        s.edit { DraftEdits.confirm(it, CalibRole.STEER_WHEEL) }
        val d = s.state().draft
        assertEquals(SteeringMode.SLIDER, d.steering)
        assertTrue("radius from the wheel width: ${d.steerRadius}", d.steerRadius!! in 0.05f..0.1f)
        assertEquals(listOf(CalibRole.ACCELERATOR, CalibRole.BRAKE, CalibRole.STEER_WHEEL), d.requiredRoles)
    }

    @Test
    fun aLowConfidenceCandidateCanBeRejectedAndIsNotReproposed() {
        val s = analysed()
        val before = s.state().draft.controls[CalibRole.BRAKE]!!
        assertTrue(before.confidence <= 0.6f)
        s.edit { DraftEdits.reject(it, CalibRole.BRAKE) }
        assertEquals(DetectionStatus.REJECTED, s.state().draft.controls[CalibRole.BRAKE]!!.status)
        // Analysing again proposes the same spot: the person's "no" stands.
        val job = s.beginAnalysis()!!
        s.completeAnalysis(job, SetupAnalysis.run(job.frames, job.selectedId)!!)
        assertEquals(DetectionStatus.REJECTED, s.state().draft.controls[CalibRole.BRAKE]!!.status)
    }

    @Test
    fun manualPlacementWinsOverALaterAnalysis() {
        val s = analysed()
        s.edit { DraftEdits.place(it, CalibRole.ACCELERATOR, 0.5f, 0.5f) }
        val job = s.beginAnalysis()!!
        s.completeAnalysis(job, SetupAnalysis.run(job.frames, job.selectedId)!!)
        val a = s.state().draft.controls[CalibRole.ACCELERATOR]!!
        assertEquals(DetectionSource.USER, a.source)
        assertEquals(0.5f, a.x, 1e-6f)
    }

    @Test
    fun undoAndRedoWalkThroughEdits() {
        val s = analysed()
        s.edit { DraftEdits.confirm(it, CalibRole.ACCELERATOR) }
        s.edit { DraftEdits.place(it, CalibRole.BRAKE, 0.7f, 0.8f) }
        assertTrue(s.state().canUndo)
        assertTrue(s.undo())
        assertEquals(DetectionStatus.NEEDS_CONFIRMATION, s.state().draft.controls[CalibRole.BRAKE]!!.status)
        assertTrue(s.state().canRedo)
        assertTrue(s.redo())
        assertEquals(DetectionSource.USER, s.state().draft.controls[CalibRole.BRAKE]!!.source)
        s.edit { DraftEdits.reset(it, CalibRole.BRAKE) }
        assertFalse("a new edit clears redo", s.state().canRedo)
        assertNull(s.state().draft.controls[CalibRole.BRAKE])
    }

    @Test
    fun choosingADifferentlyShapedPictureClearsPositionsMadeForTheOldShape() {
        val s = session()
        s.importFrames(listOf(Toe3Scene().frame(1)), FrameOriginKind.SCREENSHOT)
        s.selectDrivingFrame(s.state().frames.single().id)
        s.edit { DraftEdits.place(it, CalibRole.ACCELERATOR, 0.9f, 0.8f) }
        s.importFrames(listOf(Toe3Scene(w = 300, h = 300).frame(1)), FrameOriginKind.SCREENSHOT)
        s.selectDrivingFrame(s.state().frames.last().id)
        assertEquals(0, s.state().draft.controls.size)
    }

    // ---- validation --------------------------------------------------------------------------------------------------

    @Test
    fun saveIsBlockedUntilSomethingValidIsConfirmed() {
        val s = analysed()
        val issues = s.validate()
        assertTrue(issues.any { it.severity == IssueSeverity.ERROR })
        assertFalse(s.state().canSave)
        s.edit { DraftEdits.confirm(it, CalibRole.ACCELERATOR) }
        assertFalse("an edit invalidates the old validation", s.state().validatedCurrent)
        s.validate()
        assertTrue(s.state().canSave)
        assertEquals(SetupPhase.VALIDATING, s.state().phase)
    }

    @Test
    fun obviousMistakesAreErrors() {
        val base = SetupDraft(layout = dev.toe3autopilot.core.calibration.LayoutSignature(480, 216))
        var d = DraftEdits.place(base, CalibRole.ACCELERATOR, 0.80f, 0.80f)
        d = DraftEdits.place(d, CalibRole.BRAKE, 0.81f, 0.80f)
        assertTrue(DraftValidator.validate(d).any { it.severity == IssueSeverity.ERROR && it.message.contains("same spot") })
        var b = DraftEdits.place(base, CalibRole.STEER_LEFT, 0.3f, 0.8f)
        b = DraftEdits.place(b, CalibRole.STEER_RIGHT, 0.1f, 0.8f)
        assertTrue(DraftValidator.validate(b).any { it.severity == IssueSeverity.ERROR && it.message.contains("Swap") })
        var m = DraftEdits.setMinimapBox(DraftEdits.place(base, CalibRole.ACCELERATOR, 0.9f, 0.8f), Roi(0.8f, 0.05f, 0.97f, 0.4f))
        m = DraftEdits.setTruck(m, Point(0.1f, 0.9f))
        m = DraftEdits.setRouteColor(m, ColorTarget(120, 120, 120))
        val mi = DraftValidator.validate(m)
        assertTrue(mi.any { it.message.contains("inside the minimap") })
        assertTrue(mi.any { it.message.contains("grey") })
    }

    // ---- save / restore ------------------------------------------------------------------------------------------------

    @Test
    fun onlyConfirmedControlsAreSavedAndTheProfileRoundTrips() {
        val s = analysed()
        s.edit { DraftEdits.confirm(it, CalibRole.ACCELERATOR) }
        s.edit { DraftEdits.confirm(it, CalibRole.STEER_WHEEL) }
        // brake stays a candidate
        s.validate()
        val st = s.state()
        val r = DraftApply.apply(null, st.draft, st.selectedFrame!!.frame, "test", "pkg", clock.now)
        assertTrue(r.problem, r.ok)
        val p = r.profile!!
        assertNotNull(p.control(Control.ACCELERATOR))
        assertNull("candidates are never saved", p.control(Control.BRAKE))
        assertNotNull(p.control(Control.STEER_CENTER))
        assertEquals(SteeringMode.SLIDER, p.steeringMode)
        assertTrue(r.skipped.any { it.startsWith("Brake") })
        assertTrue(r.notReadyToDrive.any { it.contains("BRAKE") })
        assertTrue(r.patches.containsKey(DraftApply.MARKER))
        assertEquals(listOf(DraftApply.MARKER), p.stateRules[GameState.DRIVING])
        assertEquals("216", p.extras[LayoutCheck.HEIGHT_KEY])
        // Survives the strict text format.
        assertEquals(ProfileCodec.format(p), ProfileCodec.format(ProfileCodec.parse(ProfileCodec.format(p))))
    }

    @Test
    fun aProfileForAnotherScreenShapeIsNotMergedIntoTheNewOne() {
        val s = analysed()
        s.edit { DraftEdits.confirm(it, CalibRole.ACCELERATOR) }
        val old = TestProfiles.full().copy(extras = mapOf(LayoutCheck.HEIGHT_KEY to "300"), referenceWidth = 300)
        val r = DraftApply.apply(old, s.state().draft, s.state().selectedFrame!!.frame, "new", "pkg", clock.now)
        assertTrue(r.ok)
        assertNull("the old brake must not leak in", r.profile!!.control(Control.BRAKE))
        assertTrue(r.warnings.any { it.contains("different screen") })
    }

    @Test
    fun theOptionalDestinationMarkerIsValidatedSavedAndEditable() {
        val s = analysed()
        s.edit { DraftEdits.confirm(it, CalibRole.ACCELERATOR) }
        val box = Roi(0.79f, 0.05f, 0.97f, 0.42f)
        s.edit { DraftEdits.setMinimapBox(it, box) }
        s.edit { DraftEdits.setRouteColor(it, ColorTarget(200, 40, 220, 45)) }
        s.edit { DraftEdits.setTruck(it, Point(0.88f, 0.3f)) }
        // Same colour as the route line: cannot mark the destination.
        s.edit { DraftEdits.setDestinationColor(it, ColorTarget(205, 45, 215, 50)) }
        assertTrue(s.validate().any { it.severity == IssueSeverity.ERROR && it.message.contains("destination marker") })
        assertFalse(s.state().canSave)
        // A distinct colour is fine and ends up as the colour region the delivery detection looks for.
        s.edit { DraftEdits.setDestinationColor(it, ColorTarget(240, 200, 20, 50)) }
        assertTrue(s.validate().none { it.severity == IssueSeverity.ERROR })
        val st = s.state()
        val r = DraftApply.apply(null, st.draft, st.selectedFrame!!.frame, "dest", "pkg", clock.now)
        assertTrue(r.problem, r.ok)
        val spec = r.profile!!.colors[DraftApply.DESTINATION]
        assertNotNull(spec)
        assertEquals(box, spec!!.roi)
        assertEquals(240, spec.target.r)
        assertTrue(ProfileReadiness.advice(r.profile!!, AutomationSettings()).none { it.contains("No destination cue") })
        // Round trips through the saved-draft format and back from the profile for editing.
        val parsed = DraftCodec.parse(DraftCodec.format(st.draft, null, true))
        assertEquals(240, parsed.draft.minimap.destinationColor!!.r)
        assertEquals(240, DraftApply.fromProfile(r.profile!!).minimap.destinationColor!!.r)
        // Removing it in a later setup removes it from the profile (the setup is authoritative for the minimap).
        val cleared = DraftEdits.setDestinationColor(st.draft, null)
        val r2 = DraftApply.apply(r.profile, cleared, st.selectedFrame!!.frame, "dest", "pkg", clock.now)
        assertNull(r2.profile!!.colors[DraftApply.DESTINATION])
        assertTrue(r2.warnings.any { it.contains("destination marker") })
    }

    @Test
    fun aDraftSurvivesAnAppRestart() {
        val s = analysed()
        s.edit { DraftEdits.confirm(it, CalibRole.ACCELERATOR) }
        s.edit { DraftEdits.place(it, CalibRole.BRAKE, 0.79f, 0.8f) }
        s.edit { DraftEdits.setMinimapBox(it, Roi(0.79f, 0.05f, 0.97f, 0.42f)) }
        val text = DraftCodec.format(s.state().draft, "Pixel", dirty = true)
        val parsed = DraftCodec.parse(text)
        assertTrue(parsed.warnings.isEmpty())
        val picture = s.state().selectedFrame!!.frame
        val restored = session()
        restored.restore(parsed.draft, picture, parsed.savedProfile, parsed.dirty)
        val st = restored.state()
        assertEquals(SetupPhase.REVIEW_REQUIRED, st.phase)
        assertEquals(DetectionStatus.CONFIRMED, st.draft.controls[CalibRole.ACCELERATOR]!!.status)
        assertEquals(0.79f, st.draft.controls[CalibRole.BRAKE]!!.x, 1e-4f)
        assertTrue(st.draft.minimap.boxConfirmed)
        assertEquals(st.frames.single().id, st.draft.drivingFrameId)
        assertEquals("Pixel", st.savedProfile)
        assertTrue(st.dirty)
    }

    @Test
    fun aCorruptedSavedDraftIsRepairedNotTrusted() {
        val text = """
            version=1
            layout=480x216
            control.ACCELERATOR=NEEDS_CONFIRMATION|0.99|0.9|0.8|SHAPE|-|x
            control.BRAKE=garbage
            control.NOT_A_ROLE=CONFIRMED|1|0.1|0.1|USER|-|x
            minimap.confirmed=true
        """.trimIndent()
        val p = DraftCodec.parse(text)
        assertEquals(0.6f, p.draft.controls[CalibRole.ACCELERATOR]!!.confidence, 1e-6f)
        assertNull(p.draft.controls[CalibRole.BRAKE])
        assertFalse(p.draft.minimap.boxConfirmed)
        assertEquals(2, p.warnings.size)
    }

    @Test
    fun savingAndEditingMoveThroughTheExpectedPhases() {
        val s = analysed()
        s.edit { DraftEdits.confirm(it, CalibRole.ACCELERATOR) }
        s.validate()
        s.markSaved("Pixel")
        assertEquals(SetupPhase.CONFIRMED, s.state().phase)
        assertFalse(s.state().dirty)
        s.edit { DraftEdits.confirm(it, CalibRole.BRAKE) }
        assertEquals(SetupPhase.REVIEW_REQUIRED, s.state().phase)
        assertTrue(s.state().dirty)
    }

    @Test
    fun resetClearsTheSetupButIsAFreshStart() {
        val s = analysed()
        s.resetAll()
        assertEquals(SetupPhase.NOT_STARTED, s.state().phase)
        assertTrue(s.state().frames.isEmpty())
        assertFalse(s.state().canUndo)
    }

    // ---- steps -------------------------------------------------------------------------------------------------------

    @Test
    fun stepStatesFollowTheRealState() {
        val fresh = SetupSteps.of(session().state(), receivingGame = false)
        assertEquals(10, fresh.size)
        assertEquals(StepStatus.TODO, fresh[0].status)
        assertEquals(StepStatus.BLOCKED, fresh.first { it.step == SetupStep.SELECT_SCREEN }.status)
        assertEquals(StepStatus.BLOCKED, fresh.first { it.step == SetupStep.SAVE }.status)

        val s = analysed()
        var steps = SetupSteps.of(s.state(), receivingGame = true)
        assertEquals(StepStatus.DONE, steps.first { it.step == SetupStep.CONNECT }.status)
        assertEquals(StepStatus.DONE, steps.first { it.step == SetupStep.ANALYZE }.status)
        assertEquals(StepStatus.TODO, steps.first { it.step == SetupStep.REVIEW }.status)
        assertEquals(StepStatus.TODO, steps.first { it.step == SetupStep.PLACE }.status)

        s.edit { DraftEdits.confirm(it, CalibRole.ACCELERATOR) }
        s.edit { DraftEdits.confirm(it, CalibRole.BRAKE) }
        s.edit { DraftEdits.confirm(it, CalibRole.STEER_WHEEL) }
        s.edit { DraftEdits.skipMinimap(it) }
        steps = SetupSteps.of(s.state(), receivingGame = true)
        assertEquals(StepStatus.DONE, steps.first { it.step == SetupStep.PLACE }.status)
        assertEquals(StepStatus.SKIPPED, steps.first { it.step == SetupStep.MINIMAP }.status)
        s.validate()
        s.markSaved("p")
        steps = SetupSteps.of(s.state(), receivingGame = true)
        assertEquals(StepStatus.DONE, steps.first { it.step == SetupStep.SAVE }.status)
        assertEquals(StepStatus.TODO, steps.first { it.step == SetupStep.TEST }.status)
    }

    // ---- safe test -----------------------------------------------------------------------------------------------------

    @Test
    fun theSafeTestRecognisesTheDrivingScreenAndNeedsNoInput() {
        val scene = Toe3Scene()
        val s = analysed(scene)
        for (r in listOf(CalibRole.ACCELERATOR, CalibRole.BRAKE, CalibRole.STEER_WHEEL)) s.edit { DraftEdits.confirm(it, r) }
        s.edit { DraftEdits.confirmMinimapBox(it) }
        s.validate()
        val st = s.state()
        val r = DraftApply.apply(null, st.draft, st.selectedFrame!!.frame, "p", "pkg", clock.now)
        assertTrue(r.problem, r.ok)
        val store = MapTemplateStore(r.patches.toMutableMap())
        val live = scene.frame(77)
        val report = SetupVerifier.verify(r.profile!!, store, live, clock.now)
        val recog = report.checks.first { it.title.contains("driving screen") }
        assertTrue(recog.detail, recog.ok)
        val controls = report.checks.first { it.title.contains("controls") }
        assertTrue(controls.detail, controls.ok)
        assertTrue(report.checks.first { it.title.contains("Everything needed") }.ok)
        // A screen without the HUD (a menu) is not recognised.
        val menu = Toe3Scene().also { it.showHud = false }.frame(5)
        assertFalse(SetupVerifier.verify(r.profile!!, store, menu, clock.now).checks.first { it.title.contains("driving screen") }.ok)
        // Without a picture the test says so instead of passing.
        assertFalse(SetupVerifier.verify(r.profile!!, store, null, clock.now).passed)
    }
}
