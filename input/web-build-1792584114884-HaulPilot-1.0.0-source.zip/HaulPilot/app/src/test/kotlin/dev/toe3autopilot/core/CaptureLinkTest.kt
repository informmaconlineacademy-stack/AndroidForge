package dev.toe3autopilot.core

import dev.toe3autopilot.core.calibration.CalibRole
import dev.toe3autopilot.core.calibration.TapSnap
import dev.toe3autopilot.core.capture.CaptureFault
import dev.toe3autopilot.core.capture.CaptureHealthMonitor
import dev.toe3autopilot.core.capture.FrameGate
import dev.toe3autopilot.core.capture.FrameOrigin
import dev.toe3autopilot.core.capture.LinkAction
import dev.toe3autopilot.core.capture.LinkState
import dev.toe3autopilot.core.capture.ScreenLink
import dev.toe3autopilot.core.vision.Frame
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

/** Which pictures count as the game: the root cause of "calibration receives nothing". */
class FrameGateTest {
    @Test
    fun theGameIsOnlyTheSelectedPackageAndHaulPilotIsNever() {
        assertEquals(FrameOrigin.OWN_APP, FrameGate.classify(true, true, "game", "game"))
        assertEquals(FrameOrigin.GAME, FrameGate.classify(false, true, "game", "game"))
        assertEquals(FrameOrigin.OTHER_APP, FrameGate.classify(false, true, "com.other", "game"))
        assertEquals("cannot tell without accessibility", FrameOrigin.UNKNOWN, FrameGate.classify(false, false, null, "game"))
        assertTrue(FrameGate.analysable(FrameOrigin.GAME) && FrameGate.analysable(FrameOrigin.UNKNOWN))
        assertFalse(FrameGate.analysable(FrameOrigin.OWN_APP) || FrameGate.analysable(FrameOrigin.OTHER_APP))
    }

    @Test
    fun launchersKeyboardsAndHaulPilotCanNeverBeAdoptedAsTheGame() {
        val own = "com.praju12.haulpilot"
        assertFalse(FrameGate.couldBeGame("com.google.android.apps.nexuslauncher", own))
        assertFalse(FrameGate.couldBeGame("com.android.systemui", own))
        assertFalse(FrameGate.couldBeGame("com.samsung.android.honeyboard.inputmethod", own))
        assertFalse(FrameGate.couldBeGame(own, own))
        assertTrue(FrameGate.couldBeGame("com.some.studio.truckgame", own))
    }

    @Test
    fun theInstalledGameIsFoundByItsName() {
        val apps = listOf("Chrome" to "com.android.chrome", "Truckers of Europe 3" to "com.studio.toe3real", "Maps" to "x")
        assertEquals("com.studio.toe3real", FrameGate.findInstalledGame(apps))
        assertNull(FrameGate.findInstalledGame(listOf("Chrome" to "com.android.chrome")))
    }
}

/** The connection status never claims "connected" without real pictures. */
class ScreenLinkTest {
    private val clock = FakeClock()
    private fun monitor() = CaptureHealthMonitor(clock)

    @Test
    fun permissionDialogAndDenial() {
        assertEquals(LinkState.WAITING_FOR_PERMISSION, ScreenLink.status(true, false, monitor().diagnose(), null, null, null).state)
        val m = monitor().also { it.onFault(CaptureFault.PERMISSION_DENIED) }
        val s = ScreenLink.status(false, false, m.diagnose(), null, null, null)
        assertEquals(LinkState.FAILED, s.state)
        assertEquals(LinkAction.RETRY, s.action)
    }

    @Test
    fun notConnectedUntilTheFirstPictureArrives() {
        assertEquals(LinkState.NOT_CONNECTED, ScreenLink.status(false, false, monitor().diagnose(), null, null, null).state)
        val m = monitor().also { it.onCaptureStarted() }
        val waiting = ScreenLink.status(false, true, m.diagnose(), FrameOrigin.GAME, null, "game")
        assertEquals(LinkState.NOT_CONNECTED, waiting.state)
        assertFalse(waiting.receivingGame)
    }

    @Test
    fun noPicturesAtAllIsAFailureNotAConnection() {
        val m = monitor().also { it.onCaptureStarted() }
        clock.now += 30_000
        assertEquals(LinkState.FAILED, ScreenLink.status(false, true, m.diagnose(), FrameOrigin.GAME, null, "game").state)
    }

    @Test
    fun stalePicturesWhileTheGameIsInFrontAreReported() {
        val m = monitor().also { it.onCaptureStarted() }
        val d = m.diagnose()
        val fresh = ScreenLink.status(false, true, d.copy(kind = dev.toe3autopilot.core.capture.DiagnosisKind.HEALTHY), FrameOrigin.GAME, 500, "game")
        assertEquals(LinkState.CONNECTED, fresh.state)
        assertTrue(fresh.receivingGame)
        val stale = ScreenLink.status(false, true, d.copy(kind = dev.toe3autopilot.core.capture.DiagnosisKind.HEALTHY), FrameOrigin.GAME, ScreenLink.STALE_MS + 1, "game")
        assertEquals(LinkState.FAILED, stale.state)
        assertEquals(LinkAction.RETRY, stale.action)
    }

    @Test
    fun theWrongAppInFrontIsSaidAndCanBeFixed() {
        val d = monitor().diagnose().copy(kind = dev.toe3autopilot.core.capture.DiagnosisKind.HEALTHY)
        val other = ScreenLink.status(false, true, d, FrameOrigin.OTHER_APP, 300, "com.other")
        assertEquals(LinkState.CONNECTED, other.state)
        assertFalse(other.receivingGame)
        assertEquals(LinkAction.CHOOSE_GAME, other.action)
        assertTrue(other.detail.contains("com.other"))
        val own = ScreenLink.status(false, true, d, FrameOrigin.OWN_APP, 300, "x")
        assertFalse(own.receivingGame)
        assertEquals(LinkAction.OPEN_GAME, own.action)
    }
}

class TapSnapTest {

    @Test
    fun aTapSnapsToTheButtonUnderTheFingerOrMakesASensibleBox() {
        val scene = SynthHud()
        val frames = (0 until 30).map { scene.frame(it, it * 250L, moving = true, speed = it * 7) }
        val hud = dev.toe3autopilot.core.calibration.HudAnalyzer.analyse(frames)
        assertTrue(hud.problem ?: "", hud.ok)
        val (bx, by) = scene.center("brake")
        val box = TapSnap.boxFor(hud, bx, by, aspect = 320f / 180f)
        assertTrue("snapped box contains the tap", bx in box.left..box.right && by in box.top..box.bottom)
        assertTrue("snapped to a button-sized element", (box.right - box.left) < 0.2f)
        val fallback = TapSnap.boxFor(null, 0.99f, 0.01f, aspect = 1.8f)
        assertTrue(fallback.right <= 1f && fallback.top >= 0f)
    }

}
