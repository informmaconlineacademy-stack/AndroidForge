package dev.toe3autopilot.core

import dev.toe3autopilot.core.calibration.CalibRole
import dev.toe3autopilot.core.calibration.ControlCandidateDetector
import dev.toe3autopilot.core.calibration.ControlDetection
import dev.toe3autopilot.core.calibration.DetectionSource
import dev.toe3autopilot.core.calibration.DetectionStatus
import dev.toe3autopilot.core.calibration.HudAnalyzer
import dev.toe3autopilot.core.calibration.VideoCalibrationAnalyzer
import dev.toe3autopilot.core.calibration.VideoInfo
import dev.toe3autopilot.core.vision.Frame
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ControlCandidateTest {
    private fun frames(scene: Toe3Scene, n: Int = 45, moving: Boolean = true): List<Frame> = (0 until n).map { scene.frame(it, moving) }

    private fun detect(scene: Toe3Scene, moving: Boolean = true): ControlCandidateDetector.Result {
        val f = frames(scene, moving = moving)
        return ControlCandidateDetector.detect(HudAnalyzer.analyse(f), f)
    }

    private fun assertCandidate(d: ControlDetection?, truth: dev.toe3autopilot.core.vision.Roi, minIou: Float = 0.5f) {
        assertNotNull(d)
        d!!
        assertEquals("${d.role} status", DetectionStatus.NEEDS_CONFIRMATION, d.status)
        assertEquals(DetectionSource.SHAPE, d.source)
        assertTrue("${d.role} confidence ${d.confidence} must stay below the shape cap", d.confidence <= ControlDetection.SHAPE_MAX_CONFIDENCE)
        assertFalse("a candidate is never usable by itself", d.status.usable)
        val iou = iouOf(d.box!!, truth)
        assertTrue("${d.role} box ${d.box?.format()} vs truth ${truth.format()} IoU $iou", iou >= minIou)
        assertTrue("evidence is reported", d.evidence.size >= 2)
    }

    @Test
    fun theOldPressedStateAnalysisFindsNoPedalsOnTranslucentControlsThatNeverChange() {
        // Root cause of "no driving controls were found": the pedals of this scene look the same pressed or not.
        val f = frames(Toe3Scene())
        val v = VideoCalibrationAnalyzer.analyse(VideoInfo(15_000, 480, 216), f.size, f)
        assertEquals(DetectionStatus.NONE, v.detections[CalibRole.ACCELERATOR]!!.status)
        assertEquals(DetectionStatus.NONE, v.detections[CalibRole.BRAKE]!!.status)
    }

    @Test
    fun pedalsAreSeparatedEvenWhenAPersistentRoadEdgeTouchesBoth() {
        val s = Toe3Scene()
        val hud = HudAnalyzer.analyse(frames(s))
        assertTrue(hud.elements.any { iouOf(it.box, s.brake) > 0.6f })
        assertTrue(hud.elements.any { iouOf(it.box, s.accelerator) > 0.6f })
        assertTrue("no element may span both pedals", hud.elements.none { it.box.bottom > s.brake.top && it.box.top < s.brake.bottom && it.box.left < s.brake.right && it.box.right > s.accelerator.left })
    }

    @Test
    fun steeringWheelRimIsOneElement() {
        val s = Toe3Scene()
        val hud = HudAnalyzer.analyse(frames(s))
        val wheel = hud.elements.maxByOrNull { iouOf(it.box, s.wheelBox) }!!
        assertTrue(iouOf(wheel.box, s.wheelBox) > 0.7f)
        assertTrue("ring-ness ${wheel.ringness}", wheel.ringness > 0.9f)
    }

    @Test
    fun wheelLayoutGivesPedalsWheelAndMinimapAsCandidates() {
        val s = Toe3Scene()
        val r = detect(s)
        assertCandidate(r.detections[CalibRole.ACCELERATOR], s.accelerator)
        assertCandidate(r.detections[CalibRole.BRAKE], s.brake)
        assertTrue(r.detections[CalibRole.BRAKE]!!.x < r.detections[CalibRole.ACCELERATOR]!!.x)
        assertCandidate(r.detections[CalibRole.STEER_WHEEL], s.wheelBox)
        assertEquals(DetectionStatus.NONE, r.detections[CalibRole.STEER_LEFT]!!.status)
        assertEquals(DetectionStatus.NONE, r.detections[CalibRole.STEER_RIGHT]!!.status)
        assertEquals("reverse is never guessed", DetectionStatus.NONE, r.detections[CalibRole.GEAR_REVERSE]!!.status)
        val mm = r.minimap
        assertNotNull(mm)
        assertTrue("minimap ${mm!!.box.format()}", iouOf(mm.box, s.minimap) > 0.7f)
        assertNotNull("the orange route line is picked up", mm.routeColorRgb)
        val rgb = mm.routeColorRgb!!
        assertTrue("route colour is orange-ish: ${Integer.toHexString(rgb)}", ((rgb shr 16) and 0xFF) > 200 && (rgb and 0xFF) < 80)
    }

    @Test
    fun arrowLayoutGivesLeftAndRightButtons() {
        val s = Toe3Scene().also { it.wheel = false }
        val r = detect(s)
        assertCandidate(r.detections[CalibRole.STEER_LEFT], s.left)
        assertCandidate(r.detections[CalibRole.STEER_RIGHT], s.right)
        assertEquals(DetectionStatus.NONE, r.detections[CalibRole.STEER_WHEEL]!!.status)
        assertCandidate(r.detections[CalibRole.ACCELERATOR], s.accelerator)
        assertCandidate(r.detections[CalibRole.BRAKE], s.brake)
    }

    @Test
    fun theStaticTrailerIsNeverProposedAsAControl() {
        val r = detect(Toe3Scene())
        val trailer = dev.toe3autopilot.core.vision.Roi(0.40f, 0.28f, 0.60f, 0.82f)
        for (d in r.detections.values) d.box?.let { assertTrue("${d.role} must not sit on the trailer", iouOf(it, trailer) < 0.2f) }
    }

    @Test
    fun missingPedalsStayMissing() {
        val s = Toe3Scene().also { it.showPedals = false }
        val r = detect(s)
        assertEquals(DetectionStatus.NONE, r.detections[CalibRole.ACCELERATOR]!!.status)
        assertEquals(DetectionStatus.NONE, r.detections[CalibRole.BRAKE]!!.status)
        assertTrue(r.notes.any { it.contains("No pedal", ignoreCase = true) })
    }

    @Test
    fun aSinglePedalIsOnlyAWeakCandidateAndTheBrakeIsNotInvented() {
        val s = Toe3Scene().also { it.showBrake = false }
        val r = detect(s)
        val acc = r.detections[CalibRole.ACCELERATOR]!!
        assertEquals(DetectionStatus.NEEDS_CONFIRMATION, acc.status)
        assertTrue("low confidence ${acc.confidence}", acc.confidence <= 0.25f)
        assertTrue(acc.evidence.any { it.contains("WEAK") })
        assertEquals(DetectionStatus.NONE, r.detections[CalibRole.BRAKE]!!.status)
    }

    @Test
    fun aStaticSceneGivesNoCandidates() {
        val r = detect(Toe3Scene(), moving = false)
        assertTrue(r.detections.values.all { it.status == DetectionStatus.NONE })
        assertNull(r.minimap)
    }

    @Test
    fun noHudGivesNoCandidates() {
        val s = Toe3Scene().also { it.showHud = false }
        val r = detect(s)
        assertTrue(r.detections.filterKeys { it != CalibRole.GEAR_REVERSE }.values.none { it.status == DetectionStatus.NEEDS_CONFIRMATION && it.box?.let { b -> b.top > 0.5f } == true && it.role == CalibRole.ACCELERATOR })
        assertNull(r.minimap)
    }

    @Test
    fun noMinimapStaysUnrecognised() {
        val s = Toe3Scene().also { it.showMinimap = false }
        val r = detect(s)
        assertNull(r.minimap)
        assertTrue(r.notes.any { it.contains("No minimap") })
    }

    @Test
    fun emptyInputIsHandled() {
        val hud = HudAnalyzer.analyse(emptyList())
        val r = ControlCandidateDetector.detect(hud, emptyList())
        assertTrue(r.detections.values.all { it.status == DetectionStatus.NONE })
    }

    @Test
    fun weakerTranslucencyStillWorks() {
        val s = Toe3Scene().also { it.hudAlpha = 0.35f }
        val r = detect(s)
        assertCandidate(r.detections[CalibRole.ACCELERATOR], s.accelerator)
        assertCandidate(r.detections[CalibRole.BRAKE], s.brake)
    }
}
