# HaulPilot 1.0.0 — Known limitations

## Verification
* **No APK was built in the development environment.** Google's Maven repository and the Android SDK servers were not
  reachable there, so Gradle could not resolve AGP, Compose or AndroidX. The first real compile is your GitHub Actions run
  (`.github/workflows/build.yml` or the one-file workflow); a debug APK exists only if that run is green.
* The Android and Compose code was type-checked against hand-written stand-ins of the AndroidX APIs (checked against the
  published API signature files). That catches wrong names, types and calls, but not resource/manifest errors, dependency
  resolution, lint findings or anything at run time.
* **Nothing was run on an emulator, a phone or in Truckers of Europe 3.** All detection results come from synthetic
  pictures that imitate the game's layout (`Toe3Scene` in the tests). The real game's graphics, transparency and
  animations may differ; the analysis may then propose fewer candidates, and placing controls by hand is the fallback.
* No release APK: no signing key is configured, and none was created or invented.

## Detection and calibration
* Candidates come from shapes and arrangement only, never from where something sits on the screen. That is deliberate,
  and it means a layout with unusual shapes may yield no candidates at all. Every control can always be placed by hand.
* Evidence scores are capped at 60 % and are not probabilities. Nothing is used until you confirm it.
* Reverse gear is never proposed; place it by hand if parking by reversing is wanted.
* Detection needs at least 10 pictures of the same size, taken while the scenery moves, to separate the fixed controls
  (the live collection takes ~45); a single screenshot only allows manual placement.
* The minimap must be heading-up (the truck always points up). North-up maps are not supported.
* Positions are stored as fractions of the whole display. They stay valid in both landscape directions but not after
  switching between portrait and landscape or to another screen shape; HaulPilot detects that and asks for a new setup
  instead of stretching positions.
* The destination marker can be set up (step 7, optional). The other optional cues of 0.9 (parking area, "parked" cue,
  obstacle cue, pop-up marker) **cannot be set up** in this version; profiles that already have them keep them when
  updated on the same screen shape. Without a parking area the truck stops near the destination and asks you to park.

## Automation
* HaulPilot is a driving **assistant**. It follows the minimap's route line, stops and asks for help whenever it is unsure,
  and cannot read hidden game state (speed, traffic, damage). It is not a reliable self-driving system; stay with the
  phone.
* Emergency Stop releases every automated touch immediately. It cannot stop the truck by itself (it deliberately presses
  nothing, not even the brake), so the game's own physics decide how the truck rolls out.
* Touches use Android's documented accessibility gesture API. Android itself may cancel gestures (for example when a
  system dialog appears); HaulPilot then stops and reports it.
* Watchdog times are configurable within safe limits; very short values can make the automation stop often.

## Platform
* Screen sharing needs Android's consent dialog each time and stops when the phone locks or the system ends it. Some
  manufacturers stop background services aggressively; battery settings may need "no restrictions".
* Play Protect or store policies may warn about apps that use the Accessibility API without being accessibility tools.
  The in-app disclosure is in place; store approval is not guaranteed.
* Tablets, foldables and multi-window were not considered in testing.
* Notification permission is asked right before the first screen-sharing dialog (Android 13+). Without it the
  notification's Emergency Stop is not shown; the in-app bar and the floating button still work.

## Interface
* The new interface has not been seen on a real screen yet; spacing, contrast and touch comfort need a device pass.
* No Compose UI tests or screenshot tests exist; the interface logic that decides what is shown (readiness, setup steps,
  status advice, overlay, editor geometry) is unit-tested as plain Kotlin.
* English only.
