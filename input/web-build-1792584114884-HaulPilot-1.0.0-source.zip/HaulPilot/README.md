# HaulPilot 1.0.0

**Drive smarter. Deliver better.**
*Made by Praju (praju_12)*

HaulPilot is a native Kotlin / Jetpack Compose driving assistant for *Truckers of Europe 3*. It watches the screen (with
your permission), follows the route line on the minimap, slows for bends (and near the destination when its marker is set
up), and stops and asks you whenever it is unsure. **You** choose the job, attach the trailer, unload, collect payment and pick the next job.
Touches go through Android's documented accessibility gesture API, or use **Assisted mode**, which only shows what it
would do. It is an assistant, not a reliable self-driving system.

HaulPilot is an independent app, not affiliated with or endorsed by the developer or publisher of Truckers of Europe 3.

> ## Read this first: what has and has not been verified (1.0.0)
>
> * **No APK has been built from this version yet.** The development environment could not reach Google's Maven
>   repository or the Android SDK servers. Your GitHub Actions run is the first real compile; a debug APK exists only
>   if that run is green.
> * **All 373 JVM unit tests pass** (coordinates, detection on synthetic game-like pictures, Smart Setup state model,
>   profiles, automation safety, readiness, status texts, simulated drives) — see `TEST_REPORT.md`.
> * **The whole Android/Compose layer type-checks** (0 errors) against `android.jar` and hand-written AndroidX stand-ins
>   that were checked against the published API signature files (`tools/typecheck/`). This is not a build.
> * **Nothing has run on a phone, an emulator or in the real game.** `DEVICE_TEST_CHECKLIST.md` lists what to check.

## What is new in 1.0.0
Details: `ROOT_CAUSE_REPORT.md` (what was wrong and how it was fixed), `UI_REDESIGN.md`, `KNOWN_LIMITATIONS.md`,
`ACCEPTANCE_CHECKLIST.md`.
* **Calibration rebuilt from the evidence up.** Candidates come only from shapes and arrangement (pedal pair, mirrored
  arrow buttons, wheel ring, changing minimap), never from screen corners or from assuming a control changes when pressed;
  evidence is capped at 60 % and nothing is used until you confirm it.
* **One coordinate system** (fractions of the whole display) with tested transforms from capture to editor; captured
  frames are cropped to the mirrored display, so picture, markers and touches line up.
* **Smart Setup in ten steps** with one real state model (capturing, analysing, review, validated, saved, failed,
  cancelled), duplicate-job protection, cancel, recovery actions, undo/redo and a draft that survives restarts.
* **Placement editor**: crosshair, trackpad-style drag, loupe, one-pixel nudges, 8× zoom, control switcher, per-control
  reset, confirm.
* **Profiles**: several profiles, crash-safe saves, undo last change, delete with undo, export/import.
* **Safety**: "Ready" only when every prerequisite holds; Emergency Stop releases all touches and presses nothing; held
  touches are released if the automation stalls; configurable watchdogs; red Emergency Stop bar on every screen.
* **New interface**: Dashboard, Smart Setup, Profiles, Settings (dark charcoal-navy, amber primary, cyan accent).

## Using it (once built and installed)
1. **Smart Setup** (bottom navigation): connect the screen, collect pictures while driving (or import screenshots / a
   recording), choose the driving screen, analyse, confirm or place the controls, mark the minimap, check, save, test.
2. Settings → Permissions: turn on the accessibility service (after reading HaulPilot's explanation), or switch on
   Assisted mode in Settings → Touch & coordinates. Start with Assisted mode.
3. In the game: take a job, attach the trailer, drive to a safe start. On the Dashboard, **Start Auto Drive** appears only
   when everything is ready; it switches to the game and counts down.
4. Pause / Resume / Emergency Stop: the red bar in the app, the floating button, or the notification.

## Background operation and storage

* Capture runs in a foreground service (type *mediaProjection*) with a persistent notification (Pause/Resume, End, Emergency stop).
  A small floating button (accessibility overlay, no branding on it) can be dragged to a screen edge and remembers its place; tap it for the
  state, picture-collection progress, Start / Pause / Resume / End and Emergency Stop. Keep it off the calibrated controls.
* The service is not sticky. If Android ends capture the session stops and you must start again (Android asks consent each time).
  Some phones (MIUI/HyperOS, Oppo, Vivo, Huawei, Samsung "sleeping apps") need *No restrictions* in battery settings.
* Frames are analysed in memory at ~480 px and discarded. **No video is recorded.** Stored pictures: small control pictures
  in saved profiles, the one driving picture of an unfinished Smart Setup, and optional low-rate sample snapshots (off by
  default, capped, deletable). Imported clips are read in place and never copied. The app has no `INTERNET` permission.

## Building from a phone (GitHub Actions)

Easiest: the single file **`.github/one-file-build/haulpilot-build.yml`** contains the whole project (regenerate it with
`tools/make-one-file-workflow.py` after changes). Put it in any GitHub repository
as `.github/workflows/haulpilot-build.yml`; GitHub unpacks the project, runs the tests, compiles and offers
**haulpilot-debug-apk** under *Artifacts* only if everything succeeded (otherwise a `build-log`).

This project also contains the regular workflows in `.github/workflows/` (`build.yml`: tests, debug APK, lint report, release
configuration check, optional emulator tests; `unpack-zip.yml`: unpacks an uploaded `project.zip`).

With a computer: JDK 17 + Android SDK 36, then `./gradlew testDebugUnitTest assembleDebug`. Release signing:
`tools/make-keystore.sh`, then `./gradlew assembleRelease` (keystore and passwords stay out of git).

## Permissions

| Permission / capability | Why |
|---|---|
| Screen capture (MediaProjection, consent each time) | See the game screen. In memory only. |
| `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_MEDIA_PROJECTION` | Required to capture while the game is in front. |
| `POST_NOTIFICATIONS` (optional, asked right before the first screen-sharing dialog) | State notification with Emergency Stop, and alerts when a drive stops. |
| `VIBRATE` (optional) | Countdown and alert buzz. |
| Accessibility service (you enable it) | `dispatchGesture` touches, foreground package name, floating panel. Window content is **not** read. |
| Photo Picker / file picker | Chosen videos and screenshots are read once through Android's own pickers; no storage permission. |
| Launcher `<queries>` | List launchable apps to choose the game. |

## Privacy and store publishing
* `PRIVACY.md` — privacy policy (add contact details and host it publicly before publishing).
* `docs/STORE_LISTING.md` — honest listing text, graphics, and what Google Play asks for (Accessibility declaration with a video,
  data safety form). Approval by any store is **not** guaranteed; Play Protect may warn about sideloaded apps using accessibility.
* `docs/RELEASE_CHECKLIST.md`, `docs/ASSETS.md` (icon sources and licences).
* Supported Android versions: 8.0 (API 26) to 16 (API 36). Phone screens; tablets untested.
* Dependencies (Apache 2.0): AndroidX Core, Activity Compose, Lifecycle runtime-compose, Compose BOM 2025.09.00, kotlinx-coroutines; JUnit 4 and AndroidX Test.
  Pinned in `gradle/libs.versions.toml`; not checked against vulnerability databases from the sandbox. Dependabot proposes updates.

## Tests: simulated versus real
See `TEST_REPORT.md` for every command and result (373 JVM tests passing, app layer type-checked, nothing run on a
device). Instrumented tests in `app/src/androidTest` (settings, profile PNG round trip, unfinished-setup restore,
floating-button position, disclosure consent) exist but were never run. **Real-device validation is still required** for
everything Android-specific and for behaviour in the real game.

## Layout
```
app/src/main/kotlin/dev/toe3autopilot/
  core/   Android-free logic: geometry/ (coordinate system), setup/ (Smart Setup state, edits, validation, save),
          calibration/ (fixed-element analysis, candidate detection), profile/ (repository), session/, status/,
          vision/, agents/, capture/, overlay/
  app/    Android layer: MainActivity, AutopilotRuntime, setup/ (SetupController), capture/, input/, data/,
          ui/ (Theme, Icons, Components, AppRoot, Dashboard, Smart Setup + steps, PlacementEditor, Profiles, Settings)
app/src/main/res/   icon, splash, themes, strings
app/src/test/       JVM unit + simulation tests
docs/               store listing, release checklist, assets, store graphics
tools/              offline core tests, offline type-check (not a build), one-file workflow generator, keystore script
.github/            workflows, one-file build, dependabot
```
