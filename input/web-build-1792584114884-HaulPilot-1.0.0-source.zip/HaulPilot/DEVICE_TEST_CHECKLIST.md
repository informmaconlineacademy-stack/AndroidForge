# HaulPilot 1.0.0 — Phone test checklist

Do these on a phone after the GitHub build succeeds. **None of them has been done yet.** Tick only what you actually saw,
and note the phone model, Android version and game version.

## First start and permissions
- [ ] First start: Dashboard shows the welcome card and **"Setup needed"**, never "Ready". Start Auto Drive is disabled and
      "Before you drive" lists what is missing, each with a working button.
- [ ] Bottom navigation: Dashboard, Smart Setup, Profiles, Settings. Back closes a settings page, then returns to Dashboard.
- [ ] Smart Setup step 1 → Connect screen: on Android 13+ the notification question comes first, then Android's
      screen-sharing dialog (choose "Entire screen"). Decline → "Capture failed" with "Ask again".
- [ ] Accept → the top chip shows Connected; with the game in front for a few seconds it shows Live.
- [ ] Settings → Permissions → Turn on (accessibility): HaulPilot's explanation appears first; "Not now" changes nothing;
      "I agree" opens Android's accessibility settings. Coming back, the page shows the new state.
- [ ] Stop sharing from the status bar: the chip and Dashboard say capture ended; nothing restarts by itself.

## Smart Setup (live)
- [ ] Step 2 → Start collecting: the game opens; the floating button shows the count rising only while the game is in
      front; drive normally for ~15 s. Back in HaulPilot the count is 45 (or "Stop and use these" earlier).
- [ ] Collecting while HaulPilot or another app is in front adds nothing; after 60 s without game pictures it stops with
      the right recovery button.
- [ ] Lock the screen while collecting: the collection stops (cancelled), the pictures so far are kept.
- [ ] Rotate while collecting: the collection restarts for the new shape instead of mixing shapes.
- [ ] Step 3: the suggested picture is marked "Suggested", not chosen, until "This is the driving screen" is tapped.
- [ ] Step 4: Analyse shows progress and can be cancelled; tapping Analyse twice starts only one job.
- [ ] Step 5: candidates (if any) are drawn on the right controls; evidence ≤ 60 %; Confirm / Move / Reject work.
- [ ] Step 6 editor: tap places the crosshair; one-finger drag moves it; the loupe shows pixels; arrows move one pixel;
      pinch and ± zoom; the markers stay exactly on the picture while zooming and panning; Undo/Redo; Reset; Confirm.
- [ ] Place two controls on the same spot: the editor refuses to confirm and step 8 reports an error.
- [ ] Step 7: mark the minimap (drag, resize by a corner, move), pick the route colour (grey is refused), mark the truck
      (outside the box is refused). Optional destination marker: the route colour is refused, another colour is
      accepted. "Skip for now" leaves steps 8–10 usable.
- [ ] Step 8 → Check for problems; step 9 → save to a new profile; the result lists what was saved and what is still
      missing.
- [ ] Step 10 → with the game on the driving view and back within 15 s → Run the test: no touch is sent; the checks show.
- [ ] Close HaulPilot from the recent apps during step 6 and open it again: the setup comes back with its picture.

## Smart Setup (imports)
- [ ] Screenshots (Photo Picker, several taken a moment apart while driving) → added, step 3 opens.
- [ ] A screen recording of yourself driving (Photo Picker, and "Find a video in files") → progress, cancel works.

## Profiles
- [ ] New, Rename, Duplicate, Make active, Export (.zip) and Import (the imported copy is not active until you choose).
- [ ] Delete → confirmation → snackbar Undo brings it back.
- [ ] After saving twice: Undo last change restores the earlier version (positions and control pictures).
- [ ] Edit in Smart Setup loads the profile's controls onto the current picture.

## Driving (only after a complete setup)
- [ ] Dashboard shows "Ready to drive" only when all six checks are green.
- [ ] Assisted mode first: the countdown, then hints; no touches are sent.
- [ ] A short real drive with a finger near Emergency Stop. The red bar appears on every screen (also in the editor).
- [ ] Emergency Stop from the app bar, the floating button and the notification releases all touches at once and does
      not press the brake.
- [ ] Pause / Resume; game sent to the background → pause; frozen picture → stop; route lost → asks for help.
- [ ] Settings → Automation & safety is locked during the drive.

## Look and accessibility
- [ ] Text readable in sunlight and at the largest font size; no clipped buttons at 360 dp width.
- [ ] TalkBack reads headings, icon buttons, the step rail and the drive status.
