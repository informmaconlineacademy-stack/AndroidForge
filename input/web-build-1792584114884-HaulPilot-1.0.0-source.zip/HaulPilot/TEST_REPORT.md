# HaulPilot 1.0.0 — Test report

Date: 21 October 2026. Environment: Linux container, JDK 17, Kotlin compiler 2.2.20 (same version as the project), JUnit
4.13.2. **No Android SDK, no Gradle dependency download** (Google's Maven repository and the Android SDK servers are
blocked from this environment), **no emulator, no phone, no game.**

## 1. What was run and the real results

| # | Check | Command | Result |
|---|---|---|---|
| 1 | All JVM unit tests (core: geometry, detection, Smart Setup state, profiles, sessions, safety, status models, simulated game) | `tools/verify-core-offline.sh` (Kotlin embedded in Gradle 8.14.3) | **OK (373 tests)**, 0 failures |
| 2 | Same suite with the project's Kotlin version | kotlinc 2.2.20 `-jvm-target 17`, then `JUnitCore` on every `*Test` class | **OK (373 tests)**, 0 failures |
| 3 | Type-check of the whole app layer (all screens, MainActivity, services, stores) plus the core, against `android.jar` (API 36) and hand-written AndroidX/Compose stand-ins | `tools/typecheck/typecheck.sh` | **0 errors, 0 warnings** (70 source files) |
| 4 | Same, with the Compose compiler plugin's checks (e.g. "@Composable invocations can only happen from a @Composable function") | `tools/typecheck/typecheck.sh --plugin` | **0 front-end errors.** The plugin then stops at code generation because the real Compose runtime is not available here (expected; no classes are produced). A deliberate wrong call in a probe file *is* reported by the plugin, so its checks were active. |
| 5 | Stand-ins versus the published AndroidX API signature files (Compose UI/foundation/runtime 1.9.0-beta01, Material3 1.4.0-beta03, Activity 1.11.0-beta01, Lifecycle runtime-compose 2.9.0-beta01, Core 1.11.0-beta02) | `tools/typecheck/verify_stubs.py` | **229 Kotlin declarations match** (names, order, required/optional parameters). The 8 remaining entries are Java methods whose parameters have no names in the signature files (checked by hand: same types and order) plus `enableEdgeToEdge` (published under its JVM name `EdgeToEdge.enable`, same parameters) and `ServiceCompat.startForeground` (added in androidx.core 1.12; the project uses core-ktx 1.17; already used by 0.9.0). |
| 6 | CI file check steps of `.github/workflows/build.yml` run locally on the project | step scripts extracted and run with `bash -eo pipefail` | "All expected files are present" (70 main / 30 test Kotlin files) |

### Unit tests per class (all passing)
| Area | Test class (tests) |
|---|---|
| Coordinates: display, capture surface letterbox and crop, frame, editor fit, zoom/pan, inverse round trips, rotation of the unit square | `GeometryTest` (20) |
| Editor boxes: corners, resize without flipping, move at edges, hit testing at any zoom | `BoxEditingTest` (7) |
| Candidate detection on a synthetic TOE3-like scene (pedals, wheel or arrow buttons, minimap, hidden brake, no HUD, still frames, never confirmed, confidence cap) | `ControlCandidateTest` (13) |
| Fixed-element separation | `HudAnalyzerTest` (4) |
| Smart Setup state model: capture, duplicate jobs, interruption, permission loss, black/blank/corrupt frames, rotation, stale results, cancel, undo/redo, validation, save, restore, reset, step states, safe test | `SetupSessionTest` (34) |
| Profiles: atomic save, interrupted save recovery, previous version, delete/undo, import, migration | `ProfileRepositoryTest` (12), `ProfileTest` (12), `ProfileArchiveTest` (5), `ProfileEditingTest` (10), `CalibrationChecklistTest` (3) |
| Dashboard readiness ("Ready" only when every prerequisite holds) | `DriveReadinessTest` (6) |
| Automation safety: emergency stop releases only, pause/resume, watchdogs, no auto-resume, typed stop reasons | `SessionManagerTest` (41) |
| Status texts and recovery actions | `StatusAdviceTest` (14), `UserStateMappingTest` (5), `UserStateTest` (2) |
| Floating controls model | `OverlayModelTest` (15) |
| Capture health, frame gate, screen link, frame statistics | `CaptureHealthMonitorTest` (14), `FrameGateTest` (3), `ScreenLinkTest` (5), `FrameStatsTest` (7) |
| Clip import validation and analysis | `VideoValidatorTest` (7), `VideoSamplePlanTest` (4), `VideoCalibrationAnalyzerTest` (10) |
| Driving logic (simulated) | `RoadTrackerTest` (11), `DrivingControllerTest` (10), `NavigationDriveAgentTest` (7), `ParkingAgentTest` (6), `RecoveryAgentTest` (9), `DeliveryAreaDetectorTest` (14), `ControlMapperTest` (8), `PulseDriverTest` (3), `StateDetectorTest` (8), `LayoutCheckTest` (4), `LayoutGateTest` (6), `VisionTest` (14), `SimulatedGameTest` (13) |
| Misc. | `AnalyzerDiagnosisTest` (3), `GuidedSetupTest` (1), `TapSnapTest` (1), `SessionHistoryTest` (2) |

## 2. What was NOT run (and must not be read as passed)

| Not done | Why | Where it happens instead |
|---|---|---|
| Gradle build, `assembleDebug`, lint, resource merging, dexing | Google Maven / Android SDK blocked here | `.github/workflows/build.yml` on GitHub |
| **Debug APK** | as above — **no APK exists from this work** | the `haulpilot-debug-apk` artifact of a green CI run |
| Release APK | no signing material is configured (none was invented) | `tools/make-keystore.sh` + `keystore.properties`, then `assembleRelease` |
| Compose UI tests, screenshot tests | need the real Compose runtime and a device | — (not written) |
| Instrumented tests (`app/src/androidTest`: settings, profile PNG round trip, unfinished-setup restore, floating button position, disclosure consent) | need an emulator | `build.yml` → Run workflow → "device tests" |
| Anything on a phone, MediaProjection, accessibility gestures, the real game | no device | `DEVICE_TEST_CHECKLIST.md` |

The type-check (rows 3–5) proves that the Android and Compose code resolves against faithful stand-ins of the APIs. It
cannot find problems that only appear in a real build (for example resource or manifest errors, Gradle dependency
resolution, R8/lint findings) or at run time.
