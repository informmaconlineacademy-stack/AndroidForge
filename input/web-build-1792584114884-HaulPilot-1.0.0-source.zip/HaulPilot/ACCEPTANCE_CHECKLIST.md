# HaulPilot 1.0.0 — Acceptance checklist

Statuses are only what was actually checked on 21 October 2026:

* **PASS (unit test)** — covered by a JVM unit test that passes (`TEST_REPORT.md`).
* **PASS (type-check)** — Android/Compose code compiles against `android.jar` + API-checked stand-ins; not built, not run.
* **PASS (local run)** — the step itself was executed here.
* **NOT TESTED** — implemented, but needs a phone, an emulator, the real game or the real CI. Not a pass.
* **NOT DONE** — not implemented or not possible here.

## Build and delivery
| Item | Status |
|---|---|
| Complete corrected source project (ZIP) | PASS (local run): packaged |
| Gradle build `testDebugUnitTest assembleDebug` | **NOT TESTED** — dependencies not downloadable here; runs in GitHub Actions |
| Debug APK | **NOT DONE** — no APK was produced here (no claim of a successful build is made) |
| Release APK | **NOT DONE** — no signing configuration exists; none was invented. Release stays unsigned until `keystore.properties` is added |
| Workflow checks that source files exist, uploads the APK only on success, prints an error summary | PASS (local run) for the file checks; full workflow **NOT TESTED** |
| One-file workflow regenerated with this version | PASS (local run): payload checksum verified by unpacking |
| Root-cause report, test report, UI summary, known limitations | PASS: `ROOT_CAUSE_REPORT.md`, `TEST_REPORT.md`, `UI_REDESIGN.md`, `KNOWN_LIMITATIONS.md` |

## Coordinates and placement
| Item | Status |
|---|---|
| Canonical system: normalised display space, `x = sourceX / sourceWidth` | PASS (unit test) `GeometryTest` |
| Letterbox / crop of the capture surface, display size, rotation, zoom/pan, view offset transforms with inverses | PASS (unit test) `GeometryTest` |
| Frames cropped to the mirrored display; touches clamped onto the screen | Core PASS (unit test); capture service PASS (type-check); on device NOT TESTED |
| Insets / density: positions use the whole display; editor works in its own view coordinates | PASS (unit test) for the math; on device NOT TESTED |
| Editor: pinch zoom, pan, crosshair, label, loupe, nudge, undo/redo, per-control reset, reset all with warning, control switcher, confirm | PASS (type-check); geometry and box editing PASS (unit test); on device NOT TESTED |
| No drift between picture and markers (same transform for both) | PASS (unit test) for the transform chain; visually NOT TESTED |
| No need to tap tiny controls (crosshair + trackpad drag + 1-pixel nudges + 48 dp buttons) | PASS (type-check); NOT TESTED on device |

## Detection
| Item | Status |
|---|---|
| Evidence-based candidates only; honest, capped confidence; always needs confirmation | PASS (unit test) `ControlCandidateTest` |
| Never assumes controls change look when pressed; never infers a control from a screen corner alone | PASS (unit test): detection works with no pressed evidence and is placement-independent; code review: no position priors remain |
| Reverse never guessed | PASS (unit test) |
| Works on the real game's graphics | **NOT TESTED** (synthetic pictures only) |

## Calibration state model
| Item | Status |
|---|---|
| NOT_STARTED → CAPTURING → ANALYZING → REVIEW_REQUIRED → VALIDATING → CONFIRMED, plus FAILED / CANCELLED | PASS (unit test) `SetupSessionTest` |
| Duplicate-job prevention, stale results ignored, cancellation | PASS (unit test) |
| Interruption, permission revoked, empty / black / corrupt frames, rotation | PASS (unit test) |
| Retry, data preserved on failure/cancel, restore after restart | PASS (unit test); on-device restart NOT TESTED |
| UI observes the real state (one StateFlow, no second status) | PASS (type-check) |
| Minimap step independent and skippable | PASS (unit test) |
| Driving-screen selection (suggested, never auto-confirmed; shape change warned) | PASS (unit test) + PASS (type-check) |

## Automation safety
| Item | Status |
|---|---|
| Start only with confirmed and validated controls and every prerequisite | PASS (unit test) `DriveReadinessTest`, `SessionManagerTest` |
| Emergency Stop releases input immediately and presses nothing | PASS (unit test) |
| Configurable timeouts / watchdogs, locked during a drive | PASS (unit test) for the session; settings UI PASS (type-check) |
| Dead-man release of held touches | PASS (type-check); NOT TESTED on device |
| Documented APIs only (MediaProjection, AccessibilityService gestures); no root, no hidden injection, no bypasses | PASS (code review) |
| No claim of reliable autonomous driving | PASS (texts in app and docs) |
| Behaviour in the real game | **NOT TESTED** |

## Permissions and services
| Item | Status |
|---|---|
| Asked at the point of need (notifications before screen sharing; accessibility after disclosure) | PASS (type-check); NOT TESTED on device |
| Foreground service type mediaProjection, not sticky, stops on capture end | PASS (type-check); NOT TESTED on device |
| No leaks: jobs cancellable, receivers/projections released on stop | PASS (code review + type-check); NOT TESTED on device |

## Interface
| Item | Status |
|---|---|
| Charcoal-navy / amber / cyan theme; bottom navigation Dashboard, Smart Setup, Profiles, Settings | PASS (type-check) |
| Dashboard never shows "Ready" just because the screen is connected; Start only when ready; Emergency Stop visible during automation | PASS (unit test) for the logic; PASS (type-check) for the screen |
| Ten-step Smart Setup | PASS (type-check); step logic PASS (unit test) |
| Profiles: create, edit, rename, duplicate, activate, delete with confirmation and undo, export/import | Repository PASS (unit test); screen PASS (type-check) |
| Settings: permissions, capture/overlay, touch/coordinates, safety, diagnostics/logs, reset (keeps profiles), version/build | PASS (type-check) |
| Every control works or is disabled with a reason | PASS (code review); NOT TESTED on device |
| Looks right on a real screen, TalkBack, large fonts | **NOT TESTED** |

## Persistence
| Item | Status |
|---|---|
| Atomic saves, previous version kept, crash recovery, migration of the 0.9 profile, validation on load/import | PASS (unit test) `ProfileRepositoryTest`, `ProfileArchiveTest` |
| PNG round trip with the real Android codec, settings round trip | instrumented tests written; **NOT TESTED** (need an emulator) |
