# HaulPilot 1.0.0 — Interface redesign

All screens were rewritten in Jetpack Compose (Material 3) under `app/src/main/kotlin/dev/toe3autopilot/app/ui/`.
The code is type-checked (see `TEST_REPORT.md`); **it has not been seen on a phone yet**, so spacing, contrast and touch
comfort still need a real-device pass (`DEVICE_TEST_CHECKLIST.md`).

## Visual system (`Theme.kt`, `Brand.kt`, `Icons.kt`, `Components.kt`)
* One dark theme: charcoal-navy surfaces in three steps (`#0B0F15` background, `#121821` cards, `#19212C` raised).
* **Amber-orange `#FF9A1F`** only for the one main action of a screen (Start Auto Drive, Confirm, Save).
* **Restrained cyan `#46C2D8`** for selection, the active step and the marker being edited.
* Status colours carry meaning only: green good, yellow needs you, red stop/problem, blue information. Emergency Stop is a
  solid red bar with white text (about 5.3:1).
* Text contrast on the background: primary ~16:1, secondary ~8.6:1, muted ~4.9:1.
* 4-point spacing grid, 16 dp screen gutter, 48 dp minimum touch targets, 16 dp card corners.
* A small line-icon set drawn in code (one stroke weight), so no icon font or image assets are needed.
* TalkBack: headings are marked, icon-only buttons have descriptions, step chips and pictures describe their state, the
  drive status is a polite live region.

## Navigation (`AppRoot.kt`)
Bottom navigation with four destinations — **Dashboard, Smart Setup, Profiles, Settings** — and a top bar with the screen
title and one connection chip (Live / Connected / Waiting / Offline / Capture failed, plus "Touch off" when needed). Back
closes the editor, then a settings page, then returns to the Dashboard. While a drive runs, is arming, is paused or waits
for help, a red **EMERGENCY STOP** bar sits above the navigation on every screen, including the placement editor.

## Dashboard (`DashboardScreen.kt`)
* Drive status card: "Ready to drive" only when all six prerequisites hold (`DriveReadiness`); otherwise "Setup needed",
  "Not ready", "Setting up", or the live state (Starting / Driving / Paused / Needs your help).
* Exactly one main action: **Start Auto Drive** (enabled only when ready, with the number of open checks when not),
  Pause/Stop while driving, Resume/Stop when paused, Cancel start while counting down.
* Up to three situation banners from `StatusAdvice`, each with its real action (reconnect, review controls, resume…).
* "Before you drive" checklist with one action per unmet item; screen connection card; active profile; recent drives.
* First-run welcome card with the three steps; a permanent note that HaulPilot assists and is not a reliable self-driver.

## Smart Setup (`SmartSetupScreen.kt`, `SetupReviewSteps.kt`)
A step rail (1–10, status-coloured, tappable) above the current step, Back / Next below, Undo / Redo and "Start over…" in
the header. The phase pill shows the real job state (Not started, Capturing, Analysing, Needs your review, Validated,
Saved, Stopped with a problem, Cancelled); problems show their recovery action.
1. **Connect** — screen sharing (with what Android will ask), the game, alternatives when capture is blocked.
2. **Capture** — collect ~45 pictures while driving (real count, Stop and use these, Cancel), or import screenshots, a clip
   or recorded snapshots, with progress and cancel.
3. **Driving screen** — large preview of the suggested picture (never auto-confirmed), gallery with evidence labels,
   remove; a warning before switching to a picture of another shape.
4. **Analyse** — what it does and what it never does, progress + cancel, findings, or skip to manual placement.
5. **Review** — each candidate with an evidence meter ("evidence strength, not a probability"), its source and reasons;
   Confirm / Move / Reject.
6. **Place** — steering style (wheel or buttons), steering range, every control with its state, per-control reset, the
   editor, "Reset all controls…" with a warning.
7. **Minimap** — box, route colour (swatch), truck, optional destination marker (must differ from the route colour),
   independent of the rest and skippable; the driving-screen marker.
8. **Validate** — summary, errors (block saving) and warnings with "Fix" links into the editor, what Auto Drive still needs.
9. **Save** — update any existing profile or create a new one; what was saved, skipped and still missing.
10. **Test** — read-only check of the saved profile against a fresh game picture; sends no touches.

## Placement editor (`PlacementEditor.kt`, `SetupPicture.kt`)
Full-screen. Tap places a crosshair; one-finger drag moves it relative to the finger; a loupe shows the real pixels; four
arrow buttons move one picture pixel; pinch or the ± / fit buttons zoom (up to 8×) and pan; a control switcher with
state dots; same-spot warning before confirming; per-control Reset; Undo/Redo; nothing is stored until Confirm. Boxes
(minimap, screen marker) are drawn by dragging, resized by corners, moved from the inside. The route-colour mode shows
the sampled colour and refuses grey/black. Picture and markers share one transform.

## Profiles (`ProfilesScreen.kt`)
List with Active / Ready / "n missing" / Damaged badges and a summary (screen size, pedals, steering, minimap, last
save). Actions: New, Import, Make active, Edit in Smart Setup, Rename, Duplicate, Export (.zip), Undo last change
(confirmation), Delete (confirmation + snackbar Undo). Everything that would change the profile under a running drive is
disabled with the reason shown.

## Settings (`SettingsScreen.kt`)
Permissions & connection (live state of capture, accessibility, notifications, battery, App info) · Game & screen capture
(choose the game from installed apps, capture health, floating button, vibration) · Touch & coordinates (Assisted mode,
display size and shape vs. the profile, where each touch goes in pixels, touch-safety facts) · Automation & safety (speed,
steering, parking, five watchdog timeouts; locked during a drive; restore defaults) · Diagnostics & logs (capture history,
log with share/clear, drive history, sample recording) · Reset (setup, settings, preferences — **profiles are never deleted
here**) · About (version and build from `BuildConfig`, what the app does and does not do, privacy).

## Removed
The 0.9 screens (`AppScreen`, `AutoCalibrateUi`, `AutoCalibrationScreen`, `CalibrateTab`, `CalibrationExtras`,
`CalibrationWorkspace`, `SmartSetupNav`, `HelpTab`, `PermissionsCard`, `AboutPage`, `BrandUi`, `Navigation`) and the
expert template editor. Their functions are covered by the screens above, except the optional extra cues (parking area, parked, obstacle, pop-up — the destination marker *is* available in step 7), which this version cannot set up (see
`KNOWN_LIMITATIONS.md`).
