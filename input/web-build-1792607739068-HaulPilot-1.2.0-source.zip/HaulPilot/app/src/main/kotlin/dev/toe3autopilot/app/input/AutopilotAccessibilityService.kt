package dev.toe3autopilot.app.input

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import dev.toe3autopilot.app.AutopilotRuntime
import dev.toe3autopilot.app.MainActivity
import dev.toe3autopilot.core.overlay.OverlayInputs
import dev.toe3autopilot.core.overlay.OverlayModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Accessibility service used for exactly three things: dispatching the gestures the user enabled automation
 * for, learning which package is in front (package name only; no window content is requested) and drawing the
 * compact floating controls (a small movable button that opens Start / Auto-Calibrate / Pause / Resume / End / Emergency
 * Stop). It does not read touch events, keystrokes or the content of other apps.
 */
class AutopilotAccessibilityService : AccessibilityService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var panel: FloatingControls? = null
    private var panelNote: String? = null
    private var panelFailureLogged = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        AutopilotRuntime.init(this)
        instance = this
        AutopilotRuntime.accessibilityConnected.value = true
        // Any change that affects what the floating panel shows refreshes it.
        scope.launch { AutopilotRuntime.snapshot.collect { panelNote = null; refreshPanel() } }
        scope.launch { AutopilotRuntime.captureActive.collect { refreshPanel() } }
        scope.launch { AutopilotRuntime.options.collect { refreshPanel() } }
        scope.launch { AutopilotRuntime.armedMessage.collect { refreshPanel() } }
        scope.launch { AutopilotRuntime.setup.state.collect { if (!it.phase.busy) panelNote = null; refreshPanel() } }
        scope.launch { AutopilotRuntime.recorder.recording.collect { refreshPanel() } }
        scope.launch { AutopilotRuntime.readiness.collect { refreshPanel() } }
        scope.launch { AutopilotRuntime.captureDiagnosis.collect { refreshPanel() } }
        scope.launch { AutopilotRuntime.link.collect { refreshPanel() } }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        // The tracker ignores our own overlay, the keyboard and the system UI, keeps helper windows (Play services pop-ups)
        // apart from the app in front, and the selected game is never changed by any of this.
        AutopilotRuntime.onWindowEvent(event.packageName?.toString())
        refreshPanel()
    }

    override fun onInterrupt() {
        // The system asked us to stop; the safe response is to lift every touch and end the session.
        AutopilotRuntime.emergencyStop("Accessibility service was interrupted")
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        teardown("Accessibility service was disabled")
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        teardown("Accessibility service was destroyed")
        scope.cancel()
        super.onDestroy()
    }

    private fun teardown(reason: String) {
        val wasActive = AutopilotRuntime.session?.currentSnapshot()?.status?.isActiveLoop == true
        instance = null
        AutopilotRuntime.accessibilityConnected.value = false
        if (wasActive) AutopilotRuntime.emergencyStop(reason)
        AutopilotRuntime.onInputServiceGone()
        hideOverlay()
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        panel?.onScreenChanged()
    }

    /** Rebuilds the floating controls from the app state. Main thread only. */
    private fun refreshPanel() {
        val readiness = AutopilotRuntime.readiness.value
        val inputs = OverlayInputs(
            snapshot = AutopilotRuntime.snapshot.value,
            captureOn = AutopilotRuntime.captureActive.value,
            armedMessage = AutopilotRuntime.armedMessage.value,
            setup = AutopilotRuntime.setup.state.value,
            note = panelNote,
            recordingSnapshots = AutopilotRuntime.recorder.recording.value,
            showWhileCaptureOn = AutopilotRuntime.options.value.showPanel,
            link = AutopilotRuntime.link.value,
            readyToDrive = readiness.isEmpty(),
            notReadyReason = readiness.firstOrNull(),
        )
        val ui = OverlayModel.build(inputs)
        val p = panel ?: FloatingControls(
            this,
            FloatingActions(
                onStartDrive = {
                    val r = AutopilotRuntime.startSession()
                    panelNote = if (r.ok) null else "Cannot start: ${r.problems.firstOrNull() ?: "unknown reason"}"
                    refreshPanel()
                },
                onStartCalibration = {
                    // Auto-Calibrate. The person is looking at the game right now; the panel would cover it, so it closes.
                    val msg = AutopilotRuntime.startAutoCalibrate(fromOverlay = true)
                    // When it started, msg can only be a note (for example that the app in front became the game).
                    val started = AutopilotRuntime.setup.state.value.phase == dev.toe3autopilot.core.setup.SetupPhase.CAPTURING
                    panelNote = msg ?: if (started) null else "Auto-Calibrate could not start. Open HaulPilot to see why."
                    if (started) panel?.collapsePanel()
                    refreshPanel()
                },
                onCancelCalibration = {
                    val setup = AutopilotRuntime.setup
                    // While analysing: cancel it (pictures are kept). While collecting: stop; Auto-Calibrate then analyses
                    // what it has, a manual collection waits for the person in the app.
                    if (setup.state.value.phase == dev.toe3autopilot.core.setup.SetupPhase.ANALYZING) setup.cancel() else setup.stopCapture()
                    panelNote = null
                    refreshPanel()
                },
                onPause = { AutopilotRuntime.pause() },
                onResume = {
                    val r = AutopilotRuntime.resume()
                    panelNote = if (r.ok) null else "Cannot resume: ${r.problems.firstOrNull() ?: "unknown reason"}"
                    refreshPanel()
                },
                onEnd = {
                    if (AutopilotRuntime.armedMessage.value != null) AutopilotRuntime.cancelArmed() else AutopilotRuntime.stopSession()
                },
                onEmergency = { AutopilotRuntime.emergencyStop("Emergency stop pressed on the floating controls") },
                onHide = {
                    AutopilotRuntime.updateOptions { it.copy(showPanel = false) }
                    AutopilotRuntime.notice.value = "The floating button is hidden. It comes back during a drive, or turn it on in Settings."
                },
                onOpenReview = {
                    panel?.collapsePanel()
                    openApp(AutopilotRuntime.OPEN_AUTO_REVIEW)
                },
                onOwnWindows = { regions, covering ->
                    AutopilotRuntime.ownUiRegions = regions
                    AutopilotRuntime.ownUiCovering = covering
                },
            ),
        ).also { panel = it }
        if (!p.show(ui)) {
            // Without the floating controls the app screen and the notification actions still work.
            if (!panelFailureLogged) {
                panelFailureLogged = true
                AutopilotRuntime.noteInputFailure("Could not draw the floating controls")
            }
        }
    }

    private fun hideOverlay() {
        panel?.hide()
        panel = null
        AutopilotRuntime.ownUiRegions = emptyList()
        AutopilotRuntime.ownUiCovering = false
    }

    /**
     * Brings HaulPilot to the front on [screen]. An app whose accessibility service is bound by the system may start its
     * activity from the background (a documented exemption of Android's background-activity rules).
     */
    private fun openApp(screen: String) {
        AutopilotRuntime.openRequest.value = screen
        try {
            startActivity(
                Intent(this, MainActivity::class.java)
                    .putExtra(MainActivity.EXTRA_OPEN, screen)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT),
            )
        } catch (e: Exception) {
            panelNote = "Could not open HaulPilot. Open it from the launcher; the result is waiting in Smart Setup."
            refreshPanel()
        }
    }

    companion object {
        @Volatile
        var instance: AutopilotAccessibilityService? = null
            private set

    }
}
