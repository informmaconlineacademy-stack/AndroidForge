package dev.toe3autopilot

import android.graphics.Bitmap
import android.graphics.Color
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import dev.toe3autopilot.app.data.ProfileStore
import dev.toe3autopilot.app.data.SettingsStore
import dev.toe3autopilot.core.AutomationSettings
import dev.toe3autopilot.core.profile.GameProfile
import dev.toe3autopilot.core.profile.ProfileEditing
import dev.toe3autopilot.core.vision.Roi
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test
import org.junit.runner.RunWith

/**
 * On-device tests for the persistence layer. They need an emulator or device and have NOT been run
 * (no Android SDK in the authoring environment).
 */
@RunWith(AndroidJUnit4::class)
class StoresInstrumentedTest {
    private val ctx = InstrumentationRegistry.getInstrumentation().targetContext

    @Test
    fun settingsRoundTrip() {
        val store = SettingsStore(ctx)
        val s = AutomationSettings(speedLevel = 0.3f, approachSpeed = 0.2f, sensitivity = 1.5f, tryParking = false, assistedMode = true)
        store.save(s)
        assertEquals(s, SettingsStore(ctx).load())
    }

    @Test
    fun profileAndTemplateRoundTrip() {
        val store = ProfileStore(ctx)
        val bmp = Bitmap.createBitmap(8, 8, Bitmap.Config.ARGB_8888).also { it.eraseColor(Color.WHITE); it.setPixel(2, 2, Color.BLACK) }
        store.saveTemplate("test_marker", bmp)
        val gray = store.gray("test_marker")
        assertNotNull(gray)
        assertEquals(8, gray!!.width)
        val p = ProfileEditing.withTemplate(GameProfile.EMPTY.copy(name = "instrumented"), "test_marker", Roi(0f, 0f, 0.5f, 0.5f), 8)
        store.save(p)
        assertEquals(8, store.load()!!.referenceWidth)
        store.deleteTemplate("test_marker")
        assertNull(store.gray("test_marker"))
    }

    @Test
    fun invalidProfileTextIsRejectedWithoutOverwriting() {
        val store = ProfileStore(ctx)
        val before = store.readText()
        try {
            store.saveText("bogus.key=1")
            error("expected IllegalArgumentException")
        } catch (e: IllegalArgumentException) {
            // expected
        }
        assertEquals(before, store.readText())
    }
}
