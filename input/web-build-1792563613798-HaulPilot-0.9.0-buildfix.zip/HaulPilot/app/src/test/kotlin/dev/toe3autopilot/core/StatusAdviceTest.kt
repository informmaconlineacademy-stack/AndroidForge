package dev.toe3autopilot.core

import dev.toe3autopilot.core.calibration.CalibPhase
import dev.toe3autopilot.core.calibration.CalibRole
import dev.toe3autopilot.core.calibration.CalibrationState
import dev.toe3autopilot.core.calibration.CalibrationSummaries
import dev.toe3autopilot.core.calibration.ControlDetection
import dev.toe3autopilot.core.calibration.DetectionSource
import dev.toe3autopilot.core.calibration.DetectionStatus
import dev.toe3autopilot.core.capture.CaptureDiagnosis
import dev.toe3autopilot.core.capture.CaptureFault
import dev.toe3autopilot.core.capture.CaptureHealthMonitor
import dev.toe3autopilot.core.session.DrivePhase
import dev.toe3autopilot.core.session.SessionSnapshot
import dev.toe3autopilot.core.session.SessionStatus
import dev.toe3autopilot.core.status.AdviceAction
import dev.toe3autopilot.core.status.AdviceKey
import dev.toe3autopilot.core.status.AdviceSeverity
import dev.toe3autopilot.core.status.StatusAdvice
import dev.toe3autopilot.core.status.StatusInputs
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Every operating situation the screens must explain, with the next step offered for it. */
class StatusAdviceTest {
    private val clock = FakeClock()

    private fun healthy(): CaptureDiagnosis {
        val m = CaptureHealthMonitor(clock)
        return m.diagnose() // not connected: informational, not a problem
    }

    private fun inputs(
        snap: SessionSnapshot = SessionSnapshot(),
        capture: Boolean = true,
        diagnosis: CaptureDiagnosis = healthy(),
        endReason: String? = null,
        access: Boolean = true,
        assisted: Boolean = false,
        cal: CalibrationState = CalibrationState(),
        hasProfile: Boolean = true,
    ) = StatusInputs(snap, capture, diagnosis, endReason, access, assisted, cal, CalibrationSummaries.controls(cal.detections, emptySet()), hasProfile)

    private fun keys(i: StatusInputs) = StatusAdvice.all(i).map { it.key }
    private fun first(i: StatusInputs) = StatusAdvice.all(i).first()

    @Test
    fun aHealthyIdleSetupHasNothingToSay() {
        assertTrue(StatusAdvice.all(inputs()).isEmpty())
    }

    @Test
    fun emergencyStopComesFirstAndNeverOffersResume() {
        val a = first(inputs(SessionSnapshot(status = SessionStatus.EMERGENCY_STOPPED)))
        assertEquals(AdviceKey.EMERGENCY_STOP, a.key)
        assertEquals(AdviceSeverity.ERROR, a.severity)
        assertTrue(a.action != AdviceAction.RESUME)
    }

    @Test
    fun roadLostExplainsAndOffersResume() {
        val snap = SessionSnapshot(status = SessionStatus.NEEDS_ASSIST, phase = DrivePhase.DRIVING, lastError = "Lost track of the road (route not visible for 6s). Stopped.", helpKind = HelpKind.ROAD_LOST)
        val a = first(inputs(snap))
        assertEquals(AdviceKey.ROAD_LOST, a.key)
        assertEquals(AdviceAction.RESUME, a.action)
        assertTrue(a.text.contains("minimap"))
    }

    @Test
    fun eachHelpReasonGetsItsOwnNextStep() {
        fun keyFor(k: HelpKind, st: SessionStatus = SessionStatus.NEEDS_ASSIST) = first(inputs(SessionSnapshot(status = st, lastError = "x", helpKind = k)))
        assertEquals(AdviceAction.OPEN_CALIBRATION, keyFor(HelpKind.LAYOUT_CHANGED).action)
        assertEquals(AdviceKey.PARKING_NEEDS_YOU, keyFor(HelpKind.PARKING_FAILED).key)
        assertEquals(AdviceAction.ENABLE_ACCESSIBILITY, keyFor(HelpKind.INPUT).action)
        val stopped = keyFor(HelpKind.CAPTURE, SessionStatus.ERROR)
        assertEquals(AdviceKey.SERVICE_STOPPED, stopped.key)
        assertEquals(AdviceAction.TURN_ON_CAPTURE, stopped.action)
        val other = keyFor(HelpKind.SCREEN_UNKNOWN)
        assertEquals(AdviceKey.NEEDS_ASSISTANCE, other.key)
        assertEquals(AdviceAction.RESUME, other.action)
        // An ERROR stop cannot be resumed, only started again.
        assertEquals(AdviceAction.START_DRIVE, keyFor(HelpKind.OTHER, SessionStatus.ERROR).action)
    }

    @Test
    fun pausedAndParkedAreExplained() {
        assertEquals(AdviceKey.PAUSED, first(inputs(SessionSnapshot(status = SessionStatus.PAUSED, task = "Paused by user"))).key)
        val parked = first(inputs(SessionSnapshot(status = SessionStatus.FINISHED)))
        assertEquals(AdviceKey.PARKED, parked.key)
        assertEquals(AdviceSeverity.SUCCESS, parked.severity)
    }

    @Test
    fun declinedPermissionIsNotMistakenForAProtectedGame() {
        val m = CaptureHealthMonitor(clock)
        m.onFault(CaptureFault.PERMISSION_DENIED)
        val a = first(inputs(capture = false, diagnosis = m.diagnose()))
        assertEquals(AdviceKey.PERMISSION_DENIED, a.key)
        assertEquals(AdviceAction.TURN_ON_CAPTURE, a.action)
    }

    @Test
    fun aStoppedProjectionOffersTheRecordedClip() {
        val m = CaptureHealthMonitor(clock)
        m.onCaptureStarted()
        m.onFault(CaptureFault.PROJECTION_STOPPED)
        val a = first(inputs(capture = false, diagnosis = m.diagnose()))
        assertEquals(AdviceKey.CAPTURE_UNAVAILABLE, a.key)
        assertEquals(CaptureFault.PROJECTION_STOPPED.offersVideo, a.action == AdviceAction.USE_RECORDED_CLIP)
    }

    @Test
    fun noFramesAtAllIsReportedAsNoUsableFrames() {
        val m = CaptureHealthMonitor(clock)
        m.onCaptureStarted()
        clock.now += 30_000
        val a = StatusAdvice.all(inputs(diagnosis = m.diagnose())).first { it.severity == AdviceSeverity.ERROR }
        assertEquals(AdviceKey.NO_USABLE_FRAMES, a.key)
    }

    @Test
    fun captureThatEndedNormallyIsInformationOnly() {
        val a = first(inputs(capture = false, endReason = "Screen locked"))
        assertEquals(AdviceKey.CAPTURE_OFF, a.key)
        assertEquals(AdviceSeverity.INFO, a.severity)
        assertTrue(a.text.contains("Screen locked"))
    }

    @Test
    fun calibrationStatesInProgressFailedAndNeedingConfirmation() {
        assertEquals(AdviceKey.CALIBRATING, first(inputs(cal = CalibrationState(phase = CalibPhase.OBSERVING, message = "Watching"))).key)
        val failed = first(inputs(cal = CalibrationState(problem = "The picture barely changes")))
        assertEquals(AdviceKey.CALIBRATION_FAILED, failed.key)
        assertTrue("explains that capture itself works", failed.text.contains("capture is working"))
        val det = ControlDetection(CalibRole.BRAKE, 0.5f, 0.5f, null, 0.5f, DetectionStatus.NEEDS_CONFIRMATION, DetectionSource.VIDEO, emptyList())
        val needs = first(inputs(cal = CalibrationState(detections = mapOf(CalibRole.BRAKE to det))))
        assertEquals(AdviceKey.NEEDS_CONFIRMATION, needs.key)
        assertEquals(AdviceAction.REVIEW_CONTROLS, needs.action)
    }

    @Test
    fun noProfileAndAccessibilityOff() {
        assertTrue(AdviceKey.NO_PROFILE in keys(inputs(hasProfile = false)))
        assertTrue(AdviceKey.ACCESSIBILITY_OFF in keys(inputs(access = false)))
        assertFalse("not needed in Assisted mode", AdviceKey.ACCESSIBILITY_OFF in keys(inputs(access = false, assisted = true)))
    }

    @Test
    fun calibrationAdviceIsHiddenWhileDriving() {
        val running = SessionSnapshot(status = SessionStatus.RUNNING, phase = DrivePhase.DRIVING)
        assertFalse(AdviceKey.NO_PROFILE in keys(inputs(snap = running, hasProfile = false)))
    }
}
