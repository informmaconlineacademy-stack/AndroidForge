package dev.toe3autopilot.core

import dev.toe3autopilot.core.profile.GameProfile
import dev.toe3autopilot.core.profile.ColorSpec
import dev.toe3autopilot.core.session.DrivePhase
import dev.toe3autopilot.core.session.InputKind
import dev.toe3autopilot.core.session.SessionManager
import dev.toe3autopilot.core.session.SessionSnapshot
import dev.toe3autopilot.core.session.SessionStatus
import dev.toe3autopilot.core.session.UserState
import dev.toe3autopilot.core.session.userState
import dev.toe3autopilot.core.state.GameState
import dev.toe3autopilot.core.vision.ColorTarget
import dev.toe3autopilot.core.vision.Frame
import dev.toe3autopilot.core.vision.Roi
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Draws test screens from named markers and wires a [SessionManager] to fakes. */
class Rig(kind: InputKind = InputKind.INJECTED, var profile: GameProfile? = TestProfiles.full()) {
    val clock = FakeClock()
    val images = TestProfiles.templateImages()
    val store = MapTemplateStore(images)
    val frames = FakeFrames()
    val monitor = FakeMonitor()
    val input = FakeInput(kind)
    var settings = AutomationSettings(assistedMode = kind == InputKind.ASSISTED)
    val snapshots = ArrayList<SessionSnapshot>()
    var markers: List<String> = emptyList()

    /** When true the scenery changes on every frame, like a moving truck (otherwise the motion proxy stays at zero). */
    var animated = false

    /** Extra drawing on every rendered frame (used to place control look-alike patches). */
    var overlay: (IntArray) -> Unit = {}

    val session = SessionManager(
        frames, monitor, input, { profile }, store, { settings }, clock,
        listener = { snapshots.add(it) },
    )

    fun render(): Frame {
        val px = Synth.blankPixels(TestProfiles.FW, TestProfiles.FH)
        if (animated) {
            val r = java.util.Random(clock.now)
            for (y in (0.25f * TestProfiles.FH).toInt() until (0.7f * TestProfiles.FH).toInt()) {
                for (x in (0.2f * TestProfiles.FW).toInt() until (0.8f * TestProfiles.FW).toInt()) {
                    val g = 0x30 + r.nextInt(0x60)
                    px[y * TestProfiles.FW + x] = (0xFF shl 24) or (g shl 16) or (g shl 8) or g
                }
            }
        }
        for (n in markers) {
            val v = TestProfiles.FIXED[n] ?: error("unknown marker $n")
            val img = images[n]!!
            Synth.drawPatch(
                px, TestProfiles.FW, TestProfiles.FH, img,
                (v[0].toFloat() * TestProfiles.FW).toInt() - img.width / 2,
                (v[1].toFloat() * TestProfiles.FH).toInt() - img.height / 2,
            )
        }
        route?.let { Synth.drawRoute(px, TestProfiles.FW, TestProfiles.FH, it.first, it.second) }
        zoneX?.let { cx ->
            Synth.drawRect(
                px, TestProfiles.FW, TestProfiles.FH, ((cx - 0.05f) * TestProfiles.FW).toInt(), ((0.6f - 0.06f) * TestProfiles.FH).toInt(),
                ((cx + 0.05f) * TestProfiles.FW).toInt(), ((0.6f + 0.06f) * TestProfiles.FH).toInt(), 0x00C800,
            )
        }
        overlay(px)
        return Frame(TestProfiles.FW, TestProfiles.FH, px, clock.now)
    }

    /** Route line drawn on the minimap in every frame: (near offset, far offset), or null for no route. */
    var route: Pair<Float, Float>? = null

    /** Parking zone drawn in every frame: centre x as a fraction of the width, or null. */
    var zoneX: Float? = null

    fun withRoute(offset: Float = 0f, farOffset: Float = offset): Rig {
        route = offset to farOffset
        return this
    }

    fun withParkingZone(cx: Float = 0.5f): Rig {
        zoneX = cx
        return this
    }

    /** Runs [ms] in 100 ms steps and reports whether [c] was held at any tick. */
    fun everHeld(c: Control, ms: Long): Boolean {
        var held = false
        var t = 0L
        while (t < ms) {
            run(100, stepMs = 100)
            t += 100
            if (input.holds.containsKey(c)) held = true
        }
        return held
    }

    /** Share of 100 ms ticks within [ms] on which [c] was held. */
    fun heldShare(c: Control, ms: Long): Float {
        var held = 0
        var n = 0
        var t = 0L
        while (t < ms) {
            run(100, stepMs = 100)
            t += 100
            n++
            if (input.holds.containsKey(c)) held++
        }
        return held.toFloat() / n
    }

    fun show(vararg names: String) {
        markers = names.toList()
        frames.frame = render()
    }

    /** Advance time and deliver a fresh frame before each tick, as a live capture would. */
    fun run(ms: Long, stepMs: Long = 200, freshFrames: Boolean = true) {
        var elapsed = 0L
        while (elapsed < ms) {
            clock.advance(stepMs)
            elapsed += stepMs
            if (freshFrames) frames.frame = render()
            session.tick()
        }
    }

    fun startRunning(vararg names: String): Rig {
        show(*names)
        assertTrue(session.start().ok)
        run(1000)
        assertEquals(SessionStatus.RUNNING, session.currentSnapshot().status)
        return this
    }

    fun status() = session.currentSnapshot().status
}

class SessionManagerTest {
    private fun refused(mutate: (Rig) -> Unit, mention: String) {
        val rig = Rig()
        rig.show("hud_marker")
        mutate(rig)
        val r = rig.session.start()
        assertFalse("start should be refused", r.ok)
        assertTrue("problems ${r.problems} should mention '$mention'", r.problems.any { it.contains(mention, ignoreCase = true) })
        assertEquals(SessionStatus.IDLE, rig.status())
        assertTrue(rig.input.taps.isEmpty())
        assertTrue(rig.input.holds.isEmpty())
        assertNotNull(rig.session.currentSnapshot().lastError)
    }

    @Test
    fun startIsRefusedUnlessEveryPrerequisiteIsVerified() {
        refused({ it.frames.active = false }, "capture")
        refused({ it.frames.frame = null }, "frame")
        refused({ it.input.isReady = false }, "accessibility")
        refused({ it.monitor.foreground = false }, "foreground")
        refused({ it.monitor.foreground = null }, "verify the foreground")
        refused({ it.profile = null }, "profile")
        refused({ it.profile = GameProfile.EMPTY }, "calibrated")
        refused({ it.settings = it.settings.copy(assistedMode = true) }, "mode")
        refused({ it.input.isHealthy = false }, "failures")
    }

    @Test
    fun nothingIsInjectedUntilTheScreenHasBeenRecognised() {
        val rig = Rig().withRoute()
        rig.show("hud_marker")
        assertTrue(rig.session.start().ok)
        assertEquals(SessionStatus.STARTING, rig.status())
        rig.run(200)
        assertEquals(SessionStatus.STARTING, rig.status()) // one frame is not enough (debounce)
        assertTrue(rig.input.holds.isEmpty())
        rig.run(400)
        assertEquals(SessionStatus.RUNNING, rig.status())
        assertTrue(rig.input.taps.isEmpty())
    }

    @Test
    fun anUnrecognisedGameNeverReceivesInputAndEscalates() {
        val rig = Rig()
        rig.show() // blank screen
        assertTrue(rig.session.start().ok)
        rig.run(14_000)
        assertEquals(SessionStatus.STARTING, rig.status())
        rig.run(2000)
        assertEquals(SessionStatus.NEEDS_ASSIST, rig.status())
        assertTrue(rig.input.taps.isEmpty())
        assertTrue(rig.input.holds.isEmpty())
        assertTrue(rig.session.currentSnapshot().lastError!!.contains("recognise"))
        assertEquals(HelpKind.SCREEN_UNKNOWN, rig.session.currentSnapshot().helpKind)
    }

    @Test
    fun emergencyStopReleasesBrakesAndStaysStopped() {
        val rig = Rig().withRoute().startRunning("hud_marker")
        rig.run(1000)
        val before = rig.input.releaseAllCalls
        rig.session.emergencyStop("test")
        assertEquals(SessionStatus.EMERGENCY_STOPPED, rig.status())
        assertTrue(rig.input.releaseAllCalls > before)
        assertEquals(setOf(Control.BRAKE), rig.input.holds.keys) // truck is braked, nothing else held
        // No later tick may drive again.
        rig.run(1500)
        assertEquals(setOf(Control.BRAKE), rig.input.holds.keys)
        assertEquals(SessionStatus.EMERGENCY_STOPPED, rig.status())
        assertFalse(rig.session.shouldReleaseCapture()) // still braking
        rig.run(1000)
        assertTrue(rig.input.holds.isEmpty()) // brake released after the safety window
        assertTrue(rig.session.shouldReleaseCapture())
        assertEquals(UserState.EMERGENCY_STOP, rig.session.currentSnapshot().userState(false))
    }

    @Test
    fun emergencyStopWorksEvenWhenNothingIsRunning() {
        val rig = Rig()
        rig.session.emergencyStop()
        assertEquals(SessionStatus.EMERGENCY_STOPPED, rig.status())
        assertTrue(rig.input.holds.isEmpty())
    }

    @Test
    fun anEmergencyStoppedSessionCanOnlyBeRestartedFromScratch() {
        val rig = Rig().withRoute().startRunning("hud_marker")
        rig.session.emergencyStop()
        assertFalse("resume is not allowed after an emergency stop", rig.session.resume().ok)
        rig.run(3000)
        assertEquals(SessionStatus.EMERGENCY_STOPPED, rig.status())
        assertTrue(rig.session.start().ok)
    }

    @Test
    fun pauseHaltsInputAndResumeReverifiesRecognition() {
        val rig = Rig().withRoute().startRunning("hud_marker")
        rig.session.pause()
        assertEquals(SessionStatus.PAUSED, rig.status())
        assertEquals(UserState.PAUSED, rig.session.currentSnapshot().userState(false))
        rig.run(3000)
        assertFalse("nothing is driven while paused", rig.input.holds.containsKey(Control.ACCELERATOR))
        assertTrue(rig.session.resume().ok)
        assertEquals(SessionStatus.STARTING, rig.status())
        rig.run(1000)
        assertEquals(SessionStatus.RUNNING, rig.status())
    }

    @Test
    fun resumeIsRefusedWhenNotPaused() {
        val rig = Rig()
        assertFalse(rig.session.resume().ok)
    }

    @Test
    fun leavingTheGameFirstWaitsThenPauses() {
        val rig = Rig().withRoute().startRunning("hud_marker")
        rig.monitor.foreground = false
        rig.run(3000)
        assertEquals(SessionStatus.RUNNING, rig.status()) // grace period (notification shade, etc.)
        assertTrue(rig.input.holds.isEmpty())
        rig.run(2000)
        assertEquals(SessionStatus.PAUSED, rig.status())
        assertTrue(rig.session.currentSnapshot().task.contains("foreground"))
    }

    @Test
    fun aLostAccessibilityConnectionPausesToo() {
        val rig = Rig().withRoute().startRunning("hud_marker")
        rig.monitor.foreground = null
        rig.run(5000)
        assertEquals(SessionStatus.PAUSED, rig.status())
    }

    @Test
    fun aFailingInputChannelStopsTheSession() {
        val rig = Rig().withRoute().startRunning("hud_marker")
        rig.input.isHealthy = false
        rig.run(400)
        assertEquals(SessionStatus.NEEDS_ASSIST, rig.status())
        assertEquals(HelpKind.INPUT, rig.session.currentSnapshot().helpKind)
        assertEquals(setOf(Control.BRAKE), rig.input.holds.keys)
    }

    @Test
    fun captureStoppingIsAnError() {
        val rig = Rig().withRoute().startRunning("hud_marker")
        rig.frames.active = false
        rig.run(400)
        assertEquals(SessionStatus.ERROR, rig.status())
        assertEquals(HelpKind.CAPTURE, rig.session.currentSnapshot().helpKind)
        assertEquals(UserState.NEEDS_ASSISTANCE, rig.session.currentSnapshot().userState(false))
        rig.run(1500)
        assertFalse(rig.input.holds.containsKey(Control.ACCELERATOR))
    }

    @Test
    fun aFrozenGameWhileDrivingStopsTheTruck() {
        val rig = Rig().withRoute().startRunning("hud_marker")
        rig.run(2000, freshFrames = true)
        rig.run(5600, freshFrames = false) // the picture stops updating
        assertEquals(SessionStatus.NEEDS_ASSIST, rig.status())
        assertTrue(rig.session.currentSnapshot().lastError!!.contains("frozen"))
    }

    @Test
    fun anUnrecognisedScreenWhileDrivingBrakesFirstThenGivesUp() {
        val rig = Rig().withRoute().startRunning("hud_marker")
        rig.run(2000)
        rig.show() // HUD disappears (overlay, glitch, ...)
        var braked = false
        var accelerated = false
        var elapsed = 0L
        while (elapsed < 7000) {
            rig.run(100, stepMs = 100)
            elapsed += 100
            if (rig.input.holds.containsKey(Control.BRAKE)) braked = true
            if (elapsed > 1000 && rig.input.holds.containsKey(Control.ACCELERATOR)) accelerated = true
        }
        assertTrue(braked)
        assertFalse("must not keep accelerating on a screen it cannot read", accelerated)
        rig.run(4000)
        assertEquals(SessionStatus.NEEDS_ASSIST, rig.status())
    }

    @Test
    fun aLoadingScreenBrakesAndEventuallyGivesUp() {
        val rig = Rig().withRoute().startRunning("hud_marker")
        rig.run(1000)
        rig.show("loading_spinner")
        rig.run(2000)
        assertEquals(SessionStatus.RUNNING, rig.status())
        assertTrue(rig.input.holds.containsKey(Control.BRAKE) || rig.input.holds.isEmpty())
        assertFalse(rig.input.holds.containsKey(Control.ACCELERATOR))
        rig.run(70_000)
        assertEquals(SessionStatus.NEEDS_ASSIST, rig.status())
    }

    @Test
    fun anExceptionInTheLoopStopsSafelyInsteadOfCrashing() {
        val boom = Rig()
        var explode = false
        val session = SessionManager(
            boom.frames, boom.monitor, boom.input, { if (explode) throw IllegalStateException("boom") else boom.profile },
            boom.store, { boom.settings }, boom.clock,
        )
        boom.show("hud_marker")
        assertTrue(session.start().ok)
        boom.clock.advance(200)
        session.tick()
        explode = true
        boom.clock.advance(200)
        session.tick() // must not throw
        assertEquals(SessionStatus.ERROR, session.currentSnapshot().status)
        assertTrue(session.currentSnapshot().lastError!!.contains("boom"))
    }

    @Test
    fun stopReleasesEverythingAndAllowsReleasingCapture() {
        val rig = Rig().withRoute().startRunning("hud_marker")
        rig.session.stop()
        assertEquals(SessionStatus.IDLE, rig.status())
        assertTrue(rig.input.holds.isEmpty())
        assertTrue(rig.session.shouldReleaseCapture())
        val n = rig.input.setHoldsCalls
        rig.run(3000)
        assertEquals("no input after stop", n, rig.input.setHoldsCalls)
    }

    @Test
    fun snapshotsReportStateAndConfidence() {
        val rig = Rig().withRoute().startRunning("hud_marker")
        val s = rig.session.currentSnapshot()
        assertEquals(GameState.DRIVING, s.gameState)
        assertTrue(s.confidence > 0.85f)
        assertTrue(rig.snapshots.isNotEmpty())
        assertNull(s.lastError)
        assertEquals(DrivePhase.DRIVING, s.phase)
        assertEquals(UserState.DRIVING, s.userState(false))
    }

    // ---- driving -----------------------------------------------------------------------------------------

    @Test
    fun theTruckOnlyAcceleratesWhileTheRouteIsVisible() {
        val noRoute = Rig().startRunning("hud_marker")
        assertFalse("no route on the minimap: must not accelerate", noRoute.everHeld(Control.ACCELERATOR, 3000))
        assertTrue("route lost for a long time stops the session", noRoute.run(4000).let { noRoute.status() == SessionStatus.NEEDS_ASSIST })
        assertTrue(noRoute.session.currentSnapshot().lastError!!.contains("Lost track of the road"))

        val withRoute = Rig().withRoute().startRunning("hud_marker")
        assertTrue(withRoute.everHeld(Control.ACCELERATOR, 3000))
        assertEquals(SessionStatus.RUNNING, withRoute.status())
    }

    @Test
    fun theRoadVanishingMidDriveSlowsThenStopsAndAsks() {
        val rig = Rig().withRoute().startRunning("hud_marker")
        assertTrue(rig.everHeld(Control.ACCELERATOR, 2000))
        rig.route = null // the minimap loses the route line
        rig.run(1000)
        assertFalse(rig.everHeld(Control.ACCELERATOR, 1500))
        assertEquals(SessionStatus.RUNNING, rig.status())
        rig.run(7000)
        assertEquals(SessionStatus.NEEDS_ASSIST, rig.status())
        assertEquals(UserState.NEEDS_ASSISTANCE, rig.session.currentSnapshot().userState(false))
        assertTrue(rig.session.currentSnapshot().lastError!!.contains("Lost track of the road"))
        assertEquals(HelpKind.ROAD_LOST, rig.session.currentSnapshot().helpKind)
    }

    @Test
    fun steeringFollowsWhichSideTheRouteIsOn() {
        val centre = TestProfiles.CONTROLS[Control.STEER_CENTER]!!.x
        val right = Rig().withRoute(offset = 0.6f, farOffset = 0.8f).startRunning("hud_marker")
        right.run(1500)
        assertTrue("steering x ${right.input.holds[Control.STEER_CENTER]}", right.input.holds[Control.STEER_CENTER]!!.x > centre + 0.02f)
        val left = Rig().withRoute(offset = -0.6f, farOffset = -0.8f).startRunning("hud_marker")
        left.run(1500)
        assertTrue(left.input.holds[Control.STEER_CENTER]!!.x < centre - 0.02f)
    }

    @Test
    fun aTruckThatDoesNotMoveIsStoppedNotReversedBlindly() {
        // The rig's pictures never change, so the motion proxy stays at zero although throttle is demanded.
        val rig = Rig().withRoute().startRunning("hud_marker")
        rig.run(14_000)
        assertEquals(SessionStatus.NEEDS_ASSIST, rig.status())
        assertTrue(rig.session.currentSnapshot().lastError!!.contains("does not seem to move"))
        assertTrue(rig.input.taps.isEmpty())
    }

    // ---- approach, parking, parked -----------------------------------------------------------------------

    @Test
    fun aDeliveryCueSwitchesToApproachingAndLowersTheSpeed() {
        val rig = Rig().withRoute().startRunning("hud_marker")
        val cruise = rig.heldShare(Control.ACCELERATOR, 3000)
        assertEquals(DrivePhase.DRIVING, rig.session.currentSnapshot().phase)
        rig.show("hud_marker", "destination_near")
        rig.run(1000)
        assertEquals(DrivePhase.APPROACHING, rig.session.currentSnapshot().phase)
        assertEquals(UserState.APPROACHING_DELIVERY, rig.session.currentSnapshot().userState(false))
        val approach = rig.heldShare(Control.ACCELERATOR, 3000)
        assertTrue("cruise $cruise approach $approach", cruise > 0.35f && approach < 0.35f && approach > 0f)
        assertTrue(rig.session.log.entries().any { it.message.contains("Delivery area recognised") })
    }

    @Test
    fun aFlickeringCueDoesNotStartTheApproach() {
        val rig = Rig().withRoute().startRunning("hud_marker")
        repeat(6) {
            rig.show("hud_marker", "destination_near")
            rig.run(200)
            rig.show("hud_marker")
            rig.run(200)
        }
        assertEquals(DrivePhase.DRIVING, rig.session.currentSnapshot().phase)
    }

    @Test
    fun whenTheCueGoesAwayTheTruckReturnsToNormalDriving() {
        val rig = Rig().withRoute().startRunning("hud_marker", "destination_near")
        rig.run(1000)
        assertEquals(DrivePhase.APPROACHING, rig.session.currentSnapshot().phase)
        rig.show("hud_marker")
        rig.run(12_000)
        assertEquals(DrivePhase.DRIVING, rig.session.currentSnapshot().phase)
    }

    @Test
    fun reachingTheDestinationMarkerWithoutAParkingAreaStopsAndAsksTheUserToPark() {
        val base = TestProfiles.full()
        val withMarker = base.copy(colors = base.colors + ("destination_marker" to ColorSpec("destination_marker", Roi(0f, 0.5f, 0.3f, 1f), ColorTarget(255, 0, 0, 40))))
        val rig = Rig(profile = withMarker).withRoute()
        rig.overlay = { px ->
            // red destination marker right on the truck marker of the minimap
            Synth.drawRect(px, TestProfiles.FW, TestProfiles.FH, 44, 166, 52, 174, 0xFF0000)
        }
        rig.show("hud_marker")
        assertTrue(rig.session.start().ok)
        rig.run(4000)
        assertEquals(SessionStatus.NEEDS_ASSIST, rig.status())
        assertEquals(DrivePhase.APPROACHING, rig.session.currentSnapshot().phase)
        assertTrue(rig.session.currentSnapshot().lastError!!.contains("park manually"))
        assertFalse(rig.input.holds.containsKey(Control.ACCELERATOR))
        assertTrue(rig.input.taps.isEmpty())
    }

    @Test
    fun aVisibleParkingAreaStartsParkingInReverse() {
        val rig = Rig().withRoute().withParkingZone(cx = 0.62f)
        rig.startRunning("hud_marker", "destination_near")
        rig.run(3000)
        assertEquals(DrivePhase.PARKING, rig.session.currentSnapshot().phase)
        assertEquals(UserState.PARKING, rig.session.currentSnapshot().userState(false))
        rig.run(4000)
        assertTrue("reverse gear is selected once the truck stands still", rig.input.taps.contains(TestProfiles.CONTROLS[Control.GEAR_REVERSE]))
    }

    @Test
    fun parkingIsRefusedWhenSwitchedOffAndTheTruckStopsInstead() {
        val rig = Rig()
        rig.settings = rig.settings.copy(tryParking = false)
        rig.withRoute().withParkingZone()
        rig.show("hud_marker", "destination_near")
        assertTrue(rig.session.start().ok)
        rig.run(4000)
        assertEquals(SessionStatus.NEEDS_ASSIST, rig.status())
        assertTrue(rig.session.currentSnapshot().lastError!!.contains("park manually"))
        assertTrue(rig.input.taps.isEmpty())
    }

    @Test
    fun theGamesOwnParkingViewIsOnlyDrivenWhenParkingIsPossible() {
        val off = Rig()
        off.settings = off.settings.copy(tryParking = false)
        off.withRoute().startRunning("hud_marker")
        off.show("parking_hud")
        off.run(2000)
        assertEquals(SessionStatus.NEEDS_ASSIST, off.status())
        assertTrue(off.session.currentSnapshot().lastError!!.contains("parking view"))

        val on = Rig().withParkingZone(cx = 0.62f).startRunning("hud_marker")
        on.show("parking_hud")
        on.run(2000)
        assertEquals(SessionStatus.RUNNING, on.status())
        assertEquals(DrivePhase.PARKING, on.session.currentSnapshot().phase)
    }

    @Test
    fun theParkedCueFinishesTheTripAndStopsEverything() {
        val rig = Rig().withRoute().withParkingZone()
        rig.startRunning("hud_marker", "destination_near")
        rig.run(3000)
        assertEquals(DrivePhase.PARKING, rig.session.currentSnapshot().phase)
        rig.show("hud_marker", "destination_near", "parked_ok")
        rig.run(600)
        val s = rig.session.currentSnapshot()
        assertEquals(SessionStatus.FINISHED, s.status)
        assertEquals(DrivePhase.PARKED, s.phase)
        assertEquals(UserState.PARKED, s.userState(false))
        assertNull(s.lastError)
        assertTrue(s.task, s.task.contains("unload"))
        assertEquals(setOf(Control.BRAKE), rig.input.holds.keys)
        val taps = rig.input.taps.size
        rig.run(4000)
        assertTrue("brake released after the safety window", rig.input.holds.isEmpty())
        assertEquals("nothing is tapped after parking", taps, rig.input.taps.size)
        assertTrue(rig.session.shouldReleaseCapture())
    }

    @Test
    fun theParkedCueMustBeSeenTwiceInARow() {
        val rig = Rig().withRoute().withParkingZone()
        rig.startRunning("hud_marker", "destination_near")
        rig.run(3000)
        rig.show("hud_marker", "destination_near", "parked_ok")
        rig.run(200) // one sighting
        rig.show("hud_marker", "destination_near")
        rig.run(200)
        assertEquals(SessionStatus.RUNNING, rig.status())
        rig.show("hud_marker", "destination_near", "parked_ok")
        rig.run(200)
        rig.show("hud_marker", "destination_near")
        rig.run(200)
        assertEquals(SessionStatus.RUNNING, rig.status())
    }

    @Test
    fun theDeliveryScreenAlsoFinishesTheTripWithoutBeingTapped() {
        val rig = Rig().withRoute().startRunning("hud_marker")
        rig.run(1000)
        rig.show("delivery_header")
        rig.run(1200)
        assertEquals(SessionStatus.FINISHED, rig.status())
        assertEquals(UserState.PARKED, rig.session.currentSnapshot().userState(false))
        rig.run(4000)
        assertTrue(rig.input.taps.isEmpty())
        assertTrue(rig.input.holds.isEmpty())
    }

    @Test
    fun aPopUpOrCrashScreenStopsTheTruckAndIsNeverTapped() {
        for ((marker, word) in listOf("dialog_marker" to "dialog", "crash_marker" to "crash")) {
            val rig = Rig().withRoute().startRunning("hud_marker")
            rig.run(1000)
            rig.show("hud_marker", marker)
            rig.run(1500)
            assertEquals(SessionStatus.NEEDS_ASSIST, rig.status())
            assertTrue(rig.session.currentSnapshot().lastError!!.contains(word, ignoreCase = true))
            assertTrue(rig.input.taps.isEmpty())
            assertFalse(rig.input.holds.containsKey(Control.ACCELERATOR))
        }
    }

    @Test
    fun resumingKeepsThePhaseAndDoesNotFallBackStraightAway() {
        val rig = Rig().withRoute().startRunning("hud_marker", "destination_near")
        rig.run(1000)
        assertEquals(DrivePhase.APPROACHING, rig.session.currentSnapshot().phase)
        rig.session.pause()
        assertTrue(rig.session.resume().ok)
        rig.show("hud_marker") // the cue is not visible for the first moments after resuming
        rig.run(2500)
        assertEquals(SessionStatus.RUNNING, rig.status())
        assertEquals(DrivePhase.APPROACHING, rig.session.currentSnapshot().phase)
    }

    @Test
    fun aNewStartAlwaysBeginsWithDriving() {
        val rig = Rig().withRoute().startRunning("hud_marker", "destination_near")
        rig.run(1000)
        assertEquals(DrivePhase.APPROACHING, rig.session.currentSnapshot().phase)
        rig.session.stop()
        rig.show("hud_marker")
        assertTrue(rig.session.start().ok)
        rig.run(1000)
        assertEquals(DrivePhase.DRIVING, rig.session.currentSnapshot().phase)
    }

    @Test
    fun theRoadStatusIsReportedForTheDisplay() {
        val rig = Rig().withRoute().startRunning("hud_marker")
        rig.run(500)
        assertTrue(rig.session.currentSnapshot().road!!.startsWith("Road tracked"))
        rig.route = null
        rig.run(1500)
        assertTrue(rig.session.currentSnapshot().road!!.contains("unclear"))
    }

    // ---- assisted mode -----------------------------------------------------------------------------------

    @Test
    fun assistedModeShowsHintsAndInjectsNothingItself() {
        val rig = Rig(InputKind.ASSISTED).withRoute()
        rig.show("hud_marker")
        assertTrue(rig.session.start().ok)
        rig.run(1500)
        val snap = rig.session.currentSnapshot()
        assertEquals(InputKind.ASSISTED, snap.inputKind)
        assertNotNull(snap.assistHint)
        assertTrue(rig.input.taps.isEmpty())
    }

    @Test
    fun assistedSuggestionsDoNotExhaustTheParkingCorrectionBudget() {
        val rig = Rig(InputKind.ASSISTED).withParkingZone(cx = 0.7f)
        rig.show("parking_hud")
        assertTrue(rig.session.start().ok)
        rig.run(120_000, stepMs = 400) // far longer than 60 corrections of ~1.3 s each
        assertEquals(SessionStatus.RUNNING, rig.status())
    }
}

class UserStateTest {
    private fun s(status: SessionStatus, phase: DrivePhase? = null) = SessionSnapshot(status = status, phase = phase)

    @Test
    fun everyStatusMapsToTheWordsTheUserSees() {
        assertEquals(UserState.READY, s(SessionStatus.IDLE).userState(false))
        assertEquals(UserState.CALIBRATING, s(SessionStatus.IDLE).userState(true))
        assertEquals(UserState.STARTING, s(SessionStatus.STARTING).userState(false))
        assertEquals(UserState.DRIVING, s(SessionStatus.RUNNING, DrivePhase.DRIVING).userState(false))
        assertEquals(UserState.APPROACHING_DELIVERY, s(SessionStatus.RUNNING, DrivePhase.APPROACHING).userState(false))
        assertEquals(UserState.PARKING, s(SessionStatus.RUNNING, DrivePhase.PARKING).userState(false))
        assertEquals(UserState.PARKED, s(SessionStatus.RUNNING, DrivePhase.PARKED).userState(false))
        assertEquals(UserState.PARKED, s(SessionStatus.FINISHED, DrivePhase.PARKED).userState(false))
        assertEquals(UserState.PAUSED, s(SessionStatus.PAUSED).userState(false))
        assertEquals(UserState.NEEDS_ASSISTANCE, s(SessionStatus.NEEDS_ASSIST).userState(false))
        assertEquals(UserState.NEEDS_ASSISTANCE, s(SessionStatus.ERROR).userState(false))
        assertEquals(UserState.EMERGENCY_STOP, s(SessionStatus.EMERGENCY_STOPPED).userState(false))
    }

    @Test
    fun calibratingIsNeverShownOverALiveSession() {
        assertEquals(UserState.DRIVING, s(SessionStatus.RUNNING, DrivePhase.DRIVING).userState(true))
        assertEquals("Needs Assistance", UserState.NEEDS_ASSISTANCE.label)
        assertEquals("Approaching Delivery", UserState.APPROACHING_DELIVERY.label)
    }
}

class LayoutGateTest {
    private val calibratedLayout = mapOf("reference.height" to TestProfiles.FH.toString())

    private fun rig(): Rig = Rig(profile = TestProfiles.full(extras = calibratedLayout)).withRoute().also { it.animated = true }

    private fun rotated(rig: Rig) = Frame(TestProfiles.FH, TestProfiles.FW, Synth.blankPixels(TestProfiles.FH, TestProfiles.FW), rig.clock.now)

    @Test
    fun startIsRefusedWhenTheScreenLayoutDiffersFromTheCalibration() {
        val rig = rig()
        rig.show("hud_marker")
        rig.frames.frame = rotated(rig)
        val r = rig.session.start()
        assertFalse(r.ok)
        assertTrue(r.problems.toString(), r.problems.any { it.contains("layout changed", ignoreCase = true) })
        assertTrue(rig.input.taps.isEmpty())
    }

    @Test
    fun aRotationDuringARunStopsTheTruckAndAsksForRecalibration() {
        val rig = rig().startRunning("hud_marker")
        rig.frames.frame = rotated(rig)
        rig.run(600, freshFrames = false)
        assertEquals(SessionStatus.NEEDS_ASSIST, rig.status())
        assertTrue(rig.session.currentSnapshot().lastError!!.contains("Recalibrate"))
        assertEquals(dev.toe3autopilot.core.HelpKind.LAYOUT_CHANGED, rig.session.currentSnapshot().helpKind)
        assertTrue(rig.input.holds.isEmpty() || rig.input.holds.keys == setOf(Control.BRAKE)) // only the safety brake may remain
        // Rotating back does not resume by itself.
        rig.frames.frame = null
        rig.run(1500)
        assertEquals(SessionStatus.NEEDS_ASSIST, rig.status())
    }

    @Test
    fun profilesWithoutARecordedHeightAreNotJudgedByGeometry() {
        val rig = Rig(profile = TestProfiles.full())
        rig.show("hud_marker")
        rig.frames.frame = rotated(rig)
        // not refused for layout reasons (the blank rotated frame is simply not recognised yet)
        assertTrue(rig.session.start().ok)
    }

    private fun withPatches(rig: Rig) {
        val a = Synth.patch(50, 14, 14)
        val b = Synth.patch(51, 14, 14)
        val g = Synth.patch(52, 14, 14)
        rig.images["ctl_accelerator"] = a
        rig.images["ctl_brake"] = b
        rig.images["ctl_gear_reverse"] = g
        val p = rig.profile!!
        fun spec(n: String, c: Control) = dev.toe3autopilot.core.profile.TemplateSpec(
            n, dev.toe3autopilot.core.vision.Roi(
                (TestProfiles.CONTROLS[c]!!.x - 0.1f).coerceAtLeast(0f), (TestProfiles.CONTROLS[c]!!.y - 0.15f).coerceAtLeast(0f),
                (TestProfiles.CONTROLS[c]!!.x + 0.1f).coerceAtMost(1f), (TestProfiles.CONTROLS[c]!!.y + 0.15f).coerceAtMost(1f),
            ),
            0.7f,
        )
        rig.profile = p.copy(
            templates = p.templates + ("ctl_accelerator" to spec("ctl_accelerator", Control.ACCELERATOR)) + ("ctl_brake" to spec("ctl_brake", Control.BRAKE)) +
                ("ctl_gear_reverse" to spec("ctl_gear_reverse", Control.GEAR_REVERSE)),
        )
        rig.overlay = { px ->
            for ((img, c) in listOf(a to Control.ACCELERATOR, b to Control.BRAKE, g to Control.GEAR_REVERSE)) {
                val pt = TestProfiles.CONTROLS[c]!!
                Synth.drawPatch(px, TestProfiles.FW, TestProfiles.FH, img, (pt.x * TestProfiles.FW).toInt() - 7, (pt.y * TestProfiles.FH).toInt() - 7)
            }
        }
    }

    @Test
    fun controlsThatStillLookRightKeepTheSessionRunning() {
        val rig = rig()
        withPatches(rig)
        rig.startRunning("hud_marker")
        rig.run(25_000)
        assertEquals(rig.session.currentSnapshot().lastError, SessionStatus.RUNNING, rig.status())
    }

    @Test
    fun controlsThatDisappearStopTheSessionAfterRepeatedChecks() {
        val rig = rig()
        withPatches(rig)
        rig.startRunning("hud_marker")
        rig.run(6_000)
        assertEquals(rig.session.currentSnapshot().lastError, SessionStatus.RUNNING, rig.status())
        rig.overlay = {} // the interface changed: the calibrated controls are no longer where they were
        rig.run(25_000)
        assertEquals(SessionStatus.NEEDS_ASSIST, rig.status())
        assertTrue(rig.session.currentSnapshot().lastError!!.contains("interface may have changed"))
    }

    @Test
    fun aSingleBadCheckDoesNotStopTheSession() {
        val rig = rig()
        withPatches(rig)
        rig.startRunning("hud_marker")
        val good = rig.overlay
        rig.overlay = {}
        rig.run(5_000) // one or two checks fail...
        rig.overlay = good
        rig.run(20_000) // ...then the controls are seen again: the streak resets
        assertEquals(rig.session.currentSnapshot().lastError, SessionStatus.RUNNING, rig.status())
    }
}
