package dev.toe3autopilot.core

import dev.toe3autopilot.core.calibration.CalibRole
import dev.toe3autopilot.core.calibration.CalibrationApply
import dev.toe3autopilot.core.calibration.CalibrationCodec
import dev.toe3autopilot.core.calibration.CalibrationEngine
import dev.toe3autopilot.core.calibration.DetectionStatus
import dev.toe3autopilot.core.calibration.LayoutCheck
import dev.toe3autopilot.core.calibration.LayoutSignature
import dev.toe3autopilot.core.calibration.TimingEstimate
import dev.toe3autopilot.core.profile.GameProfile
import dev.toe3autopilot.core.profile.ProfileArchive
import dev.toe3autopilot.core.profile.ProfileCodec
import dev.toe3autopilot.core.profile.SteeringMode
import dev.toe3autopilot.core.vision.TemplateProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.math.abs

class CalibrationApplyTest {
    private fun rigWith(vararg roles: Pair<CalibRole, String>): CalibRig {
        val c = FakeClock()
        val r = CalibRig(CalibrationEngine(c), c)
        r.observe()
        for ((role, ring) in roles) r.demo(role, setOf(ring))
        return r
    }

    private val layout = LayoutSignature(320, 180)

    @Test
    fun onlyUsableDetectionsReachTheProfile() {
        val r = rigWith(CalibRole.ACCELERATOR to "accel")
        r.demo(CalibRole.BRAKE, emptySet(), flashAll = true) // ambiguous -> NEEDS_CONFIRMATION
        val st = r.engine.state()
        assertEquals(DetectionStatus.AUTO_CONFIRMED, st.detections[CalibRole.ACCELERATOR]!!.status)
        assertEquals(DetectionStatus.NEEDS_CONFIRMATION, st.detections[CalibRole.BRAKE]!!.status)

        val base = GameProfile.EMPTY.copy(name = "t", gamePackage = "x.y")
        val res = CalibrationApply.apply(base, st.detections, r.engine.patches(), layout, st.timing, applyTiming = false)
        val p = res.profile!!
        assertNotNull(p.controls[Control.ACCELERATOR])
        assertNull("an unconfirmed detection must never become a control", p.controls[Control.BRAKE])
        assertTrue(res.skipped.any { it.contains("Brake") })
        assertEquals(320, p.referenceWidth)
        assertEquals("180", p.extras[LayoutCheck.HEIGHT_KEY])
        assertTrue(res.patches.containsKey("ctl_accelerator"))
        assertNotNull(p.templates["ctl_accelerator"])
        // the result must survive the strict codec
        val again = ProfileCodec.parse(ProfileCodec.format(p))
        assertEquals(p.controls[Control.ACCELERATOR]!!.x, again.controls[Control.ACCELERATOR]!!.x, 1e-3f)
        assertEquals(p.controls[Control.ACCELERATOR]!!.y, again.controls[Control.ACCELERATOR]!!.y, 1e-3f)
        assertEquals(layout, LayoutCheck.referenceSize(again))
    }

    @Test
    fun confirmingMakesAControlUsable() {
        val r = rigWith()
        r.demo(CalibRole.BRAKE, emptySet(), flashAll = true)
        assertTrue(r.engine.confirm(CalibRole.BRAKE))
        val res = CalibrationApply.apply(GameProfile.EMPTY, r.engine.state().detections, r.engine.patches(), layout, null, false)
        assertNotNull(res.profile!!.controls[Control.BRAKE])
    }

    @Test
    fun steeringStyleFollowsWhatWasConfirmed() {
        val both = rigWith(CalibRole.STEER_LEFT to "left", CalibRole.STEER_RIGHT to "right")
        val p = CalibrationApply.apply(GameProfile.EMPTY, both.engine.state().detections, both.engine.patches(), layout, null, false).profile!!
        assertEquals(SteeringMode.BUTTONS, p.steeringMode)
        assertNotNull(p.controls[Control.STEER_LEFT])
        assertNotNull(p.controls[Control.STEER_RIGHT])

        val only = rigWith(CalibRole.STEER_LEFT to "left")
        val res = CalibrationApply.apply(
            GameProfile.EMPTY.copy(steeringMode = SteeringMode.SLIDER), only.engine.state().detections, only.engine.patches(), layout, null, false,
        )
        assertEquals("one side alone must not switch the style", SteeringMode.SLIDER, res.profile!!.steeringMode)
        assertTrue(res.skipped.any { it.contains("Steering") })
    }

    @Test
    fun wheelIsAppliedOnlyAfterConfirmation() {
        val c = FakeClock()
        val r = CalibRig(CalibrationEngine(c), c)
        r.scene.wheelInsteadOfButtons = true
        r.observe()
        r.demo(CalibRole.STEER_LEFT, emptySet(), wheelAngle = -50)
        r.demo(CalibRole.STEER_RIGHT, emptySet(), wheelAngle = 50)
        val before = CalibrationApply.apply(GameProfile.EMPTY, r.engine.state().detections, r.engine.patches(), layout, null, false).profile!!
        assertNull(before.controls[Control.STEER_CENTER])
        assertTrue(r.engine.confirm(CalibRole.STEER_WHEEL))
        val after = CalibrationApply.apply(GameProfile.EMPTY, r.engine.state().detections, r.engine.patches(), layout, null, false).profile!!
        assertNotNull(after.controls[Control.STEER_CENTER])
        assertEquals(SteeringMode.SLIDER, after.steeringMode)
    }

    @Test
    fun informationalRolesAreStoredAsExtras() {
        val r = rigWith()
        r.engine.place(CalibRole.SPEED_READOUT, 0.5f, 0.92f)
        val p = CalibrationApply.apply(GameProfile.EMPTY, r.engine.state().detections, r.engine.patches(), layout, null, false).profile!!
        assertEquals("0.500,0.920", p.extras["calib.speed_readout"])
        assertEquals(0.92f, LayoutCheck.locationOf(p, CalibRole.SPEED_READOUT)!!.y, 1e-3f)
        ProfileCodec.parse(ProfileCodec.format(p)) // extras survive the codec
    }

    @Test
    fun timingIsOnlyAppliedOnRequestAndNeverOverwritesYourSettleTimes() {
        val t = TimingEstimate(0.0123f, 0f, 0.2f, 600, 900, 1100, emptyList())
        val base = GameProfile.EMPTY.copy(extras = mapOf("parking.settleMs" to "2500"))
        val off = CalibrationApply.apply(base, emptyMap(), emptyMap(), layout, t, applyTiming = false).profile!!
        assertNull(off.extras["motion.stopped"])
        val on = CalibrationApply.apply(base, emptyMap(), emptyMap(), layout, t, applyTiming = true).profile!!
        assertEquals("0.0123", on.extras["motion.stopped"])
        assertEquals("2500", on.extras["parking.settleMs"])
        assertNull("coupling no longer exists", on.extras["coupling.settleMs"])
    }

    @Test
    fun templatesFromAnotherScreenWidthBlockTheApply() {
        val r = rigWith(CalibRole.ACCELERATOR to "accel")
        val base = TestProfiles.full().copy(referenceWidth = 640)
        val res = CalibrationApply.apply(base, r.engine.state().detections, r.engine.patches(), layout, null, false)
        assertNull(res.profile)
        assertNotNull(res.problem)
    }
}

class LayoutCheckTest {
    private fun calibrated(): Pair<GameProfile, MapTemplateStore> {
        val c = FakeClock()
        val r = CalibRig(CalibrationEngine(c), c)
        r.observe()
        r.demo(CalibRole.ACCELERATOR, setOf("accel"))
        r.demo(CalibRole.BRAKE, setOf("brake"))
        val st = r.engine.state()
        val res = CalibrationApply.apply(TestProfiles.full(), st.detections, r.engine.patches(), LayoutSignature(320, 180), null, false)
        val store = MapTemplateStore(HashMap(TestProfiles.templateImages()))
        for ((n, img) in res.patches) store.map[n] = img
        return res.profile!! to store
    }

    private fun verify(p: GameProfile, store: MapTemplateStore, scene: SynthHud, skip: Set<CalibRole> = emptySet()): LayoutCheck.Verification {
        val f = scene.frame(99, 99_000, moving = true)
        return LayoutCheck.verifyControls(p, f.toGray(), TemplateProvider(store, p.referenceWidth), f.width, skip)
    }

    @Test
    fun aspectRatioChangesAreDetectedAndSameAspectIsAccepted() {
        val p = TestProfiles.full().copy(extras = mapOf(LayoutCheck.HEIGHT_KEY to "180"))
        assertNull(LayoutCheck.layoutProblem(p, 320, 180))
        assertNull("same aspect at another resolution is fine", LayoutCheck.layoutProblem(p, 1280, 720))
        assertNotNull("rotation", LayoutCheck.layoutProblem(p, 180, 320))
        assertNotNull("different aspect", LayoutCheck.layoutProblem(p, 320, 150))
        assertNull("profiles that do not record a height are not judged", LayoutCheck.layoutProblem(TestProfiles.full(), 180, 320))
    }

    @Test
    fun unchangedInterfaceVerifiesAndMovedInterfaceIsStale() {
        val (p, store) = calibrated()
        val same = verify(p, store, SynthHud())
        assertEquals(2, same.evaluated)
        assertEquals("scores=${same.scores}", 2, same.matched)
        assertFalse(same.stale)

        val moved = SynthHud()
        moved.rings.replaceAll { it.copy(y = it.y - 0.15f) }
        val v = verify(p, store, moved)
        assertEquals(2, v.evaluated)
        assertEquals("scores=${v.scores}", 0, v.matched)
        assertTrue(v.stale)
    }

    @Test
    fun heldControlsAreNotJudgedAndOneControlIsNeverEnoughForAVerdict() {
        val (p, store) = calibrated()
        val moved = SynthHud()
        moved.rings.replaceAll { it.copy(y = it.y - 0.15f) }
        val v = verify(p, store, moved, skip = setOf(CalibRole.ACCELERATOR))
        assertEquals(1, v.evaluated)
        assertFalse("a single control is not enough evidence", v.stale)
    }

    @Test
    fun movedControlsAreRelocatedAsProposals() {
        val (p, store) = calibrated()
        val moved = SynthHud()
        moved.rings.replaceAll { it.copy(y = it.y - 0.15f) }
        val f = moved.frame(50, 50_000, moving = true)
        val rel = LayoutCheck.relocate(p, f.toGray(), TemplateProvider(store, p.referenceWidth), f.width)
        val accel = rel.firstOrNull { it.role == CalibRole.ACCELERATOR }
        assertNotNull("relocations=$rel", accel)
        assertTrue(abs(accel!!.x - 0.90f) < 0.04f && abs(accel.y - 0.65f) < 0.05f)
        assertTrue(accel.movedBy > 0.1f)
        // The two pedals look identical in this scene, so the match must be flagged as uncertain.
        assertTrue(accel.ambiguous)
    }
}

class CalibrationCodecTest {
    @Test
    fun roundTripKeepsDetectionsTimingAndLayout() {
        val c = FakeClock()
        val r = CalibRig(CalibrationEngine(c), c)
        r.observe()
        r.demo(CalibRole.ACCELERATOR, setOf("accel"))
        r.demo(CalibRole.BRAKE, emptySet(), flashAll = true)
        val persisted = r.engine.persisted()
        val text = CalibrationCodec.format(persisted)
        val parsed = CalibrationCodec.parse(text)
        assertTrue(parsed.warnings.toString(), parsed.warnings.isEmpty())
        val back = parsed.calibration
        assertEquals(persisted.layout, back.layout)
        for ((role, d) in persisted.detections) {
            val b = back.detections[role]!!
            assertEquals(d.status, b.status)
            assertEquals(d.confidence, b.confidence, 1e-3f)
            assertEquals(d.x, b.x, 1e-3f)
            assertEquals(d.source, b.source)
        }
        assertEquals(persisted.timing!!.stoppedThreshold!!, back.timing!!.stoppedThreshold!!, 1e-4f)
        assertEquals(persisted.timing!!.suggestedSettleMs, back.timing!!.suggestedSettleMs)
    }

    @Test
    fun aForgedAutoConfirmationIsDowngraded() {
        val text = "version=1\ndet.BRAKE=AUTO_CONFIRMED|0.30|0.5|0.5|DEMONSTRATION|-|forged\n" +
            "det.ACCELERATOR=AUTO_CONFIRMED|0.99|0.5|0.5|USER|-|forged\n"
        val parsed = CalibrationCodec.parse(text).calibration
        assertEquals(DetectionStatus.NEEDS_CONFIRMATION, parsed.detections[CalibRole.BRAKE]!!.status)
        assertEquals(DetectionStatus.NEEDS_CONFIRMATION, parsed.detections[CalibRole.ACCELERATOR]!!.status)
    }

    @Test
    fun garbageIsSkippedWithWarningsAndNeverCrashes() {
        val parsed = CalibrationCodec.parse("det.NOPE=x\ndet.BRAKE=bad\nlayout=zz\ndet.GEAR_REVERSE=NONE|0|0|0|DEMONSTRATION|-|none")
        assertTrue(parsed.warnings.size >= 3)
        assertEquals(1, parsed.calibration.detections.size)
        assertNull(parsed.calibration.layout)
    }
}

class ProfileArchiveTest {
    private val profileText = ProfileCodec.format(
        TestProfiles.full().let { p -> p.copy(templates = p.templates.filterKeys { it == "hud_marker" }, stateRules = mapOf()) },
    )

    @Test
    fun roundTrip() {
        val bytes = ProfileArchive.pack(profileText, "version=1\n", mapOf("hud_marker" to byteArrayOf(1, 2, 3)))
        val c = ProfileArchive.unpack(bytes)
        assertEquals("test", c.profile.name)
        assertEquals(listOf<Byte>(1, 2, 3), c.templatesPng["hud_marker"]!!.toList())
        assertEquals("version=1\n", c.calibrationText)
        assertTrue(c.warnings.isEmpty())
    }

    @Test
    fun missingTemplateImagesAreReported() {
        val c = ProfileArchive.unpack(ProfileArchive.pack(profileText, null, emptyMap()))
        assertTrue(c.warnings.any { it.contains("hud_marker") })
    }

    private fun zip(vararg entries: Pair<String, ByteArray>): ByteArray {
        val out = ByteArrayOutputStream()
        ZipOutputStream(out).use { z ->
            for ((n, b) in entries) {
                z.putNextEntry(ZipEntry(n))
                z.write(b)
                z.closeEntry()
            }
        }
        return out.toByteArray()
    }

    private fun assertRejected(bytes: ByteArray) {
        try {
            ProfileArchive.unpack(bytes)
            fail("expected the archive to be rejected")
        } catch (e: IllegalArgumentException) {
            // expected
        }
    }

    @Test
    fun malformedArchivesAreRejected() {
        assertRejected(byteArrayOf(1, 2, 3, 4))
        assertRejected(zip("readme.txt" to "hi".toByteArray())) // no profile
        assertRejected(zip(ProfileArchive.PROFILE_ENTRY to "bogus.key=1".toByteArray())) // invalid profile
    }

    @Test
    fun oversizedEntriesAndUnsafeNamesAreHandled() {
        assertRejected(zip(ProfileArchive.PROFILE_ENTRY to ByteArray(600 * 1024) { 'a'.code.toByte() }))
        val c = ProfileArchive.unpack(
            zip(
                ProfileArchive.PROFILE_ENTRY to profileText.toByteArray(),
                "templates/../../evil.png" to byteArrayOf(9),
                "templates/UPPER.png" to byteArrayOf(9),
                "other/thing.bin" to byteArrayOf(9),
            ),
        )
        assertTrue(c.templatesPng.isEmpty())
        assertTrue(c.warnings.size >= 3)
    }

    @Test
    fun tooManyEntriesAreRejected() {
        val many = (0..310).map { "templates/t$it.png" to byteArrayOf(1) }.toTypedArray()
        assertRejected(zip(ProfileArchive.PROFILE_ENTRY to profileText.toByteArray(), *many))
    }
}
