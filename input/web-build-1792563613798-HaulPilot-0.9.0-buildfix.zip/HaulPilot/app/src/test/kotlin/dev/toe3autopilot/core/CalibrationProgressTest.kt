package dev.toe3autopilot.core

import dev.toe3autopilot.core.calibration.CalibPhase
import dev.toe3autopilot.core.calibration.CalibRole
import dev.toe3autopilot.core.calibration.CalibrationEngine
import dev.toe3autopilot.core.calibration.CalibrationState
import dev.toe3autopilot.core.calibration.CalibrationSummaries
import dev.toe3autopilot.core.calibration.ConfidenceLevel
import dev.toe3autopilot.core.calibration.ControlDetection
import dev.toe3autopilot.core.calibration.ControlStatus
import dev.toe3autopilot.core.calibration.DetectionSource
import dev.toe3autopilot.core.calibration.DetectionStatus
import dev.toe3autopilot.core.calibration.StageState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

private fun det(role: CalibRole, status: DetectionStatus, conf: Float, source: DetectionSource = DetectionSource.DEMONSTRATION) =
    ControlDetection(role, 0.8f, 0.8f, null, conf, status, source, emptyList())

class ControlSummaryTest {
    @Test
    fun nothingKnownMeansEverythingRequiredIsMissing() {
        val s = CalibrationSummaries.controls(emptyMap(), emptySet())
        assertFalse(s.ready)
        assertEquals(4, s.missingRequired)
        assertEquals(0, s.confirmed)
        assertEquals(ConfidenceLevel.NONE, s.level)
        assertNull(s.averageConfidence)
    }

    @Test
    fun anUncertainDetectionIsNeverShownAsConfirmed() {
        val s = CalibrationSummaries.controls(mapOf(CalibRole.BRAKE to det(CalibRole.BRAKE, DetectionStatus.NEEDS_CONFIRMATION, 0.5f)), emptySet())
        val line = s.lines.first { it.role == CalibRole.BRAKE }
        assertEquals(ControlStatus.UNCERTAIN, line.status)
        assertEquals(1, s.uncertain)
        assertEquals(0, s.confirmed)
    }

    @Test
    fun anUncertainNewProposalOverridesAnOldSavedControlInTheDisplay() {
        val s = CalibrationSummaries.controls(
            mapOf(CalibRole.BRAKE to det(CalibRole.BRAKE, DetectionStatus.NEEDS_CONFIRMATION, 0.5f)),
            setOf(Control.BRAKE),
        )
        assertEquals(ControlStatus.UNCERTAIN, s.lines.first { it.role == CalibRole.BRAKE }.status)
    }

    @Test
    fun rejectedAndNoneAreMissing() {
        val s = CalibrationSummaries.controls(
            mapOf(
                CalibRole.BRAKE to det(CalibRole.BRAKE, DetectionStatus.REJECTED, 0.9f),
                CalibRole.ACCELERATOR to ControlDetection.none(CalibRole.ACCELERATOR, "x"),
            ),
            emptySet(),
        )
        assertEquals(ControlStatus.MISSING, s.lines.first { it.role == CalibRole.BRAKE }.status)
        assertEquals(ControlStatus.MISSING, s.lines.first { it.role == CalibRole.ACCELERATOR }.status)
    }

    @Test
    fun savedControlsCountAsConfirmedAndMakeTheSetReady() {
        val s = CalibrationSummaries.controls(emptyMap(), setOf(Control.ACCELERATOR, Control.BRAKE, Control.STEER_LEFT, Control.STEER_RIGHT))
        assertTrue(s.ready)
        assertEquals(4, s.saved)
        assertEquals(0, s.missingRequired)
        // reverse is optional and still missing
        assertEquals(1, s.missing)
    }

    @Test
    fun aSteeringWheelMakesLeftAndRightOptional() {
        val s = CalibrationSummaries.controls(emptyMap(), setOf(Control.ACCELERATOR, Control.BRAKE, Control.STEER_CENTER))
        assertTrue(s.ready)
        assertFalse(s.lines.first { it.role == CalibRole.STEER_LEFT }.required)
    }

    @Test
    fun confidenceLevelsFollowTheAverage() {
        fun level(c: Float) = CalibrationSummaries.controls(
            mapOf(CalibRole.ACCELERATOR to det(CalibRole.ACCELERATOR, DetectionStatus.NEEDS_CONFIRMATION, c)), emptySet(),
        ).level
        assertEquals(ConfidenceLevel.LOW, level(0.3f))
        assertEquals(ConfidenceLevel.MEDIUM, level(0.6f))
        assertEquals(ConfidenceLevel.HIGH, level(0.9f))
    }
}

class CalibrationProgressTest {
    private val all4 = setOf(Control.ACCELERATOR, Control.BRAKE, Control.STEER_LEFT, Control.STEER_RIGHT)

    @Test
    fun beforeAnythingEverythingIsPendingAtZero() {
        val p = CalibrationSummaries.progress(CalibrationState(), emptySet(), null)
        assertTrue(p.stages.all { it.state == StageState.PENDING })
        assertEquals(0f, p.fraction, 0f)
        assertNull(p.blocker)
        assertFalse(p.complete)
    }

    @Test
    fun observationFinishesStagesAAndB() {
        val clock = FakeClock()
        val rig = CalibRig(CalibrationEngine(clock), clock)
        rig.observe()
        val p = CalibrationSummaries.progress(rig.engine.state(), emptySet(), null)
        assertEquals(StageState.DONE, p.stages[0].state)
        assertEquals(StageState.DONE, p.stages[1].state)
        assertEquals(StageState.ACTIVE, p.stages[2].state)
        assertTrue(p.stages[2].detail.startsWith("0 of 4"))
        assertTrue(p.fraction in 0.4f..0.6f)
    }

    @Test
    fun confirmingControlsAdvancesStageC() {
        val clock = FakeClock()
        val rig = CalibRig(CalibrationEngine(clock), clock)
        rig.observe()
        rig.engine.place(CalibRole.ACCELERATOR, 0.9f, 0.8f)
        rig.engine.place(CalibRole.BRAKE, 0.78f, 0.8f)
        val p = CalibrationSummaries.progress(rig.engine.state(), emptySet(), null)
        assertTrue(p.stages[2].detail.startsWith("2 of 4"))
        assertEquals(StageState.ACTIVE, p.stages[2].state)
    }

    @Test
    fun fullySavedProfileIsComplete() {
        val st = CalibrationState(
            phase = CalibPhase.DONE,
            detections = CalibRole.entries.filter { it.control != null }.associateWith { det(it, DetectionStatus.CONFIRMED, 1f, DetectionSource.USER) },
        )
        val p = CalibrationSummaries.progress(st, all4, null)
        assertEquals(StageState.DONE, p.stages[2].state)
        assertEquals(StageState.DONE, p.stages[3].state)
    }

    @Test
    fun aCaptureProblemBlocksStageAAndIsTheBlocker() {
        val p = CalibrationSummaries.progress(CalibrationState(), emptySet(), "The game picture arrives black")
        assertEquals(StageState.BLOCKED, p.stages[0].state)
        assertEquals("The game picture arrives black", p.blocker)
    }

    @Test
    fun anUnstableLayoutBlocksStageBWithTheReason() {
        val st = CalibrationState(problem = "The on-screen layout changed", layoutUnstable = true)
        val p = CalibrationSummaries.progress(st, emptySet(), null)
        assertEquals(StageState.BLOCKED, p.stages[1].state)
        assertNotNull(p.blocker)
        assertTrue(p.blocker!!.contains("layout"))
    }

    @Test
    fun aFailedAnalysisOnAStaticSceneIsBlockedWithItsReason() {
        val clock = FakeClock()
        val rig = CalibRig(CalibrationEngine(clock), clock)
        rig.engine.startObserving()
        repeat(60) { rig.step(250, false) }
        rig.engine.stopObserving()
        val p = CalibrationSummaries.progress(rig.engine.state(), emptySet(), null)
        assertEquals(StageState.BLOCKED, p.stages[0].state)
        assertTrue(p.blocker!!.contains("barely changes"))
    }
}
