package dev.toe3autopilot.core

import dev.toe3autopilot.core.calibration.CalibPhase
import dev.toe3autopilot.core.calibration.CalibRole
import dev.toe3autopilot.core.calibration.CalibrationState
import dev.toe3autopilot.core.calibration.CalibrationSummaries
import dev.toe3autopilot.core.calibration.ControlDetection
import dev.toe3autopilot.core.calibration.DetectionSource
import dev.toe3autopilot.core.calibration.DetectionStatus
import dev.toe3autopilot.core.overlay.DockPosition
import dev.toe3autopilot.core.overlay.OverlayInputs
import dev.toe3autopilot.core.overlay.OverlayModel
import dev.toe3autopilot.core.overlay.OverlayPlacement
import dev.toe3autopilot.core.overlay.OverlayTone
import dev.toe3autopilot.core.overlay.TapGuard
import dev.toe3autopilot.core.session.DrivePhase
import dev.toe3autopilot.core.session.SessionSnapshot
import dev.toe3autopilot.core.session.SessionStatus
import dev.toe3autopilot.core.session.UserState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** The floating controls are a pure function of the app state: these tests pin that mapping down. */
class OverlayModelTest {
    private fun inputs(
        status: SessionStatus = SessionStatus.IDLE,
        phase: DrivePhase? = null,
        capture: Boolean = true,
        armed: String? = null,
        cal: CalibrationState = CalibrationState(),
        note: String? = null,
        show: Boolean = true,
    ) = OverlayInputs(
        snapshot = SessionSnapshot(status = status, phase = phase, task = "task text"),
        captureOn = capture,
        armedMessage = armed,
        calibration = cal,
        progress = CalibrationSummaries.progress(cal, emptySet(), null),
        controls = CalibrationSummaries.controls(cal.detections, emptySet()),
        note = note,
        recordingSnapshots = false,
        showWhileCaptureOn = show,
    )

    private fun det(role: CalibRole, status: DetectionStatus, conf: Float) =
        ControlDetection(role, 0.5f, 0.5f, null, conf, status, if (status == DetectionStatus.CONFIRMED) DetectionSource.USER else DetectionSource.VIDEO, emptyList())

    @Test
    fun hiddenWhenNothingIsHappeningAndCaptureIsOff() {
        val ui = OverlayModel.build(inputs(capture = false))
        assertFalse(ui.visible)
        assertFalse(ui.canStartDrive)
    }

    @Test
    fun readyWithCaptureOnOffersStartAndCalibrationButNotPause() {
        val ui = OverlayModel.build(inputs())
        assertTrue(ui.visible)
        assertEquals(UserState.READY, ui.state)
        assertTrue(ui.canStartDrive)
        assertTrue(ui.canStartCalibration)
        assertFalse(ui.canPause)
        assertFalse(ui.canResume)
        assertFalse(ui.canEnd)
        assertTrue(ui.canEmergency)
    }

    @Test
    fun theSettingCanHideTheIdleButtonButNeverDuringADrive() {
        assertFalse(OverlayModel.build(inputs(show = false)).visible)
        assertTrue(OverlayModel.build(inputs(status = SessionStatus.RUNNING, phase = DrivePhase.DRIVING, show = false)).visible)
    }

    @Test
    fun drivingAllowsPauseAndEndButNotAnotherStartOrCalibration() {
        val ui = OverlayModel.build(inputs(status = SessionStatus.RUNNING, phase = DrivePhase.APPROACHING))
        assertEquals(UserState.APPROACHING_DELIVERY, ui.state)
        assertEquals(OverlayTone.ACTIVE, ui.tone)
        assertTrue(ui.canPause)
        assertTrue(ui.canEnd)
        assertFalse(ui.canResume)
        assertFalse(ui.canStartDrive)
        assertFalse(ui.canStartCalibration)
        assertNull("no calibration block while driving", ui.calibration)
    }

    @Test
    fun pausedAndNeedsAssistanceOfferResumeAndDrawAttentionOnlyWhenHelpIsNeeded() {
        val paused = OverlayModel.build(inputs(status = SessionStatus.PAUSED, phase = DrivePhase.DRIVING))
        assertTrue(paused.canResume)
        assertFalse(paused.canPause)
        assertFalse(paused.attention)
        val help = OverlayModel.build(inputs(status = SessionStatus.NEEDS_ASSIST, phase = DrivePhase.DRIVING))
        assertEquals(UserState.NEEDS_ASSISTANCE, help.state)
        assertEquals(OverlayTone.DANGER, help.tone)
        assertTrue(help.canResume)
        assertTrue(help.attention)
    }

    @Test
    fun afterEmergencyStopNothingResumesButANewStartIsPossible() {
        val ui = OverlayModel.build(inputs(status = SessionStatus.EMERGENCY_STOPPED))
        assertEquals(UserState.EMERGENCY_STOP, ui.state)
        assertFalse(ui.canResume)
        assertFalse(ui.canPause)
        assertTrue(ui.attention)
        assertTrue(ui.canStartDrive)
    }

    @Test
    fun armingShowsTheCountdownAndCanBeCancelled() {
        val ui = OverlayModel.build(inputs(armed = "Starting in 2…"))
        assertEquals(UserState.STARTING, ui.state)
        assertEquals("Starting in 2…", ui.status)
        assertTrue(ui.canEnd)
        assertEquals("Cancel start", ui.endLabel)
        assertFalse(ui.canStartDrive)
    }

    @Test
    fun calibrationShowsRealProgressAndCountsAndRingOnTheButton() {
        val cal = CalibrationState(
            phase = CalibPhase.OBSERVING, message = "Watching", framesSeen = 4,
            detections = mapOf(
                CalibRole.ACCELERATOR to det(CalibRole.ACCELERATOR, DetectionStatus.CONFIRMED, 1f),
                CalibRole.BRAKE to det(CalibRole.BRAKE, DetectionStatus.NEEDS_CONFIRMATION, 0.5f),
            ),
        )
        val i = inputs(cal = cal)
        val ui = OverlayModel.build(i)
        assertEquals(UserState.CALIBRATING, ui.state)
        assertEquals("Watching", ui.status)
        assertNotNull(ui.calibration)
        val c = ui.calibration!!
        assertEquals(1, c.confirmed)
        assertEquals(1, c.uncertain)
        assertEquals(i.controls.missingRequired, c.missingRequired)
        assertTrue(kotlin.math.abs(i.progress.fraction * 100 - c.percent) <= 1f)
        assertNotNull(ui.ring)
        assertTrue(ui.canCancelCalibration)
        assertFalse("a drive must not start during calibration", ui.canStartDrive)
    }

    @Test
    fun aNoteFromTheLastButtonPressIsShownFirst() {
        assertEquals("Cannot start: no profile", OverlayModel.build(inputs(note = "Cannot start: no profile")).status)
    }

    @Test
    fun dockPositionSnapsToTheNearerEdgeAndSurvivesRotation() {
        val size = 150
        val m = 20
        val left = OverlayPlacement.snap(100, 500, size, 1080, 2400, m)
        assertFalse(left.rightSide)
        val right = OverlayPlacement.snap(800, 500, size, 1080, 2400, m)
        assertTrue(right.rightSide)
        // Same stored position on a landscape screen stays on screen and on the same side.
        val (x, y) = OverlayPlacement.place(right, size, 2400, 1080, m)
        assertEquals(2400 - size - m, x)
        assertTrue(y in 0..(1080 - size))
        // Extreme fractions are clamped onto the screen.
        val (_, yBottom) = OverlayPlacement.place(DockPosition(true, 5f), size, 1080, 2400, m)
        assertTrue(yBottom <= 2400 - size)
    }

    @Test
    fun panelOpensBesideTheButtonAndStaysOnScreen() {
        val (px, py) = OverlayPlacement.panelAnchor(bx = 910, by = 2300, size = 150, panelW = 700, panelH = 900, screenW = 1080, screenH = 2400, gap = 16)
        assertTrue("panel to the left of a right-edge button", px + 700 <= 910)
        assertTrue(py + 900 <= 2400)
        val (lx, _) = OverlayPlacement.panelAnchor(bx = 20, by = 100, size = 150, panelW = 700, panelH = 900, screenW = 1080, screenH = 2400, gap = 16)
        assertEquals(20 + 150 + 16, lx)
    }

    @Test
    fun tapGuardSeparatesDragsAndIgnoresPressesRightAfterOpening() {
        val g = TapGuard(slopPx = 24f)
        assertTrue(g.isTap(100f, 100f, 110f, 95f))
        assertFalse(g.isTap(100f, 100f, 180f, 100f))
        g.panelOpened(1_000)
        assertFalse(g.accepts(1_100))
        assertTrue(g.accepts(1_000 + TapGuard.ARM_DELAY_MS))
    }

    @Test
    fun autoCalibrateShowsRealStageAndCollectionProgressAndTheLinkState() {
        val clock = FakeClock()
        val run = dev.toe3autopilot.core.calibration.AutoCalibrationRun(clock, target = 45).also { it.start() }
        run.onLink(true, null, dev.toe3autopilot.core.capture.FrameOrigin.GAME)
        val scene = SynthHud()
        repeat(9) { k -> clock.now += 400; run.offer(scene.frame(k, 0, moving = true), dev.toe3autopilot.core.capture.FrameOrigin.GAME) }
        val link = dev.toe3autopilot.core.capture.LinkStatus(
            dev.toe3autopilot.core.capture.LinkState.CONNECTED, "live", true, dev.toe3autopilot.core.capture.LinkAction.NONE, null,
        )
        val ui = OverlayModel.build(inputs().copy(auto = run.state(), link = link))
        assertEquals(UserState.CALIBRATING, ui.state)
        assertTrue(ui.status, ui.status.startsWith("Receiving live frames"))
        val c = ui.calibration!!
        // 1 finished stage (connect) + 9/45 of the collection, out of 7 stages.
        assertTrue("percent ${c.percent}", kotlin.math.abs(((1 + 9f / 45f) / 7f * 100f) - c.percent) <= 1f)
        assertTrue(ui.canCancelCalibration)
        assertFalse(ui.canAutoCalibrate)
        assertEquals("Screen connected", ui.linkLabel)
        assertTrue(ui.linkOk)
        assertNotNull(ui.ring)
    }

    @Test
    fun theAdoptGameButtonOnlyAppearsWhenAnotherAppIsInFront() {
        val other = dev.toe3autopilot.core.capture.LinkStatus(
            dev.toe3autopilot.core.capture.LinkState.CONNECTED, "other", false, dev.toe3autopilot.core.capture.LinkAction.CHOOSE_GAME, "Choose",
        )
        assertTrue(OverlayModel.build(inputs().copy(link = other, canAdoptGame = true)).canAdoptGame)
        assertFalse(OverlayModel.build(inputs().copy(link = other, canAdoptGame = false)).canAdoptGame)
        assertFalse("not during a drive", OverlayModel.build(inputs(status = SessionStatus.RUNNING, phase = DrivePhase.DRIVING).copy(link = other, canAdoptGame = true)).canAdoptGame)
        assertFalse(OverlayModel.build(inputs()).linkOk)
    }
}
