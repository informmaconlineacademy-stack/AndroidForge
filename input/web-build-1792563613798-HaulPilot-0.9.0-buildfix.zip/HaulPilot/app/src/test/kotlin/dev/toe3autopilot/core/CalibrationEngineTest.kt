package dev.toe3autopilot.core

import dev.toe3autopilot.core.calibration.CalibPhase
import dev.toe3autopilot.core.calibration.CalibRole
import dev.toe3autopilot.core.calibration.CalibrationEngine
import dev.toe3autopilot.core.calibration.ControlDetection
import dev.toe3autopilot.core.calibration.DetectionSource
import dev.toe3autopilot.core.calibration.DetectionStatus
import dev.toe3autopilot.core.calibration.HudAnalyzer
import dev.toe3autopilot.core.vision.Roi
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import kotlin.math.abs

class HudAnalyzerTest {
    private fun framesMoving(scene: SynthHud, n: Int) = (0 until n).map { scene.frame(it, it * 250L, moving = true, speed = 10 + it) }

    private fun near(el: List<dev.toe3autopilot.core.calibration.HudElement>, x: Float, y: Float, tol: Float = 0.03f) =
        el.any { abs(it.cx - x) <= tol && abs(it.cy - y) <= tol }

    @Test
    fun findsFixedButtonsOverMovingScenery() {
        val scene = SynthHud()
        val a = HudAnalyzer.analyse(framesMoving(scene, 16))
        assertTrue(a.problem ?: "", a.ok)
        for (name in listOf("accel", "brake", "left", "right", "reverse")) {
            val (x, y) = scene.center(name)
            assertTrue("button '$name' was not found; elements=${a.elements.map { it.cx to it.cy }}", near(a.elements, x, y))
        }
        // The scenery itself must not show up as elements.
        assertTrue("too many elements: ${a.elements.size}", a.elements.size <= 8)
    }

    @Test
    fun staticSceneGivesNoResultAndSaysWhy() {
        val scene = SynthHud()
        val frames = (0 until 14).map { scene.frame(it, it * 250L, moving = false) }
        val a = HudAnalyzer.analyse(frames)
        assertFalse(a.ok)
        assertTrue(a.problem!!.contains("barely changes"))
        assertTrue(a.elements.isEmpty())
    }

    @Test
    fun tooFewFramesIsRefused() {
        val scene = SynthHud()
        val a = HudAnalyzer.analyse(framesMoving(scene, 5))
        assertFalse(a.ok)
        assertTrue(a.problem!!.contains("at least"))
    }

    @Test
    fun sceneWithoutAnyHudFindsNothing() {
        val scene = SynthHud()
        val a = HudAnalyzer.analyse((0 until 16).map { scene.frame(it, it * 250L, moving = true, drawHud = false) })
        assertFalse(a.ok)
        assertTrue(a.elements.isEmpty())
    }
}

class CalibrationEngineTest {
    private fun rig(): CalibRig {
        val clock = FakeClock()
        return CalibRig(CalibrationEngine(clock, timings = dev.toe3autopilot.core.calibration.DemoTimings()), clock)
    }

    private fun CalibRig.close(role: CalibRole, name: String) {
        val d = engine.state().detections[role]!!
        val (x, y) = scene.center(name)
        assertTrue("${role.label} detected at (${d.x},${d.y}) expected near ($x,$y)", abs(d.x - x) < 0.04f && abs(d.y - y) < 0.06f)
    }

    @Test
    fun demonstrationsRequireTheHudToBeObservedFirst() {
        val r = rig()
        assertNotNull(r.engine.startDemo(CalibRole.ACCELERATOR))
        // observing a static scene is not enough either
        r.engine.startObserving()
        repeat(60) { r.step(125, false) }
        assertNotNull(r.engine.startDemo(CalibRole.ACCELERATOR))
        assertNotNull(r.engine.state().problem)
    }

    @Test
    fun acceleratorDemoIsFoundWithHighConfidenceAndTimingIsEstimated() {
        val r = rig()
        r.observe()
        val hud = r.engine.state().hud!!
        assertTrue(hud.problem ?: "", hud.ok)
        r.demo(CalibRole.ACCELERATOR, setOf("accel"))
        val st = r.engine.state()
        val d = st.detections[CalibRole.ACCELERATOR]!!
        r.close(CalibRole.ACCELERATOR, "accel")
        assertEquals(d.toString(), DetectionStatus.AUTO_CONFIRMED, d.status)
        assertTrue(d.confidence >= ControlDetection.AUTO_CONFIRM_MIN)
        assertEquals(DetectionSource.DEMONSTRATION, d.source)
        assertTrue(d.evidence.isNotEmpty())
        assertEquals(CalibPhase.DONE, st.phase)

        val t = st.timing!!
        assertNotNull("timing notes: ${t.notes}", t.stoppedThreshold)
        assertTrue("threshold ${t.stoppedThreshold} between rest ${t.restLevel} and moving ${t.movingLevel}", t.stoppedThreshold!! > t.restLevel && t.stoppedThreshold!! < t.movingLevel)
        assertNotNull(t.startLatencyMsUpperBound)
        assertNotNull("stop time; notes=${t.notes}", t.stopMs)
        assertTrue("settle ${t.suggestedSettleMs}", t.suggestedSettleMs!! in 300L..3000L)
        // the speed read-out region is proposed as informational, not confirmed
        assertNotNull(st.speedGuess)
        assertTrue(abs(st.speedGuess!!.x - 0.5f) < 0.05f)
    }

    @Test
    fun brakeIsDistinguishedFromAccelerator() {
        val r = rig()
        r.observe()
        r.demo(CalibRole.ACCELERATOR, setOf("accel"))
        r.demo(CalibRole.BRAKE, setOf("brake"))
        r.close(CalibRole.ACCELERATOR, "accel")
        r.close(CalibRole.BRAKE, "brake")
        assertTrue(r.engine.state().detections[CalibRole.BRAKE]!!.status.usable)
    }

    @Test
    fun ambiguousEvidenceIsNeverAutoConfirmed() {
        val r = rig()
        r.observe()
        // Every button lights up at once (a flash): the evidence cannot single out one control.
        r.demo(CalibRole.BRAKE, emptySet(), flashAll = true)
        val d = r.engine.state().detections[CalibRole.BRAKE]!!
        assertEquals(d.toString(), DetectionStatus.NEEDS_CONFIRMATION, d.status)
        assertFalse(d.status.usable)
        assertTrue(d.confidence <= 0.5f)
        assertTrue(d.evidence.any { it.contains("unreliable") })
    }

    @Test
    fun nothingChangingMeansNothingDetected() {
        val r = rig()
        r.observe()
        r.demo(CalibRole.GEAR_REVERSE, setOf("reverse"), responds = false)
        val d = r.engine.state().detections[CalibRole.GEAR_REVERSE]!!
        assertEquals(DetectionStatus.NONE, d.status)
        assertFalse(d.status.usable)
        assertTrue(r.engine.state().message.contains("nothing found", ignoreCase = true))
    }

    @Test
    fun oneElementReactingToBothDirectionsIsProposedAsAWheelAndNeedsConfirmation() {
        val r = rig()
        r.scene.wheelInsteadOfButtons = true
        r.observe()
        r.demo(CalibRole.STEER_LEFT, emptySet(), wheelAngle = -50)
        r.demo(CalibRole.STEER_RIGHT, emptySet(), wheelAngle = 50)
        val s = r.engine.state().detections
        val wheel = s[CalibRole.STEER_WHEEL]
        assertNotNull("detections=$s", wheel)
        assertEquals(DetectionStatus.NEEDS_CONFIRMATION, wheel!!.status)
        assertFalse(s[CalibRole.STEER_LEFT]!!.status.usable)
        assertFalse(s[CalibRole.STEER_RIGHT]!!.status.usable)
        assertTrue(abs(wheel.x - r.scene.wheelRing.x) < 0.05f)
    }

    @Test
    fun separateButtonsForLeftAndRightAreEachFound() {
        val r = rig()
        r.observe()
        r.demo(CalibRole.STEER_LEFT, setOf("left"))
        r.demo(CalibRole.STEER_RIGHT, setOf("right"))
        r.close(CalibRole.STEER_LEFT, "left")
        r.close(CalibRole.STEER_RIGHT, "right")
        assertNull(r.engine.state().detections[CalibRole.STEER_WHEEL])
    }

    @Test
    fun confirmRejectAndManualPlacement() {
        val r = rig()
        r.observe()
        r.demo(CalibRole.BRAKE, emptySet(), flashAll = true)
        assertEquals(DetectionStatus.NEEDS_CONFIRMATION, r.engine.state().detections[CalibRole.BRAKE]!!.status)
        assertTrue(r.engine.confirm(CalibRole.BRAKE))
        assertEquals(DetectionStatus.CONFIRMED, r.engine.state().detections[CalibRole.BRAKE]!!.status)
        assertTrue(r.engine.state().detections[CalibRole.BRAKE]!!.status.usable)
        assertTrue(r.engine.reject(CalibRole.BRAKE))
        assertEquals(DetectionStatus.REJECTED, r.engine.state().detections[CalibRole.BRAKE]!!.status)
        assertFalse(r.engine.state().detections[CalibRole.BRAKE]!!.status.usable)
        // A detection that does not exist cannot be confirmed.
        assertFalse(r.engine.confirm(CalibRole.GEAR_REVERSE))
        r.engine.place(CalibRole.GEAR_REVERSE, 0.5f, 1.5f)
        val placed = r.engine.state().detections[CalibRole.GEAR_REVERSE]!!
        assertEquals(DetectionStatus.CONFIRMED, placed.status)
        assertEquals(DetectionSource.USER, placed.source)
        assertEquals(1f, placed.y, 0f) // clamped
        assertTrue(r.engine.patches().containsKey(CalibRole.GEAR_REVERSE))
    }

    @Test
    fun cannotConfirmWhenNothingWasFound() {
        val r = rig()
        r.observe()
        r.demo(CalibRole.GEAR_REVERSE, setOf("reverse"), responds = false)
        assertFalse(r.engine.confirm(CalibRole.GEAR_REVERSE))
        assertEquals(DetectionStatus.NONE, r.engine.state().detections[CalibRole.GEAR_REVERSE]!!.status)
    }

    @Test
    fun screenSizeChangeDiscardsTheHudAndCancelsDemos() {
        val r = rig()
        r.observe()
        assertNotNull(r.engine.state().hud)
        val other = SynthHud(w = 240, h = 180)
        r.engine.offerFrame(other.frame(1, r.clock.now + 500, moving = true))
        val s = r.engine.state()
        assertNull(s.hud)
        assertNotNull(s.problem)
        assertEquals(240, s.layout!!.width)
        assertNotNull(r.engine.startDemo(CalibRole.ACCELERATOR)) // refused: must observe again
    }

    @Test
    fun resetForgetsEverything() {
        val r = rig()
        r.observe()
        r.demo(CalibRole.ACCELERATOR, setOf("accel"))
        r.engine.reset()
        val s = r.engine.state()
        assertTrue(s.detections.isEmpty())
        assertNull(s.hud)
        assertNull(s.timing)
        assertTrue(r.engine.patches().isEmpty())
    }

    @Test
    fun demonstrationCanBeCancelled() {
        val r = rig()
        r.observe()
        assertNull(r.engine.startDemo(CalibRole.ACCELERATOR))
        assertTrue(r.engine.isBusy)
        r.engine.cancel()
        assertFalse(r.engine.isBusy)
        assertEquals(CalibPhase.IDLE, r.engine.state().phase)
    }

    @Test
    fun invariantsCannotBeBypassed() {
        try {
            ControlDetection(CalibRole.BRAKE, 0.5f, 0.5f, null, 0.5f, DetectionStatus.AUTO_CONFIRMED, DetectionSource.DEMONSTRATION, emptyList())
            fail("low-confidence auto-confirm must be rejected")
        } catch (e: IllegalArgumentException) {
            // expected
        }
        try {
            ControlDetection(CalibRole.BRAKE, 0.5f, 0.5f, null, 0.95f, DetectionStatus.AUTO_CONFIRMED, DetectionSource.PRIOR, emptyList())
            fail("a position guess must never be auto-confirmed")
        } catch (e: IllegalArgumentException) {
            // expected
        }
        try {
            ControlDetection(CalibRole.BRAKE, 0.5f, 0.5f, null, 0.9f, DetectionStatus.NEEDS_CONFIRMATION, DetectionSource.PRIOR, emptyList())
            fail("a position guess may not claim high confidence")
        } catch (e: IllegalArgumentException) {
            // expected
        }
    }

    @Test
    fun positionGuessesAreOnlyOfferedAsLowConfidenceHelp() {
        val r = rig()
        r.observe()
        val g = r.engine.state().guesses
        val accel = g[CalibRole.ACCELERATOR].orEmpty()
        assertTrue(accel.isNotEmpty())
        assertTrue(accel.all { it.score <= ControlDetection.PRIOR_MAX_CONFIDENCE })
        assertTrue("guess should be the right-most lower element", abs(accel.first().x - 0.90f) < 0.05f)
        assertTrue(r.engine.state().detections.isEmpty()) // guesses are not detections
    }

    @Test
    fun minimapIsOnlyProposed() {
        val r = rig()
        r.observe()
        val m = r.engine.state().minimap
        assertNotNull(m)
        assertTrue(m!!.box.left < 0.3f)
        assertEquals(Roi(m.box.left, m.box.top, m.box.right, m.box.bottom), m.box)
        assertNotNull(m.routeColorRgb)
    }

    @Test
    fun savedSnapshotsCanBeAnalysedLikeLiveObservation() {
        val clock = FakeClock()
        val engine = CalibrationEngine(clock)
        val scene = SynthHud()
        val frames = (1..14).map { i -> scene.frame(i, 1000L * i, true, emptySet(), 10 + i, 0, true) }
        assertNull(engine.analyseSnapshots(frames))
        val st = engine.state()
        assertTrue(st.hud?.problem ?: "no analysis", st.hud?.ok == true)
        // a demonstration can follow
        assertNull(engine.startDemo(CalibRole.ACCELERATOR))
    }

    @Test
    fun snapshotAnalysisRefusesTooFewOrMixedSizes() {
        val engine = CalibrationEngine(FakeClock())
        val a = SynthHud(320, 180)
        val b = SynthHud(160, 90)
        assertNotNull(engine.analyseSnapshots((1..3).map { a.frame(it, it * 1000L, true, emptySet(), 10, 0, true) }))
        val mixed = (1..12).map { i -> (if (i % 2 == 0) a else b).frame(i, i * 1000L, true, emptySet(), 10, 0, true) }
        assertNotNull(engine.analyseSnapshots(mixed))
    }
}
