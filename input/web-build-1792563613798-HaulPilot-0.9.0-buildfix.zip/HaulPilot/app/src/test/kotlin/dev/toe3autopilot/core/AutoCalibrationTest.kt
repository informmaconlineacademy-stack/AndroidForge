package dev.toe3autopilot.core

import dev.toe3autopilot.core.calibration.AutoCalibrationRun
import dev.toe3autopilot.core.calibration.AutoStage
import dev.toe3autopilot.core.calibration.CalibRole
import dev.toe3autopilot.core.calibration.Recovery
import dev.toe3autopilot.core.calibration.RunPhase
import dev.toe3autopilot.core.calibration.StageStatus
import dev.toe3autopilot.core.calibration.TapSnap
import dev.toe3autopilot.core.calibration.ViewTransform
import dev.toe3autopilot.core.calibration.ViewportDetector
import dev.toe3autopilot.core.capture.CaptureFault
import dev.toe3autopilot.core.capture.CaptureHealthMonitor
import dev.toe3autopilot.core.capture.FrameGate
import dev.toe3autopilot.core.capture.FrameOrigin
import dev.toe3autopilot.core.capture.LinkAction
import dev.toe3autopilot.core.capture.LinkState
import dev.toe3autopilot.core.capture.ScreenLink
import dev.toe3autopilot.core.vision.Frame
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

/** Which pictures count as the game: the root cause of "calibration receives nothing". */
class FrameGateTest {
    @Test
    fun theGameIsOnlyTheSelectedPackageAndHaulPilotIsNever() {
        assertEquals(FrameOrigin.OWN_APP, FrameGate.classify(true, true, "game", "game"))
        assertEquals(FrameOrigin.GAME, FrameGate.classify(false, true, "game", "game"))
        assertEquals(FrameOrigin.OTHER_APP, FrameGate.classify(false, true, "com.other", "game"))
        assertEquals("cannot tell without accessibility", FrameOrigin.UNKNOWN, FrameGate.classify(false, false, null, "game"))
        assertTrue(FrameGate.analysable(FrameOrigin.GAME) && FrameGate.analysable(FrameOrigin.UNKNOWN))
        assertFalse(FrameGate.analysable(FrameOrigin.OWN_APP) || FrameGate.analysable(FrameOrigin.OTHER_APP))
    }

    @Test
    fun launchersKeyboardsAndHaulPilotCanNeverBeAdoptedAsTheGame() {
        val own = "com.praju12.haulpilot"
        assertFalse(FrameGate.couldBeGame("com.google.android.apps.nexuslauncher", own))
        assertFalse(FrameGate.couldBeGame("com.android.systemui", own))
        assertFalse(FrameGate.couldBeGame("com.samsung.android.honeyboard.inputmethod", own))
        assertFalse(FrameGate.couldBeGame(own, own))
        assertTrue(FrameGate.couldBeGame("com.some.studio.truckgame", own))
    }

    @Test
    fun theInstalledGameIsFoundByItsName() {
        val apps = listOf("Chrome" to "com.android.chrome", "Truckers of Europe 3" to "com.studio.toe3real", "Maps" to "x")
        assertEquals("com.studio.toe3real", FrameGate.findInstalledGame(apps))
        assertNull(FrameGate.findInstalledGame(listOf("Chrome" to "com.android.chrome")))
    }
}

/** The connection status never claims "connected" without real pictures. */
class ScreenLinkTest {
    private val clock = FakeClock()
    private fun monitor() = CaptureHealthMonitor(clock)

    @Test
    fun permissionDialogAndDenial() {
        assertEquals(LinkState.WAITING_FOR_PERMISSION, ScreenLink.status(true, false, monitor().diagnose(), null, null, null).state)
        val m = monitor().also { it.onFault(CaptureFault.PERMISSION_DENIED) }
        val s = ScreenLink.status(false, false, m.diagnose(), null, null, null)
        assertEquals(LinkState.FAILED, s.state)
        assertEquals(LinkAction.RETRY, s.action)
    }

    @Test
    fun notConnectedUntilTheFirstPictureArrives() {
        assertEquals(LinkState.NOT_CONNECTED, ScreenLink.status(false, false, monitor().diagnose(), null, null, null).state)
        val m = monitor().also { it.onCaptureStarted() }
        val waiting = ScreenLink.status(false, true, m.diagnose(), FrameOrigin.GAME, null, "game")
        assertEquals(LinkState.NOT_CONNECTED, waiting.state)
        assertFalse(waiting.receivingGame)
    }

    @Test
    fun noPicturesAtAllIsAFailureNotAConnection() {
        val m = monitor().also { it.onCaptureStarted() }
        clock.now += 30_000
        assertEquals(LinkState.FAILED, ScreenLink.status(false, true, m.diagnose(), FrameOrigin.GAME, null, "game").state)
    }

    @Test
    fun stalePicturesWhileTheGameIsInFrontAreReported() {
        val m = monitor().also { it.onCaptureStarted() }
        val d = m.diagnose()
        val fresh = ScreenLink.status(false, true, d.copy(kind = dev.toe3autopilot.core.capture.DiagnosisKind.HEALTHY), FrameOrigin.GAME, 500, "game")
        assertEquals(LinkState.CONNECTED, fresh.state)
        assertTrue(fresh.receivingGame)
        val stale = ScreenLink.status(false, true, d.copy(kind = dev.toe3autopilot.core.capture.DiagnosisKind.HEALTHY), FrameOrigin.GAME, ScreenLink.STALE_MS + 1, "game")
        assertEquals(LinkState.FAILED, stale.state)
        assertEquals(LinkAction.RETRY, stale.action)
    }

    @Test
    fun theWrongAppInFrontIsSaidAndCanBeFixed() {
        val d = monitor().diagnose().copy(kind = dev.toe3autopilot.core.capture.DiagnosisKind.HEALTHY)
        val other = ScreenLink.status(false, true, d, FrameOrigin.OTHER_APP, 300, "com.other")
        assertEquals(LinkState.CONNECTED, other.state)
        assertFalse(other.receivingGame)
        assertEquals(LinkAction.CHOOSE_GAME, other.action)
        assertTrue(other.detail.contains("com.other"))
        val own = ScreenLink.status(false, true, d, FrameOrigin.OWN_APP, 300, "x")
        assertFalse(own.receivingGame)
        assertEquals(LinkAction.OPEN_GAME, own.action)
    }
}

/** One-tap Auto-Calibrate on synthetic gameplay pictures (not the real game). */
class AutoCalibrationRunTest {
    private val clock = FakeClock()

    /** Idle, then accelerator held while the scenery moves, then braking while it slows. */
    private fun drive(scene: SynthHud, n: Int = 45): List<Frame> = (0 until n).map { k ->
        val going = k in 8..24
        val braking = k in 30..38
        scene.frame(k, k * 330L, moving = going || braking, pressed = when { going -> setOf("accel"); braking -> setOf("brake"); else -> emptySet() }, speed = k * 7)
    }

    private fun run(): AutoCalibrationRun = AutoCalibrationRun(clock, target = 45, spacingMs = 330).also { it.start() }

    @Test
    fun onlyGamePicturesAreCollectedAndProgressIsReal() {
        val r = run()
        val scene = SynthHud()
        r.onLink(true, null, FrameOrigin.OWN_APP)
        assertEquals(StageStatus.DONE, r.state().stages.first { it.stage == AutoStage.CONNECT }.status)
        r.offer(scene.frame(0, 0, moving = false), FrameOrigin.OWN_APP)
        r.offer(scene.frame(1, 0, moving = false), FrameOrigin.OTHER_APP)
        assertEquals(0, r.state().collected)
        for (f in drive(scene).take(10)) {
            clock.now += 330
            r.offer(f, FrameOrigin.GAME)
        }
        assertEquals(10, r.state().collected)
        assertEquals(RunPhase.COLLECTING, r.state().phase)
        // Pictures arriving faster than the spacing are not counted twice.
        r.offer(scene.frame(99, 0, moving = true), FrameOrigin.GAME)
        assertEquals(10, r.state().collected)
    }

    @Test
    fun aFullRunFindsTheControlsFromEvidenceAndAsksOnlyForWhatIsLeft() {
        val r = run()
        val scene = SynthHud()
        r.onLink(true, null, FrameOrigin.GAME)
        for (f in drive(scene)) {
            clock.now += 330
            r.offer(f, FrameOrigin.GAME)
        }
        assertTrue(r.readyToAnalyse())
        val preview = r.analyse()
        assertNotNull(preview)
        val s = r.state()
        assertEquals(s.problem ?: "", RunPhase.REVIEW, s.phase)
        val res = s.result!!
        assertTrue("accelerator from evidence", CalibRole.ACCELERATOR in res.evidenceRoles)
        val acc = res.video.detections[CalibRole.ACCELERATOR]!!
        val (ax, ay) = scene.center("accel")
        assertTrue(abs(acc.x - ax) < 0.06f && abs(acc.y - ay) < 0.08f)
        // Steering is never claimed from evidence: it is asked about.
        assertTrue(res.corrections.any { it.role == CalibRole.STEER_LEFT })
        assertFalse(CalibRole.STEER_LEFT in res.evidenceRoles)
        // Nothing is confirmed by the run itself.
        assertTrue(res.video.detections.values.none { it.status.usable })
        assertTrue(s.stages.none { it.status == StageStatus.WAITING || it.status == StageStatus.RUNNING })
    }

    @Test
    fun aStillPictureFailsAtTheControlsStageWithARecovery() {
        val r = run()
        val scene = SynthHud()
        r.onLink(true, null, FrameOrigin.GAME)
        repeat(45) { k ->
            clock.now += 330
            r.offer(scene.frame(k, k * 330L, moving = false), FrameOrigin.GAME)
        }
        r.analyse()
        val s = r.state()
        assertEquals(RunPhase.FAILED, s.phase)
        assertEquals(Recovery.DRIVE_AND_RETRY, s.recovery)
        assertEquals(StageStatus.FAILED, s.stages.first { it.stage == AutoStage.CONTROLS }.status)
        assertNull(s.result)
    }

    @Test
    fun blackPicturesAreIgnoredAndNoGameTimesOutWithTheRightRecovery() {
        val r = AutoCalibrationRun(clock, target = 45, spacingMs = 330, noGameTimeoutMs = 10_000).also { it.start() }
        val black = Frame(320, 180, IntArray(320 * 180) { 0xFF000000.toInt() }, 0)
        clock.now += 400
        r.offer(black, FrameOrigin.GAME)
        assertEquals(0, r.state().collected)
        clock.now += 20_000
        r.onLink(true, null, FrameOrigin.OTHER_APP)
        assertEquals(RunPhase.FAILED, r.state().phase)
        assertEquals(Recovery.CHOOSE_GAME, r.state().recovery)
    }

    @Test
    fun aCaptureProblemStopsTheRunAtTheConnectStage() {
        val r = run()
        r.onLink(false, "Android stopped the screen capture", null)
        assertEquals(RunPhase.FAILED, r.state().phase)
        assertEquals(Recovery.CONNECT_SCREEN, r.state().recovery)
        assertEquals(StageStatus.FAILED, r.state().stages.first().status)
    }

    @Test
    fun rotatingRestartsTheCollectionInsteadOfMixingLayouts() {
        val r = run()
        val wide = SynthHud(320, 180)
        val tall = SynthHud(180, 320)
        repeat(5) { k -> clock.now += 330; r.offer(wide.frame(k, 0, moving = true), FrameOrigin.GAME) }
        assertEquals(5, r.state().collected)
        clock.now += 330
        r.offer(tall.frame(9, 0, moving = true), FrameOrigin.GAME)
        assertEquals(1, r.state().collected)
    }

    @Test
    fun cancelAndRetry() {
        val r = run()
        r.cancel()
        assertEquals(RunPhase.CANCELLED, r.state().phase)
        r.start()
        assertEquals(RunPhase.COLLECTING, r.state().phase)
        assertEquals(0, r.state().collected)
    }
}

class ViewportAndTouchTest {
    @Test
    fun blackBarsAreExcludedFromTheViewport() {
        val w = 320
        val h = 180
        val px = IntArray(w * h) { i ->
            val x = i % w
            if (x < 40 || x >= 280) 0xFF000000.toInt() else 0xFF808080.toInt()
        }
        val vp = ViewportDetector.detect(listOf(Frame(w, h, px, 0)))
        assertEquals(40f / w, vp.left, 1e-4f)
        assertEquals(280f / w, vp.right, 1e-4f)
        assertEquals(0f, vp.top, 1e-4f)
    }

    @Test
    fun aTapSnapsToTheButtonUnderTheFingerOrMakesASensibleBox() {
        val scene = SynthHud()
        val frames = (0 until 30).map { scene.frame(it, it * 250L, moving = true, speed = it * 7) }
        val hud = dev.toe3autopilot.core.calibration.HudAnalyzer.analyse(frames)
        assertTrue(hud.problem ?: "", hud.ok)
        val (bx, by) = scene.center("brake")
        val box = TapSnap.boxFor(hud, bx, by, aspect = 320f / 180f)
        assertTrue("snapped box contains the tap", bx in box.left..box.right && by in box.top..box.bottom)
        assertTrue("snapped to a button-sized element", (box.right - box.left) < 0.2f)
        val fallback = TapSnap.boxFor(null, 0.99f, 0.01f, aspect = 1.8f)
        assertTrue(fallback.right <= 1f && fallback.top >= 0f)
    }

    @Test
    fun zoomedTapsMapBackToThePictureAndOffPictureTapsAreIgnored() {
        var t = ViewTransform(400f, 225f)
        assertEquals(0.5f, t.toImage(200f, 112.5f)!!.first, 1e-4f)
        // Zoom 2x around the centre: the view centre still shows the picture centre.
        t = t.transformed(2f, 0f, 0f, 200f, 112.5f)
        assertEquals(2f, t.scale, 1e-4f)
        val c = t.toImage(200f, 112.5f)!!
        assertEquals(0.5f, c.first, 1e-3f)
        assertEquals(0.5f, c.second, 1e-3f)
        // Panning cannot move the picture away from the view edge, and zoom is limited.
        val panned = t.transformed(1f, 10_000f, 10_000f, 0f, 0f)
        assertEquals(0f, panned.offsetX, 1e-3f)
        assertTrue(t.transformed(100f, 0f, 0f, 0f, 0f).scale <= ViewTransform.MAX_SCALE)
        assertNull(ViewTransform(400f, 225f).toImage(-5f, 10f))
    }
}
