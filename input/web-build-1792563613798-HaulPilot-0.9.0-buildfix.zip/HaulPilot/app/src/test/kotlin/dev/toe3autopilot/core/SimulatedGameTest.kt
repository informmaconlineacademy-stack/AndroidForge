package dev.toe3autopilot.core

import dev.toe3autopilot.core.session.DrivePhase
import dev.toe3autopilot.core.session.SessionManager
import dev.toe3autopilot.core.session.SessionStatus
import dev.toe3autopilot.core.session.UserState
import dev.toe3autopilot.core.session.userState
import dev.toe3autopilot.core.state.GameState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

/** Closed-loop tests against [SimulatedGame]: see its documentation for what these do and do not prove. */
class SimulatedGameTest {
    private class World(settings: AutomationSettings = AutomationSettings(), zoneX: Float = 0.64f, routeOffset: Float = 0.05f) {
        val clock = FakeClock()
        val game = SimulatedGame(clock, zoneX, routeOffset)
        val input = SimInput(game, clock)
        val frames = FakeFrames().also { it.frame = game.render() }
        val monitor = FakeMonitor()
        val profile = TestProfiles.full()
        var settings = settings
        val session = SessionManager(
            frames, monitor, input, { profile }, MapTemplateStore(TestProfiles.templateImages()),
            { this.settings }, clock,
        )
        var tickNanos = 0L
        var ticks = 0
        val phases = ArrayList<DrivePhase?>()

        fun runUntil(maxMs: Long, done: () -> Boolean): Boolean {
            var t = 0L
            while (t < maxMs) {
                if (done()) return true
                val t0 = System.nanoTime()
                val delay = session.tick()
                tickNanos += System.nanoTime() - t0
                ticks++
                val p = session.currentSnapshot().phase
                if (phases.lastOrNull() != p) phases.add(p)
                val dt = delay.coerceIn(50L, 500L)
                clock.advance(dt)
                game.step()
                frames.frame = game.render()
                t += dt
            }
            return done()
        }

        fun status() = session.currentSnapshot().status
        fun logText() = session.log.entries().joinToString("\n") { it.message }
        fun finished() = status() == SessionStatus.FINISHED
    }

    @Test
    fun drivesToTheDeliveryAreaParksAndStopsByItself() {
        val w = World()
        assertTrue(w.session.start().ok)
        val finished = w.runUntil(400_000) { w.finished() }
        val log = w.logText()
        assertTrue("did not finish; status=${w.session.currentSnapshot()}; log:\n$log", finished)
        assertEquals(UserState.PARKED, w.session.currentSnapshot().userState(false))
        assertTrue("truck should be parked", w.game.parkedPose)
        assertEquals("rule violations: gear=${w.game.gearChangeWhileRolling} offRoad=${w.game.offRoad} stray=${w.game.strayTaps}", 0, w.game.violations)
        assertEquals(listOf(DrivePhase.DRIVING, DrivePhase.APPROACHING, DrivePhase.PARKING, DrivePhase.PARKED), w.phases.filterNotNull().distinct())
        for (expected in listOf("Delivery area recognised", "Parking area in sight", "Parked")) {
            assertTrue("log should contain '$expected':\n$log", log.contains(expected))
        }
        // Only the gear change is ever tapped: nothing on any delivery / job / payment screen.
        assertTrue(w.input.tapEvents.all { abs(it.second.x - TestProfiles.CONTROLS[Control.GEAR_REVERSE]!!.x) < 0.01f })
        // After the end of the trip nothing drives any more.
        w.runUntil(6000) { false }
        assertTrue("controls still held: ${w.input.holdEvents.last()}", w.input.holdEvents.last().holds.isEmpty())
        assertTrue(w.game.speed < 0.01f)
        assertEquals(0, w.game.tapsAfterDelivery)
        assertTrue(w.session.shouldReleaseCapture())
        println("simulated trip: ${(w.clock.now - 1_000_000L) / 1000} s of game time, ${w.ticks} ticks, " +
            "avg tick ${w.tickNanos / w.ticks / 1000} us (JVM on a desktop CPU; a phone will be several times slower)")
    }

    @Test
    fun theTruckSlowsDownOnceTheDeliveryAreaIsRecognised() {
        val w = World()
        assertTrue(w.session.start().ok)
        assertTrue(w.runUntil(400_000) { w.session.currentSnapshot().phase == DrivePhase.APPROACHING })
        w.runUntil(2500) { false }
        assertTrue("speed ${w.game.speed}", w.game.speed <= 0.45f)
        assertEquals(DrivePhase.APPROACHING, w.session.currentSnapshot().phase)
        assertEquals(UserState.APPROACHING_DELIVERY, w.session.currentSnapshot().userState(false))
    }

    @Test
    fun convergesFromDifferentStartingPositions() {
        for ((zx, ro) in listOf(0.30f to -0.3f, 0.45f to 0.4f, 0.56f to 0.0f, 0.70f to 0.2f)) {
            val w = World(zoneX = zx, routeOffset = ro)
            assertTrue(w.session.start().ok)
            val ok = w.runUntil(400_000) { w.finished() }
            assertTrue("start zone=$zx route=$ro: ${w.session.currentSnapshot()}\n${w.logText()}", ok)
            assertEquals("violations at zone=$zx route=$ro", 0, w.game.violations)
        }
    }

    @Test
    fun withoutAParkingViewTheTruckStopsNearTheDeliveryAreaAndAsksTheUserToPark() {
        val w = World()
        w.game.parkViewAt = null
        w.game.routeEndsAt = 5f
        assertTrue(w.session.start().ok)
        val stopped = w.runUntil(400_000) { w.status() == SessionStatus.NEEDS_ASSIST }
        assertTrue("status=${w.session.currentSnapshot()}\n${w.logText()}", stopped)
        assertEquals(UserState.NEEDS_ASSISTANCE, w.session.currentSnapshot().userState(false))
        assertTrue(w.session.currentSnapshot().lastError!!.contains("road", ignoreCase = true))
        w.runUntil(5000) { false }
        assertTrue("truck should stand still, speed=${w.game.speed}", w.game.speed < 0.02f)
        assertTrue(w.game.driven > w.game.nearAt)
        assertEquals(0, w.game.violations)
        assertTrue(w.input.tapEvents.isEmpty())
    }

    @Test
    fun parkingCanBeSwitchedOffAndThenTheTruckNeverTriesToReverse() {
        val w = World(AutomationSettings(tryParking = false))
        assertTrue(w.session.start().ok)
        val stopped = w.runUntil(400_000) { w.status() == SessionStatus.NEEDS_ASSIST }
        assertTrue("status=${w.session.currentSnapshot()}\n${w.logText()}", stopped)
        assertTrue(w.session.currentSnapshot().lastError!!.contains("park manually", ignoreCase = true))
        assertTrue(w.input.tapEvents.isEmpty())
        assertEquals(Gear.FORWARD, w.game.gear)
    }

    @Test
    fun aPopUpStopsTheTruckAndIsNeverTapped() {
        val w = World()
        w.game.dialogAt = 1.5f
        assertTrue(w.session.start().ok)
        val stopped = w.runUntil(400_000) { w.status() == SessionStatus.NEEDS_ASSIST }
        assertTrue("status=${w.session.currentSnapshot()}\n${w.logText()}", stopped)
        assertTrue(w.session.currentSnapshot().lastError!!.contains("dialog", ignoreCase = true))
        w.runUntil(5000) { false }
        assertTrue(w.game.speed < 0.02f)
        assertTrue(w.input.tapEvents.isEmpty())
    }

    @Test
    fun aShortLossOfTheRouteSlowsTheTruckAndDrivingResumes() {
        val w = World()
        assertTrue(w.session.start().ok)
        assertTrue(w.runUntil(60_000) { w.game.driven > 1f })
        val before = w.game.speed
        w.game.routeHidden = true
        w.runUntil(2000) { false }
        assertTrue("speed should drop while the route is not visible: $before -> ${w.game.speed}", w.game.speed < before)
        assertEquals(SessionStatus.RUNNING, w.status())
        w.game.routeHidden = false
        w.runUntil(3000) { false }
        assertEquals(SessionStatus.RUNNING, w.status())
        assertTrue("speed ${w.game.speed}", w.game.speed > 0.1f)
    }

    @Test
    fun aLongLossOfTheRouteStopsTheTruckAndNeedsAssistance() {
        val w = World()
        assertTrue(w.session.start().ok)
        assertTrue(w.runUntil(60_000) { w.game.driven > 1f })
        w.game.routeHidden = true
        val stopped = w.runUntil(20_000) { w.status() == SessionStatus.NEEDS_ASSIST }
        assertTrue("status=${w.session.currentSnapshot()}\n${w.logText()}", stopped)
        assertTrue(w.session.currentSnapshot().lastError!!.contains("road", ignoreCase = true))
        w.runUntil(4000) { false }
        assertTrue("speed ${w.game.speed}", w.game.speed < 0.02f)
    }

    @Test
    fun steeringAndTapsStayWithinSafeRates() {
        val w = World()
        assertTrue(w.session.start().ok)
        w.runUntil(400_000) { w.finished() }

        // Steering never moves faster than the mapper's rate limit (3.5 per second, plus a little slack).
        val centre = TestProfiles.CONTROLS[Control.STEER_CENTER]!!.x
        var prev: SimInput.HoldEvent? = null
        var worst = 0f
        for (e in w.input.holdEvents) {
            val s = e.holds[Control.STEER_CENTER]?.let { pt -> (pt.x - centre) / 0.12f }
            val p = prev?.holds?.get(Control.STEER_CENTER)?.let { pt -> (pt.x - centre) / 0.12f }
            if (s != null && p != null) {
                val dt = ((e.at - prev!!.at) / 1000f).coerceIn(0.02f, 0.5f)
                worst = maxOf(worst, abs(s - p) / dt)
            }
            prev = e
        }
        assertTrue("worst steering rate $worst /s", worst <= 3.6f)

        val gaps = w.input.tapEvents.zipWithNext { a, b -> b.first - a.first }
        assertTrue("taps ${w.input.tapEvents.size}, min gap ${gaps.minOrNull()}", gaps.all { it >= SessionManager.MIN_TAP_INTERVAL_MS })
        // Throttle and brake are never held together.
        assertTrue(w.input.holdEvents.none { it.holds.containsKey(Control.ACCELERATOR) && it.holds.containsKey(Control.BRAKE) })
    }

    @Test
    fun emergencyStopMidDriveHaltsTheTruckAndNeverAcceleratesAgain() {
        val w = World()
        assertTrue(w.session.start().ok)
        val driving = w.runUntil(400_000) { w.game.speed > 0.2f }
        assertTrue("never reached driving: ${w.logText()}", driving)
        w.game.emergencyAt = w.clock.now
        w.session.emergencyStop("test")
        assertEquals(SessionStatus.EMERGENCY_STOPPED, w.status())
        w.runUntil(6000) { false }
        assertEquals("accelerator pressed after emergency stop", 0L, w.game.accelerationAfter)
        assertTrue("truck should have stopped, speed=${w.game.speed}", w.game.speed < 0.01f)
        assertTrue(w.input.holdEvents.last().holds.isEmpty())
        assertTrue(w.session.shouldReleaseCapture())
        assertEquals(SessionStatus.EMERGENCY_STOPPED, w.status())
        assertEquals(UserState.EMERGENCY_STOP, w.session.currentSnapshot().userState(false))
    }

    @Test
    fun gameLeavingTheForegroundMidDriveBrakesAndPauses() {
        val w = World()
        assertTrue(w.session.start().ok)
        assertTrue(w.runUntil(400_000) { w.game.speed > 0.2f })
        w.monitor.foreground = false
        val paused = w.runUntil(10_000) { w.status() == SessionStatus.PAUSED }
        assertTrue(paused)
        w.runUntil(4000) { false }
        assertTrue("speed ${w.game.speed}", w.game.speed < 0.05f)
    }

    @Test
    fun pausingWhileApproachingKeepsThePhaseAndTheTripStillFinishes() {
        val w = World()
        assertTrue(w.session.start().ok)
        assertTrue(w.runUntil(400_000) { w.session.currentSnapshot().phase == DrivePhase.APPROACHING })
        w.session.pause()
        assertEquals(SessionStatus.PAUSED, w.status())
        w.runUntil(6000) { false }
        assertTrue("speed ${w.game.speed}", w.game.speed < 0.02f)
        assertTrue(w.session.resume().ok)
        assertTrue(w.runUntil(400_000) { w.finished() })
        assertEquals(0, w.game.violations)
        assertFalse(w.phases.indexOf(DrivePhase.PARKING) < w.phases.indexOf(DrivePhase.APPROACHING))
    }

    @Test
    fun theSessionNeverActsOnAGameItCannotRecogniseEvenWhenTheScreenChangesConstantly() {
        val w = World()
        w.frames.frame = dev.toe3autopilot.core.vision.Frame.solid(TestProfiles.FW, TestProfiles.FH, 0x202020, w.clock.now)
        assertTrue(w.session.start().ok)
        repeat(100) {
            w.clock.advance(200)
            w.frames.frame = dev.toe3autopilot.core.vision.Frame.solid(TestProfiles.FW, TestProfiles.FH, 0x202020 + (it % 7), w.clock.now)
            w.session.tick()
        }
        assertEquals(SessionStatus.NEEDS_ASSIST, w.status())
        assertTrue(w.input.tapEvents.isEmpty())
        assertFalse(w.input.holdEvents.any { it.holds.isNotEmpty() })
        assertEquals(GameState.UNKNOWN, w.session.currentSnapshot().gameState)
    }
}
