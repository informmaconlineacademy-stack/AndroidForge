package dev.toe3autopilot.core

import dev.toe3autopilot.core.calibration.CalibRole
import dev.toe3autopilot.core.calibration.CalibrationState
import dev.toe3autopilot.core.calibration.ControlDetection
import dev.toe3autopilot.core.calibration.DetectionSource
import dev.toe3autopilot.core.calibration.DetectionStatus
import dev.toe3autopilot.core.calibration.GuidedSetup
import dev.toe3autopilot.core.calibration.HudAnalysis
import dev.toe3autopilot.core.calibration.HudElement
import dev.toe3autopilot.core.calibration.MinimapSuggestion
import dev.toe3autopilot.core.profile.GameProfile
import dev.toe3autopilot.core.profile.ProfileReadiness
import dev.toe3autopilot.core.state.GameState
import dev.toe3autopilot.core.vision.Frame
import dev.toe3autopilot.core.vision.Roi
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Smart Setup's tap-based navigation steps: no template names, no rules typed by the person. Synthetic pictures. */
class GuidedSetupTest {
    private val w = 320
    private val h = 180
    private val empty = GameProfile.EMPTY.copy(name = "t", gamePackage = "g")

    private fun el(l: Float, t: Float, r: Float, b: Float, persistence: Float) =
        HudElement(Roi(l, t, r, b), (l + r) / 2, (t + b) / 2, persistence, (r - l) / (b - t), (r - l) * (b - t), persistence)

    private fun hud(vararg e: HudElement) = HudAnalysis(w, h, 12, 0.3f, e.toList(), ok = true, problem = null)

    /** Grey scene, a blue minimap with a magenta route line and a red destination dot. */
    private fun frame(): Frame {
        val px = IntArray(w * h) { (0xFF shl 24) or 0x404040 }
        fun fill(x0: Int, y0: Int, x1: Int, y1: Int, rgb: Int) {
            for (y in y0 until y1) for (x in x0 until x1) px[y * w + x] = (0xFF shl 24) or rgb
        }
        fill(240, 10, 310, 80, 0x1E2A44) // minimap background
        fill(272, 20, 278, 70, 0xE040FB) // route line
        fill(290, 25, 296, 31, 0xFF2020) // destination marker
        fill(20, 10, 60, 24, 0xDDDDDD)   // a steady dashboard badge
        return Frame(w, h, px, 0)
    }

    private fun det(role: CalibRole, box: Roi) =
        ControlDetection(role, (box.left + box.right) / 2, (box.top + box.bottom) / 2, box, 1f, DetectionStatus.CONFIRMED, DetectionSource.USER, emptyList())

    @Test
    fun theDrivingMarkerIsASteadyElementThatIsNotAControl() {
        val pedal = Roi(0.80f, 0.70f, 0.95f, 0.95f)
        val h = hud(
            el(0.80f, 0.70f, 0.95f, 0.95f, 0.99f), // the accelerator: changes when pressed, must be avoided
            el(0.06f, 0.05f, 0.19f, 0.13f, 0.95f), // dashboard badge
            el(0.40f, 0.40f, 0.42f, 0.41f, 0.99f), // too tiny
            el(0.10f, 0.30f, 0.90f, 0.95f, 0.99f), // huge: would include scenery
            el(0.50f, 0.05f, 0.60f, 0.12f, 0.50f), // flickers
        )
        val pick = GuidedSetup.pickDrivingMarker(h, listOf(pedal))
        assertNotNull(pick)
        assertEquals(0.06f, pick!!.box.left, 1e-4f)
    }

    @Test
    fun drivingScreenStepSavesAMarkerRuleAndItsPicture() {
        val st = CalibrationState(
            hud = hud(el(0.06f, 0.05f, 0.19f, 0.13f, 0.95f)),
            detections = mapOf(CalibRole.ACCELERATOR to det(CalibRole.ACCELERATOR, Roi(0.80f, 0.70f, 0.95f, 0.95f))),
        )
        val out = GuidedSetup.drivingScreen(empty, frame(), st)
        assertTrue(out.toString(), out is GuidedSetup.Outcome.Ok)
        val ok = out as GuidedSetup.Outcome.Ok
        assertEquals(ProfileReadiness.HUD_MARKER, ok.patchName)
        assertNotNull(ok.patch)
        assertEquals(listOf(ProfileReadiness.HUD_MARKER), ok.profile.stateRules[GameState.DRIVING])
        assertTrue(ok.profile.templates.containsKey(ProfileReadiness.HUD_MARKER))
    }

    @Test
    fun drivingScreenStepRefusesWithoutAnAnalysisOrOnASizeChange() {
        assertTrue(GuidedSetup.drivingScreen(empty, frame(), CalibrationState()) is GuidedSetup.Outcome.Refused)
        val other = Frame(180, 320, IntArray(180 * 320), 0)
        val st = CalibrationState(hud = hud(el(0.06f, 0.05f, 0.19f, 0.13f, 0.95f)))
        assertTrue(GuidedSetup.drivingScreen(empty, other, st) is GuidedSetup.Outcome.Refused)
        val nothingSteady = CalibrationState(hud = hud(el(0.06f, 0.05f, 0.19f, 0.13f, 0.4f)))
        assertTrue(GuidedSetup.drivingScreen(empty, frame(), nothingSteady) is GuidedSetup.Outcome.Refused)
    }

    @Test
    fun navigationByTappingTheMap() {
        val f = frame()
        var p = (GuidedSetup.minimapFromSuggestion(empty, MinimapSuggestion(Roi(0.75f, 0.05f, 0.97f, 0.45f), null, "")) as GuidedSetup.Outcome.Ok).profile
        assertNotNull(p.nav)
        // A tap on the grey background is refused; a tap on the magenta line is accepted.
        assertTrue(GuidedSetup.routeColor(p, f, 0.80f, 0.40f) is GuidedSetup.Outcome.Refused)
        assertTrue("outside the minimap", GuidedSetup.routeColor(p, f, 0.10f, 0.50f) is GuidedSetup.Outcome.Refused)
        p = (GuidedSetup.routeColor(p, f, 275f / w, 45f / h) as GuidedSetup.Outcome.Ok).profile
        val c = p.nav!!.routeColor
        assertTrue(c.r > 200 && c.b > 200 && c.g < 100)
        p = (GuidedSetup.truckMarker(p, 275f / w, 72f / h) as GuidedSetup.Outcome.Ok).profile
        // The destination may not use the route colour, but the red dot is accepted.
        assertTrue(GuidedSetup.destination(p, f, 275f / w, 45f / h) is GuidedSetup.Outcome.Refused)
        p = (GuidedSetup.destination(p, f, 293f / w, 28f / h) as GuidedSetup.Outcome.Ok).profile
        val done = GuidedSetup.status(p, MapTemplateStore()).associate { it.step to it.done }
        assertTrue(done[GuidedSetup.Step.MINIMAP]!!)
        assertTrue(done[GuidedSetup.Step.ROUTE_COLOR]!!)
        assertTrue(done[GuidedSetup.Step.TRUCK_MARKER]!!)
        assertTrue(done[GuidedSetup.Step.DESTINATION]!!)
        assertFalse("no driving marker picture stored", done[GuidedSetup.Step.DRIVING_SCREEN]!!)
        assertEquals(GuidedSetup.Step.DRIVING_SCREEN, GuidedSetup.nextRequired(p, MapTemplateStore()))
    }

    @Test
    fun aTappedMinimapStaysInsideThePictureAndCanBeResized() {
        val p = (GuidedSetup.minimapAt(empty, frame(), 0.98f, 0.02f) as GuidedSetup.Outcome.Ok).profile
        val r = p.nav!!.minimapRoi
        assertTrue(r.right <= 1f && r.top >= 0f)
        val bigger = (GuidedSetup.resizeMinimap(p, 1.3f) as GuidedSetup.Outcome.Ok).profile.nav!!.minimapRoi
        assertTrue(bigger.bottom - bigger.top > r.bottom - r.top)
        assertTrue(GuidedSetup.resizeMinimap(empty, 1.2f) is GuidedSetup.Outcome.Refused)
    }

    @Test
    fun stepsNeedTheMinimapFirst() {
        assertTrue(GuidedSetup.routeColor(empty, frame(), 0.5f, 0.5f) is GuidedSetup.Outcome.Refused)
        assertTrue(GuidedSetup.truckMarker(empty, 0.5f, 0.5f) is GuidedSetup.Outcome.Refused)
        assertNull(GuidedSetup.status(null, MapTemplateStore()).firstOrNull { it.done })
    }
}
