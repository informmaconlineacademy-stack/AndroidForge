package dev.toe3autopilot.app.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import dev.toe3autopilot.core.AutomationSettings
import dev.toe3autopilot.core.profile.GameProfile
import dev.toe3autopilot.core.profile.ProfileCodec
import dev.toe3autopilot.core.profile.TemplateStore
import dev.toe3autopilot.core.session.LogEntry
import dev.toe3autopilot.core.vision.GrayImage
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Default game package; the user can change or auto-detect it on the Setup screen (this id is NOT verified). */
const val DEFAULT_GAME_PACKAGE = "com.wandasoftware.truckersofeurope3"

/** Options of the background-operation and recording features (kept apart from the automation settings). */
data class AppOptions(
    /** Show the floating Start/Pause/Resume/Stop panel (needs the accessibility service) while capture is connected. */
    val showPanel: Boolean = true,
    /** Seconds between saved sample snapshots while recording. */
    val recordIntervalSec: Int = 5,
    /** Oldest snapshots are deleted beyond this count. */
    val recordMaxFrames: Int = 150,
    /** Vibrate at the start/end of a calibration demonstration (useful when the app is not on screen). */
    val vibrateCues: Boolean = true,
    /** The person accepted the in-app disclosure about the accessibility service (required before it is switched on). */
    val accessibilityDisclosureAccepted: Boolean = false,
    /** Shows the expert editors (template editor, profile text) in Calibration Profiles. Off by default. */
    val advancedTools: Boolean = false,
    /** The first-run welcome card on the Dashboard was dismissed. */
    val welcomeDismissed: Boolean = false,
) {
    fun sanitized() = copy(
        recordIntervalSec = recordIntervalSec.coerceIn(1, 60),
        recordMaxFrames = recordMaxFrames.coerceIn(10, 400),
    )
}

class OptionsStore(context: Context) {
    private val prefs = context.getSharedPreferences("options", Context.MODE_PRIVATE)

    fun load(): AppOptions = AppOptions(
        showPanel = prefs.getBoolean("showPanel", true),
        recordIntervalSec = prefs.getInt("recordIntervalSec", 5),
        recordMaxFrames = prefs.getInt("recordMaxFrames", 150),
        vibrateCues = prefs.getBoolean("vibrateCues", true),
        accessibilityDisclosureAccepted = prefs.getBoolean("a11yDisclosure", false),
        advancedTools = prefs.getBoolean("advancedTools", false),
        welcomeDismissed = prefs.getBoolean("welcomeDismissed", false),
    ).sanitized()

    fun save(o: AppOptions) {
        prefs.edit().putBoolean("showPanel", o.showPanel).putInt("recordIntervalSec", o.recordIntervalSec)
            .putInt("recordMaxFrames", o.recordMaxFrames).putBoolean("vibrateCues", o.vibrateCues)
            .putBoolean("a11yDisclosure", o.accessibilityDisclosureAccepted)
            .putBoolean("advancedTools", o.advancedTools).putBoolean("welcomeDismissed", o.welcomeDismissed).apply()
    }
}

class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)

    fun load(): AutomationSettings = AutomationSettings(
        speedLevel = prefs.getFloat("speedLevel", 0.5f),
        approachSpeed = prefs.getFloat("approachSpeed", 0.25f),
        sensitivity = prefs.getFloat("sensitivity", 1.0f),
        tryParking = prefs.getBoolean("tryParking", true),
        assistedMode = prefs.getBoolean("assistedMode", false),
    ).sanitized()

    fun save(s: AutomationSettings) {
        prefs.edit()
            .putFloat("speedLevel", s.speedLevel).putFloat("approachSpeed", s.approachSpeed)
            .putFloat("sensitivity", s.sensitivity).putBoolean("tryParking", s.tryParking)
            .putBoolean("assistedMode", s.assistedMode)
            .apply()
    }

    fun gamePackage(): String = prefs.getString("gamePackage", DEFAULT_GAME_PACKAGE) ?: DEFAULT_GAME_PACKAGE

    fun saveGamePackage(pkg: String) {
        prefs.edit().putString("gamePackage", pkg.trim()).apply()
    }
}

/**
 * Stores the calibration profile (text) and its template images (PNG) in the app's private files directory.
 * Nothing leaves the device.
 */
class ProfileStore(context: Context) : TemplateStore {
    private val dir = File(context.filesDir, "profile").also { it.mkdirs() }
    private val templatesDir = File(dir, "templates").also { it.mkdirs() }
    private val profileFile = File(dir, "profile.properties")
    private val cache = HashMap<String, Pair<Long, GrayImage?>>()

    /** Last problem found while loading the profile, for the UI. */
    @Volatile
    var loadError: String? = null
        private set

    fun load(): GameProfile? {
        loadError = null
        if (!profileFile.exists()) return null
        return try {
            ProfileCodec.parse(profileFile.readText())
        } catch (e: IllegalArgumentException) {
            loadError = e.message
            null
        }
    }

    fun readText(): String = if (profileFile.exists()) profileFile.readText() else ""

    /** Validates by parsing, then writes. Throws IllegalArgumentException for an invalid profile. */
    fun saveText(text: String): GameProfile {
        val p = ProfileCodec.parse(text)
        profileFile.writeText(ProfileCodec.format(p))
        return p
    }

    fun save(p: GameProfile) {
        profileFile.writeText(ProfileCodec.format(p))
    }

    private val backupFile = File(dir, "profile.previous.properties")
    private val calibrationFile = File(dir, "calibration.properties")

    fun readCalibrationText(): String? = if (calibrationFile.exists()) calibrationFile.readText() else null

    fun writeCalibrationText(text: String) {
        calibrationFile.writeText(text)
    }

    fun deleteCalibrationText() {
        calibrationFile.delete()
    }

    /** Keeps a copy of the current profile text so the last change can be undone. */
    fun backupProfile() {
        if (profileFile.exists()) profileFile.copyTo(backupFile, overwrite = true)
    }

    fun hasBackup(): Boolean = backupFile.exists()

    /** Puts the backed-up profile text back. Returns false if there is none or it no longer parses. */
    fun restoreBackup(): Boolean {
        if (!backupFile.exists()) return false
        return try {
            ProfileCodec.parse(backupFile.readText())
            backupFile.copyTo(profileFile, overwrite = true)
            true
        } catch (e: IllegalArgumentException) {
            false
        }
    }

    /** Stores a grayscale patch (used by the layout check) as a PNG. */
    fun saveGray(name: String, img: GrayImage) {
        val px = IntArray(img.px.size) { i ->
            val v = img.px[i].coerceIn(0, 255)
            (0xFF shl 24) or (v shl 16) or (v shl 8) or v
        }
        val bmp = Bitmap.createBitmap(px, img.width, img.height, Bitmap.Config.ARGB_8888)
        saveTemplate(name, bmp)
        bmp.recycle()
    }

    fun templateBytes(name: String): ByteArray? {
        val f = File(templatesDir, "$name.png")
        return if (f.exists()) f.readBytes() else null
    }

    fun writeTemplateBytes(name: String, bytes: ByteArray) {
        File(templatesDir, "$name.png").writeBytes(bytes)
        synchronized(cache) { cache.remove(name) }
    }

    fun templateNames(): List<String> =
        templatesDir.listFiles { f -> f.name.endsWith(".png") }?.map { it.name.removeSuffix(".png") }.orEmpty().sorted()

    fun saveTemplate(name: String, bitmap: Bitmap) {
        File(templatesDir, "$name.png").outputStream().use { bitmap.compress(Bitmap.CompressFormat.PNG, 100, it) }
        synchronized(cache) { cache.remove(name) }
    }

    fun deleteTemplate(name: String) {
        File(templatesDir, "$name.png").delete()
        synchronized(cache) { cache.remove(name) }
    }

    fun hasTemplate(name: String): Boolean = File(templatesDir, "$name.png").exists()

    override fun gray(name: String): GrayImage? {
        val f = File(templatesDir, "$name.png")
        if (!f.exists()) return null
        synchronized(cache) {
            val hit = cache[name]
            if (hit != null && hit.first == f.lastModified()) return hit.second
            val bmp = BitmapFactory.decodeFile(f.absolutePath)
            val img = bmp?.let { b ->
                val w = b.width
                val h = b.height
                val px = IntArray(w * h)
                b.getPixels(px, 0, w, 0, 0, w, h)
                b.recycle()
                dev.toe3autopilot.core.vision.Frame(w, h, px).toGray()
            }
            cache[name] = f.lastModified() to img
            return img
        }
    }
}

/** Bounded on-disk copy of the session log for troubleshooting. Contains states and actions only. */
class LogFile(context: Context, private val maxBytes: Long = 200_000) {
    private val file = File(context.filesDir, "session.log")
    private val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)

    @Synchronized
    fun append(e: LogEntry) {
        if (file.exists() && file.length() > maxBytes) {
            // Keep the newest half.
            val text = file.readText()
            file.writeText(text.substring(text.length / 2).substringAfter('\n', ""))
        }
        file.appendText("${fmt.format(Date(e.timeMs))} ${e.level} ${e.message}\n")
    }

    @Synchronized
    fun clear() {
        file.delete()
    }

    @Synchronized
    fun readTail(maxChars: Int = 20_000): String =
        if (file.exists()) file.readText().takeLast(maxChars) else ""
}
