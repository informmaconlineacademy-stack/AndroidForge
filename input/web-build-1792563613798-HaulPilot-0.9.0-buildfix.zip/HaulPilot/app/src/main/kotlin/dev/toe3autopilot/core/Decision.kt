package dev.toe3autopilot.core

/** Continuous driving demand. All values are normalised: steer -1 (left) .. +1 (right), throttle/brake 0..1. */
data class DriveCommand(
    val steer: Float = 0f,
    val throttle: Float = 0f,
    val brake: Float = 0f,
    val gear: Gear = Gear.FORWARD,
) {
    companion object {
        val STOP = DriveCommand(brake = 1f)
    }
}

/** What an agent wants to happen this tick. Agents never touch Android; the session turns decisions into input. */
sealed class Decision {
    abstract val note: String

    /** Apply a continuous driving command (held controls). */
    data class Drive(val command: DriveCommand, override val note: String) : Decision()

    /** Tap a calibrated control. */
    data class Tap(val control: Control, override val note: String) : Decision()

    /** Tap a point found by vision (for example a job card). */
    data class TapAt(val point: Point, override val note: String) : Decision()

    /** Release all controls and wait. */
    data class Wait(override val note: String) : Decision()

    /** Stop safely and ask the user to take over. [kind] lets the UI explain and suggest the right next step. */
    data class NeedHelp(override val note: String, val kind: HelpKind = HelpKind.OTHER) : Decision()
}

/** Why the automation stopped and asked for the person. */
enum class HelpKind {
    /** The route line / road could not be seen for too long. */
    ROAD_LOST,
    /** The parking area was lost or parking needed too many corrections. */
    PARKING_FAILED,
    /** Throttle was applied but the truck did not move. */
    NOT_MOVING,
    /** The game screen was not recognised (unknown screen, dialog, crash/penalty, loading). */
    SCREEN_UNKNOWN,
    /** Screen size or the calibrated controls changed: recalibration is needed. */
    LAYOUT_CHANGED,
    /** Screen capture stopped, no frames, or the picture froze. */
    CAPTURE,
    /** Touches could not be sent (accessibility service off or failing). */
    INPUT,
    OTHER,
}

/** User-facing driving options. */
data class AutomationSettings(
    /** Cruise throttle ceiling, 0.1..1.0. */
    val speedLevel: Float = 0.5f,
    /** Throttle ceiling once the delivery area has been recognised, 0.1..0.5. */
    val approachSpeed: Float = 0.25f,
    /** Steering gain multiplier, 0.5..2.0. */
    val sensitivity: Float = 1.0f,
    /** Try the final parking manoeuvre. When off (or when the parking area is not calibrated) the truck stops near the delivery area and asks the user. */
    val tryParking: Boolean = true,
    /** Do not inject any input; only show what the user should do. */
    val assistedMode: Boolean = false,
) {
    fun sanitized(): AutomationSettings = copy(
        speedLevel = clampF(speedLevel, 0.1f, 1.0f),
        approachSpeed = clampF(approachSpeed, 0.1f, 0.5f),
        sensitivity = clampF(sensitivity, 0.5f, 2.0f),
    )
}
