package dev.toe3autopilot.core.profile

import dev.toe3autopilot.core.AutomationSettings
import dev.toe3autopilot.core.Control
import dev.toe3autopilot.core.Point
import dev.toe3autopilot.core.state.GameState
import dev.toe3autopilot.core.vision.ColorTarget
import dev.toe3autopilot.core.vision.GrayImage
import dev.toe3autopilot.core.vision.Roi

/** Where to look for a named template and how strict to be. Template pixels live in a [TemplateStore]. */
data class TemplateSpec(val name: String, val roi: Roi, val minScore: Float = 0.80f)

/** A named colour region (for example the parking-zone highlight). */
data class ColorSpec(val name: String, val roi: Roi, val target: ColorTarget)

enum class SteeringMode {
    /** Press the wheel/steering area and drag horizontally: steer = offset from [GameProfile.controls]'s STEER_CENTER. */
    SLIDER,

    /** Hold a left or right button. */
    BUTTONS,
}

/**
 * Navigation minimap description. Assumes a heading-up minimap (the truck always points up the screen),
 * which is what the route estimator relies on.
 */
data class NavProfile(
    val minimapRoi: Roi,
    val routeColor: ColorTarget,
    /** Normalised frame position of the truck marker on the minimap. */
    val truckX: Float,
    val truckY: Float,
    /** How far ahead of the truck marker to look, as a fraction of the minimap height. */
    val lookahead: Float = 0.6f,
)

/**
 * Everything that is specific to one game build / device layout. It is produced by the in-app
 * calibration screen and stored as a text file; nothing about the game is hard-coded in the app.
 */
data class GameProfile(
    val name: String,
    val gamePackage: String,
    /** Frame width at which templates were captured; templates are rescaled if the live frame width differs. 0 = no scaling. */
    val referenceWidth: Int,
    val templates: Map<String, TemplateSpec>,
    val colors: Map<String, ColorSpec>,
    /** State -> template names; a leading '!' means the template must be ABSENT. */
    val stateRules: Map<GameState, List<String>>,
    val controls: Map<Control, Point>,
    val steeringMode: SteeringMode,
    /** Horizontal steering travel in SLIDER mode, as a fraction of screen width. */
    val steerRadius: Float,
    val nav: NavProfile?,
    val extras: Map<String, String>,
) {
    fun control(c: Control): Point? = controls[c]

    fun extraFloat(key: String, default: Float): Float = extras[key]?.toFloatOrNull() ?: default

    fun extra(key: String, default: String): String = extras[key] ?: default

    fun positiveTemplates(): Set<String> =
        stateRules.values.flatten().filter { !it.startsWith("!") }.toSet()

    companion object {
        val EMPTY = GameProfile(
            name = "empty", gamePackage = "", referenceWidth = 0, templates = emptyMap(), colors = emptyMap(),
            stateRules = emptyMap(), controls = emptyMap(), steeringMode = SteeringMode.SLIDER, steerRadius = 0.12f,
            nav = null, extras = emptyMap(),
        )
    }
}

/** Supplies template pixels (at the reference resolution) by name. */
interface TemplateStore {
    fun gray(name: String): GrayImage?
}

/** Decides whether a profile has enough calibration to drive, and lists what is missing for the optional parts. */
object ProfileReadiness {
    /** Template that, together with a state rule, tells the app that the normal driving view is on screen. */
    const val HUD_MARKER = "hud_marker"

    /** Things that make driving unsafe or impossible. Start is refused while this list is not empty. */
    fun problems(profile: GameProfile, settings: AutomationSettings, store: TemplateStore): List<String> {
        val p = ArrayList<String>()

        fun needControl(c: Control) {
            if (profile.control(c) == null && profile.templates[c.buttonTemplate] == null) {
                p += "Control ${c.name} is not calibrated"
            }
        }

        val rule = profile.stateRules[GameState.DRIVING]
        if (rule.isNullOrEmpty()) {
            p += "The driving screen is not set up (Smart Setup → Navigation and screen → Driving screen)"
        } else {
            for (item in rule) {
                val n = item.removePrefix("!")
                if (!profile.templates.containsKey(n)) p += "Template '$n' (used by 'Driving') has no region"
                else if (store.gray(n) == null) p += "Template image '$n' (used by 'Driving') is missing"
            }
        }
        if (profile.nav == null) p += "The minimap is not set up (Smart Setup → Navigation and screen: minimap, route line and your truck)"
        needControl(Control.ACCELERATOR)
        needControl(Control.BRAKE)
        when (profile.steeringMode) {
            SteeringMode.SLIDER -> needControl(Control.STEER_CENTER)
            SteeringMode.BUTTONS -> {
                needControl(Control.STEER_LEFT)
                needControl(Control.STEER_RIGHT)
            }
        }
        // Every state rule that IS defined must be usable, otherwise the detector would silently never match it.
        for ((s, r) in profile.stateRules) {
            if (s == GameState.DRIVING) continue
            for (item in r) {
                val n = item.removePrefix("!")
                if (!profile.templates.containsKey(n)) p += "Template '$n' (used by '${s.label}') has no region"
                else if (store.gray(n) == null) p += "Template image '$n' (used by '${s.label}') is missing"
            }
        }
        return p.distinct()
    }

    /**
     * Things that are NOT required to start but limit what the app can do. Shown to the user so nothing is a surprise.
     * The wording states the consequence, e.g. "cannot know when it has arrived".
     */
    fun advice(profile: GameProfile, settings: AutomationSettings): List<String> {
        val a = ArrayList<String>()
        val hasZone = profile.templates.containsKey("parking_zone") || profile.colors.containsKey("parking_zone")
        val hasArrivalCue = profile.templates.containsKey("destination_near") || profile.colors.containsKey("destination_marker") || hasZone
        if (!hasArrivalCue) {
            a += "No destination cue is set up: the truck cannot tell when it has arrived. It will follow the route and stop only " +
                "when the route is lost. (Smart Setup → Navigation and screen → Destination marker.)"
        }
        if (settings.tryParking) {
            if (!hasZone) a += "No parking area is set up: the truck will stop near the delivery area and ask you to park."
            if (profile.control(Control.GEAR_REVERSE) == null && profile.extra("parking.direction", "REVERSE").uppercase() != "FORWARD") {
                a += "Reverse gear is not calibrated: parking by reversing is not possible, so the truck will stop and ask you to park."
            }
            if (!profile.templates.containsKey("parked_ok") && profile.stateRules[GameState.DELIVERY_COMPLETE].isNullOrEmpty()) {
                a += "No 'parked' cue is calibrated ('parked_ok' or the delivery screen): the app cannot tell that parking succeeded. It will stop after its correction limit and ask you."
            }
        }
        if (!profile.templates.containsKey("obstacle_ahead")) a += "No obstacle cue is set up: the app cannot see vehicles or obstacles ahead (expert option in Settings → Advanced tools)."
        if (profile.stateRules[GameState.UNEXPECTED_DIALOG].isNullOrEmpty()) a += "No pop-up cue is set up: pop-ups are only noticed because the driving screen disappears (expert option)."
        return a
    }
}
