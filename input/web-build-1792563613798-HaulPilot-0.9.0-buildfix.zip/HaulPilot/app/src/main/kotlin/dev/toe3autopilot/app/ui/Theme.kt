package dev.toe3autopilot.app.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.toe3autopilot.app.Brand

/**
 * Design tokens. One dark "instrument cluster" look: midnight-navy and graphite surfaces, white text, electric orange for the
 * primary action, cyan for secondary actions and indicators, and status colours used only to carry meaning (green = good,
 * amber = attention, red = stop/problem, blue = information). Values come from [Brand] so the floating controls match.
 */
object Tokens {
    val Bg = Color(Brand.BG)
    val Surface = Color(Brand.SURFACE)
    val Raised = Color(Brand.RAISED)
    val Border = Color(Brand.BORDER)

    val TextPrimary = Color(Brand.TEXT_PRIMARY)
    val TextSecondary = Color(Brand.TEXT_SECONDARY)
    val TextMuted = Color(Brand.TEXT_MUTED)

    val Primary = Color(Brand.PRIMARY)
    val OnPrimary = Color(Brand.ON_PRIMARY)

    /** Cyan secondary accent. */
    val Accent = Color(Brand.ACCENT)
    val OnAccent = Color(Brand.ON_ACCENT)

    val Success = Color(Brand.SUCCESS)
    val Warning = Color(Brand.WARNING)
    val Danger = Color(Brand.DANGER)
    val DangerFill = Color(Brand.DANGER_FILL)
    val Info = Color(Brand.INFO)
}

/** Spacing and sizes. Touch targets are at least 48 dp. */
object Dim {
    val xs = 4.dp
    val s = 8.dp
    val m = 12.dp
    val l = 16.dp
    val xl = 24.dp
    val radiusCard = 16.dp
    val radiusControl = 12.dp
    val minTouch = 48.dp
}

private val AppTypography = Typography(
    headlineMedium = TextStyle(fontSize = 28.sp, lineHeight = 34.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.4.sp),
    headlineSmall = TextStyle(fontSize = 22.sp, lineHeight = 28.sp, fontWeight = FontWeight.Bold),
    titleLarge = TextStyle(fontSize = 20.sp, lineHeight = 26.sp, fontWeight = FontWeight.SemiBold),
    titleMedium = TextStyle(fontSize = 16.sp, lineHeight = 22.sp, fontWeight = FontWeight.SemiBold),
    titleSmall = TextStyle(fontSize = 14.sp, lineHeight = 20.sp, fontWeight = FontWeight.SemiBold),
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 23.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontSize = 12.sp, lineHeight = 17.sp),
    labelLarge = TextStyle(fontSize = 14.sp, lineHeight = 18.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.2.sp),
    labelMedium = TextStyle(fontSize = 12.sp, lineHeight = 16.sp, fontWeight = FontWeight.Medium, letterSpacing = 0.4.sp),
    labelSmall = TextStyle(fontSize = 12.sp, lineHeight = 16.sp, fontWeight = FontWeight.Medium, letterSpacing = 0.4.sp),
)

/** Always dark: the app is used next to a game, and one carefully tuned theme reads better than two. */
@Composable
fun HaulPilotTheme(content: @Composable () -> Unit) {
    // isSystemInDarkTheme() is intentionally not used to switch themes; it is read so the status-bar icons follow the system.
    @Suppress("UNUSED_VARIABLE") val systemDark = isSystemInDarkTheme()
    val scheme = darkColorScheme(
        primary = Tokens.Primary,
        onPrimary = Tokens.OnPrimary,
        primaryContainer = Tokens.Raised,
        onPrimaryContainer = Tokens.TextPrimary,
        secondary = Tokens.Accent,
        onSecondary = Tokens.OnAccent,
        secondaryContainer = Tokens.Raised,
        onSecondaryContainer = Tokens.TextPrimary,
        tertiary = Tokens.Info,
        background = Tokens.Bg,
        onBackground = Tokens.TextPrimary,
        surface = Tokens.Surface,
        onSurface = Tokens.TextPrimary,
        surfaceVariant = Tokens.Raised,
        onSurfaceVariant = Tokens.TextSecondary,
        error = Tokens.Danger,
        onError = Tokens.TextPrimary,
        outline = Tokens.Border,
        outlineVariant = Tokens.Border,
    )
    MaterialTheme(colorScheme = scheme, typography = AppTypography, content = content)
}
