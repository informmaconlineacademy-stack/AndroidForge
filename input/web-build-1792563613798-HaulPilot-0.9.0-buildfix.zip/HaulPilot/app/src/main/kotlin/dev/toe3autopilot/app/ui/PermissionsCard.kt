package dev.toe3autopilot.app.ui

import android.app.NotificationManager
import android.os.Build
import android.os.PowerManager
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import dev.toe3autopilot.app.AutopilotRuntime
import kotlinx.coroutines.delay

@Composable
private fun StateLine(label: String, ok: Boolean, detail: String) {
    Row(verticalAlignment = Alignment.Top) {
        Text(if (ok) "✔ " else "✘ ", color = if (ok) Tokens.Success else Tokens.Danger, fontWeight = FontWeight.Bold)
        Text("$label: $detail")
    }
}

/** Live state of every permission or system setting that background operation depends on, with a shortcut to fix each. */
@Composable
fun PermissionsCard(actions: Actions) {
    val ctx = LocalContext.current
    val capture by AutopilotRuntime.captureActive.collectAsState()
    val access by AutopilotRuntime.accessibilityConnected.collectAsState()
    val endReason by AutopilotRuntime.captureEndReason.collectAsState()
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(1500)
            tick++
        }
    }
    val notificationsOn = remember(tick) {
        try {
            ctx.getSystemService(NotificationManager::class.java).areNotificationsEnabled()
        } catch (e: Exception) {
            true
        }
    }
    val batteryExempt = remember(tick) {
        try {
            ctx.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(ctx.packageName)
        } catch (e: Exception) {
            false
        }
    }

    SectionCard("Permissions and background operation") {
        StateLine("Screen capture", capture, if (capture) "connected" else "not connected (START AUTO DRIVE or Calibrate → Turn on; Android asks every time)")
        if (!capture) endReason?.let { Text("Last ended: $it", style = MaterialTheme.typography.bodySmall) }
        StateLine("Accessibility service", access, if (access) "enabled" else "not enabled (needed for touches, the floating button and the foreground check)")
        StateLine(
            "Notifications", notificationsOn,
            if (notificationsOn) "allowed" else "blocked: the session still runs, but its status and Pause/Stop buttons are hidden from the notification shade",
        )
        StateLine(
            "Battery optimisation", batteryExempt,
            if (batteryExempt) "this app is not restricted" else "this app may be limited in the background (recommended: set it to unrestricted)",
        )
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = actions.openAccessibilitySettings) { Text("Accessibility") }
            if (Build.VERSION.SDK_INT >= 33 && !notificationsOn) OutlinedButton(onClick = actions.requestNotifications) { Text("Allow notifications") }
            OutlinedButton(onClick = actions.openNotificationSettings) { Text("Notification settings") }
            OutlinedButton(onClick = actions.openBatterySettings) { Text("Battery settings") }
            OutlinedButton(onClick = actions.openAppDetails) { Text("App info") }
        }
        Text(
            "Some phones (Xiaomi/MIUI/HyperOS, Oppo, Vivo, Huawei, Samsung's \"sleeping apps\") stop background apps aggressively. " +
                "If the session stops when you switch to the game, open App info → Battery and choose \"No restrictions\" (wording varies), " +
                "and allow Autostart if your phone has that option. Android also ends screen capture whenever you tap \"Stop sharing\" and, on some phones, when the screen locks; " +
                "then press Connect again.",
            style = MaterialTheme.typography.bodySmall,
        )
        Text(
            "Android 13+ may grey out the accessibility switch for apps installed outside a store (\"restricted setting\"). " +
                "Open App info, tap the ⋮ menu and choose \"Allow restricted settings\", then enable the service. " +
                "This is a normal Android protection and is not bypassed by this app. Without the service you can still use Assisted mode.",
            style = MaterialTheme.typography.bodySmall,
        )
    }
}

/** Switches for the floating panel and vibration cues. */
@Composable
fun BackgroundCard() {
    val opts by AutopilotRuntime.options.collectAsState()
    val access by AutopilotRuntime.accessibilityConnected.collectAsState()
    SectionCard("While the game is open") {
        Text(
            "START AUTO DRIVE opens the game for you. A notification stays visible while screen sharing is on, with Pause / Resume / End / Emergency stop, " +
                "and a small round button floats over the game (tap it for the controls). The drive pauses by itself when the screen turns off and is never resumed automatically.",
            style = MaterialTheme.typography.bodySmall,
        )
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Show the floating control button over the game", Modifier.weight(1f).padding(end = 8.dp))
            Switch(checked = opts.showPanel, onCheckedChange = { v -> AutopilotRuntime.updateOptions { it.copy(showPanel = v) } })
        }
        if (opts.showPanel && !access) Text("The floating button needs the accessibility service.", color = MaterialTheme.colorScheme.error)
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Vibrate at the start and end of calibration steps", Modifier.weight(1f).padding(end = 8.dp))
            Switch(checked = opts.vibrateCues, onCheckedChange = { v -> AutopilotRuntime.updateOptions { it.copy(vibrateCues = v) } })
        }
        Text(
            "The button is a small window above the game: if automation taps a spot under it, the tap lands on the button. Drag it to a screen edge away from your controls; it remembers where you leave it.",
            style = MaterialTheme.typography.bodySmall,
        )
    }
}
