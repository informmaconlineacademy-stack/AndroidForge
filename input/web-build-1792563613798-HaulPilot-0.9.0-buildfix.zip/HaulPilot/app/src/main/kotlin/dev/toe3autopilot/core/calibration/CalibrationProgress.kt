package dev.toe3autopilot.core.calibration

import dev.toe3autopilot.core.Control

enum class StageState { PENDING, ACTIVE, DONE, BLOCKED }

/** One of the four calibration stages shown to the person. */
data class CalibStage(val key: String, val title: String, val state: StageState, val detail: String)

data class CalibrationProgress(
    val stages: List<CalibStage>,
    /** 0..1 overall. Only counts what is really done: a stage in progress counts partially, a blocked one counts nothing. */
    val fraction: Float,
    /** Why calibration cannot continue right now, in plain words (null = nothing is blocking). */
    val blocker: String?,
) {
    val complete: Boolean get() = stages.all { it.state == StageState.DONE }
}

enum class ControlStatus(val label: String) {
    /** In the saved profile (the person confirmed it before it was saved). */
    SAVED("Saved"),

    /** Confirmed by the person (or an unmistakable demonstration), not saved yet. */
    CONFIRMED("Confirmed"),

    /** Found but not trusted: waits for the person. */
    UNCERTAIN("Uncertain"),

    /** Not found, rejected or not yet looked for. */
    MISSING("Missing"),
}

data class ControlLine(
    val role: CalibRole,
    val status: ControlStatus,
    /** Evidence strength of the current detection, null for controls that are only known from the saved profile. */
    val confidence: Float?,
    val required: Boolean,
    val detection: ControlDetection?,
)

enum class ConfidenceLevel(val label: String) { NONE("No data"), LOW("Low"), MEDIUM("Medium"), HIGH("High") }

data class ControlSummary(val lines: List<ControlLine>) {
    val saved: Int get() = lines.count { it.status == ControlStatus.SAVED }
    val confirmed: Int get() = lines.count { it.status == ControlStatus.CONFIRMED || it.status == ControlStatus.SAVED }
    val uncertain: Int get() = lines.count { it.status == ControlStatus.UNCERTAIN }
    val missingRequired: Int get() = lines.count { it.required && it.status == ControlStatus.MISSING }
    val missing: Int get() = lines.count { it.status == ControlStatus.MISSING }

    /** All required controls are confirmed or saved. */
    val ready: Boolean get() = lines.filter { it.required }.all { it.status == ControlStatus.SAVED || it.status == ControlStatus.CONFIRMED }

    val averageConfidence: Float?
        get() = lines.mapNotNull { it.confidence }.takeIf { it.isNotEmpty() }?.average()?.toFloat()

    val level: ConfidenceLevel
        get() = when (val a = averageConfidence) {
            null -> ConfidenceLevel.NONE
            else -> if (a >= 0.8f) ConfidenceLevel.HIGH else if (a >= 0.55f) ConfidenceLevel.MEDIUM else ConfidenceLevel.LOW
        }
}

object CalibrationSummaries {
    /** The roles shown to the person, in order. */
    val ROLES = listOf(CalibRole.ACCELERATOR, CalibRole.BRAKE, CalibRole.STEER_LEFT, CalibRole.STEER_RIGHT, CalibRole.GEAR_REVERSE)

    /**
     * Combines what the engine currently proposes with what the saved profile already holds. A saved control is "Saved"
     * unless the engine currently holds a newer proposal for it that the person has not confirmed (then it is shown as
     * that proposal, so nothing unverified is ever displayed as confirmed).
     */
    fun controls(detections: Map<CalibRole, ControlDetection>, saved: Set<Control>): ControlSummary {
        val wheelOk = detections[CalibRole.STEER_WHEEL]?.status?.usable == true || Control.STEER_CENTER in saved
        val lines = ROLES.map { role ->
            val d = detections[role]
            val inProfile = role.control != null && role.control in saved
            val steerOptional = wheelOk && (role == CalibRole.STEER_LEFT || role == CalibRole.STEER_RIGHT)
            val required = role != CalibRole.GEAR_REVERSE && !steerOptional
            when {
                d != null && d.status.usable -> ControlLine(role, ControlStatus.CONFIRMED, d.confidence, required, d)
                d != null && d.status == DetectionStatus.NEEDS_CONFIRMATION -> ControlLine(role, ControlStatus.UNCERTAIN, d.confidence, required, d)
                inProfile -> ControlLine(role, ControlStatus.SAVED, null, required, d)
                else -> ControlLine(role, ControlStatus.MISSING, null, required, d)
            }
        }
        return ControlSummary(lines)
    }

    /** The four stages. [saved] are the controls in the saved profile; [captureProblem] is a capture diagnosis, if any. */
    fun progress(st: CalibrationState, saved: Set<Control>, captureProblem: String?): CalibrationProgress {
        val hud = st.hud
        val hudOk = hud?.ok == true
        val observing = st.phase == CalibPhase.OBSERVING
        val busy = st.phase != CalibPhase.IDLE && st.phase != CalibPhase.DONE
        val summary = controls(st.detections, saved)
        val required = summary.lines.filter { it.required }
        val reqDone = required.count { it.status == ControlStatus.SAVED || it.status == ControlStatus.CONFIRMED }
        val reqSaved = required.count { it.role.control != null && it.role.control in saved }

        val a = when {
            hudOk -> CalibStage("A", "Screen analysis", StageState.DONE, "${hud!!.elements.size} fixed on-screen elements found (${hud.frameWidth}x${hud.frameHeight})")
            captureProblem != null -> CalibStage("A", "Screen analysis", StageState.BLOCKED, captureProblem)
            st.layoutUnstable -> CalibStage("A", "Screen analysis", StageState.BLOCKED, st.problem ?: "The layout changed")
            hud != null && !busy -> CalibStage("A", "Screen analysis", StageState.BLOCKED, hud.problem ?: "No fixed elements found")
            observing || st.framesSeen > 0 -> CalibStage("A", "Screen analysis", StageState.ACTIVE, st.message)
            else -> CalibStage("A", "Screen analysis", StageState.PENDING, "Not started")
        }
        val b = when {
            st.layoutUnstable -> CalibStage("B", "Temporal analysis", StageState.BLOCKED, st.problem ?: "The layout changed while observing")
            hudOk && hud!!.framesUsed >= HudAnalyzer.MIN_FRAMES -> CalibStage("B", "Temporal analysis", StageState.DONE, "${hud.framesUsed} pictures compared; ${(hud.sceneChange * 100).toInt()}% scenery change")
            observing -> CalibStage("B", "Temporal analysis", StageState.ACTIVE, "Comparing pictures (${st.framesSeen} so far)")
            else -> CalibStage("B", "Temporal analysis", StageState.PENDING, "Needs several pictures while the scenery moves")
        }
        val c = when {
            !hudOk && reqDone == 0 -> CalibStage("C", "Guided verification", StageState.PENDING, "Waits for the screen analysis")
            required.isNotEmpty() && reqDone == required.size -> CalibStage("C", "Guided verification", StageState.DONE, "All required controls confirmed")
            else -> CalibStage("C", "Guided verification", StageState.ACTIVE, "$reqDone of ${required.size} required controls confirmed")
        }
        val d = when {
            required.isNotEmpty() && reqSaved == required.size -> CalibStage("D", "Calibration profile", StageState.DONE, "Saved to the profile")
            reqSaved > 0 -> CalibStage("D", "Calibration profile", StageState.ACTIVE, "$reqSaved of ${required.size} required controls saved")
            else -> CalibStage("D", "Calibration profile", StageState.PENDING, "Nothing saved yet")
        }
        val stages = listOf(a, b, c, d)
        val partial = { s: CalibStage ->
            when (s.state) {
                StageState.DONE -> 1f
                StageState.ACTIVE -> if (s.key == "C" && required.isNotEmpty()) reqDone.toFloat() / required.size else if (s.key == "D" && required.isNotEmpty()) reqSaved.toFloat() / required.size else 0.4f
                else -> 0f
            }
        }
        val fraction = stages.sumOf { partial(it).toDouble() }.toFloat() / stages.size
        val blocker = stages.firstOrNull { it.state == StageState.BLOCKED }?.detail
        return CalibrationProgress(stages, fraction.coerceIn(0f, 1f), blocker)
    }
}
