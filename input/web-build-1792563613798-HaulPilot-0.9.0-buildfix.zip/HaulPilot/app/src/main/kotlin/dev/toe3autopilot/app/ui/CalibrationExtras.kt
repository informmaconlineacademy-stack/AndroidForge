package dev.toe3autopilot.app.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import dev.toe3autopilot.app.AutopilotRuntime
import dev.toe3autopilot.app.capture.SavedSnapshot
import dev.toe3autopilot.core.calibration.CalibPhase
import dev.toe3autopilot.core.calibration.CalibRole
import dev.toe3autopilot.core.calibration.CalibrationState
import dev.toe3autopilot.core.calibration.ControlDetection
import dev.toe3autopilot.core.calibration.DetectionStatus
import dev.toe3autopilot.core.vision.Roi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.DateFormat
import java.util.Date

@Composable
fun SuggestionsCard(st: CalibrationState, applyTiming: Boolean, setApplyTiming: (Boolean) -> Unit) {
    val ctl = AutopilotRuntime.calibration
    val t = st.timing
    val hasAnything = t != null || st.minimap != null || st.speedGuess != null
    if (!hasAnything) return
    SectionCard("Measurements and suggestions") {
        st.speedGuess?.let { g ->
            Text(
                "Possible speed gauge near (${(g.x * 100).toInt()}%, ${(g.y * 100).toInt()}%): ${g.note}. This is a guess; the number is not read.",
                style = MaterialTheme.typography.bodySmall,
            )
        }
        st.minimap?.let { m ->
            Text("Possible minimap: ${m.note}", style = MaterialTheme.typography.bodySmall)
            OutlinedButton(onClick = { AutopilotRuntime.notice.value = ctl.useMinimapSuggestion() ?: "Minimap region saved to the profile. Check it in the Manual tab." }) {
                Text("Use as minimap (I checked the magenta box)")
            }
        }
        if (t != null) {
            Text("Timing from your accelerator demonstration:", fontWeight = FontWeight.Bold)
            t.stoppedThreshold?.let { Text("• \"Stopped\" motion level ≈ ${"%.4f".format(it)} (rest ${"%.4f".format(t.restLevel)}, moving ${"%.4f".format(t.movingLevel)})", style = MaterialTheme.typography.bodySmall) }
            t.startLatencyMsUpperBound?.let { Text("• Started moving within about $it ms (includes your reaction time)", style = MaterialTheme.typography.bodySmall) }
            t.stopMs?.let { Text("• Came to rest about $it ms after you let go (includes your reaction time)", style = MaterialTheme.typography.bodySmall) }
            t.suggestedSettleMs?.let { Text("• Suggested settle time $it ms", style = MaterialTheme.typography.bodySmall) }
            t.notes.forEach { Text("· $it", style = MaterialTheme.typography.bodySmall) }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Also save these timing values when I save to the profile", Modifier.weight(1f).padding(end = 8.dp))
                Switch(checked = applyTiming, onCheckedChange = setApplyTiming)
            }
        }
    }
}

@Composable
fun LayoutCard(actions: Actions, capture: Boolean) {
    val ctl = AutopilotRuntime.calibration
    val report by ctl.layoutReport.collectAsState()
    val scope = rememberCoroutineScope()
    var countdown by remember { mutableStateOf(0) }
    SectionCard("Did the game's interface change?") {
        Text(
            "Compares the game's driving screen with what was learned and proposes where moved controls went. The app also does this check " +
                "by itself during a session and pauses if the screen size changes (for example after rotating).",
            style = MaterialTheme.typography.bodySmall,
        )
        Button(enabled = capture && countdown == 0, onClick = {
            scope.launch {
                for (i in 8 downTo 1) {
                    countdown = i
                    delay(1000)
                }
                countdown = 0
                if (AutopilotRuntime.appVisible) {
                    AutopilotRuntime.notice.value = "This app was still on screen. Press the button again and switch to the game's driving screen within 8 seconds."
                } else {
                    val f = AutopilotRuntime.frameSource.latest()
                    withContext(Dispatchers.Default) { ctl.checkLayout(f) }
                }
            }
        }) { Text(if (countdown > 0) "Checking in $countdown…" else "Check in 8 s (switch to the driving screen)") }
        report?.let { r ->
            r.lines.forEach { Text(it, style = MaterialTheme.typography.bodySmall) }
            r.relocations.forEach { m ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("${m.role.label} → (${(m.x * 100).toInt()}%, ${(m.y * 100).toInt()}%)", Modifier.weight(1f))
                    OutlinedButton(onClick = { ctl.acceptRelocation(m) }) { Text("Accept") }
                }
            }
            if (r.needsRecalibration) Text("Run Step 1 and Step 2 again for this screen layout.", fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun RecordingCard(actions: Actions, capture: Boolean, access: Boolean) {
    val recorder = AutopilotRuntime.recorder
    val recording by recorder.recording.collectAsState()
    val items by recorder.items.collectAsState()
    val opts by AutopilotRuntime.options.collectAsState()
    val scope = rememberCoroutineScope()
    var viewing by remember { mutableStateOf<SavedSnapshot?>(null) }
    val fmt = remember { DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.MEDIUM) }

    SectionCard("Sample snapshots (optional)") {
        Text(
            "Saves a small picture of the game screen every few seconds, only while the game is in front. Not video. The pictures stay on " +
                "this phone in the app's private storage, are used only to test the calibration, and you can delete them any time. " +
                "Saving always stops when screen capture ends.",
            style = MaterialTheme.typography.bodySmall,
        )
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(2, 5, 10, 30).forEach { sec ->
                FilterChip(selected = opts.recordIntervalSec == sec, enabled = !recording, onClick = { AutopilotRuntime.updateOptions { it.copy(recordIntervalSec = sec) } }, label = { Text("every $sec s") })
            }
        }
        Text("At most ${opts.recordMaxFrames} pictures are kept; the oldest are deleted first.", style = MaterialTheme.typography.bodySmall)
        if (!access) Text("Needs the accessibility service, so the app can be sure only the game is saved.", color = MaterialTheme.colorScheme.error)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (!recording) {
                Button(enabled = capture && access, onClick = { recorder.start(opts.recordIntervalSec, opts.recordMaxFrames) }) { Text("Start saving") }
            } else {
                Button(onClick = { recorder.stop() }) { Text("Stop saving") }
            }
            OutlinedButton(enabled = items.isNotEmpty(), onClick = { recorder.deleteAll() }) { Text("Delete all") }
        }
        Text("${items.size} picture(s), ${recorder.totalBytes() / 1024} KB", fontWeight = FontWeight.Bold)
        OutlinedButton(enabled = items.size >= 10, onClick = {
            scope.launch {
                val err = withContext(Dispatchers.Default) {
                    val frames = recorder.sampleForAnalysis(24)
                    AutopilotRuntime.calibration.analyseSnapshots(frames)
                }
                AutopilotRuntime.notice.value = err ?: AutopilotRuntime.calibration.state.value.message
            }
        }) { Text("Analyse saved pictures (needs 10+)") }
        items.take(8).forEach { item ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Text("${fmt.format(Date(item.timeMs))}  ${item.bytes / 1024} KB", style = MaterialTheme.typography.bodySmall)
                Row {
                    TextButton(onClick = { viewing = item }) { Text("View") }
                    TextButton(onClick = { recorder.delete(item) }) { Text("Delete") }
                }
            }
        }
        if (items.size > 8) Text("…and ${items.size - 8} older picture(s).", style = MaterialTheme.typography.bodySmall)
    }

    viewing?.let { item ->
        val bmp = remember(item) { BitmapFactory.decodeFile(item.file.absolutePath) }
        AlertDialog(
            onDismissRequest = { viewing = null },
            confirmButton = { TextButton(onClick = { viewing = null }) { Text("Close") } },
            dismissButton = { TextButton(onClick = { recorder.delete(item); viewing = null }) { Text("Delete") } },
            title = { Text(fmt.format(Date(item.timeMs))) },
            text = {
                if (bmp != null) {
                    Image(bmp.asImageBitmap(), contentDescription = "Saved snapshot", modifier = Modifier.fillMaxWidth())
                } else {
                    Text("This picture cannot be read.")
                }
            },
        )
    }
}
