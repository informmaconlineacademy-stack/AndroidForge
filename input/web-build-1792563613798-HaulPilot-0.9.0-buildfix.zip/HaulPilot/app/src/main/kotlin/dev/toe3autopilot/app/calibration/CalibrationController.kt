package dev.toe3autopilot.app.calibration

import dev.toe3autopilot.app.capture.ScreenFrameSource
import dev.toe3autopilot.app.data.ProfileStore
import dev.toe3autopilot.core.Point
import dev.toe3autopilot.core.WallClock
import dev.toe3autopilot.core.calibration.Alternative
import dev.toe3autopilot.core.calibration.CalibPhase
import dev.toe3autopilot.core.calibration.CalibRole
import dev.toe3autopilot.core.calibration.CalibrationApply
import dev.toe3autopilot.core.calibration.CalibrationCodec
import dev.toe3autopilot.core.calibration.CalibrationEngine
import dev.toe3autopilot.core.calibration.CalibrationState
import dev.toe3autopilot.core.calibration.DemoTimings
import dev.toe3autopilot.core.calibration.GuidedSetup
import dev.toe3autopilot.core.calibration.AutoResult
import dev.toe3autopilot.core.calibration.ControlDetection
import dev.toe3autopilot.core.calibration.DetectionStatus
import dev.toe3autopilot.core.calibration.TapSnap
import dev.toe3autopilot.core.calibration.LayoutCheck
import dev.toe3autopilot.core.profile.GameProfile
import dev.toe3autopilot.core.profile.ProfileArchive
import dev.toe3autopilot.core.profile.ProfileCodec
import dev.toe3autopilot.core.profile.ProfileEditing
import dev.toe3autopilot.core.profile.TemplateSpec
import dev.toe3autopilot.core.session.GameMonitor
import dev.toe3autopilot.core.session.LogLevel
import dev.toe3autopilot.core.session.SessionLog
import dev.toe3autopilot.core.vision.ColorTarget
import dev.toe3autopilot.core.vision.Frame
import dev.toe3autopilot.core.vision.Roi
import dev.toe3autopilot.core.vision.TemplateProvider
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Result of comparing the live screen with the stored calibration. */
data class LayoutReport(
    val lines: List<String>,
    val relocations: List<LayoutCheck.Relocation>,
    /** True when the screen geometry no longer fits (rotation, other screen): positions cannot simply be moved. */
    val needsRecalibration: Boolean,
)

/**
 * Android-side owner of the self-calibration: feeds sampled frames to the [CalibrationEngine], decides *when* frames
 * may be used, persists results, and applies them to the saved profile.
 *
 * Rules enforced here (the engine itself is frame-driven and knows nothing about Android):
 *  - Frames are only analysed while the game is not known to be elsewhere and this app's own screen is not in front;
 *    otherwise the "HUD" it learned would be this app's user interface.
 *  - Nothing is applied to the profile unless its detection status is usable (CalibrationApply enforces that).
 *  - Calibration pauses while an automation session is running.
 *  - The previous profile is kept as a backup before every change made here, so the change can be undone.
 */
class CalibrationController(
    private val profileStore: ProfileStore,
    private val log: SessionLog,
    private val monitor: GameMonitor,
    private val currentProfile: () -> GameProfile?,
    private val publishProfile: (GameProfile) -> Unit,
    private val gamePackage: () -> String,
    private val appVisible: () -> Boolean,
) {
    val engine = CalibrationEngine(WallClock, log, DemoTimings(prepareMs = PREPARE_MS))

    private val _state = MutableStateFlow(engine.state())
    val state: StateFlow<CalibrationState> = _state.asStateFlow()

    /** Last game frame given to the engine; the boxes in [state] refer to it. */
    private val _preview = MutableStateFlow<Frame?>(null)
    val preview: StateFlow<Frame?> = _preview.asStateFlow()

    private val _note = MutableStateFlow<String?>(null)
    val note: StateFlow<String?> = _note.asStateFlow()

    private val _lastApply = MutableStateFlow<CalibrationApply.Result?>(null)
    val lastApply: StateFlow<CalibrationApply.Result?> = _lastApply.asStateFlow()

    private val _layoutReport = MutableStateFlow<LayoutReport?>(null)
    val layoutReport: StateFlow<LayoutReport?> = _layoutReport.asStateFlow()

    private val _canUndo = MutableStateFlow(profileStore.hasBackup())
    val canUndo: StateFlow<Boolean> = _canUndo.asStateFlow()

    /** Called on every phase change of a demonstration (the service uses it to vibrate). */
    @Volatile
    var onPhaseChange: ((CalibPhase) -> Unit)? = null

    private var lastPhase = CalibPhase.IDLE
    private var awaySince = 0L
    private var lastPreviewAt = 0L
    private var lastPublishAt = 0L

    init {
        try {
            profileStore.readCalibrationText()?.let { text ->
                val parsed = CalibrationCodec.parse(text)
                engine.restore(parsed.calibration)
                parsed.warnings.forEach { log.add(WallClock.nowMs(), LogLevel.WARN, "Calibration file: $it") }
            }
        } catch (e: Exception) {
            log.add(WallClock.nowMs(), LogLevel.WARN, "Saved calibration could not be read and was ignored: ${e.javaClass.simpleName}")
        }
        publish()
    }

    // ---- loop hook -------------------------------------------------------------------------------------

    /**
     * Called regularly from the service loop on a background thread. Returns the delay until the next call.
     * @param sessionActive an automation session is running: calibration steps aside.
     */
    fun pump(frames: ScreenFrameSource, sessionActive: Boolean): Long {
        if (sessionActive) {
            if (engine.isBusy) {
                engine.cancel()
                _note.value = "Calibration was stopped because an automation session started."
            }
            publishIfChanged()
            return IDLE_PUMP_MS
        }
        if (!engine.isBusy) {
            frames.minIntervalMs = IDLE_FRAME_MS
            awaySince = 0L
            publishIfChanged()
            return IDLE_PUMP_MS
        }

        val now = WallClock.nowMs()
        val away = appVisible() || monitor.isGameForeground() == false
        if (away) {
            if (awaySince == 0L) awaySince = now
        } else {
            awaySince = 0L
        }
        val phase = engine.state().phase
        if (!away) {
            val f = frames.latest()
            if (f != null) {
                engine.offerFrame(f)
                if (now - lastPreviewAt >= 1000L) {
                    lastPreviewAt = now
                    _preview.value = f
                }
            }
        } else if ((phase == CalibPhase.BASELINE || phase == CalibPhase.ACTION || phase == CalibPhase.RELEASE) && now - awaySince > AWAY_CANCEL_MS) {
            engine.cancel()
            _note.value = "The demonstration was cancelled because the game was not on screen. Start it again and switch to the game within ${PREPARE_MS / 1000} seconds."
        }
        engine.tick()
        frames.minIntervalMs = engine.desiredFrameIntervalMs()
        publishIfChanged(force = true)
        return BUSY_PUMP_MS
    }

    private fun publishIfChanged(force: Boolean = false) {
        val now = WallClock.nowMs()
        if (!force && now - lastPublishAt < 500L) return
        lastPublishAt = now
        publish()
    }

    private fun publish() {
        val st = engine.state()
        _state.value = st
        if (st.phase != lastPhase) {
            val was = lastPhase
            lastPhase = st.phase
            if (st.phase == CalibPhase.DONE && was != CalibPhase.IDLE && was != CalibPhase.OBSERVING) persist()
            onPhaseChange?.invoke(st.phase)
        }
    }

    private fun persist() {
        try {
            profileStore.writeCalibrationText(CalibrationCodec.format(engine.persisted()))
        } catch (e: Exception) {
            log.add(WallClock.nowMs(), LogLevel.WARN, "Could not save calibration results: ${e.javaClass.simpleName}")
        }
    }

    // ---- user actions ----------------------------------------------------------------------------------

    fun clearNote() {
        _note.value = null
    }

    fun startObserving() {
        _note.value = null
        engine.startObserving()
        publish()
    }

    fun stopObserving() {
        engine.stopObserving()
        publish()
    }

    /** Null when the demonstration started, otherwise why not. */
    fun startDemo(role: CalibRole): String? {
        _note.value = null
        val err = engine.startDemo(role)
        publish()
        return err
    }

    fun cancel() {
        engine.cancel()
        publish()
    }

    fun confirm(role: CalibRole) {
        pushUndo()
        engine.confirm(role)
        persist()
        publish()
    }

    fun reject(role: CalibRole) {
        pushUndo()
        engine.reject(role)
        persist()
        publish()
    }

    fun place(role: CalibRole, x: Float, y: Float) {
        pushUndo()
        engine.place(role, x, y)
        persist()
        publish()
    }

    fun chooseAlternative(role: CalibRole, index: Int) {
        pushUndo()
        engine.chooseAlternative(role, index)
        persist()
        publish()
    }

    /** Uses an explicit candidate position (for example a guess listed when nothing was detected) as the user's own choice. */
    fun placeFromGuess(role: CalibRole, guess: Alternative) = place(role, guess.x, guess.y)

    /** Null if the analysis ran, otherwise why not. */
    fun analyseSnapshots(frames: List<Frame>): String? {
        val err = engine.analyseSnapshots(frames)
        frames.lastOrNull()?.let { _preview.value = it }
        publish()
        return err
    }

    /**
     * Hands the candidates from an analysed clip to the engine. Null if accepted, otherwise why not. The candidates need the
     * person's confirmation like any other; nothing here touches the game or a session.
     */
    fun importVideoResult(res: dev.toe3autopilot.core.calibration.VideoCalibrationResult, preview: Frame): String? {
        val err = engine.importVideoResult(res, preview)
        if (err == null) _preview.value = preview
        publish()
        return err
    }

    fun setBox(role: CalibRole, box: Roi): Boolean {
        pushUndo()
        val ok = engine.setBox(role, box)
        if (ok) persist()
        publish()
        return ok
    }

    /** Forgets everything the engine learned. Does not change the saved profile. */
    fun resetLearned() {
        undoStack.clear()
        _canUndoEdit.value = false
        engine.reset()
        profileStore.deleteCalibrationText()
        _lastApply.value = null
        _layoutReport.value = null
        _note.value = "Learned calibration data was cleared. The saved profile was not changed."
        publish()
    }

    // ---- profile ---------------------------------------------------------------------------------------

    private fun baseProfile(): GameProfile = currentProfile() ?: GameProfile.EMPTY.copy(name = "my-device", gamePackage = gamePackage())

    fun apply(applyTiming: Boolean): CalibrationApply.Result {
        val st = engine.state()
        val layout = st.layout
        if (layout == null) {
            val r = CalibrationApply.Result(null, emptyMap(), emptyList(), emptyList(), "No frame has been analysed yet")
            _lastApply.value = r
            return r
        }
        val r = CalibrationApply.apply(baseProfile(), st.detections, engine.patches(), layout, st.timing, applyTiming)
        val p = r.profile
        if (p != null) {
            profileStore.backupProfile()
            for ((name, img) in r.patches) profileStore.saveGray(name, img)
            publishProfile(p.copy(gamePackage = p.gamePackage.ifBlank { gamePackage() }))
            _canUndo.value = profileStore.hasBackup()
            persist()
            log.add(WallClock.nowMs(), LogLevel.INFO, "Calibration applied to the profile (${r.applied.size} item(s))")
        }
        _lastApply.value = r
        return r
    }

    /** Puts back the profile as it was before the last change made on the Auto-calibrate tab. */
    fun undo(): Boolean {
        val ok = profileStore.restoreBackup()
        if (ok) {
            profileStore.load()?.let { publishProfile(it) }
            _canUndo.value = false
            _lastApply.value = null
            log.add(WallClock.nowMs(), LogLevel.INFO, "Profile restored to the version before the last calibration change")
        }
        return ok
    }

    /** Removes the controls, control patches and calibration extras that auto-calibration (or the editor) put in the profile. */
    fun clearCalibratedControls() {
        val p = currentProfile() ?: return
        profileStore.backupProfile()
        val patchNames = p.templates.keys.filter { LayoutCheck.roleOfPatch(it) != null }
        val cleaned = p.copy(
            controls = emptyMap(),
            templates = p.templates - patchNames.toSet(),
            stateRules = p.stateRules.mapValues { (_, names) -> names.filter { it.removePrefix("!") !in patchNames } }.filterValues { it.isNotEmpty() },
            extras = p.extras.filterKeys { !it.startsWith("calib.") },
        )
        patchNames.forEach { profileStore.deleteTemplate(it) }
        publishProfile(cleaned)
        _canUndo.value = profileStore.hasBackup()
        _lastApply.value = null
        log.add(WallClock.nowMs(), LogLevel.INFO, "Calibrated controls removed from the profile")
    }

    /** Offers the minimap region found by observation as the profile's minimap. The user decides; it is only a guess. */
    fun useMinimapSuggestion(): String? {
        val m = engine.state().minimap ?: return "No minimap suggestion available"
        profileStore.backupProfile()
        var p = ProfileEditing.withNavMinimap(baseProfile(), m.box)
        m.routeColorRgb?.let { rgb ->
            ProfileEditing.withRouteColor(p, ColorTarget((rgb shr 16) and 0xFF, (rgb shr 8) and 0xFF, rgb and 0xFF, 45))?.let { p = it }
        }
        publishProfile(p.copy(gamePackage = p.gamePackage.ifBlank { gamePackage() }))
        _canUndo.value = profileStore.hasBackup()
        return null
    }

    // ---- one-tap Auto-Calibrate: review, small corrections, undo, confirm ---------------------------------

    private val undoStack = ArrayDeque<Map<CalibRole, ControlDetection>>()
    private val _canUndoEdit = MutableStateFlow(false)

    /** True when a change to the proposed controls can be undone. */
    val canUndoEdit: StateFlow<Boolean> = _canUndoEdit.asStateFlow()

    private fun pushUndo() {
        undoStack.addLast(engine.detectionsSnapshot())
        while (undoStack.size > 30) undoStack.removeFirst()
        _canUndoEdit.value = true
    }

    /** Undoes the last confirm / reject / move / tap on the proposed controls. */
    fun undoEdit(): Boolean {
        val prev = undoStack.removeLastOrNull() ?: return false
        engine.restoreDetections(prev)
        _canUndoEdit.value = undoStack.isNotEmpty()
        persist()
        publish()
        return true
    }

    /** Takes the result of an Auto-Calibrate run: proposals only, nothing is confirmed or saved here. */
    fun importAutoResult(res: AutoResult, preview: Frame): String? {
        pushUndo()
        val err = engine.importVideoResult(res.video, preview, sourceLabel = "live pictures")
        if (err == null) _preview.value = preview
        persist()
        publish()
        return err
    }

    /**
     * Tap-to-identify: the person taps [role] on the picture. The region snaps to the fixed on-screen element under the
     * finger (so it fits the button); counts as the person's own confirmation and can be undone.
     */
    fun identify(role: CalibRole, x: Float, y: Float): String {
        val f = _preview.value ?: return "No picture to tap on yet."
        val box = TapSnap.boxFor(engine.state().hud, x, y, f.width.toFloat() / f.height)
        return if (setBox(role, box)) "${role.label} set where you tapped." else "That spot is too close to the edge; tap the middle of the control."
    }

    /**
     * The person reviewed the Auto-Calibrate picture and tapped Confirm. Confirms the controls proposed from evidence and the
     * guesses the person explicitly accepted ([acceptedGuesses]), saves them, and sets up the driving screen and the map
     * (minimap, route colour, and the truck position [truckAt] when the person accepted or tapped it). Returns a summary.
     */
    fun confirmAuto(res: AutoResult, acceptedGuesses: Set<CalibRole>, truckAt: Point?): String {
        val st = engine.state()
        for (r in res.evidenceRoles + acceptedGuesses) {
            val d = st.detections[r] ?: continue
            if (d.status == DetectionStatus.NEEDS_CONFIRMATION) engine.confirm(r)
        }
        persist()
        val applied = apply(false)
        val lines = ArrayList<String>()
        applied.problem?.let { lines += "Controls not saved: $it" } ?: run { lines += "Saved ${applied.applied.size} control item(s)." }
        if (res.drivingMarker != null) lines += guided(GuidedSetup.Step.DRIVING_SCREEN)
        val mm = res.minimap
        if (mm != null) {
            lines += guided(GuidedSetup.Step.MINIMAP, x = -1f)
            if (mm.routeColorRgb != null) {
                // The person saw the minimap and its route line on the picture before confirming.
                currentProfile()?.let { p -> publishProfile(p.copy(extras = p.extras + ("setup.route" to "1"))) }
            }
            if (truckAt != null) lines += guided(GuidedSetup.Step.TRUCK_MARKER, truckAt.x, truckAt.y)
        }
        publish()
        log.add(WallClock.nowMs(), LogLevel.INFO, "Auto-Calibrate confirmed: ${lines.joinToString(" | ")}")
        return lines.joinToString("\n")
    }

    // ---- guided navigation setup (Smart Setup, no template names) ----------------------------------------

    /**
     * Applies one tap-based Smart Setup step to the profile using the current calibration picture. Returns a message for the
     * person. The previous profile is kept for Undo. Call off the main thread for the driving-screen step (it crops a picture).
     */
    fun guided(step: GuidedSetup.Step, x: Float = 0.5f, y: Float = 0.5f, resize: Float? = null): String {
        val frame = _preview.value
        val p = baseProfile()
        val st = engine.state()
        val out = when {
            resize != null -> GuidedSetup.resizeMinimap(p, resize)
            step == GuidedSetup.Step.MINIMAP && st.minimap != null && x < 0f -> GuidedSetup.minimapFromSuggestion(p, st.minimap!!)
            frame == null -> GuidedSetup.Outcome.Refused("No picture yet. Observe live play, import a clip or pick screenshots first.")
            else -> when (step) {
                GuidedSetup.Step.DRIVING_SCREEN -> GuidedSetup.drivingScreen(p, frame, st)
                GuidedSetup.Step.MINIMAP -> GuidedSetup.minimapAt(p, frame, x, y)
                GuidedSetup.Step.ROUTE_COLOR -> GuidedSetup.routeColor(p, frame, x, y)
                GuidedSetup.Step.TRUCK_MARKER -> GuidedSetup.truckMarker(p, x, y)
                GuidedSetup.Step.DESTINATION -> GuidedSetup.destination(p, frame, x, y)
                GuidedSetup.Step.PARKING_ZONE -> GuidedSetup.parkingZone(p, frame, x, y)
            }
        }
        return when (out) {
            is GuidedSetup.Outcome.Refused -> out.reason
            is GuidedSetup.Outcome.Ok -> {
                profileStore.backupProfile()
                val name = out.patchName
                val patch = out.patch
                if (name != null && patch != null) profileStore.saveGray(name, patch)
                publishProfile(out.profile.copy(gamePackage = out.profile.gamePackage.ifBlank { gamePackage() }))
                _canUndo.value = profileStore.hasBackup()
                log.add(WallClock.nowMs(), LogLevel.INFO, "Smart Setup: ${step.title} saved")
                out.message
            }
        }
    }

    // ---- layout check ----------------------------------------------------------------------------------

    /** Compares [frame] (a live game frame) with the stored calibration. Call off the main thread. */
    fun checkLayout(frame: Frame?): LayoutReport {
        val p = currentProfile()
        val lines = ArrayList<String>()
        if (p == null) return LayoutReport(listOf("There is no profile yet."), emptyList(), false).also { _layoutReport.value = it }
        if (frame == null) return LayoutReport(listOf("No game frame is available. Connect capture and show the game first."), emptyList(), false).also { _layoutReport.value = it }
        val geometry = LayoutCheck.layoutProblem(p, frame.width, frame.height)
        if (geometry != null) {
            return LayoutReport(listOf(geometry), emptyList(), true).also { _layoutReport.value = it }
        }
        if (LayoutCheck.referenceSize(p) == null) lines += "This profile does not record the screen size it was made on, so its geometry cannot be checked."
        val provider = TemplateProvider(profileStore, p.referenceWidth)
        val gray = frame.toGray()
        val v = LayoutCheck.verifyControls(p, gray, provider, frame.width)
        if (v.evaluated < 2) {
            lines += "Fewer than two calibrated control pictures are stored, so the controls cannot be checked. Run Auto-calibrate and apply it."
            return LayoutReport(lines, emptyList(), false).also { _layoutReport.value = it }
        }
        lines += "${v.matched} of ${v.evaluated} calibrated controls were found where they were learned."
        if (!v.stale) {
            lines += "The layout looks unchanged. (This only works while the game's driving screen is showing and nothing is being pressed.)"
            return LayoutReport(lines, emptyList(), false).also { _layoutReport.value = it }
        }
        lines += "Most controls are not where they were. Either this is not a driving screen, or the interface changed."
        val moves = LayoutCheck.relocate(p, gray, provider, frame.width).filter { it.movedBy > 0.02f }
        if (moves.isEmpty()) lines += "No moved controls could be found automatically. Recalibrate."
        for (m in moves) {
            lines += "${m.role.label}: looks moved by ${(m.movedBy * 100).toInt()}% of the screen (match ${(m.score * 100).toInt()}%)${if (m.ambiguous) ", ambiguous (several similar buttons)" else ""}."
        }
        return LayoutReport(lines, moves, false).also { _layoutReport.value = it }
    }

    /** Applies one proposed move after the user accepted it. */
    fun acceptRelocation(m: LayoutCheck.Relocation) {
        val p = currentProfile() ?: return
        profileStore.backupProfile()
        val pt = Point(m.x.coerceIn(0f, 1f), m.y.coerceIn(0f, 1f))
        val role = m.role
        val c = role.control
        var q = if (c != null) ProfileEditing.withControl(p, c, pt)
        else p.copy(extras = p.extras + ("calib." + role.name.lowercase() to String.format(java.util.Locale.ROOT, "%.3f,%.3f", pt.x, pt.y)))
        val name = LayoutCheck.patchName(role)
        q.templates[name]?.let { spec ->
            val hx = 0.1f
            val hy = 0.12f
            val roi = Roi(
                (pt.x - hx).coerceAtLeast(0f), (pt.y - hy).coerceAtLeast(0f),
                (pt.x + hx).coerceAtMost(1f), (pt.y + hy).coerceAtMost(1f),
            )
            q = q.copy(templates = q.templates + (name to TemplateSpec(name, roi, spec.minScore)))
        }
        publishProfile(q)
        _canUndo.value = profileStore.hasBackup()
        _layoutReport.value = _layoutReport.value?.let { r -> r.copy(relocations = r.relocations.filter { it.role != role }) }
        log.add(WallClock.nowMs(), LogLevel.INFO, "${role.label} moved to (${"%.2f".format(pt.x)}, ${"%.2f".format(pt.y)}) after you accepted the proposal")
    }

    // ---- export / import -------------------------------------------------------------------------------

    /** Zip with the profile, learned calibration and template pictures. Throws IllegalStateException if there is no profile. */
    fun exportArchive(): ByteArray {
        val text = profileStore.readText()
        check(text.isNotBlank()) { "There is no profile to export yet" }
        val profile = ProfileCodec.parse(text)
        val templates = LinkedHashMap<String, ByteArray>()
        for (name in profile.templates.keys) profileStore.templateBytes(name)?.let { templates[name] = it }
        return ProfileArchive.pack(text, CalibrationCodec.format(engine.persisted()), templates)
    }

    /** Replaces the profile with the one in [bytes]. Throws IllegalArgumentException if the archive is invalid. Returns a summary. */
    fun importArchive(bytes: ByteArray): String {
        val c = ProfileArchive.unpack(bytes)
        profileStore.backupProfile()
        for ((name, png) in c.templatesPng) profileStore.writeTemplateBytes(name, png)
        publishProfile(c.profile)
        var extra = ""
        c.calibrationText?.let { t ->
            try {
                val parsed = CalibrationCodec.parse(t)
                engine.restore(parsed.calibration)
                persist()
                if (parsed.warnings.isNotEmpty()) extra = " (${parsed.warnings.size} calibration line(s) were skipped)"
            } catch (e: Exception) {
                extra = " (the learned-calibration part could not be read and was ignored)"
            }
        }
        _canUndo.value = profileStore.hasBackup()
        publish()
        log.add(WallClock.nowMs(), LogLevel.INFO, "Profile imported: ${c.profile.templates.size} template(s)")
        return "Imported profile '${c.profile.name}' with ${c.templatesPng.size} picture(s)$extra."
    }

    companion object {
        /** Time to switch from this app to the game after pressing "Demonstrate". */
        const val PREPARE_MS = 8000L
        private const val AWAY_CANCEL_MS = 1500L
        private const val IDLE_PUMP_MS = 250L
        private const val BUSY_PUMP_MS = 100L
        private const val IDLE_FRAME_MS = 1000L
    }
}
