package dev.toe3autopilot.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import dev.toe3autopilot.app.AutopilotRuntime
import dev.toe3autopilot.core.calibration.LayoutCheck
import dev.toe3autopilot.core.profile.CalibrationChecklist

/** Profiles: what is saved, whether it still fits the screen, backup/restore/reset, the checklist and the manual editors. */
@Composable
fun ProfilesScreen(actions: Actions, nav: Navigator, sub: Int, onSub: (Int) -> Unit) {
    val options by AutopilotRuntime.options.collectAsState()
    // The template editor and the profile text are expert tools; they only appear when Settings → Advanced tools is on.
    val expert = options.advancedTools
    val page = if (!expert && (sub == Sub.PROFILE_MANUAL || sub == Sub.PROFILE_ADVANCED)) Sub.PROFILE_OVERVIEW else sub
    Column(Modifier.fillMaxSize()) {
        ScreenTitle("Calibration Profiles", "Saved control positions for your screen")
        Column(Modifier.padding(horizontal = Dim.l, vertical = Dim.s)) {
            val labels = if (expert) listOf("Overview", "Checklist", "Expert editor", "Profile text") else listOf("Overview", "Checklist")
            SegmentRow(labels, page) { onSub(it) }
        }
        when (page) {
            Sub.PROFILE_CHECKLIST -> ChecklistPage(nav)
            Sub.PROFILE_MANUAL -> CalibrateTab()
            Sub.PROFILE_ADVANCED -> ProfileTextEditor()
            else -> ProfileOverview(actions, nav)
        }
    }
}

@Composable
private fun ProfileOverview(actions: Actions, nav: Navigator) {
    val ctl = AutopilotRuntime.calibration
    val profile by AutopilotRuntime.profile.collectAsState()
    val profileError by AutopilotRuntime.profileError.collectAsState()
    val snap by AutopilotRuntime.snapshot.collectAsState()
    val canUndo by ctl.canUndo.collectAsState()
    val preview by ctl.preview.collectAsState()
    val sessionLive = snap.status.isActiveLoop
    var message by remember { mutableStateOf<String?>(null) }
    var confirm by remember { mutableStateOf<String?>(null) }

    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(horizontal = Dim.l, vertical = Dim.s),
        verticalArrangement = Arrangement.spacedBy(Dim.m),
    ) {
        message?.let { Banner(BannerKind.Info, it, actionLabel = "OK", onAction = { message = null }) }
        profileError?.let { Banner(BannerKind.Error, "The saved profile could not be read", it) }

        val p = profile
        if (p == null) {
            Panel(title = "Calibration profile") {
                EmptyState(
                    "No profile yet",
                    "A profile holds the confirmed positions of the controls and the map. Create one with Smart Setup, or import a backup.",
                    actionLabel = "Open Smart Setup",
                    onAction = { nav.to(MainTab.Calibration) },
                    icon = IconKind.PROFILE,
                )
            }
        } else {
            val ref = LayoutCheck.referenceSize(p)
            val live = preview ?: AutopilotRuntime.frameSource.latest()
            val layoutProblem = live?.let { LayoutCheck.layoutProblem(p, it.width, it.height) }
            Panel(title = "Profile \"${p.name}\"", subtitle = p.gamePackage.ifBlank { "No game selected" }) {
                CheckRow("${p.controls.size} control position(s) saved", p.controls.isNotEmpty(), "Confirm the controls in Smart Setup.")
                CheckRow("${p.templates.size} control picture(s) / screen marker(s)", p.templates.isNotEmpty(), "Created by Smart Setup → Navigation and screen.")
                Body(
                    if (ref != null) "Calibrated for a ${ref.width} × ${ref.height} picture."
                    else "This profile does not record the picture size it was made for (an older profile).",
                )
                when {
                    layoutProblem != null -> Banner(
                        BannerKind.Warning, "Verification needed", layoutProblem,
                        actionLabel = "Recalibrate", onAction = { nav.to(MainTab.Calibration) },
                    )
                    live != null && ref != null -> Banner(BannerKind.Success, "Matches the current screen", "The picture size fits this profile, so it can be reused.")
                    else -> Caption("The layout check runs when a picture is available (screen capture on, or a calibration picture loaded).")
                }
                AppButton("Recalibrate", { nav.to(MainTab.Calibration) }, Modifier.fillMaxWidth(), ButtonKind.Secondary, icon = IconKind.REFRESH)
            }
        }

        Panel(title = "Backup and restore") {
            Body("Export saves the profile, the learned calibration and the control pictures as one .zip file whose location you choose. Import replaces the current profile; the old one is kept for Undo.")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(Dim.s)) {
                AppButton("Export", actions.exportProfile, Modifier.weight(1f), ButtonKind.Secondary, icon = IconKind.UPLOAD)
                AppButton("Import", actions.importProfile, Modifier.weight(1f), ButtonKind.Secondary, enabled = !sessionLive)
            }
            AppButton(
                "Undo last change",
                { message = if (ctl.undo()) "Profile restored to the version before the last change." else "Nothing to undo." },
                Modifier.fillMaxWidth(), ButtonKind.Ghost, enabled = canUndo && !sessionLive,
            )
        }

        Panel(title = "Reset") {
            Body("Resetting never deletes your backup .zip files. Removing calibrated controls can be undone.")
            AppButton("Remove calibrated controls from the profile", { confirm = "remove" }, Modifier.fillMaxWidth(), ButtonKind.Secondary, enabled = !sessionLive && profile != null)
            AppButton("Reset learned calibration data", { confirm = "learned" }, Modifier.fillMaxWidth(), ButtonKind.Danger, enabled = !sessionLive)
        }
    }

    when (confirm) {
        "remove" -> ConfirmDialog(
            "Remove calibrated controls?",
            "Control positions, their pictures and calibration extras are removed from the profile. Screen markers stay. You can undo this.",
            "Remove", onDismiss = { confirm = null },
        ) {
            ctl.clearCalibratedControls()
            message = "Calibrated controls removed."
            confirm = null
        }
        "learned" -> ConfirmDialog(
            "Reset learned calibration?",
            "What the app learned (found controls, timing, layout) is cleared. The saved profile is not changed.",
            "Reset", onDismiss = { confirm = null },
        ) {
            ctl.resetLearned()
            message = "Learned calibration cleared."
            confirm = null
        }
        else -> {}
    }
}

@Composable
fun ConfirmDialog(title: String, text: String, confirmLabel: String, onDismiss: () -> Unit, onConfirm: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Tokens.Surface,
        title = { Text(title, color = Tokens.TextPrimary) },
        text = { Text(text, color = Tokens.TextSecondary) },
        confirmButton = { AppButton(confirmLabel, onConfirm, kind = ButtonKind.Danger) },
        dismissButton = { AppButton("Keep", onDismiss, kind = ButtonKind.Ghost) },
    )
}

@Composable
private fun ChecklistPage(nav: Navigator) {
    val profile by AutopilotRuntime.profile.collectAsState()
    val items = CalibrationChecklist.items(profile, AutopilotRuntime.profileStore)
    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(horizontal = Dim.l, vertical = Dim.s),
        verticalArrangement = Arrangement.spacedBy(Dim.m),
    ) {
        Panel(title = "Needed before START AUTO DRIVE") {
            items.filter { it.required }.forEach { CheckRow(it.title, it.done, it.hint) }
        }
        Panel(title = "Optional", subtitle = "Each one switches on a capability") {
            Body("The app only knows what you calibrate. It cannot read the game's destination or parking data; it sees pictures of the screen.")
            items.filter { !it.required }.forEach { CheckRow(it.title, it.done, it.hint) }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(Dim.s)) {
            AppButton("Open Smart Setup", { nav.to(MainTab.Calibration) }, Modifier.weight(1f))
        }
        Caption(
            "Order that works best: 1. Smart Setup: pick a few screenshots, import a 10-second clip, or observe live play. 2. Confirm only the " +
                "controls it is unsure about and save. 3. Navigation and screen: driving screen, minimap, route line and your truck. " +
                "4. Optional destination and parking area. Then start from the Dashboard.",
        )
    }
}

@Composable
private fun ProfileTextEditor() {
    var profileText by remember { mutableStateOf(AutopilotRuntime.profileStore.readText()) }
    var profileMsg by remember { mutableStateOf<String?>(null) }
    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(horizontal = Dim.l, vertical = Dim.s),
        verticalArrangement = Arrangement.spacedBy(Dim.m),
    ) {
        Panel(title = "Profile text (experts)") {
            Body(
                "For experts. Normally Smart Setup builds the profile. Here you can review it or set values that have no editor, " +
                    "such as extra.parking.direction, extra.parking.moveMs, extra.delivery.nearDist / atDist, extra.approach.maxMs and steering.mode. " +
                    "It is validated strictly on save.",
            )
            OutlinedTextField(
                value = profileText,
                onValueChange = { profileText = it },
                modifier = Modifier.fillMaxWidth().heightIn(min = 160.dp, max = 360.dp),
                textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(Dim.s), verticalAlignment = Alignment.CenterVertically) {
                AppButton("Save", {
                    profileMsg = try {
                        AutopilotRuntime.profileStore.saveText(profileText)
                        AutopilotRuntime.reloadProfile()
                        "Saved."
                    } catch (e: IllegalArgumentException) {
                        "Not saved: ${e.message}"
                    }
                }, Modifier.weight(1f))
                AppButton("Reload", {
                    AutopilotRuntime.reloadProfile()
                    profileText = AutopilotRuntime.profileStore.readText()
                    profileMsg = "Reloaded from storage."
                }, Modifier.weight(1f), ButtonKind.Secondary)
            }
            profileMsg?.let { Body(it, color = Tokens.TextPrimary) }
        }
    }
}
