package dev.toe3autopilot.core.calibration

import dev.toe3autopilot.core.Point
import dev.toe3autopilot.core.profile.GameProfile
import dev.toe3autopilot.core.profile.ProfileEditing
import dev.toe3autopilot.core.profile.ProfileReadiness
import dev.toe3autopilot.core.profile.TemplateStore
import dev.toe3autopilot.core.state.GameState
import dev.toe3autopilot.core.vision.ColorTarget
import dev.toe3autopilot.core.vision.Frame
import dev.toe3autopilot.core.vision.GrayImage
import dev.toe3autopilot.core.vision.Roi
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * The "Navigation and screen" part of Smart Setup, done by tapping a picture instead of naming templates or writing rules.
 *
 * Every step works on one picture (a live game frame, a frame from an imported clip, or a screenshot) and produces a
 * profile change. Pure logic: the Android layer only stores the resulting picture patch and the profile.
 */
object GuidedSetup {
    enum class Step(val title: String, val required: Boolean, val instruction: String) {
        DRIVING_SCREEN(
            "Driving screen", true,
            "Show the normal driving view, then press the button. The app picks a part of the dashboard that never moves and uses it to know you are driving.",
        ),
        MINIMAP("Minimap", true, "Use the minimap the app found, or tap the centre of the minimap. It must turn with the truck (heading-up)."),
        ROUTE_COLOR("Route line", true, "Tap the coloured route line on the minimap."),
        TRUCK_MARKER("Your truck on the map", true, "Tap the arrow that shows your truck on the minimap."),
        DESTINATION("Destination marker", false, "Optional: tap the destination marker on the minimap so the truck knows when it is close."),
        PARKING_ZONE("Parking area", false, "Optional: on a picture of the delivery point, tap the highlighted parking area."),
    }

    data class StepStatus(val step: Step, val done: Boolean)

    sealed class Outcome {
        /** [patch] is the picture to store under [patchName] (only for the driving-screen step). */
        data class Ok(val profile: GameProfile, val message: String, val patchName: String? = null, val patch: GrayImage? = null) : Outcome()
        data class Refused(val reason: String) : Outcome()
    }

    const val DESTINATION = "destination_marker"
    const val PARKING_ZONE = "parking_zone"
    const val DEFAULT_MINIMAP_HEIGHT = 0.30f

    /** The placeholder route colour ProfileEditing.withNavMinimap uses until a real one is picked. */
    private val DEFAULT_ROUTE = ColorTarget(255, 200, 0, 45)

    fun status(p: GameProfile?, store: TemplateStore): List<StepStatus> {
        val prof = p ?: GameProfile.EMPTY
        val rule = prof.stateRules[GameState.DRIVING]
        val driving = !rule.isNullOrEmpty() && rule.all { n -> val name = n.removePrefix("!"); prof.templates.containsKey(name) && store.gray(name) != null }
        val nav = prof.nav
        return listOf(
            StepStatus(Step.DRIVING_SCREEN, driving),
            StepStatus(Step.MINIMAP, nav != null),
            // Profiles made with the older manual editor have no setup flags: anything other than the defaults counts as set.
            StepStatus(Step.ROUTE_COLOR, nav != null && (prof.extras["setup.route"] == "1" || nav.routeColor != DEFAULT_ROUTE)),
            StepStatus(
                Step.TRUCK_MARKER,
                nav != null && (
                    prof.extras["setup.truck"] == "1" ||
                        abs(nav.truckX - (nav.minimapRoi.left + nav.minimapRoi.right) / 2f) > 0.001f ||
                        abs(nav.truckY - (nav.minimapRoi.top + (nav.minimapRoi.bottom - nav.minimapRoi.top) * 0.75f)) > 0.001f
                    ),
            ),
            StepStatus(Step.DESTINATION, prof.colors.containsKey(DESTINATION) || prof.templates.containsKey("destination_near")),
            StepStatus(Step.PARKING_ZONE, prof.colors.containsKey(PARKING_ZONE) || prof.templates.containsKey(PARKING_ZONE)),
        )
    }

    /** The first required step not done yet, or null when the navigation part is complete. */
    fun nextRequired(p: GameProfile?, store: TemplateStore): Step? = status(p, store).firstOrNull { it.step.required && !it.done }?.step

    // ---- driving screen --------------------------------------------------------------------------------------

    /**
     * Picks the fixed on-screen element that best identifies the driving view: present in nearly every analysed picture,
     * not a control (its look changes when pressed), not the speed readout or minimap (their content changes), not tiny
     * (unreliable) and not huge (would include scenery).
     */
    fun pickDrivingMarker(hud: HudAnalysis, avoid: List<Roi>): HudElement? =
        hud.elements
            .filter { it.persistence >= 0.8f && it.areaFraction in 0.0006f..0.05f }
            .filter { e -> avoid.none { overlaps(it, e.box) } }
            .maxByOrNull { it.persistence * 2f + min(it.areaFraction * 40f, 1f) }

    fun drivingScreen(p: GameProfile, frame: Frame, st: CalibrationState): Outcome {
        val hud = st.hud ?: return Outcome.Refused("The screen has not been analysed yet. Watch a few seconds of driving, import a clip, or pick screenshots first.")
        if (!hud.ok) return Outcome.Refused(hud.problem ?: "No fixed dashboard elements were found yet.")
        if (hud.frameWidth != frame.width || hud.frameHeight != frame.height) return Outcome.Refused("The picture size changed since the analysis. Analyse again.")
        ProfileEditing.widthProblem(p, frame.width)?.let { return Outcome.Refused(it) }
        val avoid = st.detections.values.mapNotNull { it.box } + listOfNotNull(st.minimap?.box, st.speedGuess?.box)
        val pick = pickDrivingMarker(hud, avoid) ?: return Outcome.Refused(
            "No part of the dashboard is steady enough to recognise the driving screen. Drive a little longer while observing, or use Advanced tools.",
        )
        val r = pick.box.toRect(frame.width, frame.height)
        if (r.width < 4 || r.height < 4) return Outcome.Refused("The steady element is too small to use.")
        val patch = frame.toGray().crop(r.x0, r.y0, r.x1, r.y1)
        val name = ProfileReadiness.HUD_MARKER
        val withTpl = ProfileEditing.withTemplate(p, name, ProfileEditing.searchRoi(pick.box), frame.width, frameHeight = frame.height)
        val rule = if (withTpl.templates.containsKey("parking_hud")) "$name, !parking_hud" else name
        val (p2, err) = ProfileEditing.withStateRule(withTpl, GameState.DRIVING, rule)
        if (err != null) return Outcome.Refused(err)
        return Outcome.Ok(p2, "Driving screen saved. It is recognised by a steady part of the dashboard.", name, patch)
    }

    // ---- minimap -------------------------------------------------------------------------------------------

    fun minimapFromSuggestion(p: GameProfile, m: MinimapSuggestion): Outcome {
        var out = ProfileEditing.withNavMinimap(p, m.box)
        val rgb = m.routeColorRgb
        if (rgb != null) {
            ProfileEditing.withRouteColor(out, ColorTarget((rgb shr 16) and 0xFF, (rgb shr 8) and 0xFF, rgb and 0xFF, 45))?.let { out = it }
        }
        return Outcome.Ok(out, "Minimap saved." + if (rgb != null) " A route colour was guessed; tap the route line to confirm it." else "")
    }

    /** A square minimap region of [heightFraction] of the picture height around the tap, kept inside the picture. */
    fun minimapAt(p: GameProfile, frame: Frame, x: Float, y: Float, heightFraction: Float = DEFAULT_MINIMAP_HEIGHT): Outcome {
        val h = heightFraction.coerceIn(0.1f, 0.6f)
        val w = (h * frame.height / frame.width).coerceIn(0.05f, 0.6f)
        val l = (x - w / 2).coerceIn(0f, 1f - w)
        val t = (y - h / 2).coerceIn(0f, 1f - h)
        return Outcome.Ok(ProfileEditing.withNavMinimap(p, Roi(l, t, l + w, t + h)), "Minimap area saved. Use Larger / Smaller if it does not cover the whole map.")
    }

    fun resizeMinimap(p: GameProfile, factor: Float): Outcome {
        val nav = p.nav ?: return Outcome.Refused("Set the minimap first.")
        val b = nav.minimapRoi
        val cx = (b.left + b.right) / 2
        val cy = (b.top + b.bottom) / 2
        val w = ((b.right - b.left) * factor).coerceIn(0.05f, 0.7f)
        val h = ((b.bottom - b.top) * factor).coerceIn(0.05f, 0.7f)
        val l = (cx - w / 2).coerceIn(0f, 1f - w)
        val t = (cy - h / 2).coerceIn(0f, 1f - h)
        return Outcome.Ok(p.copy(nav = nav.copy(minimapRoi = Roi(l, t, l + w, t + h))), "Minimap area resized.")
    }

    // ---- taps on the map ---------------------------------------------------------------------------------------

    /** Average colour of a small square around a tap (5 x 5 pixels at the processing resolution). */
    fun colorAt(frame: Frame, x: Float, y: Float, tolerance: Int = 45): ColorTarget {
        val px = (x * frame.width).toInt().coerceIn(0, frame.width - 1)
        val py = (y * frame.height).toInt().coerceIn(0, frame.height - 1)
        val x0 = max(0, px - 2); val x1 = min(frame.width, px + 3)
        val y0 = max(0, py - 2); val y1 = min(frame.height, py + 3)
        return ProfileEditing.averageColor(frame, Roi(x0.toFloat() / frame.width, y0.toFloat() / frame.height, x1.toFloat() / frame.width, y1.toFloat() / frame.height), tolerance)
    }

    /** Route lines and markers are saturated colours; grey or very dark taps are almost always the map background. */
    fun colourProblem(c: ColorTarget): String? {
        val hi = max(c.r, max(c.g, c.b))
        val lo = min(c.r, min(c.g, c.b))
        return when {
            hi < 60 -> "That spot is almost black. Tap exactly on the coloured line or marker (zoom the picture with two fingers if needed)."
            hi - lo < 40 -> "That spot is grey, not a colour. Tap exactly on the coloured line or marker."
            else -> null
        }
    }

    private fun inside(r: Roi, x: Float, y: Float) = x >= r.left && x <= r.right && y >= r.top && y <= r.bottom

    fun routeColor(p: GameProfile, frame: Frame, x: Float, y: Float): Outcome {
        val nav = p.nav ?: return Outcome.Refused("Set the minimap first.")
        if (!inside(nav.minimapRoi, x, y)) return Outcome.Refused("Tap inside the minimap (the box drawn on the picture).")
        val c = colorAt(frame, x, y)
        colourProblem(c)?.let { return Outcome.Refused(it) }
        val out = ProfileEditing.withRouteColor(p, c) ?: return Outcome.Refused("Set the minimap first.")
        return Outcome.Ok(out.copy(extras = out.extras + ("setup.route" to "1")), "Route colour saved.")
    }

    fun truckMarker(p: GameProfile, x: Float, y: Float): Outcome {
        val nav = p.nav ?: return Outcome.Refused("Set the minimap first.")
        if (!inside(nav.minimapRoi, x, y)) return Outcome.Refused("Tap inside the minimap (the box drawn on the picture).")
        val out = ProfileEditing.withTruckMarker(p, Point(x, y)) ?: return Outcome.Refused("Set the minimap first.")
        return Outcome.Ok(out.copy(extras = out.extras + ("setup.truck" to "1")), "Truck position saved.")
    }

    fun destination(p: GameProfile, frame: Frame, x: Float, y: Float): Outcome {
        val nav = p.nav ?: return Outcome.Refused("Set the minimap first.")
        if (!inside(nav.minimapRoi, x, y)) return Outcome.Refused("Tap the destination marker inside the minimap.")
        val c = colorAt(frame, x, y, 50)
        colourProblem(c)?.let { return Outcome.Refused(it) }
        if (abs(c.r - nav.routeColor.r) + abs(c.g - nav.routeColor.g) + abs(c.b - nav.routeColor.b) < 60) {
            return Outcome.Refused("That colour is the same as the route line, so it cannot mark the destination. Tap the destination icon itself.")
        }
        return Outcome.Ok(ProfileEditing.withColor(p, DESTINATION, nav.minimapRoi, c), "Destination marker colour saved.")
    }

    fun parkingZone(p: GameProfile, frame: Frame, x: Float, y: Float): Outcome {
        val c = colorAt(frame, x, y, 50)
        colourProblem(c)?.let { return Outcome.Refused(it) }
        return Outcome.Ok(ProfileEditing.withColor(p, PARKING_ZONE, Roi(0.05f, 0.05f, 0.95f, 0.95f), c), "Parking area colour saved.")
    }

    private fun overlaps(a: Roi, b: Roi): Boolean = a.left < b.right && b.left < a.right && a.top < b.bottom && b.top < a.bottom
}
