package dev.toe3autopilot.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import dev.toe3autopilot.app.AutopilotRuntime
import dev.toe3autopilot.core.calibration.CalibrationState
import dev.toe3autopilot.core.calibration.GuidedSetup
import dev.toe3autopilot.core.profile.GameProfile
import kotlinx.coroutines.launch

/**
 * Smart Setup, part 2: the screen and the map. Every step is a button press or a tap on the picture above; nobody has to
 * name a template or write a rule. [waiting] is the step currently waiting for a tap on the picture.
 */
@Composable
fun NavigationSetupPanel(
    profile: GameProfile?,
    st: CalibrationState,
    hasPicture: Boolean,
    busy: Boolean,
    waiting: GuidedSetup.Step?,
    onWait: (GuidedSetup.Step?) -> Unit,
    onMessage: (String) -> Unit,
) {
    val steps = GuidedSetup.status(profile, AutopilotRuntime.profileStore)
    val next = steps.firstOrNull { it.step.required && !it.done }?.step
    val doneRequired = steps.count { it.step.required && it.done }
    val totalRequired = steps.count { it.step.required }
    Panel(
        title = "Navigation and screen",
        subtitle = "$doneRequired of $totalRequired required steps done",
        trailing = { StatusChip(if (next == null) "Ready" else "To do", if (next == null) Tokens.Success else Tokens.Warning) },
    ) {
        MeterBar(doneRequired.toFloat() / totalRequired, if (next == null) Tokens.Success else Tokens.Accent)
        if (!hasPicture) {
            Body("These steps need a picture of the game. Observe live play, import a clip or pick screenshots first.")
        }
        steps.forEachIndexed { i, s ->
            if (i > 0) androidx.compose.material3.HorizontalDivider(color = Tokens.Border)
            Column(verticalArrangement = Arrangement.spacedBy(Dim.xs)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(
                        "${i + 1}. ${s.step.title}" + if (!s.step.required) " (optional)" else "",
                        Modifier.weight(1f),
                        style = MaterialTheme.typography.titleSmall,
                        color = Tokens.TextPrimary,
                    )
                    StatusChip(
                        when {
                            s.done -> "Done"
                            s.step == next -> "Next"
                            !s.step.required -> "Optional"
                            else -> "To do"
                        },
                        when {
                            s.done -> Tokens.Success
                            s.step == next -> Tokens.Primary
                            else -> Tokens.TextMuted
                        },
                    )
                }
                if (!s.done || waiting == s.step) Caption(s.step.instruction, color = Tokens.TextSecondary)
                if (waiting == s.step) {
                    Text("Tap the picture above now.", style = MaterialTheme.typography.titleSmall, color = Tokens.Primary)
                    AppButton("Cancel", { onWait(null) }, kind = ButtonKind.Ghost, minHeight = 40.dp)
                } else {
                    StepActions(s.step, s.done, st, hasPicture && !busy, profile, onWait, onMessage)
                }
            }
        }
        Caption("Steps 1–4 are needed before Start Auto Drive. The optional steps let the truck slow down and park at the delivery point.")
    }
}

@Composable
private fun StepActions(
    step: GuidedSetup.Step,
    done: Boolean,
    st: CalibrationState,
    enabled: Boolean,
    profile: GameProfile?,
    onWait: (GuidedSetup.Step?) -> Unit,
    onMessage: (String) -> Unit,
) {
    val ctl = AutopilotRuntime.calibration
    val again = if (done) "Redo" else null
    ButtonRow {
        when (step) {
            GuidedSetup.Step.DRIVING_SCREEN -> AppButton(
                again ?: "Use this picture as the driving screen",
                { AutopilotRuntime.ioScope.launch { onMessage(ctl.guided(step)) } },
                enabled = enabled && st.hud?.ok == true, minHeight = 40.dp,
                kind = if (done) ButtonKind.Secondary else ButtonKind.Primary,
            )
            GuidedSetup.Step.MINIMAP -> {
                if (st.minimap != null) {
                    AppButton(
                        "Use the minimap found", { onMessage(ctl.guided(step, x = -1f)) },
                        enabled = enabled, minHeight = 40.dp, kind = if (done) ButtonKind.Secondary else ButtonKind.Primary,
                    )
                }
                AppButton("Tap it on the picture", { onWait(step) }, enabled = enabled, minHeight = 40.dp, kind = ButtonKind.Secondary)
                if (profile?.nav != null) {
                    AppButton("Larger", { onMessage(ctl.guided(step, resize = 1.15f)) }, minHeight = 40.dp, kind = ButtonKind.Ghost)
                    AppButton("Smaller", { onMessage(ctl.guided(step, resize = 0.87f)) }, minHeight = 40.dp, kind = ButtonKind.Ghost)
                }
            }
            else -> AppButton(
                again ?: "Tap it on the picture", { onWait(step) },
                enabled = enabled && profile?.nav != null || (enabled && step == GuidedSetup.Step.PARKING_ZONE),
                minHeight = 40.dp, kind = if (done || !step.required) ButtonKind.Secondary else ButtonKind.Primary,
            )
        }
    }
    if (step == GuidedSetup.Step.DRIVING_SCREEN && st.hud?.ok != true && !done) {
        Caption("Available after the screen analysis (stage A) has found the fixed dashboard elements.")
    }
}
