package dev.toe3autopilot.core.profile

import dev.toe3autopilot.core.Control
import dev.toe3autopilot.core.state.GameState

/** One thing the person has to (or may) calibrate, and whether it is done. */
data class ChecklistItem(val title: String, val done: Boolean, val required: Boolean, val hint: String)

/**
 * The calibration to-do list shown on the Calibrate screen. [required] items are exactly the ones whose absence blocks
 * START AUTO DRIVE (see [ProfileReadiness.problems]); the optional ones each switch on one capability and the hint says which.
 */
object CalibrationChecklist {
    fun items(profile: GameProfile?, store: TemplateStore): List<ChecklistItem> {
        val p = profile ?: GameProfile.EMPTY
        fun hasControl(c: Control) = p.control(c) != null || p.templates.containsKey(c.buttonTemplate)
        fun templateUsable(n: String) = p.templates.containsKey(n) && store.gray(n) != null

        val drivingRule = p.stateRules[GameState.DRIVING]
        val drivingDone = !drivingRule.isNullOrEmpty() && drivingRule.all { templateUsable(it.removePrefix("!")) }
        val steeringDone = when (p.steeringMode) {
            SteeringMode.SLIDER -> hasControl(Control.STEER_CENTER)
            SteeringMode.BUTTONS -> hasControl(Control.STEER_LEFT) && hasControl(Control.STEER_RIGHT)
        }
        val hasZone = p.templates.containsKey("parking_zone") || p.colors.containsKey("parking_zone")
        val reverseOk = hasControl(Control.GEAR_REVERSE) || p.extra("parking.direction", "REVERSE").uppercase() == "FORWARD"

        return listOf(
            ChecklistItem(
                "Driving screen marker", drivingDone, true,
                "Smart Setup → Navigation and screen: show the normal driving view and press \"Use this picture as the driving screen\".",
            ),
            ChecklistItem(
                "Minimap, route colour and truck marker", p.nav != null, true,
                "Smart Setup → Navigation and screen: confirm the minimap, then tap the route line and your truck on it. The minimap must be heading-up (truck always points up).",
            ),
            ChecklistItem("Accelerator", hasControl(Control.ACCELERATOR), true, "Smart Setup: confirm the detected accelerator, demonstrate it, or tap it on the picture."),
            ChecklistItem("Brake", hasControl(Control.BRAKE), true, "Smart Setup: confirm the detected brake, demonstrate it, or tap it on the picture."),
            ChecklistItem("Steering", steeringDone, true, "Smart Setup: confirm or demonstrate steering left and right, or tap the controls on the picture."),
            ChecklistItem(
                "Delivery-area cue", p.templates.containsKey("destination_near") || p.colors.containsKey("destination_marker") || hasZone, false,
                "Without it the truck cannot tell it has arrived. Smart Setup: tap the destination marker on the minimap.",
            ),
            ChecklistItem("Parking area colour", hasZone, false, "Without it the truck stops near the delivery area and you park. Smart Setup: tap the highlighted parking area on a picture of the delivery point."),
            ChecklistItem("Reverse gear", reverseOk, false, "Needed for parking by reversing. Smart Setup: demonstrate reverse or tap it on the picture."),
            ChecklistItem(
                "Parked cue", p.templates.containsKey("parked_ok") || !p.stateRules[GameState.DELIVERY_COMPLETE].isNullOrEmpty(), false,
                "Without it the app cannot tell that parking worked. Available in Settings → Advanced tools.",
            ),
            ChecklistItem("Obstacle cue", p.templates.containsKey("obstacle_ahead"), false, "Without it the app cannot see vehicles or obstacles ahead. Available in Settings → Advanced tools."),
            ChecklistItem("Pop-up marker", !p.stateRules[GameState.UNEXPECTED_DIALOG].isNullOrEmpty(), false, "So the truck stops when a pop-up appears. Available in Settings → Advanced tools."),
        )
    }
}
