package dev.toe3autopilot.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import dev.toe3autopilot.app.AutopilotRuntime
import dev.toe3autopilot.core.calibration.CalibPhase
import dev.toe3autopilot.core.calibration.CalibrationState
import dev.toe3autopilot.core.calibration.CalibrationSummaries
import dev.toe3autopilot.core.calibration.ConfidenceLevel
import dev.toe3autopilot.core.status.AdviceAction
import dev.toe3autopilot.core.status.StatusAdvice
import dev.toe3autopilot.core.status.StatusInputs
import dev.toe3autopilot.core.profile.CalibrationChecklist
import dev.toe3autopilot.core.profile.ProfileReadiness
import dev.toe3autopilot.core.session.SessionSnapshot
import dev.toe3autopilot.core.session.SessionStatus
import dev.toe3autopilot.core.session.UserState
import dev.toe3autopilot.core.session.userState

fun stateColor(s: UserState): Color = when (s) {
    UserState.DRIVING, UserState.APPROACHING_TURN, UserState.APPROACHING_DELIVERY, UserState.PARKING -> Tokens.Success
    UserState.PARKED -> Tokens.Info
    UserState.NEEDS_ASSISTANCE -> Tokens.Warning
    UserState.EMERGENCY_STOP -> Tokens.Danger
    UserState.PAUSED -> Tokens.Info
    UserState.STARTING, UserState.READY, UserState.CALIBRATING -> Tokens.Accent
}

/** One sentence about what the automation is doing right now, from real state (never a canned demo value). */
fun describeState(state: UserState, snap: SessionSnapshot, cal: CalibrationState, armed: String?): String = when (state) {
    UserState.READY -> "Ready. In the game: accept a job, attach the trailer and drive to a safe starting position, then press START AUTO DRIVE."
    UserState.CALIBRATING -> cal.cue ?: cal.message
    UserState.STARTING -> armed ?: snap.task
    UserState.DRIVING -> snap.task
    UserState.APPROACHING_TURN -> "A turn or the end of the route is ahead: slowing down."
    UserState.APPROACHING_DELIVERY -> "Delivery area recognised: approaching slowly."
    UserState.PARKING -> "Parking with short, low-speed moves."
    UserState.PARKED -> "Parked. All driving inputs have stopped."
    UserState.PAUSED -> snap.recovery ?: "Paused. No inputs are being sent."
    UserState.NEEDS_ASSISTANCE -> snap.lastError ?: snap.task
    UserState.EMERGENCY_STOP -> "Emergency stop. All inputs were released and driving will not continue by itself."
}

@Composable
fun DashboardScreen(actions: Actions, nav: Navigator) {
    val snap by AutopilotRuntime.snapshot.collectAsState()
    val settings by AutopilotRuntime.settings.collectAsState()
    val capture by AutopilotRuntime.captureActive.collectAsState()
    val access by AutopilotRuntime.accessibilityConnected.collectAsState()
    val profile by AutopilotRuntime.profile.collectAsState()
    val profileError by AutopilotRuntime.profileError.collectAsState()
    val diagnosis by AutopilotRuntime.captureDiagnosis.collectAsState()
    val link by AutopilotRuntime.link.collectAsState()
    val endReason by AutopilotRuntime.captureEndReason.collectAsState()
    val armed by AutopilotRuntime.armedMessage.collectAsState()
    val cal by AutopilotRuntime.calibration.state.collectAsState()
    var startProblems by remember { mutableStateOf<List<String>>(emptyList()) }
    var pendingStart by remember { mutableStateOf(false) }

    val calibrating = cal.phase != CalibPhase.IDLE && cal.phase != CalibPhase.DONE
    val userState = snap.userState(calibrating).let { if (armed != null && snap.status == SessionStatus.IDLE) UserState.STARTING else it }
    val loopActive = snap.status.isActiveLoop
    val paused = snap.status == SessionStatus.PAUSED || snap.status == SessionStatus.NEEDS_ASSIST
    val color = stateColor(userState)

    fun begin() {
        startProblems = AutopilotRuntime.startDriving(actions.launchGame)
    }

    fun startPressed() {
        startProblems = emptyList()
        val early = AutopilotRuntime.prestartProblems()
        if (early.isNotEmpty()) {
            startProblems = early
        } else if (!capture) {
            pendingStart = true
            actions.connectCapture()
        } else {
            begin()
        }
    }

    val summary = CalibrationSummaries.controls(cal.detections, profile?.controls?.keys ?: emptySet())
    val advice = StatusAdvice.all(
        StatusInputs(snap, capture, diagnosis, endReason, access, settings.assistedMode, cal, summary, hasProfile = profile != null),
    )
    val onAdvice: (AdviceAction) -> Unit = { a ->
        when (a) {
            AdviceAction.TURN_ON_CAPTURE -> actions.connectCapture()
            AdviceAction.USE_RECORDED_CLIP -> nav.to(MainTab.Calibration, Sub.CAL_CLIP)
            AdviceAction.OPEN_CALIBRATION, AdviceAction.REVIEW_CONTROLS -> nav.to(MainTab.Calibration)
            AdviceAction.ENABLE_ACCESSIBILITY -> actions.openAccessibilitySettings()
            AdviceAction.RESUME -> startProblems = AutopilotRuntime.startDriving(actions.launchGame, resume = true)
            AdviceAction.START_DRIVE -> startPressed()
            AdviceAction.NONE -> {}
        }
    }

    // START without screen sharing: ask for it, then carry on by itself once it is granted.
    LaunchedEffect(capture, pendingStart) {
        if (pendingStart && capture) {
            pendingStart = false
            begin()
        }
    }

    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(horizontal = Dim.l, vertical = Dim.m),
        verticalArrangement = Arrangement.spacedBy(Dim.m),
    ) {
        // ---- main status + controls -----------------------------------------------------------------------------
        Panel(accent = color) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(Dim.s)) {
                StateDot(color, pulsing = loopActive || armed != null || calibrating)
                Text("AUTOMATION STATE", style = MaterialTheme.typography.labelMedium, color = Tokens.TextMuted)
            }
            Text(
                userState.label.uppercase(),
                Modifier.semantics { liveRegion = LiveRegionMode.Polite },
                style = MaterialTheme.typography.headlineMedium,
                color = color,
            )
            Body(describeState(userState, snap, cal, armed))
            if (loopActive) snap.road?.let { Caption(it) }
            snap.assistHint?.let { Text("Do this now: $it", style = MaterialTheme.typography.titleSmall, color = Tokens.TextPrimary) }

            AppButton(
                text = "START AUTO DRIVE",
                modifier = Modifier.fillMaxWidth(),
                minHeight = 60.dp,
                icon = IconKind.PLAY,
                enabled = !loopActive && !paused && armed == null && !calibrating,
                onClick = { startPressed() },
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(Dim.s)) {
                AppButton("Pause", { AutopilotRuntime.pause() }, Modifier.weight(1f), ButtonKind.Secondary, enabled = loopActive, icon = IconKind.PAUSE)
                AppButton(
                    "Resume", { startProblems = AutopilotRuntime.startDriving(actions.launchGame, resume = true) },
                    Modifier.weight(1f), ButtonKind.Secondary, enabled = paused, icon = IconKind.PLAY,
                )
            }
            AppButton(
                "EMERGENCY STOP", { AutopilotRuntime.emergencyStop("Emergency stop pressed in the app") },
                Modifier.fillMaxWidth(), ButtonKind.Danger, minHeight = 56.dp, icon = IconKind.STOP,
            )
            if (armed != null) AppButton("Cancel start", { AutopilotRuntime.cancelArmed() }, kind = ButtonKind.Ghost)
            if (loopActive || paused) AppButton("End drive and release screen capture", { AutopilotRuntime.stopSession() }, kind = ButtonKind.Ghost)
        }

        if (startProblems.isNotEmpty()) {
            val needsCalibration = startProblems.any { it.contains("calibrat", true) || it.contains("Template") || it.contains("Control ") || it.contains("minimap") }
            Banner(
                BannerKind.Error, "Cannot start yet", startProblems.take(4).joinToString("\n") { "• $it" },
                actionLabel = if (needsCalibration) "Open Smart Setup" else null,
                onAction = if (needsCalibration) ({ nav.to(MainTab.Calibration) }) else null,
            )
        }

        val options by AutopilotRuntime.options.collectAsState()
        if (!options.welcomeDismissed && !loopActive) {
            WelcomeCard(
                onSetup = { nav.to(MainTab.Calibration) },
                onDismiss = { AutopilotRuntime.updateOptions { it.copy(welcomeDismissed = true) } },
            )
        }

        // ---- what needs attention (every error / empty / waiting state, with one next step each) ------------------
        AdviceList(advice, onAdvice)

        // ---- driving status -------------------------------------------------------------------------------------
        Panel(title = "Driving status") {
            PhaseSteps(userState)
            Caption("The app only sees the screen. It cannot read hidden game state and cannot guarantee that parking succeeds.")
        }

        // ---- calibration ----------------------------------------------------------------------------------------
        CalibrationSummaryPanel(nav)

        // ---- screen capture -------------------------------------------------------------------------------------
        Panel(
            title = "Screen capture",
            trailing = { StatusChip(link.state.label, linkColor(link.state, link.receivingGame)) },
        ) {
            Body(link.detail, color = Tokens.TextPrimary)
            if (diagnosis.isProblem) {
                Body(diagnosis.title, color = Tokens.Warning)
            } else {
                Body(diagnosis.detail)
                if (!capture) endReason?.let { Caption("Last ended: $it") }
                if (capture && !loopActive && !paused) {
                    AppButton("Turn screen sharing off", actions.disconnectCapture, kind = ButtonKind.Ghost)
                } else if (!capture) {
                    AppButton("Turn screen sharing on", actions.connectCapture, kind = ButtonKind.Secondary)
                }
            }
        }

        // ---- readiness ------------------------------------------------------------------------------------------
        val problems = profile?.let { ProfileReadiness.problems(it, settings, AutopilotRuntime.profileStore) }
        Panel(title = "Before you start") {
            CheckRow("Calibrated for driving", profile != null && problems.isNullOrEmpty(), problems?.firstOrNull() ?: "No calibration profile yet")
            CheckRow(
                if (settings.assistedMode) "Accessibility service (not needed in Assisted mode)" else "Accessibility service enabled",
                access || settings.assistedMode, "Needed to send touches and to know when the game is in front",
            )
            CheckRow("Screen sharing", capture, "START will ask for it")
            if (!access && !settings.assistedMode) AppButton("Enable accessibility", actions.openAccessibilitySettings, kind = ButtonKind.Secondary)
            profileError?.let { Banner(BannerKind.Error, "Profile error", it) }
        }
        val advice = profile?.let { ProfileReadiness.advice(it, settings) }.orEmpty()
        if (profile != null && problems.isNullOrEmpty() && advice.isNotEmpty()) {
            Panel(title = "What this calibration cannot do") {
                advice.forEach { Body("• $it") }
            }
        }
        CreditFooter()
    }
}

/** Four steps: Driving, Approaching, Parking, Parked, with the current one lit. A turn ahead counts as Driving. */
@Composable
private fun PhaseSteps(state: UserState) {
    val steps = listOf("Driving", "Approaching", "Parking", "Parked")
    val current = when (state) {
        UserState.DRIVING, UserState.APPROACHING_TURN, UserState.STARTING -> 0
        UserState.APPROACHING_DELIVERY -> 1
        UserState.PARKING -> 2
        UserState.PARKED -> 3
        else -> -1
    }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(Dim.s)) {
        steps.forEachIndexed { i, label ->
            val done = current > i
            val here = current == i
            val c = when {
                here -> stateColor(state)
                done -> Tokens.Success
                else -> Tokens.TextMuted
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                MeterBar(if (done || here) 1f else 0f, c, height = 4.dp)
                Text(
                    label,
                    style = MaterialTheme.typography.labelMedium,
                    color = if (here) Tokens.TextPrimary else if (done) Tokens.TextSecondary else Tokens.TextMuted,
                    maxLines = 1,
                )
            }
        }
    }
}

@Composable
fun CalibrationSummaryPanel(nav: Navigator) {
    val cal by AutopilotRuntime.calibration.state.collectAsState()
    val profile by AutopilotRuntime.profile.collectAsState()
    val settings by AutopilotRuntime.settings.collectAsState()
    val saved = profile?.controls?.keys ?: emptySet()
    val summary = CalibrationSummaries.controls(cal.detections, saved)
    val problems = profile?.let { ProfileReadiness.problems(it, settings, AutopilotRuntime.profileStore) }
    val checklist = CalibrationChecklist.items(profile, AutopilotRuntime.profileStore).filter { it.required }
    val ready = profile != null && problems.isNullOrEmpty()
    Panel(
        title = "Calibration",
        trailing = { StatusChip(if (ready) "Ready" else "Needs work", if (ready) Tokens.Success else Tokens.Warning) },
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(Dim.s)) {
            Stat("Confirmed", summary.confirmed.toString(), Tokens.Success, Modifier.weight(1f))
            Stat("Uncertain", summary.uncertain.toString(), Tokens.Warning, Modifier.weight(1f))
            Stat("Missing", summary.missingRequired.toString(), if (summary.missingRequired == 0) Tokens.TextSecondary else Tokens.Danger, Modifier.weight(1f))
        }
        val avg = summary.averageConfidence
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Confidence", style = MaterialTheme.typography.bodyMedium, color = Tokens.TextSecondary)
            Text(summary.level.label, style = MaterialTheme.typography.labelLarge, color = Tokens.TextPrimary)
        }
        MeterBar(
            avg ?: 0f,
            when (summary.level) {
                ConfidenceLevel.HIGH -> Tokens.Success
                ConfidenceLevel.MEDIUM -> Tokens.Warning
                else -> Tokens.Danger
            },
        )
        Caption("${checklist.count { it.done }} of ${checklist.size} required calibration items done")
        if (cal.layoutUnstable) Banner(BannerKind.Warning, "The layout changed", cal.problem ?: "Calibration was paused. Verify it again.")
        AppButton("Open Smart Setup", { nav.to(MainTab.Calibration) }, Modifier.fillMaxWidth(), ButtonKind.Secondary, icon = IconKind.TARGET)
    }
}

@Composable
private fun Stat(label: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Column(
        modifier.padding(vertical = Dim.xs),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        Text(value, style = MaterialTheme.typography.headlineSmall, color = color)
        Text(label, style = MaterialTheme.typography.labelMedium, color = Tokens.TextSecondary)
    }
}
