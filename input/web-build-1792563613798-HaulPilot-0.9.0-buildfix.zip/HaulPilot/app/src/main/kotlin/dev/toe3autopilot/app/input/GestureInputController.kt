package dev.toe3autopilot.app.input

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import dev.toe3autopilot.app.AutopilotRuntime
import dev.toe3autopilot.core.Control
import dev.toe3autopilot.core.Point
import dev.toe3autopilot.core.session.GameMonitor
import dev.toe3autopilot.core.session.InputController
import dev.toe3autopilot.core.session.InputKind

/** Reports whether the configured game package is in front, using window-change events (package name only). */
class AccessibilityGameMonitor(private val gamePackage: () -> String) : GameMonitor {
    override fun isGameForeground(): Boolean? {
        if (AutopilotAccessibilityService.instance == null) return null
        val fg = AutopilotAccessibilityService.foregroundPackage ?: return null
        val pkg = gamePackage()
        if (pkg.isBlank()) return null
        return fg == pkg
    }
}

/**
 * Turns "hold these controls at these points" into AccessibilityService gestures.
 *
 * How holding works: a held control is a stroke that is dispatched in short segments (SEGMENT_MS) with
 * `willContinue = true`; when a segment completes the next one continues the same stroke, possibly toward a
 * new end point (that is how the steering slider is dragged). When the set of held controls changes, or on
 * release, the active strokes are first ended (a short final segment with `willContinue = false`) so the
 * touches are lifted deterministically, and only then are new strokes started. A new gesture would otherwise
 * cancel in-progress ones, which makes behaviour platform dependent.
 *
 * Consequences (documented limits, not hidden):
 *  - Releasing takes up to one segment (~SEGMENT_MS) to reach the screen; the safe-brake logic in the core
 *    accounts for this by braking for a window after any halt.
 *  - Changing which controls are held causes a brief lift of all of them.
 *  - Real-device continuity and latency of continued strokes are NOT verified here.
 *
 * All mutable state is touched only on the main thread; public methods just publish intent and post.
 */
class GestureInputController : InputController {
    override val kind: InputKind = InputKind.INJECTED

    private val main = Handler(Looper.getMainLooper())

    // Intent published by the session thread.
    @Volatile
    private var desired: Map<Control, Point> = emptyMap()
    private val pendingTaps = java.util.concurrent.ConcurrentLinkedQueue<Point>()

    // Main-thread state.
    private class Active(val stroke: GestureDescription.StrokeDescription, val endX: Float, val endY: Float)

    private var active: Map<Control, Active> = emptyMap()
    private var inFlight = false
    private var token = 0L
    private var failures = 0

    @Volatile
    private var healthy = true

    override val isReady: Boolean get() = AutopilotAccessibilityService.instance != null
    override val isHealthy: Boolean get() = healthy

    /** Call when a new session starts so an earlier failure streak does not block it. */
    fun resetHealth() {
        main.post {
            failures = 0
            healthy = true
        }
    }

    override fun setHolds(holds: Map<Control, Point>) {
        val next = holds.toMap()
        // Position-only changes are picked up at the next segment boundary; only key changes need an immediate kick.
        val keysChanged = next.keys != desired.keys
        desired = next
        if (keysChanged) main.post { reconcile() }
    }

    override fun tapAt(point: Point) {
        pendingTaps.add(point)
        main.post { reconcile() }
    }

    override fun releaseAll() {
        desired = emptyMap()
        pendingTaps.clear()
        main.post { reconcile() }
    }

    /** Forget all in-flight state (service went away: the system has already cancelled any touches). */
    fun onServiceGone() {
        main.post {
            active = emptyMap()
            inFlight = false
            token++
        }
    }

    // ---- main thread only below ----

    private fun reconcile() {
        val svc = AutopilotAccessibilityService.instance
        if (svc == null) {
            active = emptyMap()
            inFlight = false
            return
        }
        if (inFlight) return // the completion callback calls reconcile() again
        if (!healthy) {
            // Stop dispatching; make sure nothing stays held.
            if (active.isNotEmpty()) endActive(svc)
            return
        }
        val want = desired
        val taps = ArrayList<Point>()
        while (true) taps.add(pendingTaps.poll() ?: break)

        if (want.isEmpty() && taps.isEmpty()) {
            if (active.isNotEmpty()) endActive(svc)
            return
        }
        if (active.isNotEmpty() && (want.keys != active.keys || taps.isNotEmpty())) {
            // Lift the old strokes first; reconcile() runs again when that gesture completes.
            taps.forEach { pendingTaps.add(it) }
            endActive(svc)
            return
        }
        if (active.isNotEmpty()) continueActive(svc, want) else startFresh(svc, want, taps)
    }

    private fun px(p: Point, w: Int, h: Int): Pair<Float, Float> =
        (p.x * w).coerceIn(0f, (w - 1).toFloat()) to (p.y * h).coerceIn(0f, (h - 1).toFloat())

    private fun startFresh(svc: AccessibilityService, want: Map<Control, Point>, taps: List<Point>) {
        val (w, h) = AutopilotRuntime.realDisplaySize(svc)
        val b = GestureDescription.Builder()
        val next = HashMap<Control, Active>()
        var n = 0
        val maxStrokes = GestureDescription.getMaxStrokeCount()
        for (t in taps) {
            if (n >= maxStrokes) break
            val (x, y) = px(t, w, h)
            b.addStroke(GestureDescription.StrokeDescription(pointPath(x, y), 0, TAP_MS, false))
            n++
        }
        for ((c, p) in want) {
            if (n >= maxStrokes) break
            val (x, y) = px(p, w, h)
            val s = GestureDescription.StrokeDescription(pointPath(x, y), 0, SEGMENT_MS, true)
            b.addStroke(s)
            next[c] = Active(s, x, y)
            n++
        }
        if (n == 0) return
        dispatch(svc, b.build(), next)
    }

    private fun continueActive(svc: AccessibilityService, want: Map<Control, Point>) {
        val (w, h) = AutopilotRuntime.realDisplaySize(svc)
        val b = GestureDescription.Builder()
        val next = HashMap<Control, Active>()
        for ((c, a) in active) {
            val target = want[c] ?: continue
            val (x, y) = px(target, w, h)
            val path = Path().apply {
                moveTo(a.endX, a.endY)
                if (x != a.endX || y != a.endY) lineTo(x, y)
            }
            val s = a.stroke.continueStroke(path, 0, SEGMENT_MS, true)
            b.addStroke(s)
            next[c] = Active(s, x, y)
        }
        dispatch(svc, b.build(), next)
    }

    private fun endActive(svc: AccessibilityService) {
        val b = GestureDescription.Builder()
        for ((_, a) in active) {
            b.addStroke(a.stroke.continueStroke(pointPath(a.endX, a.endY), 0, END_MS, false))
        }
        dispatch(svc, b.build(), emptyMap())
    }

    private fun pointPath(x: Float, y: Float) = Path().apply { moveTo(x, y) }

    private fun dispatch(svc: AccessibilityService, g: GestureDescription, newActive: Map<Control, Active>) {
        val my = ++token
        inFlight = true
        val accepted = try {
            svc.dispatchGesture(
                g,
                object : AccessibilityService.GestureResultCallback() {
                    override fun onCompleted(gestureDescription: GestureDescription?) {
                        if (my != token) return
                        inFlight = false
                        active = newActive
                        failures = 0
                        reconcile()
                    }

                    override fun onCancelled(gestureDescription: GestureDescription?) {
                        if (my != token) return
                        // The system lifted our touches (user touched the screen, another gesture, ...).
                        inFlight = false
                        active = emptyMap()
                        failed()
                    }
                },
                main,
            )
        } catch (e: Exception) {
            false
        }
        if (!accepted) {
            inFlight = false
            active = emptyMap()
            failed()
        }
    }

    private fun failed() {
        failures++
        if (failures >= MAX_FAILURES) {
            healthy = false
            desired = emptyMap()
            AutopilotRuntime.noteInputFailure("Touch dispatch failed $failures times in a row")
        } else {
            reconcile()
        }
    }

    companion object {
        const val SEGMENT_MS = 250L
        const val TAP_MS = 60L
        const val END_MS = 10L
        const val MAX_FAILURES = 3
    }
}
