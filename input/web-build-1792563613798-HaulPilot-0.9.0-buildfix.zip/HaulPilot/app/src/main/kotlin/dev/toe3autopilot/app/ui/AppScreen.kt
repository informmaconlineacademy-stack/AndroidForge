package dev.toe3autopilot.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import dev.toe3autopilot.app.AutopilotRuntime
import dev.toe3autopilot.app.Brand
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import dev.toe3autopilot.core.session.SessionStatus

/** Things the UI asks the Activity to do (they need an Activity context or result launchers). */
class Actions(
    val connectCapture: () -> Unit,
    val disconnectCapture: () -> Unit,
    val openAccessibilitySettings: () -> Unit,
    val openAppDetails: () -> Unit,
    /** Brings the game to the front. False if it could not be opened. */
    val launchGame: () -> Boolean,
    val installedLaunchables: () -> List<Pair<String, String>>,
    val requestNotifications: () -> Unit,
    val openNotificationSettings: () -> Unit,
    val openBatterySettings: () -> Unit,
    val pickScreenshots: () -> Unit,
    /** Opens Android's system Photo Picker for a gameplay video (no storage permission needed). */
    val pickVideo: () -> Unit,
    /** Opens the Storage Access Framework file browser for a video, for when the Photo Picker does not show it. */
    val browseVideo: () -> Unit,
    val exportProfile: () -> Unit,
    val importProfile: () -> Unit,
)

/** Same actions with a different "open accessibility settings" (used to show the disclosure first). */
private fun Actions.withAccessibilityGate(open: () -> Unit) = Actions(
    connectCapture, disconnectCapture, open, openAppDetails, launchGame, installedLaunchables, requestNotifications,
    openNotificationSettings, openBatterySettings, pickScreenshots, pickVideo, browseVideo, exportProfile, importProfile,
)

@Composable
fun AppScreen(rawActions: Actions) {
    val options by AutopilotRuntime.options.collectAsState()
    var showDisclosure by rememberSaveable { mutableStateOf(false) }
    // Google Play requires an in-app disclosure with an explicit choice before the Accessibility service is switched on.
    val actions = remember(rawActions, options.accessibilityDisclosureAccepted) {
        if (options.accessibilityDisclosureAccepted) rawActions else rawActions.withAccessibilityGate { showDisclosure = true }
    }
    if (showDisclosure) {
        AccessibilityDisclosureDialog(
            onAccept = {
                showDisclosure = false
                AutopilotRuntime.updateOptions { it.copy(accessibilityDisclosureAccepted = true) }
                rawActions.openAccessibilitySettings()
            },
            onDecline = { showDisclosure = false },
        )
    }
    var tabIndex by rememberSaveable { mutableIntStateOf(0) }
    var calSource by rememberSaveable { mutableIntStateOf(Sub.CAL_LIVE) }
    var profileSub by rememberSaveable { mutableIntStateOf(Sub.PROFILE_OVERVIEW) }
    var settingsSub by rememberSaveable { mutableIntStateOf(Sub.SETTINGS_GENERAL) }
    val tab = MainTab.entries[tabIndex.coerceIn(0, MainTab.entries.size - 1)]

    val nav = Navigator { target, sub ->
        tabIndex = target.ordinal
        if (sub >= 0) {
            when (target) {
                MainTab.Calibration -> calSource = sub
                MainTab.Profiles -> profileSub = sub
                MainTab.Settings -> settingsSub = sub
                MainTab.Dashboard -> {}
            }
        }
    }

    Surface(Modifier.fillMaxSize(), color = Tokens.Bg) {
        Column(Modifier.safeDrawingPadding()) {
            Header(onSettings = { nav.to(MainTab.Settings, Sub.SETTINGS_GENERAL) }, onDiagnostics = { nav.to(MainTab.Settings, Sub.SETTINGS_DIAGNOSTICS) })
            RecordingBanner()
            Box(Modifier.weight(1f).fillMaxWidth()) {
                when (tab) {
                    MainTab.Dashboard -> DashboardScreen(actions, nav)
                    MainTab.Calibration -> AutoCalibrationScreen(actions, nav, calSource) { calSource = it }
                    MainTab.Profiles -> ProfilesScreen(actions, nav, profileSub) { profileSub = it }
                    MainTab.Settings -> SettingsScreen(actions, nav, settingsSub) { settingsSub = it }
                }
            }
            BottomBar(tab) { nav.to(it) }
        }
    }
}

@Composable
private fun Header(onSettings: () -> Unit, onDiagnostics: () -> Unit) {
    val capture by AutopilotRuntime.captureActive.collectAsState()
    val access by AutopilotRuntime.accessibilityConnected.collectAsState()
    val diagnosis by AutopilotRuntime.captureDiagnosis.collectAsState()
    val snap by AutopilotRuntime.snapshot.collectAsState()
    val running = snap.status.isActiveLoop || snap.status == SessionStatus.PAUSED || snap.status == SessionStatus.NEEDS_ASSIST

    Surface(color = Tokens.Surface, border = BorderStroke(1.dp, Tokens.Border)) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = Dim.l, vertical = Dim.s).heightIn(min = 48.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(Dim.s),
        ) {
            BrandMark(36.dp)
            Column(Modifier.weight(1f)) {
                Text(Brand.APP_NAME, style = MaterialTheme.typography.titleSmall, color = Tokens.TextPrimary, maxLines = 1)
                Row(horizontalArrangement = Arrangement.spacedBy(Dim.xs)) {
                    val link by AutopilotRuntime.link.collectAsState()
                    Box(Modifier.clickable(role = Role.Button, onClick = onDiagnostics)) {
                        StatusChip(link.state.label, linkColor(link.state, link.receivingGame))
                    }
                    StatusChip(if (access) "Touch on" else "Touch off", if (access) Tokens.Success else Tokens.TextMuted)
                }
            }
            if (running) {
                // Always reachable stop, on every screen.
                AppButton(
                    "STOP", { AutopilotRuntime.emergencyStop("Emergency stop pressed in the app") },
                    kind = ButtonKind.Danger, icon = IconKind.STOP, minHeight = 44.dp,
                )
            }
            Box(
                Modifier.size(48.dp)
                    .clickable(role = Role.Button, onClick = onSettings)
                    .semantics { contentDescription = "Settings" },
                contentAlignment = Alignment.Center,
            ) { AppIcon(IconKind.SETTINGS, Tokens.TextSecondary, 24.dp) }
        }
    }
}

@Composable
private fun BottomBar(selected: MainTab, onSelect: (MainTab) -> Unit) {
    NavigationBar(containerColor = Tokens.Surface, windowInsets = WindowInsets(0, 0, 0, 0)) {
        MainTab.entries.forEach { t ->
            val isSelected = t == selected
            NavigationBarItem(
                selected = isSelected,
                onClick = { onSelect(t) },
                icon = { AppIcon(t.icon, if (isSelected) Tokens.Accent else Tokens.TextSecondary, 24.dp) },
                label = { Text(t.label, style = MaterialTheme.typography.labelSmall, maxLines = 1) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Tokens.Accent,
                    selectedTextColor = Tokens.Accent,
                    indicatorColor = Tokens.Accent.copy(alpha = 0.14f),
                    unselectedIconColor = Tokens.TextSecondary,
                    unselectedTextColor = Tokens.TextSecondary,
                ),
            )
        }
    }
}

/** Shown on every screen while sample snapshots are being saved, with a one-tap stop. */
@Composable
private fun RecordingBanner() {
    val recording by AutopilotRuntime.recorder.recording.collectAsState()
    val items by AutopilotRuntime.recorder.items.collectAsState()
    if (!recording) return
    Row(
        Modifier.fillMaxWidth().background(Tokens.Danger.copy(alpha = 0.18f)).padding(horizontal = Dim.l, vertical = Dim.xs),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text("● Saving sample snapshots (${items.size} saved)", style = MaterialTheme.typography.labelLarge, color = Tokens.TextPrimary)
        AppButton("Stop saving", { AutopilotRuntime.recorder.stop() }, kind = ButtonKind.Secondary, minHeight = 40.dp)
    }
}
