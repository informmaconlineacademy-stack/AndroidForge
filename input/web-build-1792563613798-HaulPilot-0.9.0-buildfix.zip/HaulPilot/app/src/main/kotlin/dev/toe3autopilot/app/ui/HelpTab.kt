package dev.toe3autopilot.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier

@Composable
fun HelpTab(actions: Actions) {
    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(horizontal = Dim.l, vertical = Dim.s),
        verticalArrangement = Arrangement.spacedBy(Dim.m),
    ) {
        Panel(title = "What this app does") {
            Body(
                "It drives the truck from where you are to the delivery point and parks it, then stops and tells you. " +
                    "You do everything else yourself: choosing and accepting the job, attaching the trailer, unloading, detaching, payment and the next job.\n\n" +
                    "It works only from pictures of your screen (with your permission) and the screen taps Android's accessibility service sends for you. " +
                    "It cannot read hidden game data such as the real route, the destination position or collision information, and it does not guarantee that " +
                    "it will reach the destination or park successfully. It is not affiliated with the game.",
            )
        }
        Panel(title = "How it follows the road") {
            Body(
                "It follows the route line drawn on the game's navigation minimap, which must turn with the truck (heading-up). It steers toward the line and into bends, " +
                    "slows for bends and when the line gets short, and brakes if the line cannot be seen. It does not see lane markings, other vehicles or traffic lights " +
                    "unless you calibrate an \"obstacle ahead\" picture. If you switch the game to a different map style, recalibrate.",
            )
        }
        Panel(title = "Every drive") {
            Body(
                "1. In the game: accept the job, attach the trailer, drive to a safe starting position in the normal driving view.\n" +
                    "2. Open this app → Dashboard → Start Auto Drive (allow screen sharing the first time: choose the entire screen).\n" +
                    "3. The app opens the game, counts down 3 seconds and starts. A notification and a small floating button stay available; tap the button for Pause, Resume and Emergency Stop.\n" +
                    "4. When it is parked (or cannot go on) your phone vibrates and a notification says what to do. It never unloads, collects payment or picks a job.\n" +
                    "Tip: watch the first drives with your finger near EMERGENCY STOP.",
            )
        }
        Panel(title = "First-time setup") {
            Body(
                "1. Settings → General: choose the game. Settings → Permissions: enable the accessibility service (or use Assisted mode, which sends no touches).\n" +
                    "2. Open the game, then in HaulPilot → Smart Setup tap Connect (Android asks permission; choose Entire screen).\n" +
                    "3. In the game, tap the floating HaulPilot button → Auto-Calibrate and drive normally for about 15 seconds. Back in HaulPilot, answer the few checks (Yes or one tap) and tap Confirm.\n" +
                    "4. Try Assisted mode first: it shows what the app WOULD do without touching anything.",
            )
        }
        Panel(title = "Safety behaviour") {
            Body(
                "• EMERGENCY STOP (Dashboard, floating button panel, notification) lifts all touches, brakes and ends screen capture. After it, nothing moves until you START again.\n" +
                    "• No touches are sent until the driving screen is recognised. Unrecognised screens, pop-ups and crash screens make the truck brake and ask for you; the app never taps them.\n" +
                    "• If the route line is lost the truck slows, then stops and asks for you. If the truck does not move although throttle is applied it stops and asks for you; it never reverses blindly.\n" +
                    "• If the screen layout changes (rotation), screen sharing stops, the game leaves the front or the phone screen turns off, the truck brakes and the session pauses. It does not resume by itself.\n" +
                    "• If the parking area cannot be recognised it stops near the delivery area and asks you to finish parking.\n" +
                    "• Touching the screen yourself can interrupt injected gestures; press PAUSE first if you want to take over.",
            )
        }
        Panel(title = "Screen capture problems") {
            Body(
                "• The app tells you what it actually received: no permission, capture stopped by Android, a display or reader error, black pictures, or pictures that arrive but cannot be analysed.\n" +
                    "• \"The game may block capture\" is only said when this app's own screen arrives fine but the game stays black for several seconds. The app does not try to get around such a block.\n" +
                    "• Another screen recorder working does not mean this app receives the same pictures. In that case use Smart Setup → Recorded clip: import a gameplay video you recorded yourself. " +
                    "A clip is for finding the controls only. It never sends touches and says nothing about the truck right now.",
            )
        }
        Panel(title = "Troubleshooting") {
            Body(
                "• Stuck at Starting: the driving screen is not recognised; redo Smart Setup → Navigation and screen → Driving screen.\n" +
                    "• \"Lost track of the road\": the minimap route colour or area is wrong, or the minimap is not heading-up.\n" +
                    "• Touches do nothing: check the accessibility service is enabled and not restricted (Settings → Permissions).\n" +
                    "• The game did not come to the front: pick the game in Settings → General, or open it yourself and use Start Auto Drive on the floating button’s panel.\n" +
                    "• Play Protect warning on install: see the README; this app does not try to avoid it.",
            )
            AppButton("Accessibility settings", actions.openAccessibilitySettings, kind = ButtonKind.Secondary)
        }
    }
}
