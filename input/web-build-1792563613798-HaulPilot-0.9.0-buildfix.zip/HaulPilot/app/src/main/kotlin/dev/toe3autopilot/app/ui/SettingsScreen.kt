package dev.toe3autopilot.app.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import dev.toe3autopilot.app.AutopilotRuntime
import dev.toe3autopilot.core.AutomationSettings
import dev.toe3autopilot.core.session.LogLevel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Settings: game, permissions, driving limits, capture diagnostics, logs and help. */
@Composable
fun SettingsScreen(actions: Actions, nav: Navigator, sub: Int, onSub: (Int) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        ScreenTitle("Settings")
        Column(Modifier.padding(horizontal = Dim.l, vertical = Dim.s)) {
            SegmentRow(listOf("General", "Permissions", "Driving", "Diagnostics", "Logs", "Help", "About"), sub) { onSub(it) }
        }
        when (sub) {
            Sub.SETTINGS_PERMISSIONS -> ScrollPage { PermissionsCard(actions) }
            Sub.SETTINGS_DRIVING -> ScrollPage {
                val settings by AutopilotRuntime.settings.collectAsState()
                DriveSettingsCard(settings)
            }
            Sub.SETTINGS_DIAGNOSTICS -> DiagnosticsPage(actions, nav)
            Sub.SETTINGS_LOGS -> LogsTab()
            Sub.SETTINGS_HELP -> HelpTab(actions)
            Sub.SETTINGS_ABOUT -> AboutPage()
            else -> ScrollPage {
                GameCard(actions)
                BackgroundCard()
                AdvancedToolsCard()
                CreditFooter()
            }
        }
    }
}

@Composable
private fun AdvancedToolsCard() {
    val options by AutopilotRuntime.options.collectAsState()
    Panel(title = "Advanced tools") {
        Toggle("Show expert calibration editors", options.advancedTools) { v -> AutopilotRuntime.updateOptions { it.copy(advancedTools = v) } }
        Caption(
            "Not needed for normal use: Smart Setup does everything by tapping. The expert editors (template editor and profile text) " +
                "add extra screen cues such as a \"parked\" message, obstacles or pop-ups, and appear under Calibration Profiles.",
        )
    }
}

@Composable
private fun ScrollPage(content: @Composable () -> Unit) {
    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(horizontal = Dim.l, vertical = Dim.s),
        verticalArrangement = Arrangement.spacedBy(Dim.m),
    ) { content() }
}

@Composable
private fun GameCard(actions: Actions) {
    val pkg by AutopilotRuntime.gamePackage.collectAsState()
    var pkgText by remember { mutableStateOf(pkg) }
    var picker by remember { mutableStateOf(false) }
    LaunchedEffect(pkg) { pkgText = pkg }

    Panel(title = "Game") {
        Body(
            "The default package id is a guess and is NOT verified. Pick the installed game or type its package id. " +
                "The foreground check compares this id with the app in front.",
        )
        OutlinedTextField(
            value = pkgText, onValueChange = { pkgText = it }, label = { Text("Game package id") },
            singleLine = true, modifier = Modifier.fillMaxWidth(),
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(Dim.s)) {
            AppButton("Save", { AutopilotRuntime.setGamePackage(pkgText) }, Modifier.weight(1f))
            AppButton("Pick installed app", { picker = true }, Modifier.weight(1f), ButtonKind.Secondary)
        }
    }

    if (picker) {
        val apps = remember { actions.installedLaunchables() }
        AlertDialog(
            onDismissRequest = { picker = false },
            containerColor = Tokens.Surface,
            confirmButton = { AppButton("Close", { picker = false }, kind = ButtonKind.Ghost) },
            title = { Text("Installed apps", color = Tokens.TextPrimary) },
            text = {
                LazyColumn(Modifier.heightIn(max = 420.dp)) {
                    items(apps) { (label, p) ->
                        Column(
                            Modifier.fillMaxWidth().heightIn(min = Dim.minTouch).clickable {
                                pkgText = p
                                AutopilotRuntime.setGamePackage(p)
                                picker = false
                            }.padding(vertical = Dim.s),
                        ) {
                            Text(label, color = Tokens.TextPrimary)
                            Caption(p)
                        }
                    }
                }
            },
        )
    }
}

@Composable
fun DriveSettingsCard(s: AutomationSettings) {
    Panel(title = "Driving settings", subtitle = "Conservative defaults. Lower is safer.") {
        SliderRow("Cruise speed limit", "${(s.speedLevel * 100).toInt()}%", s.speedLevel, 0.1f..1f) { v -> AutopilotRuntime.updateSettings { it.copy(speedLevel = v) } }
        SliderRow("Speed near the delivery area", "${(s.approachSpeed * 100).toInt()}%", s.approachSpeed, 0.1f..0.5f) { v -> AutopilotRuntime.updateSettings { it.copy(approachSpeed = v) } }
        SliderRow("Steering sensitivity", "${"%.1f".format(s.sensitivity)}×", s.sensitivity, 0.5f..2f) { v -> AutopilotRuntime.updateSettings { it.copy(sensitivity = v) } }
        Toggle("Try to park at the delivery point (otherwise it stops near it and you park)", s.tryParking) { v -> AutopilotRuntime.updateSettings { it.copy(tryParking = v) } }
        Toggle("Assisted mode (send no touches; only show what to do)", s.assistedMode) { v -> AutopilotRuntime.updateSettings { it.copy(assistedMode = v) } }
        Caption("Speed and steering changes apply immediately; the input-mode switch applies at the next START.")
    }
}

@Composable
private fun SliderRow(label: String, value: String, v: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = Tokens.TextPrimary)
            Text(value, color = Tokens.Accent)
        }
        Slider(value = v, onValueChange = onChange, valueRange = range)
    }
}

@Composable
fun Toggle(label: String, value: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().heightIn(min = Dim.minTouch),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(label, Modifier.weight(1f).padding(end = Dim.s), color = Tokens.TextPrimary)
        Switch(checked = value, onCheckedChange = onChange)
    }
}

@Composable
private fun DiagnosticsPage(actions: Actions, nav: Navigator) {
    val diagnosis by AutopilotRuntime.captureDiagnosis.collectAsState()
    val capture by AutopilotRuntime.captureActive.collectAsState()
    val access by AutopilotRuntime.accessibilityConnected.collectAsState()
    val endReason by AutopilotRuntime.captureEndReason.collectAsState()
    var lines by remember { mutableStateOf(AutopilotRuntime.captureDiagnosticLines()) }
    ScrollPage {
        Panel(title = "Screen capture", trailing = { StatusChip(if (capture) "Connected" else "Off", if (capture) Tokens.Success else Tokens.TextMuted) }) {
            Banner(
                if (diagnosis.isProblem) BannerKind.Warning else BannerKind.Info,
                diagnosis.title, diagnosis.detail,
            )
            if (!capture) endReason?.let { Caption("Last ended: $it") }
            ButtonRow {
                if (capture) AppButton("Turn off", actions.disconnectCapture, kind = ButtonKind.Secondary)
                else AppButton("Turn on", actions.connectCapture, icon = IconKind.REFRESH)
                if (diagnosis.offerVideoCalibration) {
                    AppButton("Use a recorded clip", { nav.to(MainTab.Calibration, Sub.CAL_CLIP) }, kind = ButtonKind.Secondary, icon = IconKind.VIDEO)
                }
            }
            Caption(
                "This app only reports what it receives. It does not try to get around a game or Android blocking capture, " +
                    "and a screen recorder working does not mean this app receives the same pictures.",
            )
        }
        Panel(title = "Capture history", subtitle = "What this app saw, newest last") {
            if (lines.isEmpty()) Body("No capture events yet.") else lines.takeLast(30).forEach { Caption(it, color = Tokens.TextSecondary) }
            AppButton("Refresh", { lines = AutopilotRuntime.captureDiagnosticLines() }, kind = ButtonKind.Ghost)
        }
        RecordingCard(actions, capture, access)
    }
}

@Composable
fun LogsTab() {
    val logs by AutopilotRuntime.logs.collectAsState()
    val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)
    Column(Modifier.fillMaxSize().padding(horizontal = Dim.l, vertical = Dim.s), verticalArrangement = Arrangement.spacedBy(Dim.s)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Caption("States and actions only; screenshots are never stored. Newest first.", Modifier.weight(1f))
            AppButton("Clear", { AutopilotRuntime.clearLogs() }, kind = ButtonKind.Ghost)
        }
        if (logs.isEmpty()) EmptyState("No log entries yet", "Entries appear while you calibrate or drive.", icon = IconKind.CHECK)
        LazyColumn {
            items(logs.asReversed()) { e ->
                val color = when (e.level) {
                    LogLevel.ERROR -> Tokens.Danger
                    LogLevel.WARN -> Tokens.Warning
                    LogLevel.INFO -> Tokens.TextPrimary
                }
                Text(
                    "${fmt.format(Date(e.timeMs))} ${e.message}${if (e.repeat > 1) "  ×${e.repeat}" else ""}",
                    color = color,
                    style = androidx.compose.material3.MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(vertical = 2.dp),
                )
            }
        }
    }
}
