package dev.toe3autopilot.app.ui

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import dev.toe3autopilot.app.AutopilotRuntime
import dev.toe3autopilot.core.Point
import dev.toe3autopilot.core.calibration.AutoResult
import dev.toe3autopilot.core.calibration.CalibRole
import dev.toe3autopilot.core.calibration.DetectionStatus
import dev.toe3autopilot.core.calibration.Recovery
import dev.toe3autopilot.core.calibration.RunPhase
import dev.toe3autopilot.core.calibration.StageStatus
import dev.toe3autopilot.core.capture.LinkAction
import dev.toe3autopilot.core.capture.LinkState
import dev.toe3autopilot.core.vision.Frame
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Ticks once a second so "updated X s ago" stays true. */
@Composable
private fun nowEverySecond(): Long {
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            now = System.currentTimeMillis()
        }
    }
    return now
}

fun linkColor(s: LinkState, receivingGame: Boolean) = when (s) {
    LinkState.CONNECTED -> if (receivingGame) Tokens.Success else Tokens.Accent
    LinkState.WAITING_FOR_PERMISSION -> Tokens.Warning
    LinkState.NOT_CONNECTED -> Tokens.TextMuted
    LinkState.FAILED -> Tokens.Danger
}

/**
 * Step 1 of Smart Setup: is HaulPilot really receiving the game's picture? Shows the one honest status, why, the fix, and the
 * latest picture of the game, the same picture the calibration and the driving session use.
 */
@Composable
fun ScreenCard(actions: Actions, nav: Navigator) {
    val link by AutopilotRuntime.link.collectAsState()
    val frame by AutopilotRuntime.gameView.collectAsState()
    val game by AutopilotRuntime.gamePackage.collectAsState()
    val access by AutopilotRuntime.accessibilityConnected.collectAsState()
    val now = nowEverySecond()
    Panel(
        title = "1. Game screen",
        trailing = { StatusChip(link.state.label, linkColor(link.state, link.receivingGame)) },
    ) {
        Body(link.detail, color = Tokens.TextPrimary)
        when (link.action) {
            LinkAction.CONNECT, LinkAction.RETRY -> AppButton(link.actionLabel ?: "Connect screen", actions.connectCapture, Modifier.fillMaxWidth())
            LinkAction.OPEN_GAME -> AppButton("Open the game", { actions.launchGame() }, Modifier.fillMaxWidth(), ButtonKind.Secondary)
            LinkAction.CHOOSE_GAME, LinkAction.USE_GAME_IN_FRONT -> {
                AppButton("Choose the game", { nav.to(MainTab.Settings, Sub.SETTINGS_GENERAL) }, Modifier.fillMaxWidth(), ButtonKind.Secondary)
                Caption("Or open the game and tap \"This app is the game\" on the floating button.")
            }
            LinkAction.USE_CLIP -> AppButton(link.actionLabel ?: "Use a screenshot or clip instead", { nav.to(MainTab.Calibration, Sub.CAL_PICTURES) }, Modifier.fillMaxWidth(), ButtonKind.Secondary)
            LinkAction.NONE -> {}
        }
        if (!access) Caption("Tip: turn on the accessibility service (Settings → Permissions) so HaulPilot can tell the game apart from other apps.")
        Caption("Game: ${game.ifBlank { "not chosen" }}")
        val f = frame
        if (f == null) {
            EmptyState(
                "No picture of the game yet",
                "Open Truckers of Europe 3, connect the screen, then come back here. The latest picture of the game appears below.",
                icon = IconKind.VIDEO,
            )
        } else {
            GamePicture(f)
            val age = ((now - f.timestampMs) / 1000).coerceAtLeast(0)
            Caption(
                if (link.receivingGame && age <= 2) "Live picture of the game (the same picture HaulPilot analyses)."
                else "Last picture received from the game, $age s ago. HaulPilot is in front now, so the game is not being shown.",
            )
        }
    }
}

@Composable
private fun GamePicture(f: Frame) {
    val bmp: Bitmap = remember(f) { Bitmap.createBitmap(f.argb, f.width, f.height, Bitmap.Config.ARGB_8888) }
    Image(
        bmp.asImageBitmap(),
        contentDescription = "Latest captured picture of the game",
        contentScale = ContentScale.FillBounds,
        modifier = Modifier.fillMaxWidth().aspectRatio(f.width.toFloat() / f.height).clip(RoundedCornerShape(Dim.radiusControl)).background(Tokens.Raised),
    )
}

/**
 * Step 2: one-tap Auto-Calibrate. Shows the real stages, what is happening, a recovery when a stage fails, and the review with
 * the few checks that need the person.
 */
@Composable
fun AutoCalibrateCard(actions: Actions, nav: Navigator, onMoreOptions: () -> Unit) {
    val run by AutopilotRuntime.autoState.collectAsState()
    val link by AutopilotRuntime.link.collectAsState()
    val snap by AutopilotRuntime.snapshot.collectAsState()
    val sessionLive = snap.status.isActiveLoop
    Panel(title = "2. Auto-Calibrate", subtitle = "Finds the controls, the minimap and the driving screen for you") {
        when (run.phase) {
            RunPhase.IDLE, RunPhase.CANCELLED -> {
                Body(
                    "1. Open Truckers of Europe 3 with a job and the normal driving view.\n" +
                        "2. Connect the screen (above).\n" +
                        "3. Tap Auto-Calibrate, go to the game and drive normally for about 15 seconds. Press the accelerator and the brake once or twice.\n" +
                        "4. Come back, check the result and tap Confirm.",
                )
                AppButton(
                    "Auto-Calibrate",
                    { AutopilotRuntime.notice.value = AutopilotRuntime.startAutoCalibration(fromOverlay = false) },
                    Modifier.fillMaxWidth(), icon = IconKind.TARGET, minHeight = 56.dp, enabled = !sessionLive,
                )
                Caption("Easiest from the game itself: tap the floating HaulPilot button, then Auto-Calibrate.")
            }
            RunPhase.COLLECTING, RunPhase.ANALYSING -> {
                StageList(run.stages)
                MeterBar(run.collected.toFloat() / run.target.coerceAtLeast(1), Tokens.Accent, height = 8.dp)
                Caption("${run.collected} of ${run.target} pictures of the game collected. Only pictures of the game count.")
                if (run.phase == RunPhase.COLLECTING) {
                    if (!link.receivingGame) AppButton("Open the game and drive", { actions.launchGame() }, Modifier.fillMaxWidth())
                } else {
                    Body("Analysing the pictures…", color = Tokens.Accent)
                }
                AppButton("Cancel", { AutopilotRuntime.cancelAutoCalibration() }, Modifier.fillMaxWidth(), ButtonKind.Secondary)
            }
            RunPhase.FAILED -> {
                StageList(run.stages)
                Banner(BannerKind.Error, "Auto-Calibrate stopped", run.problem)
                val retry = { AutopilotRuntime.notice.value = AutopilotRuntime.startAutoCalibration(fromOverlay = false) }
                when (run.recovery) {
                    Recovery.CONNECT_SCREEN -> AppButton("Connect the screen", actions.connectCapture, Modifier.fillMaxWidth())
                    Recovery.OPEN_GAME -> AppButton("Open the game", { actions.launchGame() }, Modifier.fillMaxWidth())
                    Recovery.CHOOSE_GAME -> AppButton("Choose the game", { nav.to(MainTab.Settings, Sub.SETTINGS_GENERAL) }, Modifier.fillMaxWidth())
                    Recovery.USE_SCREENSHOT_OR_CLIP -> AppButton("Use a screenshot or clip instead", onMoreOptions, Modifier.fillMaxWidth())
                    else -> {}
                }
                AppButton("Try again", retry, Modifier.fillMaxWidth(), ButtonKind.Secondary, enabled = !sessionLive)
            }
            RunPhase.REVIEW -> {
                StageList(run.stages)
                run.result?.let { ReviewSection(it) }
            }
        }
    }
}

@Composable
private fun StageList(stages: List<dev.toe3autopilot.core.calibration.StageLine>) {
    Column(verticalArrangement = Arrangement.spacedBy(Dim.s)) {
        stages.forEach { s ->
            val c = when (s.status) {
                StageStatus.DONE -> Tokens.Success
                StageStatus.RUNNING -> Tokens.Accent
                StageStatus.NEEDS_YOU -> Tokens.Warning
                StageStatus.FAILED -> Tokens.Danger
                StageStatus.WAITING -> Tokens.TextMuted
            }
            Row(
                Modifier.fillMaxWidth().semantics { contentDescription = "${s.stage.title}: ${s.status.name.lowercase().replace('_', ' ')}. ${s.detail}" },
                horizontalArrangement = Arrangement.spacedBy(Dim.m),
                verticalAlignment = Alignment.Top,
            ) {
                Box(Modifier.padding(top = 5.dp).size(10.dp).clip(CircleShape).background(c))
                Column(Modifier.weight(1f)) {
                    Text(s.stage.title, style = MaterialTheme.typography.bodyMedium, color = if (s.status == StageStatus.WAITING) Tokens.TextMuted else Tokens.TextPrimary)
                    if (s.detail.isNotBlank()) Text(s.detail, style = MaterialTheme.typography.bodySmall, color = if (s.status == StageStatus.FAILED) Tokens.Danger else Tokens.TextSecondary)
                }
                Text(
                    when (s.status) {
                        StageStatus.DONE -> "Done"
                        StageStatus.RUNNING -> "Working"
                        StageStatus.NEEDS_YOU -> "Check"
                        StageStatus.FAILED -> "Failed"
                        StageStatus.WAITING -> ""
                    },
                    style = MaterialTheme.typography.labelMedium, color = c,
                )
            }
        }
    }
}

/**
 * The result on the picture, the few checks that need the person (each answered with Yes or one tap on the picture), and
 * Undo / Reset / Confirm. Confirm is only possible once accelerator, brake and steering are each confirmed or tapped.
 */
@Composable
private fun ReviewSection(res: AutoResult) {
    val ctl = AutopilotRuntime.calibration
    val st by ctl.state.collectAsState()
    val preview by ctl.preview.collectAsState()
    val canUndoEdit by ctl.canUndoEdit.collectAsState()
    var accepted by remember(res) { mutableStateOf(setOf<CalibRole>()) }
    var truckAccepted by remember(res) { mutableStateOf(false) }
    var truckAt by remember(res) { mutableStateOf<Point?>(null) }
    var tapping by remember(res) { mutableStateOf<CalibRole?>(null) }
    var tappingTruck by remember(res) { mutableStateOf(false) }
    var confirmReset by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }

    fun usable(r: CalibRole) = st.detections[r]?.status?.usable == true
    fun resolved(r: CalibRole) = usable(r) || r in accepted || (r in res.evidenceRoles && st.detections[r]?.status == DetectionStatus.NEEDS_CONFIRMATION)
    val required = listOf(CalibRole.ACCELERATOR, CalibRole.BRAKE, CalibRole.STEER_LEFT, CalibRole.STEER_RIGHT)
    val open = required.filter { !resolved(it) }

    Text("3. Check the result", style = MaterialTheme.typography.titleSmall, color = Tokens.TextPrimary)
    val prompt = tapping
    when {
        prompt != null -> Text("Tap the ${prompt.label.lowercase()} on the picture.", style = MaterialTheme.typography.titleSmall, color = Tokens.Primary)
        tappingTruck -> Text("Tap your truck on the minimap.", style = MaterialTheme.typography.titleSmall, color = Tokens.Primary)
    }
    val truckShown = truckAt ?: res.truckGuess
    CalibrationPreview(
        preview, st, placing = null, editing = null, tapPrompt = prompt != null || tappingTruck,
        marker = truckShown?.let { it.x to it.y },
    ) { x, y ->
        val r = tapping
        if (r != null) {
            AutopilotRuntime.notice.value = ctl.identify(r, x, y)
            tapping = null
        } else if (tappingTruck) {
            truckAt = Point(x, y)
            truckAccepted = true
            tappingTruck = false
        }
    }
    PreviewLegend()
    res.checks.forEach { Caption("✓ $it", color = Tokens.TextSecondary) }

    // Found from evidence: shown for information, confirmed together with Confirm.
    if (res.evidenceRoles.isNotEmpty()) {
        Body("Found from the pictures: " + res.evidenceRoles.joinToString { it.label } + ". Make sure the boxes sit on the right controls; tap Fix if one is wrong.")
        ButtonRow {
            res.evidenceRoles.forEach { r -> AppButton("Fix ${r.label.lowercase()}", { tapping = r; tappingTruck = false }, kind = ButtonKind.Ghost, minHeight = 40.dp) }
        }
    }
    // The smallest corrections: answer each with Yes or one tap.
    res.corrections.forEach { c ->
        HorizontalDivider(color = Tokens.Border)
        val r = c.role
        val done = if (r != null) resolved(r) else truckAccepted
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(Dim.s)) {
            Text(c.what, Modifier.weight(1f), style = MaterialTheme.typography.titleSmall, color = Tokens.TextPrimary)
            StatusChip(if (done) "Done" else "Check", if (done) Tokens.Success else Tokens.Warning)
        }
        Caption(c.ask, color = Tokens.TextSecondary)
        ButtonRow {
            if (r != null) {
                val isGuess = st.detections[r]?.status == DetectionStatus.NEEDS_CONFIRMATION
                if (isGuess && r !in accepted && !usable(r)) AppButton("Yes", { accepted = accepted + r }, minHeight = 40.dp)
                AppButton("Tap it on the picture", { tapping = r; tappingTruck = false }, kind = ButtonKind.Secondary, minHeight = 40.dp)
            } else if (c.what.startsWith("Truck")) {
                if (!truckAccepted) AppButton("Yes", { truckAccepted = true }, minHeight = 40.dp)
                AppButton("Tap my truck", { tappingTruck = true; tapping = null }, kind = ButtonKind.Secondary, minHeight = 40.dp)
            }
        }
        if (r == null && !c.what.startsWith("Truck")) Caption("You can finish this after Confirm, under More options \u2192 Navigation and screen.")
    }
    HorizontalDivider(color = Tokens.Border)
    if (open.isNotEmpty()) Caption("Still to check: " + open.joinToString { it.label }, color = Tokens.Warning)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(Dim.s)) {
        AppButton("Undo", { if (!ctl.undoEdit()) AutopilotRuntime.notice.value = "Nothing to undo." }, Modifier.weight(1f), ButtonKind.Secondary, enabled = canUndoEdit)
        AppButton("Reset", { confirmReset = true }, Modifier.weight(1f), ButtonKind.Ghost)
    }
    AppButton(
        if (busy) "Saving…" else "Confirm",
        {
            busy = true
            val acc = accepted
            val truck = if (truckAccepted) (truckAt ?: res.truckGuess) else null
            AutopilotRuntime.ioScope.launch {
                val summary = ctl.confirmAuto(res, acc, truck)
                AutopilotRuntime.notice.value = "Auto-Calibrate saved.\n$summary\nNext: try a short drive in Assisted mode first."
                AutopilotRuntime.resetAutoCalibration()
                busy = false
            }
        },
        Modifier.fillMaxWidth(), minHeight = 56.dp, enabled = open.isEmpty() && !busy,
    )
    Caption("Nothing is used for driving until you tap Confirm. Live driving still needs live screen capture and the accessibility service.")
    if (confirmReset) {
        ConfirmDialog(
            "Start over?", "The result of this Auto-Calibrate run and the learned calibration are cleared. Your saved profile is not changed.", "Start over",
            onDismiss = { confirmReset = false },
        ) {
            confirmReset = false
            AutopilotRuntime.resetAutoCalibration()
            ctl.resetLearned()
        }
    }
}
