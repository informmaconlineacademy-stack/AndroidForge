package dev.toe3autopilot.core.calibration

import dev.toe3autopilot.core.Point
import dev.toe3autopilot.core.profile.GameProfile
import dev.toe3autopilot.core.profile.ProfileEditing
import dev.toe3autopilot.core.profile.SteeringMode
import dev.toe3autopilot.core.profile.TemplateSpec
import dev.toe3autopilot.core.vision.GrayImage
import dev.toe3autopilot.core.vision.Roi
import java.util.Locale

/**
 * Copies calibration results into a [GameProfile]. The safety rule lives here: **only detections whose status is
 * usable (user-confirmed, or auto-confirmed from a clear demonstration) are copied.** Everything else is left
 * out and reported, so an uncertain visual detection can never become a control the automation presses.
 */
object CalibrationApply {
    data class Result(
        val profile: GameProfile?,
        /** Template images to store, keyed by template name (`ctl_<role>`). */
        val patches: Map<String, GrayImage>,
        val applied: List<String>,
        val skipped: List<String>,
        val problem: String?,
    )

    fun apply(
        base: GameProfile,
        detections: Map<CalibRole, ControlDetection>,
        patches: Map<CalibRole, GrayImage>,
        layout: LayoutSignature,
        timing: TimingEstimate?,
        applyTiming: Boolean,
    ): Result {
        ProfileEditing.widthProblem(base, layout.width)?.let { return Result(null, emptyMap(), emptyList(), emptyList(), it) }

        val applied = ArrayList<String>()
        val skipped = ArrayList<String>()
        var p = base.copy(
            referenceWidth = layout.width,
            extras = base.extras + (LayoutCheck.HEIGHT_KEY to layout.height.toString()),
        )
        val newPatches = LinkedHashMap<String, GrayImage>()

        for ((role, d) in detections) {
            if (!d.status.usable) {
                if (d.status != DetectionStatus.NONE) skipped += "${role.label}: ${d.status.name.lowercase().replace('_', ' ')} (not used)"
                continue
            }
            val pt = Point(d.x.coerceIn(0f, 1f), d.y.coerceIn(0f, 1f))
            val c = role.control
            p = if (c != null) {
                p.copy(controls = p.controls + (c to pt))
            } else {
                p.copy(extras = p.extras + ("calib." + role.name.lowercase() to "${fmt(pt.x)},${fmt(pt.y)}"))
            }
            applied += "${role.label} at (${fmt(pt.x)}, ${fmt(pt.y)})"

            patches[role]?.let { img ->
                val name = LayoutCheck.patchName(role)
                newPatches[name] = img
                val hx = img.width / 2f / layout.width + 0.06f
                val hy = img.height / 2f / layout.height + 0.06f
                val roi = Roi(
                    (pt.x - hx).coerceAtLeast(0f), (pt.y - hy).coerceAtLeast(0f),
                    (pt.x + hx).coerceAtMost(1f), (pt.y + hy).coerceAtMost(1f),
                )
                p = p.copy(templates = p.templates + (name to TemplateSpec(name, roi, 0.7f)))
            }
        }

        // Steering style follows what the user confirmed.
        val wheel = detections[CalibRole.STEER_WHEEL]?.status?.usable == true
        val left = detections[CalibRole.STEER_LEFT]?.status?.usable == true
        val right = detections[CalibRole.STEER_RIGHT]?.status?.usable == true
        when {
            wheel && !(left && right) -> {
                p = p.copy(steeringMode = SteeringMode.SLIDER)
                applied += "Steering style: wheel/slider"
            }
            left && right && !wheel -> {
                p = p.copy(steeringMode = SteeringMode.BUTTONS)
                applied += "Steering style: left/right buttons"
            }
            wheel && left && right -> skipped += "Steering: both a wheel and left/right buttons were confirmed; style left unchanged"
            left != right -> skipped += "Steering: only one of left/right was confirmed; style left unchanged"
        }

        if (applyTiming && timing != null) {
            var extras = p.extras
            timing.stoppedThreshold?.let {
                extras = extras + ("motion.stopped" to String.format(Locale.ROOT, "%.4f", it))
                applied += "Stopped-motion threshold ${String.format(Locale.ROOT, "%.4f", it)}"
            }
            timing.suggestedSettleMs?.let { ms ->
                if (!extras.containsKey("parking.settleMs")) extras = extras + ("parking.settleMs" to ms.toString())
                applied += "Settle time ${ms} ms (only where you had not set one)"
            }
            p = p.copy(extras = extras)
        }
        return Result(p, newPatches, applied, skipped, null)
    }

    private fun fmt(v: Float) = String.format(Locale.ROOT, "%.3f", v)
}
