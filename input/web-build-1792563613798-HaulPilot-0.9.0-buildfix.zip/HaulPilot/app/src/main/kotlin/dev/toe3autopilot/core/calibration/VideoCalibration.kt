package dev.toe3autopilot.core.calibration

import dev.toe3autopilot.core.capture.FrameClass
import dev.toe3autopilot.core.capture.FrameStats
import dev.toe3autopilot.core.vision.Frame
import dev.toe3autopilot.core.vision.Roi
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/*
 * Calibration from a recorded gameplay clip.
 *
 * SAFETY CONTRACT: everything here is analysis of pictures. Nothing in this file (or anything that calls it) can send a
 * touch, and the result says nothing about the state of the truck now: a clip shows how the interface looked
 * when it was recorded, not that the truck is currently in that state.
 */

/** What the platform's media metadata said about the file, before any frame is decoded. */
data class VideoInfo(
    val durationMs: Long,
    val width: Int,
    val height: Int,
    val rotationDegrees: Int = 0,
    val hasVideoTrack: Boolean = true,
)

/** Chooses which moments of a clip to decode. Decoding every frame of a 30 fps clip would be 300 frames of waste. */
object VideoSamplePlan {
    const val TARGET_FRAMES = 40
    const val MAX_FRAMES = 60
    const val MIN_SPACING_MS = 120L

    /** Longest stretch analysed; longer clips use their middle part. */
    const val MAX_SPAN_MS = 30_000L

    fun timestampsMs(durationMs: Long): List<Long> {
        if (durationMs <= 0L) return emptyList()
        val span = min(durationMs, MAX_SPAN_MS)
        val start = (durationMs - span) / 2
        val count = min(min(MAX_FRAMES.toLong(), TARGET_FRAMES.toLong()), max(1L, span / MIN_SPACING_MS)).toInt()
        val spacing = span.toDouble() / count
        return List(count) { i -> start + (spacing * i + spacing / 2).toLong() }
    }
}

data class VideoReport(
    val usable: Boolean,
    /** Reasons the clip cannot be used (each ends the process). */
    val problems: List<String>,
    /** Things that lower the quality of the result. */
    val warnings: List<String>,
    val framesRequested: Int,
    val framesDecoded: Int,
    val blackFrames: Int,
) {
    /** What to record instead, in plain words. Empty when the clip is fine. */
    fun advice(): List<String> = if (usable) emptyList() else listOf(
        "Record about 10 seconds of normal driving with the driving screen visible: accelerator, brake, steering controls and the minimap on screen.",
        "Drive or turn the camera so the scenery moves, and press the accelerator and the brake at least once each.",
        "If the clip keeps failing, place the controls by hand on the Calibrate tab.",
    )
}

object VideoValidator {
    const val MIN_DURATION_MS = 3_000L
    const val RECOMMENDED_MAX_MS = 30_000L
    const val MAX_DURATION_MS = 10 * 60_000L
    private const val BLACK_SHARE_LIMIT = 0.5f

    /** Checks done before any frame is decoded. Problems here mean there is no point decoding. */
    fun checkInfo(info: VideoInfo): VideoReport {
        val problems = ArrayList<String>()
        val warnings = ArrayList<String>()
        if (!info.hasVideoTrack) problems += "The file has no video track."
        if (info.width <= 0 || info.height <= 0) problems += "The video size could not be read."
        if (info.durationMs < MIN_DURATION_MS) problems += "The clip is only ${info.durationMs / 1000.0} s long; at least ${MIN_DURATION_MS / 1000} s is needed to see anything move."
        if (info.durationMs > MAX_DURATION_MS) problems += "The clip is longer than ${MAX_DURATION_MS / 60_000} minutes; trim it to about 10 seconds first."
        else if (info.durationMs > RECOMMENDED_MAX_MS) warnings += "Only the middle ${RECOMMENDED_MAX_MS / 1000} seconds of this ${info.durationMs / 1000} s clip will be analysed."
        if (min(info.width, info.height) in 1..239) warnings += "The video is small (${info.width}x${info.height}); small controls may be missed."
        return VideoReport(problems.isEmpty(), problems, warnings, 0, 0, 0)
    }

    /**
     * Checks the decoded frames. [requested] is how many moments were asked for; [decoded] holds those that came back.
     */
    fun checkFrames(info: VideoInfo, requested: Int, decoded: List<Frame>): VideoReport {
        val problems = ArrayList<String>()
        val warnings = ArrayList<String>()
        if (decoded.size < HudAnalyzer.MIN_FRAMES) {
            problems += "Only ${decoded.size} of $requested pictures could be read from the video (at least ${HudAnalyzer.MIN_FRAMES} are needed). The file may be damaged, use an unsupported codec, or be unreadable."
        } else if (decoded.size < requested * 0.7) {
            warnings += "Only ${decoded.size} of $requested pictures could be read; the result may be less reliable."
        }
        var black = 0
        for (f in decoded) {
            val c = FrameStats.of(f).classify()
            if (c == FrameClass.ALL_BLACK || c == FrameClass.SOLID_COLOUR || c == FrameClass.PARTLY_BLACK) black++
        }
        if (decoded.isNotEmpty() && black.toFloat() / decoded.size >= BLACK_SHARE_LIMIT) {
            problems += "The video itself is mostly black or blank ($black of ${decoded.size} pictures). It may have been recorded from a protected view or the game was not showing."
        } else if (black > 0) {
            warnings += "$black of ${decoded.size} pictures were black or blank and were ignored."
        }
        val sizes = decoded.map { it.width to it.height }.toSet()
        if (sizes.size > 1) problems += "The pictures have different sizes; the clip changed resolution or orientation."
        return VideoReport(problems.isEmpty(), problems, warnings, requested, decoded.size, black)
    }

    /** Frames that are not black/blank (these are the ones analysed). */
    fun usableFrames(decoded: List<Frame>): List<Frame> = decoded.filter {
        val c = FrameStats.of(it).classify()
        c != FrameClass.ALL_BLACK && c != FrameClass.SOLID_COLOUR
    }
}

data class VideoCalibrationResult(
    val report: VideoReport,
    val hud: HudAnalysis?,
    val layout: LayoutSignature?,
    /** One entry per demonstrable control. Status is NEEDS_CONFIRMATION or NONE, never usable by itself. */
    val detections: Map<CalibRole, ControlDetection>,
    val minimap: MinimapSuggestion?,
    /** What the clip did not contain, in plain words (for the "ask for a better clip" message). */
    val missing: List<String>,
    /** Index (into the analysed frames) of the picture to draw the preview on. */
    val previewIndex: Int,
) {
    val hasCandidates: Boolean get() = detections.values.any { it.status == DetectionStatus.NEEDS_CONFIRMATION }
}

/**
 * Finds control candidates in a clip of ~10 s of driving.
 *
 *  1. [HudAnalyzer] finds elements that stay put while the scenery moves.
 *  2. For each element the average brightness over time is split into two levels. An element that spends 10-60% of the
 *     clip in a distinct second level, with few switches, behaves like a button with a pressed state. Fast flicker (a speed
 *     read-out) is rejected.
 *  3. A pressed state that goes with the scenery speeding up supports "accelerator"; one that goes with the scenery
 *     slowing supports "brake". Without that link the element stays a weak candidate.
 *
 * Everything found is NEEDS_CONFIRMATION with confidence at most [ControlDetection.VIDEO_MAX_CONFIDENCE]. Steering and
 * reverse cannot be told from a clip that does not show them being used, so they are only offered as position guesses.
 */
object VideoCalibrationAnalyzer {
    private val worldRoi = Roi(0.2f, 0.25f, 0.8f, 0.7f)

    fun analyse(info: VideoInfo, requested: Int, decoded: List<Frame>): VideoCalibrationResult {
        val report = VideoValidator.checkFrames(info, requested, decoded)
        if (!report.usable) return unusable(report)
        val frames = VideoValidator.usableFrames(decoded)
        if (frames.size < HudAnalyzer.MIN_FRAMES) {
            return unusable(report.copy(usable = false, problems = report.problems + "Too few usable pictures remain after ignoring black ones (${frames.size})."))
        }
        val hud = HudAnalyzer.analyse(frames)
        val layout = LayoutSignature(frames.first().width, frames.first().height)
        if (!hud.ok) {
            val why = hud.problem ?: "no fixed on-screen elements found"
            val missing = listOf(
                "No fixed buttons could be separated from the scenery: $why",
                "A clip where the truck is moving (or the camera turning) and the driving controls are visible is needed.",
            )
            return VideoCalibrationResult(
                report.copy(usable = false, problems = report.problems + why), hud, layout,
                CalibRole.entries.filter { it.demonstrable }.associateWith { ControlDetection.none(it, why) }.mapValues { it.value.asVideo() },
                null, missing, frames.lastIndex,
            )
        }

        val n = frames.size
        val grays = frames.map { it.toGray() }
        val motion = sceneMotion(grays)
        val traces = hud.elements.mapNotNull { trace(it, grays, n) }

        val detections = LinkedHashMap<CalibRole, ControlDetection>()
        val used = HashSet<HudElement>()

        // Accelerator: pressed state that goes with the scenery speeding up.
        val acc = traces
            .filter { it.element.cy >= 0.4f }
            .map { it to it.link(motion, accelerating = true) }
            .filter { it.second > 0f }
            .maxByOrNull { it.second }
        detections[CalibRole.ACCELERATOR] = if (acc != null && acc.second >= MIN_LINK) {
            used += acc.first.element
            candidate(CalibRole.ACCELERATOR, acc.first, acc.second, "its look changed in ${pct(acc.first.minorityShare)}% of the clip and the scenery moved faster at those times")
        } else {
            weakOrNone(CalibRole.ACCELERATOR, traces, motion, accelerating = true, used, hud)
        }
        val brake = traces
            .filter { it.element.cy >= 0.4f && it.element !in used }
            .map { it to it.link(motion, accelerating = false) }
            .filter { it.second > 0f }
            .maxByOrNull { it.second }
        detections[CalibRole.BRAKE] = if (brake != null && brake.second >= MIN_LINK) {
            used += brake.first.element
            candidate(CalibRole.BRAKE, brake.first, brake.second, "its look changed in ${pct(brake.first.minorityShare)}% of the clip and the scenery slowed at those times")
        } else {
            weakOrNone(CalibRole.BRAKE, traces, motion, accelerating = false, used, hud)
        }
        for (role in listOf(CalibRole.STEER_LEFT, CalibRole.STEER_RIGHT)) {
            val g = CalibrationGuesses.positionGuesses(role, hud).firstOrNull { c -> used.none { it.cx == c.x && it.cy == c.y } }
            detections[role] = if (g != null) {
                ControlDetection(
                    role, g.x, g.y, g.box, g.score, DetectionStatus.NEEDS_CONFIRMATION, DetectionSource.PRIOR,
                    listOf("position guess from typical layouts; the clip does not show steering being used, so this is NOT verified"),
                )
            } else {
                ControlDetection.none(role, "no fixed element in the lower corner and the clip does not show it being used").asVideo()
            }
        }
        detections[CalibRole.GEAR_REVERSE] = ControlDetection.none(
            CalibRole.GEAR_REVERSE, "reverse is rarely used in a short driving clip; place it by hand",
        ).asVideo()

        val minimapCand = CalibrationGuesses.minimapCandidate(hud)
        val minimap = minimapCand?.let { c ->
            val colour = CalibrationGuesses.routeColorGuess(frames.last(), c.box)
            MinimapSuggestion(c.box, colour, "A corner element of map-like size. A guess from the clip; confirm it on the Calibrate tab.")
        }

        val missing = ArrayList<String>()
        if (detections[CalibRole.ACCELERATOR]!!.status == DetectionStatus.NONE) {
            missing += "No control that visibly reacts while the scenery speeds up was seen. Press the accelerator at least once in the clip."
        }
        if (detections[CalibRole.BRAKE]!!.status == DetectionStatus.NONE) {
            missing += "No control that visibly reacts while the scenery slows was seen. Press the brake at least once in the clip."
        }
        if (minimap == null) missing += "No minimap-like element was seen. Show the minimap in the clip, or mark it by hand."
        if (hud.sceneChange < 0.08f) missing += "The scenery moved very little; a clip with more movement gives stronger evidence."

        return VideoCalibrationResult(report, hud, layout, detections, minimap, missing, frames.lastIndex)
    }

    // ---- internals -------------------------------------------------------------------------------------

    private const val MIN_LINK = 0.35f

    private class Trace(
        val element: HudElement,
        /** True in frames belonging to the minority brightness level (assumed "pressed"). */
        val minority: BooleanArray,
        val minorityShare: Float,
        val separation: Float,
    ) {
        /**
         * Correlation between the pressed indicator and the scenery getting faster (or slower). Positive = supports the role.
         * motion[k] is the change between frame k-1 and k; the pressed indicator may lead or equal it by one frame.
         */
        fun link(motion: FloatArray, accelerating: Boolean): Float {
            val n = minority.size
            val signal = FloatArray(n - 1)
            for (k in 1 until n) {
                signal[k - 1] = if (accelerating) motion[k] else -(motion[k] - motion[k - 1].coerceAtLeast(0f))
            }
            var best = -1f
            for (lag in 0..1) {
                val xs = FloatArray(n - 1) { i -> if (minority[(i + 1 - lag).coerceAtLeast(0)]) 1f else 0f }
                best = max(best, corr(xs, signal))
            }
            return best
        }
    }

    /** Scalar summary of an element over time, split into two levels; null when it does not behave like a pressable button. */
    private fun trace(e: HudElement, grays: List<dev.toe3autopilot.core.vision.GrayImage>, n: Int): Trace? {
        val w = grays.first().width
        val h = grays.first().height
        val r = e.box.toRect(w, h)
        val s = FloatArray(n)
        for (k in 0 until n) {
            var sum = 0L
            val px = grays[k].px
            for (y in r.y0 until r.y1) for (x in r.x0 until r.x1) sum += px[y * w + x]
            s[k] = sum.toFloat() / ((r.x1 - r.x0) * (r.y1 - r.y0))
        }
        // Two-level split (1-D 2-means).
        var lo = s.min()
        var hi = s.max()
        if (hi - lo < MIN_SEPARATION) return null
        repeat(10) {
            var sl = 0f; var cl = 0; var sh = 0f; var ch = 0
            for (v in s) if (abs(v - lo) <= abs(v - hi)) { sl += v; cl++ } else { sh += v; ch++ }
            if (cl > 0) lo = sl / cl
            if (ch > 0) hi = sh / ch
        }
        val isHigh = BooleanArray(n) { abs(s[it] - hi) < abs(s[it] - lo) }
        val highCount = isHigh.count { it }
        val minorityIsHigh = highCount <= n - highCount
        val minority = BooleanArray(n) { isHigh[it] == minorityIsHigh }
        val share = minority.count { it }.toFloat() / n
        val sep = abs(hi - lo)
        var spread = 0f; var cnt = 0
        for (k in 0 until n) { val c = if (isHigh[k]) hi else lo; spread += (s[k] - c) * (s[k] - c); cnt++ }
        val noise = sqrt(spread / cnt)
        var switches = 0
        for (k in 1 until n) if (minority[k] != minority[k - 1]) switches++
        if (sep < max(MIN_SEPARATION, 3f * noise)) return null
        if (share < 0.08f || share > 0.6f) return null
        if (switches > n / 3) return null // flicker, for example a speed read-out
        return Trace(e, minority, share, sep)
    }

    private const val MIN_SEPARATION = 8f

    /** Per frame: how much of the scenery area changed since the previous frame (0 for the first frame). */
    private fun sceneMotion(grays: List<dev.toe3autopilot.core.vision.GrayImage>): FloatArray {
        val w = grays.first().width
        val h = grays.first().height
        val r = worldRoi.toRect(w, h)
        val out = FloatArray(grays.size)
        for (k in 1 until grays.size) {
            var c = 0; var t = 0
            val a = grays[k - 1].px
            val b = grays[k].px
            for (y in r.y0 until r.y1) for (x in r.x0 until r.x1) {
                t++
                if (abs(a[y * w + x] - b[y * w + x]) > 10) c++
            }
            out[k] = c.toFloat() / t
        }
        return out
    }

    private fun candidate(role: CalibRole, t: Trace, link: Float, what: String): ControlDetection {
        val strength = ((t.separation - MIN_SEPARATION) / 40f).coerceIn(0f, 1f)
        val conf = (0.25f + 0.25f * strength + 0.25f * link.coerceIn(0f, 1f)).coerceAtMost(ControlDetection.VIDEO_MAX_CONFIDENCE)
        return ControlDetection(
            role, t.element.cx, t.element.cy, t.element.box, conf, DetectionStatus.NEEDS_CONFIRMATION, DetectionSource.VIDEO,
            listOf(what, "link between its look and the scenery: ${"%.2f".format(link)} (1 = perfect)", "from a recorded clip: please confirm it is the ${role.label.lowercase()}"),
        )
    }

    private fun weakOrNone(
        role: CalibRole, traces: List<Trace>, motion: FloatArray, accelerating: Boolean, used: Set<HudElement>, hud: HudAnalysis,
    ): ControlDetection {
        val any = traces.filter { it.element !in used && it.element.cy >= 0.4f }.maxByOrNull { it.separation }
        if (any != null) {
            val link = any.link(motion, accelerating)
            return ControlDetection(
                role, any.element.cx, any.element.cy, any.element.box, 0.25f.coerceAtMost(ControlDetection.VIDEO_MAX_CONFIDENCE),
                DetectionStatus.NEEDS_CONFIRMATION, DetectionSource.VIDEO,
                listOf(
                    "an element in the lower half changes its look, but not in step with the scenery (link ${"%.2f".format(link)})",
                    "WEAK candidate from a recorded clip: confirm only if it really is the ${role.label.lowercase()}",
                ),
            )
        }
        return ControlDetection.none(role, "no element with a pressed state was seen in the clip").asVideo()
    }

    private fun ControlDetection.asVideo(): ControlDetection = copy(source = DetectionSource.VIDEO)

    private fun unusable(report: VideoReport) = VideoCalibrationResult(
        report.copy(usable = false), null, null, emptyMap(), null,
        report.problems + report.advice(), 0,
    )

    private fun pct(f: Float) = (f * 100).toInt()

    private fun corr(a: FloatArray, b: FloatArray): Float {
        val n = a.size
        if (n < 3) return 0f
        val ma = a.average().toFloat()
        val mb = b.average().toFloat()
        var sab = 0f; var saa = 0f; var sbb = 0f
        for (i in 0 until n) {
            val da = a[i] - ma
            val db = b[i] - mb
            sab += da * db; saa += da * da; sbb += db * db
        }
        if (saa <= 1e-9f || sbb <= 1e-9f) return 0f
        return sab / sqrt(saa * sbb)
    }
}
