package dev.toe3autopilot.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.unit.dp
import dev.toe3autopilot.BuildConfig
import dev.toe3autopilot.app.Brand

/** About: name, version, creator credit, what the app does and does not do, privacy, licences. Shows no invented links. */
@Composable
fun AboutPage() {
    val uri = LocalUriHandler.current
    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(horizontal = Dim.l, vertical = Dim.s),
        verticalArrangement = Arrangement.spacedBy(Dim.m),
    ) {
        Panel {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(Dim.s)) {
                BrandMark(88.dp)
                Text(Brand.APP_NAME, style = MaterialTheme.typography.headlineSmall, color = Tokens.TextPrimary)
                Text(Brand.TAGLINE, style = MaterialTheme.typography.bodyMedium, color = Tokens.Accent)
                Text("Version ${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})", style = MaterialTheme.typography.bodyMedium, color = Tokens.TextSecondary)
                Text(Brand.CREDIT, style = MaterialTheme.typography.titleSmall, color = Tokens.Primary)
            }
        }
        Panel(title = "What it is") {
            Body(
                "A driving assistant, currently made for Truckers of Europe 3. It looks at the screen (only with your permission), follows the route line on the " +
                    "minimap, slows down near the delivery area and can try to park when it is calibrated for that. You choose the job, attach the " +
                    "trailer, unload and collect payment yourself.",
            )
            Body(
                "It is not fully autonomous: it only sees what is on screen, cannot read hidden game data, and stops and asks you whenever it is " +
                    "unsure. Successful delivery or parking is not guaranteed.",
            )
            Caption("${Brand.APP_NAME} is an independent app. It is not made, endorsed or supported by the developer or publisher of Truckers of Europe 3.")
        }
        Panel(title = "Privacy") {
            Body(
                "• Screen pictures are analysed in memory on your phone and thrown away. No video is recorded.\n" +
                    "• Calibration profiles and optional sample snapshots stay in the app's private storage. Snapshots are off by default and can be deleted.\n" +
                    "• Exports go only where you choose to save them.\n" +
                    "• No analytics, no ads, no accounts. The app has no internet permission, so it cannot upload anything.",
            )
        }
        Panel(title = "Permissions it uses") {
            Body(
                "• Screen capture: asked by Android every time, to see the game.\n" +
                    "• Accessibility service (optional): to press the calibrated controls, know which app is in front, and show the floating button.\n" +
                    "• Notifications (optional): status, Emergency Stop button, \"parked\" and \"needs help\" alerts.\n" +
                    "• Vibration (optional): countdown and alert buzz.",
            )
        }
        Panel(title = "Support") {
            val support = Brand.SUPPORT_URL
            if (support != null) {
                AppButton("Support and documentation", { uri.openUri(support) }, kind = ButtonKind.Secondary)
            } else {
                Body("Help is in Settings → Help. No support website has been set up for this version.")
            }
        }
        Panel(title = "Open-source notices") {
            Body(
                "Built with Kotlin, Jetpack Compose, AndroidX and kotlinx.coroutines (Apache License 2.0). The splash-screen lettering is drawn from " +
                    "the Poppins typeface (SIL Open Font License 1.1). The app icon and graphics are original artwork made for ${Brand.APP_NAME}.",
            )
        }
        CreditFooter()
    }
}
