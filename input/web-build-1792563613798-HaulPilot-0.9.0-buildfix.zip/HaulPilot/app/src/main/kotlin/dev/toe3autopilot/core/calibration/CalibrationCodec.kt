package dev.toe3autopilot.core.calibration

import dev.toe3autopilot.core.vision.Roi
import java.io.StringReader
import java.util.Locale
import java.util.Properties

/**
 * Text (java.util.Properties) form of [PersistedCalibration]. Lenient on read: a malformed line is skipped and
 * reported, and a detection that would break an invariant (for example "auto-confirmed" without enough
 * confidence) is downgraded to "needs confirmation" instead of being trusted.
 */
object CalibrationCodec {
    private val LEGACY_ROLES = setOf("CAMERA", "COUPLE", "OPEN_JOBS", "ACCEPT_JOB", "NEXT_PAGE", "CONFIRM", "CLOSE_DIALOG")

    data class Parsed(val calibration: PersistedCalibration, val warnings: List<String>)

    fun format(c: PersistedCalibration): String {
        val sb = StringBuilder()
        sb.append("version=1\n")
        c.layout?.let { sb.append("layout=").append(it.width).append('x').append(it.height).append('\n') }
        for ((role, d) in c.detections) {
            sb.append("det.").append(role.name).append('=')
                .append(d.status.name).append('|')
                .append(f(d.confidence)).append('|')
                .append(f(d.x)).append('|').append(f(d.y)).append('|')
                .append(d.source.name).append('|')
                .append(d.box?.format() ?: "-").append('|')
                .append(d.evidence.joinToString("~") { clean(it) })
                .append('\n')
        }
        c.timing?.let { t ->
            t.stoppedThreshold?.let { sb.append("timing.stopped=").append(f(it, 5)).append('\n') }
            sb.append("timing.rest=").append(f(t.restLevel, 5)).append('\n')
            sb.append("timing.moving=").append(f(t.movingLevel, 5)).append('\n')
            t.startLatencyMsUpperBound?.let { sb.append("timing.start=").append(it).append('\n') }
            t.stopMs?.let { sb.append("timing.stop=").append(it).append('\n') }
            t.suggestedSettleMs?.let { sb.append("timing.settle=").append(it).append('\n') }
            sb.append("timing.notes=").append(t.notes.joinToString("~") { clean(it) }).append('\n')
        }
        return sb.toString()
    }

    fun parse(text: String): Parsed {
        val warnings = ArrayList<String>()
        val props = Properties()
        try {
            props.load(StringReader(text))
        } catch (e: Exception) {
            return Parsed(PersistedCalibration(null, emptyMap(), null), listOf("Calibration file unreadable: ${e.message}"))
        }
        var layout: LayoutSignature? = null
        props.getProperty("layout")?.let { v ->
            val parts = v.trim().split("x").map { it.toIntOrNull() }
            if (parts.size == 2 && parts[0] != null && parts[1] != null && parts[0]!! > 0 && parts[1]!! > 0) {
                layout = LayoutSignature(parts[0]!!, parts[1]!!)
            } else {
                warnings += "Bad layout line"
            }
        }
        val dets = LinkedHashMap<CalibRole, ControlDetection>()
        for (key in props.stringPropertyNames().sorted()) {
            if (!key.startsWith("det.")) continue
            val role = CalibRole.entries.firstOrNull { it.name == key.removePrefix("det.") }
            if (role == null) {
                // Roles of the older job-automation version (camera, coupling) are simply not used any more.
                if (key.removePrefix("det.") !in LEGACY_ROLES) warnings += "Unknown role in '$key'"
                continue
            }
            try {
                dets[role] = parseDetection(role, props.getProperty(key))
            } catch (e: IllegalArgumentException) {
                warnings += "Skipped '$key': ${e.message}"
            }
        }
        val timing = if (props.containsKey("timing.rest")) {
            TimingEstimate(
                stoppedThreshold = props.getProperty("timing.stopped")?.toFloatOrNull(),
                restLevel = props.getProperty("timing.rest")?.toFloatOrNull() ?: 0f,
                movingLevel = props.getProperty("timing.moving")?.toFloatOrNull() ?: 0f,
                startLatencyMsUpperBound = props.getProperty("timing.start")?.toLongOrNull(),
                stopMs = props.getProperty("timing.stop")?.toLongOrNull(),
                suggestedSettleMs = props.getProperty("timing.settle")?.toLongOrNull(),
                notes = props.getProperty("timing.notes").orEmpty().split("~").filter { it.isNotBlank() },
            )
        } else {
            null
        }
        return Parsed(PersistedCalibration(layout, dets, timing), warnings)
    }

    private fun parseDetection(role: CalibRole, v: String): ControlDetection {
        val p = v.split("|", limit = 7)
        require(p.size == 7) { "expected 7 fields" }
        val status = DetectionStatus.entries.firstOrNull { it.name == p[0] } ?: throw IllegalArgumentException("bad status")
        val conf = (p[1].toFloatOrNull() ?: throw IllegalArgumentException("bad confidence")).coerceIn(0f, 1f)
        val x = (p[2].toFloatOrNull() ?: throw IllegalArgumentException("bad x")).coerceIn(0f, 1f)
        val y = (p[3].toFloatOrNull() ?: throw IllegalArgumentException("bad y")).coerceIn(0f, 1f)
        val source = DetectionSource.entries.firstOrNull { it.name == p[4] } ?: throw IllegalArgumentException("bad source")
        val box = if (p[5] == "-") null else Roi.parse(p[5])
        val evidence = p[6].split("~").filter { it.isNotBlank() }
        // Never trust a stored "auto-confirmed" that no longer satisfies the rule; make the user look again.
        val safeStatus = when {
            status == DetectionStatus.AUTO_CONFIRMED && (source != DetectionSource.DEMONSTRATION || conf < ControlDetection.AUTO_CONFIRM_MIN) ->
                DetectionStatus.NEEDS_CONFIRMATION
            else -> status
        }
        val safeConf = when (source) {
            DetectionSource.PRIOR -> conf.coerceAtMost(ControlDetection.PRIOR_MAX_CONFIDENCE)
            DetectionSource.VIDEO -> conf.coerceAtMost(ControlDetection.VIDEO_MAX_CONFIDENCE)
            else -> conf
        }
        return ControlDetection(role, x, y, box, safeConf, safeStatus, source, evidence)
    }

    private fun f(v: Float, digits: Int = 4) = String.format(Locale.ROOT, "%.${digits}f", v)

    private fun clean(s: String) = s.replace('|', '/').replace('~', '-').replace('\n', ' ').replace('\r', ' ')
}
