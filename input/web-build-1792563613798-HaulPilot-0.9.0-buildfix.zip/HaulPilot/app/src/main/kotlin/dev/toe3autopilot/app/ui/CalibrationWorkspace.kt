package dev.toe3autopilot.app.ui

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import dev.toe3autopilot.core.calibration.CalibRole
import dev.toe3autopilot.core.calibration.CalibrationProgress
import dev.toe3autopilot.core.calibration.CalibrationState
import dev.toe3autopilot.core.calibration.ControlDetection
import dev.toe3autopilot.core.calibration.DetectionStatus
import dev.toe3autopilot.core.calibration.StageState
import dev.toe3autopilot.core.vision.Frame
import dev.toe3autopilot.core.vision.Roi
import dev.toe3autopilot.core.profile.NavProfile
import dev.toe3autopilot.core.calibration.ViewTransform
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onSizeChanged

fun detectionColor(s: DetectionStatus): Color = when (s) {
    DetectionStatus.AUTO_CONFIRMED, DetectionStatus.CONFIRMED -> Tokens.Success
    DetectionStatus.NEEDS_CONFIRMATION -> Tokens.Warning
    DetectionStatus.REJECTED -> Tokens.Danger
    DetectionStatus.NONE -> Tokens.TextMuted
}

fun detectionLabel(s: DetectionStatus): String = when (s) {
    DetectionStatus.AUTO_CONFIRMED -> "Clear (not yet confirmed by you)"
    DetectionStatus.CONFIRMED -> "Confirmed"
    DetectionStatus.NEEDS_CONFIRMATION -> "Uncertain"
    DetectionStatus.REJECTED -> "Rejected"
    DetectionStatus.NONE -> "Not found"
}

/**
 * The picture the calibration works on (a live frame, a frame from an imported clip, or a screenshot) with every proposed
 * control drawn and labelled on top. Tapping places the selected control; with [editing] set, a tap moves its region.
 */
@Composable
fun CalibrationPreview(
    frame: Frame?,
    state: CalibrationState,
    placing: CalibRole?,
    editing: CalibRole?,
    /** A Smart Setup navigation step is waiting for a tap on the picture. */
    tapPrompt: Boolean = false,
    /** The saved minimap area and truck position, drawn so the person can see what was set up. */
    nav: NavProfile? = null,
    /** An extra point to show (for example the guessed truck position on the minimap), drawn as an orange ring. */
    marker: Pair<Float, Float>? = null,
    onTap: (x: Float, y: Float) -> Unit,
) {
    if (frame == null) return
    val bitmap: Bitmap = remember(frame) { Bitmap.createBitmap(frame.argb, frame.width, frame.height, Bitmap.Config.ARGB_8888) }
    val selected = editing ?: placing
    val description = "Picture used for calibration with ${state.detections.values.count { it.status != DetectionStatus.NONE }} proposed controls marked"
    // Pinch to zoom, drag to pan; a tap only counts when the finger did not move (no accidental selections while panning).
    var view by remember(frame.width, frame.height) { mutableStateOf(ViewTransform(0f, 0f)) }
    Column(verticalArrangement = Arrangement.spacedBy(Dim.xs)) {
    BoxWithConstraints(
        Modifier
            .fillMaxWidth()
            .aspectRatio(bitmap.width.toFloat() / bitmap.height)
            .clip(RoundedCornerShape(Dim.radiusControl))
            .background(Color.Black)
            .semantics { contentDescription = description }
            .onSizeChanged { sz -> if (view.viewW != sz.width.toFloat() || view.viewH != sz.height.toFloat()) view = ViewTransform(sz.width.toFloat(), sz.height.toFloat()) }
            .pointerInput(frame.width, frame.height) {
                // Two fingers zoom; one finger pans only when zoomed in, so the page still scrolls normally otherwise.
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    do {
                        val event = awaitPointerEvent()
                        val fingers = event.changes.count { it.pressed }
                        if (fingers >= 2 || view.scale > 1.01f) {
                            val zoom = event.calculateZoom()
                            val pan = event.calculatePan()
                            val c = event.calculateCentroid(useCurrent = true)
                            if (c != Offset.Unspecified && (zoom != 1f || pan != Offset.Zero)) {
                                view = view.transformed(zoom, pan.x, pan.y, c.x, c.y)
                                event.changes.forEach { if (it.positionChanged()) it.consume() }
                            }
                        }
                    } while (event.changes.any { it.pressed })
                }
            }
            .pointerInput(selected, tapPrompt) {
                detectTapGestures { o ->
                    if (selected != null || tapPrompt) view.toImage(o.x, o.y)?.let { (x, y) -> onTap(x, y) }
                }
            },
    ) {
    // maxWidth / maxHeight belong to BoxWithConstraintsScope. Read them here, in that scope: inside the inner Box below the
    // receiver is BoxScope, and Compose's layout-scope DSL marker forbids reaching the outer scope implicitly. The inner Box
    // fills this one, so these are also its size (zoom is applied by graphicsLayer, not by changing the layout size).
    val bw = maxWidth
    val bh = maxHeight
    Box(
        Modifier.fillMaxSize().graphicsLayer {
            transformOrigin = TransformOrigin(0f, 0f)
            scaleX = view.scale
            scaleY = view.scale
            translationX = view.offsetX
            translationY = view.offsetY
        },
    ) {
        Image(bitmap.asImageBitmap(), contentDescription = null, contentScale = ContentScale.FillBounds, modifier = Modifier.fillMaxSize())
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            fun rect(b: Roi, c: Color, width: Float) =
                drawRect(c, Offset(b.left * w, b.top * h), Size((b.right - b.left) * w, (b.bottom - b.top) * h), style = Stroke(width))
            state.hud?.elements?.forEach { rect(it.box, Color(0x66FFFFFF), 1.5f) }
            if (nav == null) state.minimap?.let { rect(it.box, Color(0xFFE040FB), 3f) }
            nav?.let { n ->
                rect(n.minimapRoi, Tokens.Primary, 3f)
                drawCircle(Tokens.Primary, 8f, Offset(n.truckX * w, n.truckY * h), style = Stroke(3f))
            }
            marker?.let { (mx, my) -> drawCircle(Tokens.Primary, 11f, Offset(mx * w, my * h), style = Stroke(4f)) }
            state.detections.values.forEach { d ->
                if (d.status != DetectionStatus.NONE && d.status != DetectionStatus.REJECTED) {
                    val c = detectionColor(d.status)
                    val sel = d.role == selected
                    d.box?.let { rect(it, c, if (sel) 7f else 4f) }
                    drawCircle(c, if (sel) 14f else 9f, Offset(d.x * w, d.y * h), style = Stroke(if (sel) 5f else 3f))
                }
            }
        }
        // Labels sit above each marked control.
        state.detections.values.forEach { d ->
            if (d.status == DetectionStatus.NONE || d.status == DetectionStatus.REJECTED) return@forEach
            val top = d.box?.top ?: (d.y - 0.05f)
            val left = d.box?.left ?: (d.x - 0.05f)
            Text(
                "${d.role.label} ${(d.confidence * 100).toInt()}%",
                Modifier
                    .offset(x = bw * left.coerceIn(0f, 0.8f), y = (bh * top - 20.dp).coerceAtLeast(0.dp))
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color(0xCC0B0F14))
                    .padding(horizontal = 4.dp, vertical = 1.dp),
                style = MaterialTheme.typography.labelSmall,
                color = detectionColor(d.status),
                maxLines = 1,
            )
        }
    }
    }
    if (view.scale > 1.01f) {
        AppButton("Reset zoom", { view = ViewTransform(view.viewW, view.viewH) }, kind = ButtonKind.Ghost, minHeight = 40.dp)
    } else {
        Caption("Pinch to zoom, drag to move the picture.")
    }
    }
}

/** Colour key for [CalibrationPreview]. */
@Composable
fun PreviewLegend() {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(Dim.l), verticalAlignment = Alignment.CenterVertically) {
            LegendDot(Tokens.Success, "confirmed")
            LegendDot(Tokens.Warning, "needs your check")
        }
        Row(horizontalArrangement = Arrangement.spacedBy(Dim.l), verticalAlignment = Alignment.CenterVertically) {
            LegendDot(Color(0x99FFFFFF), "fixed element")
            LegendDot(Color(0xFFE040FB), "minimap guess")
            LegendDot(Tokens.Primary, "your minimap")
        }
    }
}

@Composable
private fun LegendDot(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        Box(Modifier.size(10.dp).clip(RoundedCornerShape(2.dp)).background(color))
        Text(label, style = MaterialTheme.typography.labelSmall, color = Tokens.TextSecondary, maxLines = 1)
    }
}

/** What each stage is for, in plain words. */
fun stageExplanation(key: String): String = when (key) {
    "A" -> "Looks at the picture and finds the buttons and gauges that stay in the same place."
    "B" -> "Compares many pictures over time, so moving scenery and road markings are not mistaken for buttons."
    "C" -> "You check each proposed control on the picture and confirm, move or reject it."
    "D" -> "Only the controls you confirmed are saved to your profile."
    else -> ""
}

/** Overall progress bar and the four stages A-D, each with its own state and one line of evidence. */
@Composable
fun ProgressSection(p: CalibrationProgress) {
    Column(verticalArrangement = Arrangement.spacedBy(Dim.s)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Calibration progress", style = MaterialTheme.typography.titleSmall, color = Tokens.TextPrimary)
            Text("${(p.fraction * 100).toInt()}%", style = MaterialTheme.typography.titleSmall, color = Tokens.Accent)
        }
        MeterBar(p.fraction, Tokens.Accent, height = 8.dp)
        p.stages.forEach { s ->
            val c = when (s.state) {
                StageState.DONE -> Tokens.Success
                StageState.ACTIVE -> Tokens.Accent
                StageState.BLOCKED -> Tokens.Danger
                StageState.PENDING -> Tokens.TextMuted
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(Dim.m), verticalAlignment = Alignment.Top) {
                Box(
                    Modifier.clip(RoundedCornerShape(50)).background(c.copy(alpha = 0.18f)).padding(horizontal = 9.dp, vertical = 2.dp),
                ) { Text(s.key, style = MaterialTheme.typography.labelLarge, color = c) }
                Column(Modifier.weight(1f)) {
                    Text(s.title, style = MaterialTheme.typography.bodyMedium, color = Tokens.TextPrimary)
                    Text(stageExplanation(s.key), style = MaterialTheme.typography.bodySmall, color = Tokens.TextMuted)
                    Text(s.detail, style = MaterialTheme.typography.bodySmall, color = if (s.state == StageState.BLOCKED) Tokens.Danger else Tokens.TextSecondary)
                }
            }
        }
    }
}

/** Confidence meter + status chip + evidence for one control. */
@Composable
fun DetectionHeader(role: CalibRole, d: ControlDetection?) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(role.label, style = MaterialTheme.typography.titleSmall, color = Tokens.TextPrimary)
            val st = d?.status ?: DetectionStatus.NONE
            StatusChip(detectionLabel(st), detectionColor(st))
        }
        if (d != null && d.status != DetectionStatus.NONE) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(Dim.s)) {
                Box(Modifier.weight(1f)) { MeterBar(d.confidence, detectionColor(d.status)) }
                Text("${(d.confidence * 100).toInt()}%", style = MaterialTheme.typography.labelMedium, color = Tokens.TextSecondary)
            }
        }
    }
}
