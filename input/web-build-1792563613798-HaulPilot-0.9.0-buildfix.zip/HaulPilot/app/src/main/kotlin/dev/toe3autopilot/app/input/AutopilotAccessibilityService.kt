package dev.toe3autopilot.app.input

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import dev.toe3autopilot.app.AutopilotRuntime
import dev.toe3autopilot.core.calibration.CalibrationSummaries
import dev.toe3autopilot.core.capture.FrameGate
import dev.toe3autopilot.core.overlay.OverlayInputs
import dev.toe3autopilot.core.overlay.OverlayModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Accessibility service used for exactly three things: dispatching the gestures the user enabled automation
 * for, learning which package is in front (package name only; no window content is requested) and drawing the
 * compact floating controls (a small movable button that opens Start / Calibrate / Pause / Resume / End / Emergency Stop).
 * It does not read touch events, keystrokes or the content of other apps.
 */
class AutopilotAccessibilityService : AccessibilityService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var panel: FloatingControls? = null
    private var panelNote: String? = null
    private var panelFailureLogged = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        AutopilotRuntime.init(this)
        instance = this
        AutopilotRuntime.accessibilityConnected.value = true
        // Any change that affects what the floating panel shows refreshes it.
        scope.launch { AutopilotRuntime.snapshot.collect { panelNote = null; refreshPanel() } }
        scope.launch { AutopilotRuntime.captureActive.collect { refreshPanel() } }
        scope.launch { AutopilotRuntime.options.collect { refreshPanel() } }
        scope.launch { AutopilotRuntime.armedMessage.collect { refreshPanel() } }
        scope.launch { AutopilotRuntime.calibration.state.collect { refreshPanel() } }
        scope.launch { AutopilotRuntime.recorder.recording.collect { refreshPanel() } }
        scope.launch { AutopilotRuntime.profile.collect { refreshPanel() } }
        scope.launch { AutopilotRuntime.captureDiagnosis.collect { refreshPanel() } }
        scope.launch { AutopilotRuntime.link.collect { refreshPanel() } }
        scope.launch { AutopilotRuntime.autoState.collect { if (!it.running) panelNote = null; refreshPanel() } }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        // Our own overlay, the keyboard and the system UI (volume panel, shade) are not "the foreground app".
        // If the shade really covers the game, the screen-recognition layer notices (unknown screen -> brake).
        if (pkg == packageName || pkg == "com.android.systemui" || pkg.contains("inputmethod")) return
        foregroundPackage = pkg
    }

    override fun onInterrupt() {
        // The system asked us to stop; the safe response is to lift every touch and end the session.
        AutopilotRuntime.emergencyStop("Accessibility service was interrupted")
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        teardown("Accessibility service was disabled")
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        teardown("Accessibility service was destroyed")
        scope.cancel()
        super.onDestroy()
    }

    private fun teardown(reason: String) {
        val wasActive = AutopilotRuntime.session?.currentSnapshot()?.status?.isActiveLoop == true
        instance = null
        foregroundPackage = null
        AutopilotRuntime.accessibilityConnected.value = false
        if (wasActive) AutopilotRuntime.emergencyStop(reason)
        AutopilotRuntime.onInputServiceGone()
        hideOverlay()
    }

    override fun onConfigurationChanged(newConfig: android.content.res.Configuration) {
        super.onConfigurationChanged(newConfig)
        panel?.onScreenChanged()
    }

    /** Rebuilds the floating controls from the app state. Main thread only. */
    private fun refreshPanel() {
        val cal = AutopilotRuntime.calibration.state.value
        val saved = AutopilotRuntime.profile.value?.controls?.keys ?: emptySet()
        val diagnosis = AutopilotRuntime.captureDiagnosis.value
        val inputs = OverlayInputs(
            snapshot = AutopilotRuntime.snapshot.value,
            captureOn = AutopilotRuntime.captureActive.value,
            armedMessage = AutopilotRuntime.armedMessage.value,
            calibration = cal,
            progress = CalibrationSummaries.progress(cal, saved, diagnosis.takeIf { it.isProblem }?.title),
            controls = CalibrationSummaries.controls(cal.detections, saved),
            note = panelNote,
            recordingSnapshots = AutopilotRuntime.recorder.recording.value,
            showWhileCaptureOn = AutopilotRuntime.options.value.showPanel,
            link = AutopilotRuntime.link.value,
            auto = AutopilotRuntime.autoState.value,
            canAdoptGame = FrameGate.couldBeGame(foregroundPackage, packageName),
        )
        val ui = OverlayModel.build(inputs)
        val p = panel ?: FloatingControls(
            this,
            FloatingActions(
                onStartDrive = {
                    val r = AutopilotRuntime.startSession()
                    panelNote = if (r.ok) null else "Cannot start: ${r.problems.firstOrNull() ?: "unknown reason"}"
                    refreshPanel()
                },
                onStartCalibration = {
                    // One-tap Auto-Calibrate. The person is looking at the game right now.
                    panelNote = AutopilotRuntime.startAutoCalibration(fromOverlay = true)
                        ?: "Drive normally for about 15 seconds; press the accelerator and the brake once or twice."
                    refreshPanel()
                },
                onCancelCalibration = {
                    AutopilotRuntime.cancelAutoCalibration()
                    AutopilotRuntime.calibration.cancel()
                    panelNote = null
                    refreshPanel()
                },
                onPause = { AutopilotRuntime.pause() },
                onResume = {
                    val r = AutopilotRuntime.resume()
                    panelNote = if (r.ok) null else "Cannot resume: ${r.problems.firstOrNull() ?: "unknown reason"}"
                    refreshPanel()
                },
                onEnd = {
                    if (AutopilotRuntime.armedMessage.value != null) AutopilotRuntime.cancelArmed() else AutopilotRuntime.stopSession()
                },
                onEmergency = { AutopilotRuntime.emergencyStop("Emergency stop pressed on the floating controls") },
                onAdoptGame = {
                    panelNote = AutopilotRuntime.adoptForegroundAsGame() ?: "This app is now the game. Tap Auto-Calibrate."
                    refreshPanel()
                },
                onHide = {
                    AutopilotRuntime.updateOptions { it.copy(showPanel = false) }
                    AutopilotRuntime.notice.value = "The floating button is hidden. It comes back during a drive, or turn it on in Settings."
                },
            ),
        ).also { panel = it }
        if (!p.show(ui)) {
            // Without the floating controls the app screen and the notification actions still work.
            if (!panelFailureLogged) {
                panelFailureLogged = true
                AutopilotRuntime.noteInputFailure("Could not draw the floating controls")
            }
        }
    }

    private fun hideOverlay() {
        panel?.hide()
        panel = null
    }

    companion object {
        @Volatile
        var instance: AutopilotAccessibilityService? = null
            private set

        @Volatile
        var foregroundPackage: String? = null
            internal set
    }
}
