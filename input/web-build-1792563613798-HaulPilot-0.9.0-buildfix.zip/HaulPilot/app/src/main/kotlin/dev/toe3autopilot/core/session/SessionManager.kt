package dev.toe3autopilot.core.session

import dev.toe3autopilot.core.HelpKind
import dev.toe3autopilot.core.AutomationSettings
import dev.toe3autopilot.core.Clock
import dev.toe3autopilot.core.Control
import dev.toe3autopilot.core.Decision
import dev.toe3autopilot.core.DriveCommand
import dev.toe3autopilot.core.Point
import dev.toe3autopilot.core.agents.DeliveryAreaDetector
import dev.toe3autopilot.core.agents.DeliveryCue
import dev.toe3autopilot.core.calibration.CalibRole
import dev.toe3autopilot.core.calibration.LayoutCheck
import dev.toe3autopilot.core.agents.NavigationDriveAgent
import dev.toe3autopilot.core.agents.ParkingAgent
import dev.toe3autopilot.core.agents.RecoveryAgent
import dev.toe3autopilot.core.profile.GameProfile
import dev.toe3autopilot.core.profile.ProfileReadiness
import dev.toe3autopilot.core.profile.TemplateStore
import dev.toe3autopilot.core.state.GameState
import dev.toe3autopilot.core.state.StateDetector
import dev.toe3autopilot.core.state.StateEstimate
import dev.toe3autopilot.core.vision.MotionEstimator
import dev.toe3autopilot.core.vision.ProfileVision
import dev.toe3autopilot.core.vision.Roi
import dev.toe3autopilot.core.vision.RoadQuality
import dev.toe3autopilot.core.vision.RouteEstimator
import dev.toe3autopilot.core.vision.TemplateProvider
import dev.toe3autopilot.core.vision.Vision

/**
 * Owns one automation session and runs the closed loop
 *
 *     Observe (frame) -> Interpret (state detector) -> Plan (agents) -> Act (input) -> Observe again
 *
 * The session is drive-only. The user selects the job, attaches the trailer and starts the app while already driving;
 * the session then follows the DRIVING -> APPROACHING -> PARKING -> PARKED phases and stops by itself when the truck is
 * parked, when the delivery screen appears, or whenever it cannot continue safely.
 *
 * one [tick] at a time. The class is synchronous and has no Android dependencies, so the host just calls
 * [tick] repeatedly and sleeps for the returned number of milliseconds.
 *
 * Safety rules enforced here (not left to the agents):
 *  - the session only reaches RUNNING after a preflight (profile, capture, input channel, foreground app)
 *    AND after the screen was actually recognised; until then nothing is injected;
 *  - unrecognised screens, a dead input channel, a frozen game or any exception stop the truck and hand
 *    control back to the user (NEEDS_ASSIST / ERROR);
 *  - taps are rate-limited and every agent action is bounded by cooldowns and attempt budgets;
 *  - [emergencyStop] is callable from any thread and takes effect without waiting for the loop.
 */
class SessionManager(
    private val frames: FrameSource,
    private val monitor: GameMonitor,
    private val input: InputController,
    private val profileProvider: () -> GameProfile?,
    private val templateStore: TemplateStore,
    private val settingsProvider: () -> AutomationSettings,
    private val clock: Clock,
    val log: SessionLog = SessionLog(),
    private val listener: (SessionSnapshot) -> Unit = {},
) {
    private val lock = Any()

    @Volatile
    private var emergency = false

    private var status = SessionStatus.IDLE
    private var snapshot = SessionSnapshot()
    private var task = "Idle"
    private var lastError: String? = null
    private var assistHint: String? = null
    private var ticks = 0L
    private var helpKind: HelpKind? = null

    // Per-profile machinery
    private var activeProfile: GameProfile? = null
    private var detector: StateDetector? = null
    private var mapper: ControlMapper? = null
    private var templates: TemplateProvider? = null
    private var router: RouteEstimator? = null
    private var motionEstimator: MotionEstimator? = null

    // Agents
    private val navAgent = NavigationDriveAgent()
    private val parkingAgent = ParkingAgent()
    private val delivery = DeliveryAreaDetector()
    private val recovery = RecoveryAgent()

    // Loop state
    private var startedAt = 0L
    private var lastState = GameState.UNKNOWN
    private var lastDrivingAt: Long? = null
    private var phase = DrivePhase.DRIVING
    private var phaseEnteredAt = 0L
    private var phaseGraceUntil = 0L
    private var parkedTicks = 0
    private var turnShownUntil = 0L
    private var notForegroundSince: Long? = null
    private var commandedThrottle = 0f
    private var lastTapAt: Long? = null
    private var brakeUntil = 0L
    private var lastFrameTs: Long? = null
    private var lastFrameChangeAt = 0L
    private var motionValue = 0f
    private var lastVision: Vision? = null
    private var lastEstimate: StateEstimate? = null
    private var captureDone = false
    private var hintAt = 0L
    private var hintState = GameState.UNKNOWN
    private var lastStaleCheckAt = 0L
    private var staleStreak = 0
    private val lastHeldAt = HashMap<Control, Long>()

    // ---- public controls -------------------------------------------------------------------------------

    fun start(): StartResult = synchronized(lock) {
        val now = clock.nowMs()
        val problems = preflight(settingsProvider().sanitized())
        if (problems.isNotEmpty()) {
            status = SessionStatus.IDLE
            lastError = "Cannot start: ${problems.first()}"
            task = "Idle"
            log.add(now, LogLevel.WARN, "Start refused (${problems.size} problem(s)): ${problems.joinToString("; ")}")
            publish()
            return StartResult(false, problems)
        }
        emergency = false
        captureDone = false
        phase = DrivePhase.DRIVING
        resetRun(now)
        status = SessionStatus.STARTING
        task = "Verifying that the driving screen is recognised"
        log.add(now, LogLevel.INFO, "Session starting (input: ${input.kind})")
        publish()
        StartResult(true, emptyList())
    }

    fun pause(reason: String = "Paused by user") = synchronized(lock) {
        if (status.isActiveLoop) halt(clock.nowMs(), SessionStatus.PAUSED, reason, isError = false)
    }

    fun resume(): StartResult = synchronized(lock) {
        val now = clock.nowMs()
        if (status != SessionStatus.PAUSED && status != SessionStatus.NEEDS_ASSIST) {
            return StartResult(false, listOf("Nothing to resume (status: ${status.label})"))
        }
        val problems = preflight(settingsProvider().sanitized())
        if (problems.isNotEmpty()) {
            lastError = "Cannot resume: ${problems.first()}"
            log.add(now, LogLevel.WARN, "Resume refused: ${problems.joinToString("; ")}")
            publish()
            return StartResult(false, problems)
        }
        emergency = false
        captureDone = false
        resetRun(now)
        phaseGraceUntil = now + PHASE_GRACE_MS // the approach cue has to be re-confirmed after a pause; do not fall back meanwhile
        status = SessionStatus.STARTING
        task = "Re-verifying the driving screen"
        log.add(now, LogLevel.INFO, "Session resumed")
        publish()
        StartResult(true, emptyList())
    }

    /** User ended the session. Releases every control immediately. */
    fun stop() = synchronized(lock) {
        val now = clock.nowMs()
        emergency = true // blocks any in-flight tick from injecting more input
        input.releaseAll()
        brakeUntil = 0L
        captureDone = true
        status = SessionStatus.IDLE
        task = "Stopped"
        log.add(now, LogLevel.INFO, "Session stopped by user")
        publish()
    }

    /** Callable from any thread (UI button, overlay, notification). Does not wait for the loop. */
    fun emergencyStop(reason: String = "Emergency stop") {
        emergency = true
        input.releaseAll()
        synchronized(lock) {
            val now = clock.nowMs()
            halt(now, SessionStatus.EMERGENCY_STOPPED, reason, isError = true)
            emergency = true
            captureDone = true
        }
    }

    fun currentSnapshot(): SessionSnapshot = synchronized(lock) { snapshot }

    /** Frames are only needed (at a high rate) while the loop is active. */
    fun suggestedCaptureIntervalMs(): Long = synchronized(lock) {
        if (!status.isActiveLoop) IDLE_CAPTURE_MS else (delayFor(lastState) / 2).coerceIn(60L, 300L)
    }

    /** True once the session has ended (stopped, emergency-stopped or finished) and any safety braking is over. */
    fun shouldReleaseCapture(): Boolean = synchronized(lock) { captureDone && clock.nowMs() >= brakeUntil }

    // ---- the loop --------------------------------------------------------------------------------------

    /** Runs one observe-interpret-plan-act cycle. Returns the delay before the next call. */
    fun tick(): Long = synchronized(lock) {
        val now = clock.nowMs()
        ticks++
        if (!status.isActiveLoop) {
            serviceBrake(now)
            return IDLE_DELAY_MS
        }
        return try {
            runTick(now)
        } catch (e: Exception) {
            halt(now, SessionStatus.ERROR, "Internal error: ${e.javaClass.simpleName}: ${e.message}", isError = true)
            IDLE_DELAY_MS
        }
    }

    private fun runTick(now: Long): Long {
        val settings = settingsProvider().sanitized()
        val profile = profileProvider()
        if (profile == null) {
            halt(now, SessionStatus.ERROR, "The game profile is no longer available", true)
            return IDLE_DELAY_MS
        }
        if (profile !== activeProfile) rebuild(profile)

        if (!frames.isActive) {
            halt(now, SessionStatus.ERROR, "Screen capture stopped", true, HelpKind.CAPTURE)
            return IDLE_DELAY_MS
        }
        val frame = frames.latest()
        if (frame == null) {
            halt(now, SessionStatus.ERROR, "No screen frame available", true, HelpKind.CAPTURE)
            return IDLE_DELAY_MS
        }
        // The calibration is only valid for the screen geometry it was made on (rotation, other screen, resized capture).
        LayoutCheck.layoutProblem(profile, frame.width, frame.height)?.let {
            halt(now, SessionStatus.NEEDS_ASSIST, it, true, HelpKind.LAYOUT_CHANGED)
            return IDLE_DELAY_MS
        }

        // Foreground app
        val fg = monitor.isGameForeground()
        val fgOk = fg == true || (fg == null && input.kind == InputKind.ASSISTED)
        if (!fgOk) {
            val since = notForegroundSince ?: now.also { notForegroundSince = it }
            if (now - since > FOREGROUND_GRACE_MS) {
                halt(
                    now, SessionStatus.PAUSED,
                    if (fg == false) "The game is no longer in the foreground" else "Cannot verify the foreground app (accessibility service disconnected)",
                    isError = false,
                )
                return IDLE_DELAY_MS
            }
            input.setHolds(emptyMap())
            task = "Waiting for the game to return to the foreground"
            publish()
            return delayFor(GameState.UNKNOWN)
        }
        notForegroundSince = null

        // Input channel health
        if (!input.isReady || !input.isHealthy) {
            halt(now, SessionStatus.NEEDS_ASSIST, "Input channel is not working (${input.kind})", isError = true, kind = HelpKind.INPUT)
            return IDLE_DELAY_MS
        }

        // Frozen-game watchdog: while driving the picture is always animated.
        if (lastState.drivingLike && now - frame.timestampMs > FROZEN_FRAME_MS) {
            halt(now, SessionStatus.NEEDS_ASSIST, "No screen updates for ${FROZEN_FRAME_MS / 1000}s while driving; the game may be frozen", true, HelpKind.CAPTURE)
            return IDLE_DELAY_MS
        }

        // Observe + interpret
        val sameFrame = lastFrameTs == frame.timestampMs && lastVision != null
        if (!sameFrame) {
            motionValue = motionEstimator!!.update(frame)
            lastFrameTs = frame.timestampMs
            lastFrameChangeAt = now
        } else if (now - lastFrameChangeAt > STATIC_MOTION_MS) {
            motionValue = 0f // no new frames at all: nothing on screen is changing
        }
        val vision: Vision
        val est: StateEstimate
        if (sameFrame) {
            vision = lastVision!!
            est = detector!!.repeat()
        } else {
            vision = ProfileVision(profile, templates!!, frame, { motionValue }, router)
            est = detector!!.update(vision)
            lastVision = vision
        }
        lastEstimate = est

        if (est.state != lastState) {
            onTransition(lastState, est.state, now)
            lastState = est.state
            if (status != SessionStatus.STARTING && status != SessionStatus.RUNNING) return IDLE_DELAY_MS // finished inside onTransition
        }
        if (est.state.drivingLike) lastDrivingAt = now

        // Interface-change watchdog: calibrated controls should still look like their stored pictures while nothing presses them.
        if (status == SessionStatus.RUNNING && est.state.drivingLike && !sameFrame && now - lastStaleCheckAt >= STALE_CHECK_MS) {
            lastStaleCheckAt = now
            val skip = CalibRole.entries.filter { r ->
                val c = r.control
                c != null && now - (lastHeldAt[c] ?: (Long.MIN_VALUE / 2)) < HELD_RECENTLY_MS
            }.toSet()
            val v = LayoutCheck.verifyControls(profile, frame.toGray(), templates!!, frame.width, skip)
            if (v.evaluated >= 2) staleStreak = if (v.stale) staleStreak + 1 else 0
            if (staleStreak >= STALE_STREAK_LIMIT) {
                halt(now, SessionStatus.NEEDS_ASSIST, "The calibrated controls no longer appear where expected; the game interface may have changed. Recalibrate.", true, HelpKind.LAYOUT_CHANGED)
                return IDLE_DELAY_MS
            }
        }

        // Starting gate: never act on a screen we have not recognised.
        if (status == SessionStatus.STARTING) {
            val recognised = est.state.drivingLike && est.confidence >= MIN_CONFIDENCE
            if (recognised) {
                status = SessionStatus.RUNNING
                log.add(now, LogLevel.INFO, "Recognition verified (${est.state.label}, ${"%.2f".format(est.confidence)}); automation active")
            } else if (now - startedAt > RECOGNITION_TIMEOUT_MS) {
                halt(now, SessionStatus.NEEDS_ASSIST, "Could not recognise the driving screen within ${RECOGNITION_TIMEOUT_MS / 1000}s. Start while the normal driving view is showing.", true, HelpKind.SCREEN_UNKNOWN)
                return IDLE_DELAY_MS
            } else {
                task = "Verifying that the driving screen is recognised"
                publish(est)
                return delayFor(GameState.UNKNOWN)
            }
        }

        // Plan. In assisted mode nothing is injected, so unexecuted suggestions must not exhaust attempt budgets
        // (time-based limits such as dwell and loading timeouts still apply).
        if (input.kind == InputKind.ASSISTED) {
            parkingAgent.resetBudgets()
            recovery.resetBudgets()
        }
        val decision = recovery.check(est.state, vision, profile, now, commandedThrottle)
            ?.let { brakeIfWasDriving(it, est.state, now) }
            ?: plan(est.state, vision, profile, settings, now)
        // The plan may have ended the session (parked / delivery screen): the halt already released the controls.
        if (!status.isActiveLoop) {
            publish(est)
            return IDLE_DELAY_MS
        }

        // Act
        act(decision, profile, vision, now)
        publish(est)
        return delayFor(est.state)
    }

    // ---- planning --------------------------------------------------------------------------------------

    private fun plan(state: GameState, vision: Vision, profile: GameProfile, s: AutomationSettings, now: Long): Decision {
        // Evidence that the trip is over comes first.
        if (state == GameState.DELIVERY_COMPLETE) {
            finishParked(now, "The game shows its delivery screen")
            return Decision.Wait("Delivery screen")
        }
        if (phase != DrivePhase.DRIVING || vision.known("parked_ok")) {
            parkedTicks = if (vision.has("parked_ok")) parkedTicks + 1 else 0
            if (parkedTicks >= PARKED_CONFIRM_TICKS) {
                finishParked(now, "The game shows the parked cue")
                return Decision.Wait("Parked")
            }
        }
        return when (state) {
            GameState.DRIVING, GameState.PARKING -> driveOrPark(state, vision, profile, s, now)
            else -> Decision.Wait(state.label)
        }
    }

    private fun parkingPossible(profile: GameProfile): Boolean {
        val zone = profile.templates.containsKey("parking_zone") || profile.colors.containsKey("parking_zone")
        val reverseOk = profile.control(Control.GEAR_REVERSE) != null || profile.extra("parking.direction", "REVERSE").uppercase() == "FORWARD"
        return zone && reverseOk
    }

    private fun driveOrPark(state: GameState, vision: Vision, profile: GameProfile, s: AutomationSettings, now: Long): Decision {
        val cue = delivery.update(vision, profile, now)
        if (state == GameState.PARKING && phase.ordinal < DrivePhase.PARKING.ordinal) {
            if (!(s.tryParking && parkingPossible(profile))) {
                return Decision.NeedHelp(
                    "The game switched to its parking view. Stopped: please park manually (automatic parking is off or not calibrated).",
                )
            }
            enterPhase(DrivePhase.PARKING, "The game switched to its parking view", now)
        }
        if (phase == DrivePhase.DRIVING && cue >= DeliveryCue.NEAR) {
            enterPhase(DrivePhase.APPROACHING, "Delivery area recognised (${delivery.reason})", now)
        } else if (phase == DrivePhase.APPROACHING && cue == DeliveryCue.NONE && now >= phaseGraceUntil) {
            enterPhase(DrivePhase.DRIVING, "The delivery cue is gone; back to normal driving", now)
        }

        if (phase == DrivePhase.APPROACHING) {
            val canPark = s.tryParking && parkingPossible(profile)
            val zoneVisible = vision.locate("parking_zone") != null
            if (canPark && zoneVisible) {
                enterPhase(DrivePhase.PARKING, "Parking area in sight", now)
            } else if (cue == DeliveryCue.AT || (zoneVisible && !canPark)) {
                return Decision.NeedHelp(
                    if (canPark) {
                        "Reached the delivery point but the parking area is not recognised. Stopped near the delivery area: please park manually."
                    } else {
                        "Reached the delivery area. Stopped here: please park manually (automatic parking is off or not calibrated)."
                    },
                )
            } else {
                val maxMs = profile.extraFloat("approach.maxMs", 180_000f).toLong()
                if (now - phaseEnteredAt > maxMs) {
                    return Decision.NeedHelp("Still approaching the delivery area after ${maxMs / 1000}s. Stopped: please take over.")
                }
            }
        }
        if (phase == DrivePhase.PARKING) return parkingAgent.decide(vision, profile, s, now)
        val cap = if (phase == DrivePhase.APPROACHING) s.approachSpeed else 1f
        return navAgent.decide(vision, s, cap, now)
    }

    private fun enterPhase(p: DrivePhase, why: String, now: Long) {
        if (p == phase) return
        log.add(now, LogLevel.INFO, "Phase: ${phase.label} -> ${p.label} ($why)")
        phase = p
        phaseEnteredAt = now
        if (p == DrivePhase.PARKING) {
            parkingAgent.reset()
            commandedThrottle = 0f
        }
    }

    /** All driving inputs stop and the person is told that the manual delivery steps are theirs. */
    private fun finishParked(now: Long, evidence: String) {
        phase = DrivePhase.PARKED
        captureDone = true
        halt(now, SessionStatus.FINISHED, "Parked ($evidence). Please unload, detach the trailer and finish the delivery yourself.", isError = false)
    }

    /** Never just let go of the controls on an unrecognised or loading screen if the truck was moving a moment ago. */
    private fun brakeIfWasDriving(d: Decision, state: GameState, now: Long): Decision {
        if (d !is Decision.Wait || (state != GameState.UNKNOWN && state != GameState.LOADING)) return d
        val last = lastDrivingAt ?: return d
        return if (now - last < 10_000) Decision.Drive(DriveCommand(brake = 0.6f), "Unrecognised screen while driving: braking") else d
    }

    private fun onTransition(from: GameState, to: GameState, now: Long) {
        log.add(now, LogLevel.INFO, "Screen: ${from.label} -> ${to.label}")
    }

    // ---- acting ----------------------------------------------------------------------------------------

    private fun act(d: Decision, profile: GameProfile, vision: Vision, now: Long) {
        if (emergency) return
        task = d.note
        val previousHint = assistHint
        when (d) {
            is Decision.Drive -> {
                val observedReverse = if (vision.known("gear_reverse_indicator")) vision.has("gear_reverse_indicator") else null
                val out = mapper!!.map(d.command, now, vision.motion(), observedReverse)
                if (out.error != null) {
                    halt(now, SessionStatus.NEEDS_ASSIST, out.error, true)
                    return
                }
                input.setHolds(out.holds)
                for (c in out.holds.keys) lastHeldAt[c] = now
                for (c in out.taps) profile.control(c)?.let { tap(it, now) }
                // The DEMANDED throttle (not the instantaneous duty-cycle press) is what stuck detection must compare with motion.
                commandedThrottle = if (d.command.brake < 0.5f) d.command.throttle else 0f
                assistHint = if (input.kind == InputKind.ASSISTED) describe(d.note, out.holds, out.taps) else null
            }
            is Decision.Tap -> {
                input.setHolds(emptyMap())
                commandedThrottle = 0f
                val p = profile.control(d.control)
                if (p == null) halt(now, SessionStatus.NEEDS_ASSIST, "${d.control.name} is not calibrated", true) else tap(p, now)
                assistHint = if (input.kind == InputKind.ASSISTED) "${d.note}: tap ${d.control.name}" else null
            }
            is Decision.TapAt -> {
                input.setHolds(emptyMap())
                commandedThrottle = 0f
                tap(d.point, now)
                assistHint = if (input.kind == InputKind.ASSISTED) "${d.note}: tap the highlighted item" else null
            }
            is Decision.Wait -> {
                input.setHolds(emptyMap())
                commandedThrottle = 0f
                assistHint = if (input.kind == InputKind.ASSISTED) d.note else null
            }
            is Decision.NeedHelp -> halt(now, SessionStatus.NEEDS_ASSIST, d.note, true, d.kind)
        }
        if (input.kind == InputKind.ASSISTED && status.isActiveLoop) {
            // Keep the last actionable hint on screen for a few seconds so it does not flicker back to "waiting".
            val actionable = d !is Decision.Wait
            if (actionable) {
                hintAt = now
                hintState = lastState
            } else if (previousHint != null && hintState == lastState && now - hintAt < HINT_STICKY_MS) {
                assistHint = previousHint
            }
        }
    }

    private fun tap(p: Point, now: Long) {
        val last = lastTapAt
        if (last != null && now - last < MIN_TAP_INTERVAL_MS) return
        lastTapAt = now
        input.tapAt(p)
    }

    private fun describe(note: String, holds: Map<Control, Point>, taps: List<Control>): String {
        val parts = ArrayList<String>()
        if (holds.isNotEmpty()) parts += "hold " + holds.keys.joinToString(" + ") { it.name }
        if (taps.isNotEmpty()) parts += "tap " + taps.joinToString(" + ") { it.name }
        return if (parts.isEmpty()) note else "$note: ${parts.joinToString(", ")}"
    }

    // ---- stopping --------------------------------------------------------------------------------------

    /** Release everything, brake briefly if the truck may be moving, and leave the active loop. */
    private fun halt(now: Long, newStatus: SessionStatus, reason: String, isError: Boolean, kind: HelpKind? = null) {
        input.releaseAll()
        helpKind = if (newStatus == SessionStatus.NEEDS_ASSIST || newStatus == SessionStatus.ERROR) (kind ?: HelpKind.OTHER) else null
        val brake = activeProfile?.control(Control.BRAKE)
        if (lastState.drivingLike && input.kind == InputKind.INJECTED && brake != null) {
            brakeUntil = now + SAFE_BRAKE_MS
            input.setHolds(mapOf(Control.BRAKE to brake))
        }
        status = newStatus
        task = reason
        lastError = if (isError || newStatus == SessionStatus.NEEDS_ASSIST) reason else lastError
        commandedThrottle = 0f
        log.add(now, if (isError) LogLevel.ERROR else if (newStatus == SessionStatus.FINISHED) LogLevel.INFO else LogLevel.WARN, "${newStatus.label}: $reason")
        publish()
    }

    private fun serviceBrake(now: Long) {
        if (brakeUntil == 0L) return
        if (now >= brakeUntil) {
            input.releaseAll()
            brakeUntil = 0L
        }
    }

    // ---- preflight & setup -----------------------------------------------------------------------------

    private fun preflight(settings: AutomationSettings): List<String> {
        val p = ArrayList<String>()
        val profile = profileProvider()
        if (profile == null) p += "No game profile is loaded (use Calibrate)"
        else p += ProfileReadiness.problems(profile, settings, templateStore)
        if (!frames.isActive) p += "Screen capture is not running (tap Connect to Game)"
        else {
            val f = frames.latest()
            if (f == null) p += "Screen capture has not produced a frame yet"
            else if (profile != null) LayoutCheck.layoutProblem(profile, f.width, f.height)?.let { p += it }
        }
        if (settings.assistedMode != (input.kind == InputKind.ASSISTED)) p += "Input mode does not match the Assisted mode setting"
        if (!input.isReady) p += if (input.kind == InputKind.INJECTED) "Accessibility input service is not enabled/connected" else "Assisted input is not ready"
        else if (!input.isHealthy) p += "Input channel reported repeated failures"
        when (monitor.isGameForeground()) {
            true -> {}
            false -> p += "The game is not in the foreground"
            null -> if (input.kind != InputKind.ASSISTED) p += "Cannot verify the foreground app (enable the accessibility service)"
        }
        return p
    }

    private fun rebuild(profile: GameProfile) {
        activeProfile = profile
        detector = StateDetector(profile)
        mapper = ControlMapper(profile)
        templates = TemplateProvider(templateStore, profile.referenceWidth)
        router = profile.nav?.let { RouteEstimator(it) }
        motionEstimator = MotionEstimator(motionRoi(profile))
        lastVision = null
        lastEstimate = null
        lastFrameTs = null
    }

    private fun motionRoi(profile: GameProfile): Roi {
        val v = profile.extras["motion.roi"]
        return if (v != null) Roi.parse(v) else Roi(0.2f, 0.25f, 0.8f, 0.7f)
    }

    private fun resetRun(now: Long) {
        val profile = profileProvider()
        if (profile != null) rebuild(profile)
        detector?.reset()
        mapper?.reset()
        motionEstimator?.reset()
        navAgent.reset()
        parkingAgent.reset()
        delivery.reset()
        recovery.reset()
        parkedTicks = 0
        startedAt = now
        lastState = GameState.UNKNOWN
        lastDrivingAt = null
        notForegroundSince = null
        commandedThrottle = 0f
        lastTapAt = null
        brakeUntil = 0L
        motionValue = 0f
        lastFrameChangeAt = now
        lastError = null
        assistHint = null
        lastStaleCheckAt = now
        staleStreak = 0
        lastHeldAt.clear()
        phaseEnteredAt = now
        phaseGraceUntil = 0L
        input.releaseAll()
    }

    private fun delayFor(state: GameState): Long = when {
        state == GameState.PARKING -> 120L
        state.drivingLike -> 150L
        else -> 400L
    }

    /** The phase shown to the person: while plainly driving, a sharp bend or route end ahead is shown as "Approaching Turn" (held 2 s to avoid flicker). */
    private fun displayPhase(): DrivePhase {
        if (phase != DrivePhase.DRIVING || status != SessionStatus.RUNNING) return phase
        val r = navAgent.road ?: return phase
        val now = clock.nowMs()
        if (r.quality == RoadQuality.TRACKING && (r.curvature > TURN_CURVATURE || r.routeEnding)) turnShownUntil = now + TURN_HOLD_MS
        return if (now < turnShownUntil) DrivePhase.APPROACHING_TURN else phase
    }

    private fun roadText(): String? {
        if (!status.isActiveLoop || phase == DrivePhase.PARKING) return null
        val r = navAgent.road ?: return null
        return when (r.quality) {
            RoadQuality.TRACKING -> "Road tracked (offset %+.2f, bend %+.2f)".format(r.offset, r.bend)
            RoadQuality.DEGRADED -> "Road unclear for ${r.missingForMs / 1000}s: slowing"
            RoadQuality.LOST -> "Road lost: stopped"
        }
    }

    private fun publish(est: StateEstimate? = null) {
        val e = est ?: lastEstimate
        val s = SessionSnapshot(
            status = status,
            gameState = lastState,
            confidence = e?.confidence ?: 0f,
            task = task,
            lastError = lastError,
            recovery = recovery.lastRecoveryNote,
            phase = if (status == SessionStatus.IDLE || status == SessionStatus.EMERGENCY_STOPPED) null else displayPhase(),
            road = roadText(),
            inputKind = input.kind,
            assistHint = assistHint,
            ticks = ticks,
            helpKind = helpKind.takeIf { status == SessionStatus.NEEDS_ASSIST || status == SessionStatus.ERROR },
        )
        if (s.copy(ticks = 0) != snapshot.copy(ticks = 0)) listener(s)
        snapshot = s
    }

    companion object {
        const val IDLE_DELAY_MS = 250L
        const val IDLE_CAPTURE_MS = 1000L
        const val FOREGROUND_GRACE_MS = 4000L
        const val FROZEN_FRAME_MS = 5000L
        const val STATIC_MOTION_MS = 500L
        const val RECOGNITION_TIMEOUT_MS = 15_000L
        const val MIN_CONFIDENCE = 0.7f
        const val MIN_TAP_INTERVAL_MS = 350L
        const val SAFE_BRAKE_MS = 2000L
        const val HINT_STICKY_MS = 3000L
        const val STALE_CHECK_MS = 4000L
        const val STALE_STREAK_LIMIT = 3
        const val HELD_RECENTLY_MS = 1500L
        const val PHASE_GRACE_MS = 3000L
        const val PARKED_CONFIRM_TICKS = 2
        const val TURN_CURVATURE = 0.35f
        const val TURN_HOLD_MS = 2000L
    }
}
