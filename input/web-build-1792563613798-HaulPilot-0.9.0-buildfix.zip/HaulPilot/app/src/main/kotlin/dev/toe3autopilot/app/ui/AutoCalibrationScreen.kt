package dev.toe3autopilot.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import dev.toe3autopilot.app.AutopilotRuntime
import dev.toe3autopilot.app.calibration.CalibrationController
import dev.toe3autopilot.app.calibration.VideoCalibrationRunner
import dev.toe3autopilot.app.calibration.VideoUiState
import dev.toe3autopilot.core.calibration.CalibPhase
import dev.toe3autopilot.core.calibration.CalibRole
import dev.toe3autopilot.core.calibration.CalibrationState
import dev.toe3autopilot.core.calibration.CalibrationSummaries
import dev.toe3autopilot.core.calibration.ControlDetection
import dev.toe3autopilot.core.calibration.GuidedSetup
import dev.toe3autopilot.core.calibration.DetectionStatus
import dev.toe3autopilot.core.capture.AnalyzerDiagnosis
import dev.toe3autopilot.core.vision.Roi

private val DEMO_PHASES = setOf(CalibPhase.PREPARE, CalibPhase.BASELINE, CalibPhase.ACTION, CalibPhase.RELEASE)

/**
 * The calibration workspace: one picture with the proposed controls drawn on it, a four-stage progress display, three ways to
 * get pictures (live play, a recorded clip, screenshots), a per-control review (Confirm / Edit / Retry / Reset) and Save.
 *
 * Nothing found here is trusted until the person confirms it. A recorded clip is for visual calibration only: it never sends
 * touches and says nothing about what the truck is doing now.
 */
@Composable
fun AutoCalibrationScreen(actions: Actions, nav: Navigator, source: Int, onSource: (Int) -> Unit) {
    val ctl = AutopilotRuntime.calibration
    val st by ctl.state.collectAsState()
    val preview by ctl.preview.collectAsState()
    val note by ctl.note.collectAsState()
    val notice by AutopilotRuntime.notice.collectAsState()
    val capture by AutopilotRuntime.captureActive.collectAsState()
    val access by AutopilotRuntime.accessibilityConnected.collectAsState()
    val snap by AutopilotRuntime.snapshot.collectAsState()
    val lastApply by ctl.lastApply.collectAsState()
    val canUndo by ctl.canUndo.collectAsState()
    val profile by AutopilotRuntime.profile.collectAsState()
    val diagnosis by AutopilotRuntime.captureDiagnosis.collectAsState()

    var applyTiming by remember { mutableStateOf(false) }
    var placing by remember { mutableStateOf<CalibRole?>(null) }
    var editing by remember { mutableStateOf<CalibRole?>(null) }
    var localMsg by remember { mutableStateOf<String?>(null) }
    var confirmReset by remember { mutableStateOf(false) }
    var waiting by remember { mutableStateOf<GuidedSetup.Step?>(null) }
    var more by rememberSaveable { mutableStateOf(source != Sub.CAL_LIVE) }
    LaunchedEffect(source) { if (source != Sub.CAL_LIVE) more = true }
    val options by AutopilotRuntime.options.collectAsState()

    val sessionLive = snap.status.isActiveLoop
    val demoRunning = st.phase in DEMO_PHASES
    val observing = st.phase == CalibPhase.OBSERVING
    val saved = profile?.controls?.keys ?: emptySet()
    val liveBlocked = source == Sub.CAL_LIVE && diagnosis.isProblem
    val progress = CalibrationSummaries.progress(st, saved, if (liveBlocked) diagnosis.title else null)
    val summary = CalibrationSummaries.controls(st.detections, saved)

    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(horizontal = Dim.l, vertical = Dim.m),
        verticalArrangement = Arrangement.spacedBy(Dim.m),
    ) {
        Text("Smart Setup", style = MaterialTheme.typography.titleLarge, color = Tokens.TextPrimary)
        Caption("Open the game, connect the screen, tap Auto-Calibrate, then confirm. You only check what HaulPilot is unsure about.")
        (notice ?: note ?: localMsg)?.let { msg ->
            Banner(BannerKind.Info, msg, actionLabel = "OK", onAction = {
                AutopilotRuntime.notice.value = null
                ctl.clearNote()
                localMsg = null
            })
        }

        ScreenCard(actions, nav)
        AutoCalibrateCard(actions, nav, onMoreOptions = { more = true; onSource(Sub.CAL_PICTURES) })

        if (demoRunning) {
            Panel(title = "Demonstration: ${st.role?.label ?: ""}", accent = Tokens.Accent) {
                Text(st.cue ?: st.message, style = MaterialTheme.typography.headlineSmall, color = Tokens.TextPrimary)
                MeterBar(st.progress, Tokens.Accent, height = 8.dp)
                if (st.phase == CalibPhase.PREPARE) Body("Switch to the game now. The phone vibrates when the next step starts, and the floating button’s panel shows the instruction and live progress.")
                AppButton("Cancel demonstration", { ctl.cancel() }, kind = ButtonKind.Secondary)
            }
        }

        // ---- everything else: other sources and manual fixes, folded away by default ------------------------------
        Panel(
            title = "More options",
            subtitle = "Screenshots, a recorded clip, fixing one control, the map by hand",
            trailing = { AppButton(if (more) "Hide" else "Show", { more = !more }, kind = ButtonKind.Ghost, minHeight = 40.dp) },
        ) {
            if (!more) Caption("Not needed when Auto-Calibrate worked. Use these when live capture is not possible or one item needs fixing.")
        }
        if (more) {
        // ---- workspace -------------------------------------------------------------------------------------------
        Panel(title = "Calibration workspace", subtitle = if (st.fromVideo) "Pictures from a recorded clip" else null) {
            ProgressSection(progress)
            if (observing || demoRunning) {
                AppButton("Cancel", { ctl.cancel() }, Modifier.fillMaxWidth(), ButtonKind.Secondary)
            }
            if (progress.complete) {
                Banner(
                    BannerKind.Success, "Calibration complete",
                    "${summary.saved} required control(s) are saved to the profile." +
                        (if (summary.uncertain > 0) " ${summary.uncertain} uncertain control(s) were left out on purpose." else "") +
                        " Finish \"Navigation and screen\" below if it still shows steps to do; the checklist shows what is missing.",
                    actionLabel = "Open the checklist", onAction = { nav.to(MainTab.Profiles, Sub.PROFILE_CHECKLIST) },
                )
            }
            progress.blocker?.let { why ->
                Banner(
                    BannerKind.Warning, "Calibration cannot continue", why,
                    actionLabel = "Retry",
                    onAction = {
                        if (source == Sub.CAL_LIVE && capture && !sessionLive) ctl.startObserving() else onSource(Sub.CAL_CLIP)
                    },
                )
            }
            if (preview == null) {
                EmptyState(
                    "No picture yet",
                    "Choose below where the pictures come from: live play, a recorded clip or screenshots.",
                    icon = IconKind.TARGET,
                )
            } else {
                val prompt = placing
                if (prompt != null) Text("Tap the picture where \"${prompt.label}\" is.", style = MaterialTheme.typography.titleSmall, color = Tokens.Accent)
                val edit = editing
                if (edit != null) Text("Editing \"${edit.label}\": tap to move its region, or use the buttons.", style = MaterialTheme.typography.titleSmall, color = Tokens.Accent)
                val wait = waiting
                if (wait != null) Text("${wait.title}: ${wait.instruction}", style = MaterialTheme.typography.titleSmall, color = Tokens.Primary)
                CalibrationPreview(preview, st, placing, editing, tapPrompt = waiting != null, nav = profile?.nav) { x, y ->
                    val p = placing
                    val e = editing
                    val g = waiting
                    if (p != null) {
                        ctl.place(p, x, y)
                        placing = null
                    } else if (e != null) {
                        moveRegionTo(ctl, st, e, x, y)
                    } else if (g != null) {
                        AutopilotRuntime.notice.value = ctl.guided(g, x, y)
                        waiting = null
                    }
                }
                PreviewLegend()
                editing?.let { role -> EditToolbar(ctl, st, role) { editing = null } }
            }
        }

        // ---- source ---------------------------------------------------------------------------------------------
        Panel(title = "Where do the pictures come from?") {
            SegmentRow(listOf("Live play", "Recorded clip", "Screenshots"), source) { onSource(it) }
            when (source) {
                Sub.CAL_LIVE -> LiveSource(actions, st, capture, access, sessionLive, demoRunning, observing)
                Sub.CAL_CLIP -> ClipSource(actions, st, sessionLive)
                else -> PicturesSource(actions, demoRunning)
            }
        }

        // ---- controls -------------------------------------------------------------------------------------------
        Panel(title = "Controls", subtitle = "${summary.confirmed} confirmed · ${summary.uncertain} uncertain · ${summary.missingRequired} required missing") {
            val roles = CalibrationSummaries.ROLES + listOfNotNull(CalibRole.STEER_WHEEL.takeIf { st.detections.containsKey(it) })
            roles.forEachIndexed { i, role ->
                if (i > 0) HorizontalDivider(color = Tokens.Border)
                ControlRow(
                    role = role, st = st, hasPreview = preview != null,
                    canDemo = source == Sub.CAL_LIVE && st.hud?.ok == true && capture && !sessionLive && !demoRunning,
                    isEditing = editing == role,
                    onDemo = { localMsg = ctl.startDemo(role) },
                    onPlace = { editing = null; waiting = null; placing = role },
                    onEdit = { placing = null; waiting = null; editing = if (editing == role) null else role },
                )
            }
            Caption("Confirm only what you can see is correct. Uncertain controls are never used by the automation.")
        }

        SuggestionsCard(st, applyTiming) { applyTiming = it }

        // ---- save -----------------------------------------------------------------------------------------------
        Panel(title = "Save to the profile") {
            val usable = st.detections.values.count { it.status.usable }
            Body("$usable control(s) are confirmed. Only confirmed ones are copied; uncertain, rejected or missing ones are left out. Your previous profile is kept so you can undo.")
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(Dim.s)) {
                AppButton("Save profile", {
                    val r = ctl.apply(applyTiming)
                    localMsg = r.problem ?: "Saved ${r.applied.size} item(s) to the profile."
                }, Modifier.weight(1f), enabled = usable > 0 && !sessionLive && !demoRunning)
                AppButton("Undo", {
                    localMsg = if (ctl.undo()) "Profile restored to the version before the last change." else "Nothing to undo."
                }, Modifier.weight(1f), ButtonKind.Secondary, enabled = canUndo && !sessionLive)
            }
            lastApply?.let { r ->
                r.problem?.let { Banner(BannerKind.Error, "Not saved", it) }
                r.applied.forEach { Text("✔ $it", style = MaterialTheme.typography.bodySmall, color = Tokens.Success) }
                r.skipped.forEach { Text("• skipped: $it", style = MaterialTheme.typography.bodySmall, color = Tokens.TextSecondary) }
            }
            profile?.let { p -> Caption("Profile \"${p.name}\": ${p.controls.size} control(s), ${p.templates.size} picture(s).") }
            Caption("Next: set up the driving screen and the map in \"Navigation and screen\" below.")
            if (summary.uncertain > 0) Caption("${summary.uncertain} uncertain control(s) will not be saved until you confirm them.", color = Tokens.Warning)
        }

        NavigationSetupPanel(
            profile = profile, st = st, hasPicture = preview != null, busy = demoRunning || sessionLive, waiting = waiting,
            onWait = { s -> placing = null; editing = null; waiting = s },
            onMessage = { m -> AutopilotRuntime.notice.value = m },
        )

        Panel(title = "Start over") {
            AppButton("Reset all learned calibration", { confirmReset = true }, Modifier.fillMaxWidth(), ButtonKind.Ghost, enabled = !demoRunning)
            if (options.advancedTools) {
                AppButton("Open the expert editor", { nav.to(MainTab.Profiles, Sub.PROFILE_MANUAL) }, Modifier.fillMaxWidth(), ButtonKind.Ghost)
            }
        }

        LayoutCard(actions, capture)
        RecordingCard(actions, capture, access)

        Panel(title = "What Smart Setup cannot do") {
            Body(
                "• It sees the same small pictures the automation sees. It cannot read hidden game state.\n" +
                    "• A control is found only if it visibly changes when pressed. Buttons without a visible pressed state need to be placed by tapping.\n" +
                    "• Speed, road position and navigation prompts are not read. The minimap is only a guess until you confirm it; the destination and parking area are found only after you tap them once.\n" +
                    "• Timing comes from your demonstration, including your reaction time, so it is a rough upper bound.\n" +
                    "• A recorded clip is weaker evidence than a live demonstration: its candidates are capped at 70% confidence and always need your confirmation.\n" +
                    "• If the game or Android does not give this app its picture, nothing here can work live, and this app does not try to get around that.",
            )
        }
        }
        CreditFooter()
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("Reset calibration?") },
            text = { Text("The learned controls, timing and layout are cleared. The saved profile is not changed.") },
            confirmButton = { AppButton("Reset", { ctl.resetLearned(); confirmReset = false; editing = null; placing = null }, kind = ButtonKind.Danger) },
            dismissButton = { AppButton("Keep", { confirmReset = false }, kind = ButtonKind.Ghost) },
        )
    }
}


// ---------------------------------------------------------------------------------------------------------------------
// Sources
// ---------------------------------------------------------------------------------------------------------------------

@Composable
private fun LiveSource(
    actions: Actions,
    st: CalibrationState,
    capture: Boolean,
    access: Boolean,
    sessionLive: Boolean,
    demoRunning: Boolean,
    observing: Boolean,
) {
    val ctl = AutopilotRuntime.calibration
    Body(
        "Press Start, switch to the game and drive normally for about 20 seconds so the scenery moves. Buttons and gauges stay put; the world does not. " +
            "Pictures are only analysed while the game is on screen, never this app.",
    )
    CheckRow("Screen capture is on", capture, "Turn screen sharing on; Android asks for your permission.")
    CheckRow("Accessibility service is on", access, "It tells the app whether the game (not this app) is in front, and draws the floating button.")
    CheckRow("No drive is running", !sessionLive, "Stop the drive before calibrating.")
    if (!capture) AppButton("Turn screen capture on", actions.connectCapture, Modifier.fillMaxWidth())
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(Dim.s)) {
        if (!observing) {
            AppButton("Start observing", { ctl.startObserving() }, Modifier.weight(1f), enabled = capture && !sessionLive && !demoRunning)
        } else {
            AppButton("Stop observing", { ctl.stopObserving() }, Modifier.weight(1f), ButtonKind.Secondary)
        }
        AppButton("Retry", { ctl.resetLearned(); ctl.startObserving() }, Modifier.weight(1f), ButtonKind.Secondary, enabled = capture && !sessionLive && !demoRunning)
    }
    Caption("State: ${st.message} · ${st.framesSeen} picture(s) analysed")
    st.hud?.let { h ->
        if (h.ok) Body("Found ${h.elements.size} fixed on-screen element(s) (white outlines in the picture).", color = Tokens.Success)
        else Body(h.problem ?: "No fixed elements found yet.", color = Tokens.Warning)
    }
    // A rejected analysis is not a capture fault: say so explicitly.
    AnalyzerDiagnosis.classify(st.problem)?.let { r ->
        Banner(BannerKind.Info, r.title, AnalyzerDiagnosis.explain(r))
    }
    if (st.layoutUnstable) {
        Banner(
            BannerKind.Warning, "The game's interface changed",
            "Calibration is paused because the layout is no longer consistent. Keep one screen showing, then press Retry.",
        )
    }
}

@Composable
private fun ClipSource(actions: Actions, st: CalibrationState, sessionLive: Boolean) {
    val video by VideoCalibrationRunner.state.collectAsState()
    Body(
        "Use an existing screen recording of about 10 seconds of driving. It should show the accelerator, brake, steering controls and the minimap, " +
            "with the scenery moving.",
    )
    Caption("The clip is used for looking at the picture only. It never sends touches and says nothing about what your truck is doing now.")
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(Dim.s)) {
        AppButton("Import gameplay video", actions.pickVideo, Modifier.weight(1f), icon = IconKind.VIDEO,
            enabled = !sessionLive && video !is VideoUiState.Working)
        AppButton("Browse files", actions.browseVideo, Modifier.weight(1f), ButtonKind.Secondary,
            enabled = !sessionLive && video !is VideoUiState.Working)
    }
    if (sessionLive) Banner(BannerKind.Warning, "A drive is running", "Stop it before calibrating from a clip.")
    when (val v = video) {
        VideoUiState.Idle -> {}
        is VideoUiState.Working -> {
            Text(v.step, style = MaterialTheme.typography.titleSmall, color = Tokens.TextPrimary)
            MeterBar(v.progress, Tokens.Accent)
            AppButton("Cancel", { VideoCalibrationRunner.cancel() }, kind = ButtonKind.Ghost)
        }
        is VideoUiState.Failed -> {
            Banner(BannerKind.Error, "This clip could not be used", v.message)
            v.advice.forEach { Body("• $it") }
            AppButton("Dismiss", { VideoCalibrationRunner.reset() }, kind = ButtonKind.Ghost)
        }
        is VideoUiState.Done -> {
            val r = v.result
            val rep = r.report
            if (!rep.usable) {
                Banner(BannerKind.Error, "Not enough usable pictures in this clip", rep.problems.firstOrNull())
                rep.problems.drop(1).forEach { Body("• $it") }
                rep.advice().forEach { Body("• $it") }
            } else {
                Banner(
                    if (r.hasCandidates) BannerKind.Success else BannerKind.Warning,
                    if (r.hasCandidates) "Read ${rep.framesDecoded} of ${rep.framesRequested} pictures" else "The clip was readable but showed no clear controls",
                    "Everything found is a proposal. Check each marked control in the picture above, then confirm, move or reject it.",
                )
                rep.warnings.forEach { Body("• $it") }
                if (r.missing.isNotEmpty()) {
                    Text("Not found in this clip:", style = MaterialTheme.typography.titleSmall, color = Tokens.TextPrimary)
                    r.missing.forEach { Body("• $it") }
                    Body("Record another clip that shows these, or place them by hand below.")
                }
            }
            if (st.fromVideo) Caption("Showing the picture from your clip.")
            AppButton("Clear clip result", { VideoCalibrationRunner.reset() }, kind = ButtonKind.Ghost)
        }
    }
}

@Composable
private fun PicturesSource(actions: Actions, demoRunning: Boolean) {
    Body(
        "Pick at least 10 screenshots of the game's driving screen taken at different moments (same orientation). " +
            "Screenshots from other apps will not work.",
    )
    AppButton("Pick screenshots", actions.pickScreenshots, Modifier.fillMaxWidth(), ButtonKind.Secondary, enabled = !demoRunning)
}

// ---------------------------------------------------------------------------------------------------------------------
// Controls
// ---------------------------------------------------------------------------------------------------------------------

@Composable
private fun ControlRow(
    role: CalibRole,
    st: CalibrationState,
    hasPreview: Boolean,
    canDemo: Boolean,
    isEditing: Boolean,
    onDemo: () -> Unit,
    onPlace: () -> Unit,
    onEdit: () -> Unit,
) {
    val ctl = AutopilotRuntime.calibration
    val d: ControlDetection? = st.detections[role]
    val status = d?.status ?: DetectionStatus.NONE
    val open = status != DetectionStatus.NONE && status != DetectionStatus.REJECTED
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(Dim.s)) {
        DetectionHeader(role, d)
        d?.evidence?.take(4)?.forEach { Caption("· $it") }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(Dim.s)) {
            if (open && status != DetectionStatus.CONFIRMED) AppButton("Confirm", { ctl.confirm(role) }, minHeight = 40.dp)
            if (open && hasPreview) AppButton(if (isEditing) "Done editing" else "Edit", onEdit, kind = ButtonKind.Secondary, minHeight = 40.dp)
            if (open) AppButton("Reject", { ctl.reject(role) }, kind = ButtonKind.Ghost, minHeight = 40.dp)
            if (!open && hasPreview) AppButton("Place on picture", onPlace, kind = ButtonKind.Secondary, minHeight = 40.dp)
            if (role.demonstrable) {
                AppButton(if (d == null) "Demonstrate" else "Retry", onDemo, kind = ButtonKind.Secondary, enabled = canDemo, minHeight = 40.dp)
            }
        }
        d?.alternatives?.forEachIndexed { i, a ->
            AppButton(
                "Use candidate ${i + 1} (${(a.score * 100).toInt()}%): ${a.note}",
                { ctl.chooseAlternative(role, i) }, Modifier.fillMaxWidth(), ButtonKind.Ghost, minHeight = 40.dp,
            )
        }
        if (!open) {
            val guesses = st.guesses[role].orEmpty()
            if (guesses.isNotEmpty()) {
                Caption("Typical positions (guesses, not detections; you must confirm):")
                guesses.forEachIndexed { i, g ->
                    AppButton("Use guess ${i + 1}: ${g.note}", { ctl.placeFromGuess(role, g) }, Modifier.fillMaxWidth(), ButtonKind.Ghost, minHeight = 40.dp)
                }
            }
        }
    }
}

/** Nudge and resize buttons for the region being edited. Tapping the picture also moves it. */
@Composable
private fun EditToolbar(ctl: CalibrationController, st: CalibrationState, role: CalibRole, onDone: () -> Unit) {
    val box = st.detections[role]?.box ?: run { onDone(); return }
    val step = 0.01f
    Column(verticalArrangement = Arrangement.spacedBy(Dim.s)) {
        Caption("Move")
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(Dim.s)) {
            AppButton("◀ Left", { ctl.setBox(role, box.moved(-step, 0f)) }, kind = ButtonKind.Secondary, minHeight = 40.dp)
            AppButton("Right ▶", { ctl.setBox(role, box.moved(step, 0f)) }, kind = ButtonKind.Secondary, minHeight = 40.dp)
            AppButton("▲ Up", { ctl.setBox(role, box.moved(0f, -step)) }, kind = ButtonKind.Secondary, minHeight = 40.dp)
            AppButton("Down ▼", { ctl.setBox(role, box.moved(0f, step)) }, kind = ButtonKind.Secondary, minHeight = 40.dp)
        }
        Caption("Resize")
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(Dim.s)) {
            AppButton("Smaller", { ctl.setBox(role, box.scaled(0.85f)) }, kind = ButtonKind.Secondary, minHeight = 40.dp)
            AppButton("Larger", { ctl.setBox(role, box.scaled(1.18f)) }, kind = ButtonKind.Secondary, minHeight = 40.dp)
            AppButton("Done", onDone, minHeight = 40.dp)
        }
        Caption("Adjusting a region counts as your confirmation of it.")
    }
}

private fun moveRegionTo(ctl: CalibrationController, st: CalibrationState, role: CalibRole, x: Float, y: Float) {
    val old = st.detections[role]?.box ?: return
    val w = old.right - old.left
    val h = old.bottom - old.top
    val l = (x - w / 2f).coerceIn(0f, 1f - w)
    val t = (y - h / 2f).coerceIn(0f, 1f - h)
    ctl.setBox(role, Roi(l, t, l + w, t + h))
}

private fun Roi.moved(dx: Float, dy: Float): Roi {
    val w = right - left
    val h = bottom - top
    val l = (left + dx).coerceIn(0f, 1f - w)
    val t = (top + dy).coerceIn(0f, 1f - h)
    return Roi(l, t, l + w, t + h)
}

private fun Roi.scaled(factor: Float): Roi {
    val cx = (left + right) / 2f
    val cy = (top + bottom) / 2f
    val w = ((right - left) * factor).coerceIn(0.02f, 0.6f)
    val h = ((bottom - top) * factor).coerceIn(0.02f, 0.6f)
    val l = (cx - w / 2f).coerceIn(0f, 1f - w)
    val t = (cy - h / 2f).coerceIn(0f, 1f - h)
    return Roi(l, t, l + w, t + h)
}
