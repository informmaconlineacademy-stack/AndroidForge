package dev.toe3autopilot.app.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import dev.toe3autopilot.R
import dev.toe3autopilot.app.Brand
import dev.toe3autopilot.core.status.Advice
import dev.toe3autopilot.core.status.AdviceAction
import dev.toe3autopilot.core.status.AdviceSeverity

/**
 * The launcher icon drawn inside the app. Compose cannot draw an adaptive mipmap directly, so the two vector layers are
 * stacked and the outer sixth is cropped the same way a launcher mask does.
 */
@Composable
fun BrandMark(size: Dp, modifier: Modifier = Modifier) {
    Box(modifier.size(size).clip(RoundedCornerShape(size * 0.28f))) {
        val zoom = Modifier.fillMaxSize().graphicsLayer(scaleX = 1.5f, scaleY = 1.5f)
        Image(painterResource(R.drawable.ic_launcher_background), contentDescription = null, modifier = zoom)
        Image(painterResource(R.drawable.ic_launcher_foreground), contentDescription = null, modifier = zoom)
    }
}

/** Quiet creator credit used at the bottom of the main screens. */
@Composable
fun CreditFooter(modifier: Modifier = Modifier) {
    Text(
        "${Brand.APP_NAME} · ${Brand.CREDIT}",
        modifier.fillMaxWidth().padding(top = Dim.s, bottom = Dim.l),
        style = MaterialTheme.typography.bodySmall,
        color = Tokens.TextMuted,
        textAlign = TextAlign.Center,
    )
}

/** Title line at the top of a main screen. */
@Composable
fun ScreenTitle(title: String, subtitle: String? = null) {
    Column(Modifier.fillMaxWidth().padding(horizontal = Dim.l).padding(top = Dim.m)) {
        Text(title, style = MaterialTheme.typography.titleLarge, color = Tokens.TextPrimary)
        if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = Tokens.TextSecondary)
    }
}

fun AdviceSeverity.bannerKind(): BannerKind = when (this) {
    AdviceSeverity.SUCCESS -> BannerKind.Success
    AdviceSeverity.INFO, AdviceSeverity.PROGRESS -> BannerKind.Info
    AdviceSeverity.WARNING -> BannerKind.Warning
    AdviceSeverity.ERROR -> BannerKind.Error
}

/** The most important things to know right now, each with one next step. */
@Composable
fun AdviceList(items: List<Advice>, onAction: (AdviceAction) -> Unit, max: Int = 3) {
    items.take(max).forEach { a ->
        Banner(
            a.severity.bannerKind(), a.title, a.text,
            actionLabel = a.actionLabel.takeIf { a.action != AdviceAction.NONE },
            onAction = if (a.action != AdviceAction.NONE) ({ onAction(a.action) }) else null,
        )
    }
}

/**
 * In-app disclosure shown before the accessibility settings are opened, as Google Play requires for apps that use the
 * Accessibility API without being an accessibility tool: what it accesses, what for, what it does not do, and an explicit
 * choice. Declining keeps the app usable in Assisted mode.
 */
@Composable
fun AccessibilityDisclosureDialog(onAccept: () -> Unit, onDecline: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDecline,
        containerColor = Tokens.Surface,
        title = { Text("Use of the Accessibility service", color = Tokens.TextPrimary) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(Dim.s)) {
                Text(
                    "${Brand.APP_NAME} uses Android's Accessibility service to:",
                    color = Tokens.TextPrimary, style = MaterialTheme.typography.bodyMedium,
                )
                Body(
                    "• press the on-screen driving controls you calibrated (accelerator, brake, steering, reverse) while Auto Drive runs;\n" +
                        "• know which app is in front (package name only), so it only acts while the game is showing;\n" +
                        "• show the small floating control button over the game.",
                )
                Text("It does not:", color = Tokens.TextPrimary, style = MaterialTheme.typography.bodyMedium)
                Body(
                    "• read the text or content of other apps;\n" +
                        "• record your touches, keystrokes or passwords;\n" +
                        "• send any data off your phone (the app has no internet permission).",
                )
                Body("You can switch it off at any time in Android's Accessibility settings. Without it, Assisted mode still shows what to do but sends no touches.")
            }
        },
        confirmButton = { AppButton("I agree, open settings", onAccept) },
        dismissButton = { AppButton("Not now", onDecline, kind = ButtonKind.Ghost) },
    )
}

/** Header brand lock-up. */
@Composable
fun BrandLockup() {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(Dim.s)) {
        BrandMark(30.dp)
        Text(Brand.APP_NAME, style = MaterialTheme.typography.titleMedium, color = Tokens.TextPrimary, maxLines = 1)
    }
}

/** First-run welcome on the Dashboard: what HaulPilot is and the three steps to the first drive. Dismissed for good with OK. */
@Composable
fun WelcomeCard(onSetup: () -> Unit, onDismiss: () -> Unit) {
    Panel(accent = Tokens.Primary) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(Dim.m)) {
            BrandMark(52.dp)
            Column {
                Text("Welcome to ${Brand.APP_NAME}", style = MaterialTheme.typography.titleMedium, color = Tokens.TextPrimary)
                Text(Brand.TAGLINE, style = MaterialTheme.typography.bodyMedium, color = Tokens.Primary)
            }
        }
        Body(
            "1. Smart Setup: show it a few screenshots, a 10-second clip or live play. It finds the controls and asks only about what it is unsure of.\n" +
                "2. In the game, take a job and attach the trailer yourself.\n" +
                "3. Press Start Auto Drive and stay ready to take over. It stops and asks you when it is not sure.",
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(Dim.s)) {
            AppButton("Start Smart Setup", onSetup, Modifier.weight(1f))
            AppButton("OK", onDismiss, kind = ButtonKind.Ghost)
        }
    }
}
