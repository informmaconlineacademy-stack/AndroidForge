package dev.toe3autopilot.app.calibration

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import dev.toe3autopilot.app.AutopilotRuntime
import dev.toe3autopilot.core.calibration.VideoInfo
import dev.toe3autopilot.core.calibration.VideoSamplePlan
import dev.toe3autopilot.core.vision.Frame

/**
 * Reads a recorded gameplay clip the person picked (Photo Picker or the system file picker) and returns a few dozen
 * small pictures from it. The video is only ever read for its pictures: nothing here can send input to the game, and what
 * the clip shows says nothing about the state of the truck now.
 *
 * Uses [MediaMetadataRetriever] (no extra libraries). It does not decode every frame: [VideoSamplePlan] picks about 40
 * moments, each fetched at the processing size.
 */
object VideoImporter {
    sealed class Result {
        class Ok(val info: VideoInfo, val requested: Int, val frames: List<Frame>) : Result()

        /** [message] is written for the person; [technical] is for the log. */
        class Failed(val message: String, val technical: String) : Result()
    }

    /** What [load] found out before decoding, so the caller can reject the file early. */
    fun readInfo(context: Context, uri: Uri): Pair<VideoInfo?, Result.Failed?> {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(context, uri)
            val hasVideo = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_VIDEO) == "yes"
            val duration = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            return VideoInfo(duration, w, h, rot, hasVideo) to null
        } catch (e: SecurityException) {
            return null to Result.Failed("This app is not allowed to read that file. Pick it again with the picker.", "SecurityException")
        } catch (e: RuntimeException) {
            // MediaMetadataRetriever throws plain RuntimeException / IllegalArgumentException for unreadable or unsupported files.
            return null to Result.Failed(
                "That file could not be opened as a video. It may be damaged, empty, or in a format this phone cannot read.",
                e.javaClass.simpleName,
            )
        } finally {
            try {
                r.release()
            } catch (_: Exception) {
            }
        }
    }

    /**
     * Decodes the sampled pictures. [onProgress] gets 0..1 and runs on the calling thread. Call off the main thread.
     * Pictures that cannot be decoded are skipped (the validator reports how many were missing).
     */
    fun load(context: Context, uri: Uri, info: VideoInfo, onProgress: (Float) -> Unit, isCancelled: () -> Boolean = { false }): Result {
        val times = VideoSamplePlan.timestampsMs(info.durationMs)
        if (times.isEmpty()) return Result.Failed("The video has no usable length.", "no timestamps")
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(context, uri)
            val frames = ArrayList<Frame>()
            for ((i, t) in times.withIndex()) {
                if (isCancelled()) return Result.Failed("Cancelled.", "cancelled")
                val f = try {
                    frameAt(r, t)
                } catch (e: Exception) {
                    null
                } catch (e: OutOfMemoryError) {
                    null
                }
                if (f != null) frames += f
                onProgress((i + 1).toFloat() / times.size)
            }
            return Result.Ok(info, times.size, frames)
        } catch (e: SecurityException) {
            return Result.Failed("This app is not allowed to read that file. Pick it again with the picker.", "SecurityException")
        } catch (e: RuntimeException) {
            return Result.Failed("The video could not be read while decoding it.", e.javaClass.simpleName)
        } finally {
            try {
                r.release()
            } catch (_: Exception) {
            }
        }
    }

    private fun frameAt(r: MediaMetadataRetriever, timeMs: Long): Frame? {
        val us = timeMs * 1000L
        val long = AutopilotRuntime.PROCESSING_LONG_SIDE
        val bmp: Bitmap = if (Build.VERSION.SDK_INT >= 27) {
            // Ask the decoder for the final size directly. The retriever rotates the picture upright.
            val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: return null
            val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: return null
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            val (uw, uh) = if (rot == 90 || rot == 270) h to w else w to h
            val scale = long.toFloat() / maxOf(uw, uh)
            val tw = maxOf(2, (uw * scale).toInt() / 2 * 2)
            val th = maxOf(2, (uh * scale).toInt() / 2 * 2)
            r.getScaledFrameAtTime(us, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, tw, th) ?: return null
        } else {
            val full = r.getFrameAtTime(us, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) ?: return null
            val scale = long.toFloat() / maxOf(full.width, full.height)
            val tw = maxOf(2, (full.width * scale).toInt() / 2 * 2)
            val th = maxOf(2, (full.height * scale).toInt() / 2 * 2)
            val scaled = Bitmap.createScaledBitmap(full, tw, th, true)
            if (scaled !== full) full.recycle()
            scaled
        }
        val w = bmp.width
        val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        bmp.recycle()
        return Frame(w, h, px, timeMs)
    }
}
