package dev.toe3autopilot.app.ui

/** The four main destinations of the bottom navigation. */
enum class MainTab(val label: String, val icon: IconKind) {
    Dashboard("Dashboard", IconKind.DASHBOARD),
    Calibration("Smart Setup", IconKind.TARGET),
    Profiles("Profiles", IconKind.PROFILE), // screen title: "Calibration Profiles"
    Settings("Settings", IconKind.SETTINGS),
}

/** Sub-pages. */
object Sub {
    const val CAL_LIVE = 0
    const val CAL_CLIP = 1
    const val CAL_PICTURES = 2

    const val PROFILE_OVERVIEW = 0
    const val PROFILE_CHECKLIST = 1
    const val PROFILE_MANUAL = 2
    const val PROFILE_ADVANCED = 3

    const val SETTINGS_GENERAL = 0
    const val SETTINGS_PERMISSIONS = 1
    const val SETTINGS_DRIVING = 2
    const val SETTINGS_DIAGNOSTICS = 3
    const val SETTINGS_LOGS = 4
    const val SETTINGS_HELP = 5
    const val SETTINGS_ABOUT = 6
}

/** Lets a screen send the person somewhere else in the app. [sub] < 0 keeps the destination's current page. */
class Navigator(val go: (MainTab, Int) -> Unit) {
    fun to(tab: MainTab, sub: Int = -1) = go(tab, sub)
}
