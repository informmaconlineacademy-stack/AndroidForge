package dev.toe3autopilot.core.calibration

import dev.toe3autopilot.core.Clock
import dev.toe3autopilot.core.Point
import dev.toe3autopilot.core.capture.FrameClass
import dev.toe3autopilot.core.capture.FrameOrigin
import dev.toe3autopilot.core.capture.FrameStats
import dev.toe3autopilot.core.vision.Frame
import dev.toe3autopilot.core.vision.Roi
import kotlin.math.max
import kotlin.math.min

/**
 * One-tap Auto-Calibrate.
 *
 * The person opens the game, connects the screen, taps Auto-Calibrate and drives normally for about 15 seconds (using the
 * accelerator and brake as usual). HaulPilot collects live pictures of the game, then runs the same evidence-based analysis
 * used for recorded clips: fixed dashboard elements are separated from moving scenery, and a control whose look changes while
 * the scenery speeds up (or slows down) is proposed as the accelerator (or brake). The minimap is found as a map-sized corner
 * element, its route colour as the most common vivid colour in it.
 *
 * Every stage below reflects real work. Nothing found here is used until the person confirms it, and positions that are only
 * typical-layout guesses (steering, the truck on the minimap) are labelled as guesses and need their own "yes" or a tap.
 */
enum class AutoStage(val title: String) {
    CONNECT("Connecting to the game"),
    FRAMES("Receiving live frames"),
    VIEWPORT("Detecting the game viewport"),
    CONTROLS("Identifying driving controls"),
    ROAD("Detecting the road and vehicle"),
    VALIDATE("Validating detections"),
    READY("Ready to test"),
}

enum class StageStatus { WAITING, RUNNING, DONE, NEEDS_YOU, FAILED }

data class StageLine(val stage: AutoStage, val status: StageStatus, val detail: String)

enum class RunPhase { IDLE, COLLECTING, ANALYSING, REVIEW, FAILED, CANCELLED }

/** What the person can do to recover from a failed stage. */
enum class Recovery { CONNECT_SCREEN, OPEN_GAME, CHOOSE_GAME, DRIVE_AND_RETRY, USE_SCREENSHOT_OR_CLIP, RETRY }

/** Something the person has to look at before confirming, kept as small as possible. */
data class Correction(val role: CalibRole?, val what: String, val ask: String)

data class AutoResult(
    val viewport: Roi,
    val video: VideoCalibrationResult,
    val minimap: MinimapSuggestion?,
    /** Typical position of the truck arrow inside the minimap; a guess, shown for a yes/no. */
    val truckGuess: Point?,
    val drivingMarker: HudElement?,
    /** Controls proposed from evidence in the pictures (confirm with one tap). */
    val evidenceRoles: List<CalibRole>,
    /** The smallest set of things the person must answer or tap before driving. */
    val corrections: List<Correction>,
    val checks: List<String>,
)

data class AutoRunState(
    val phase: RunPhase = RunPhase.IDLE,
    val stages: List<StageLine> = AutoStage.entries.map { StageLine(it, StageStatus.WAITING, "") },
    val collected: Int = 0,
    val target: Int = AutoCalibrationRun.TARGET_FRAMES,
    val problem: String? = null,
    val recovery: Recovery? = null,
    val result: AutoResult? = null,
) {
    val running: Boolean get() = phase == RunPhase.COLLECTING || phase == RunPhase.ANALYSING
}

class AutoCalibrationRun(
    private val clock: Clock,
    private val target: Int = TARGET_FRAMES,
    private val spacingMs: Long = SPACING_MS,
    private val noGameTimeoutMs: Long = NO_GAME_TIMEOUT_MS,
) {
    private val lock = Any()
    private var st = AutoRunState()
    private val frames = ArrayList<Frame>()
    private var startedAt = 0L
    private var lastTakenAt = Long.MIN_VALUE / 2
    private var lastGameAt = 0L
    private var lastOrigin: FrameOrigin? = null

    fun state(): AutoRunState = synchronized(lock) { st }

    fun start() = synchronized(lock) {
        frames.clear()
        startedAt = clock.nowMs()
        lastTakenAt = Long.MIN_VALUE / 2
        lastGameAt = 0L
        lastOrigin = null
        st = AutoRunState(phase = RunPhase.COLLECTING, target = target)
        stage(AutoStage.CONNECT, StageStatus.RUNNING, "Checking the screen connection")
    }

    fun cancel() = synchronized(lock) {
        if (st.running) st = st.copy(phase = RunPhase.CANCELLED, problem = "Cancelled.", recovery = null)
        frames.clear()
    }

    fun reset() = synchronized(lock) {
        frames.clear()
        st = AutoRunState()
    }

    /**
     * Called regularly while collecting with the screen-link facts. [linkProblem] non-null means capture is not usable.
     * [origin] is who is in front right now.
     */
    fun onLink(captureOn: Boolean, linkProblem: String?, origin: FrameOrigin?) = synchronized(lock) {
        if (st.phase != RunPhase.COLLECTING) return
        val now = clock.nowMs()
        lastOrigin = origin
        when {
            linkProblem != null -> fail(AutoStage.CONNECT, linkProblem, Recovery.CONNECT_SCREEN)
            !captureOn -> {
                stage(AutoStage.CONNECT, StageStatus.NEEDS_YOU, "Connect the screen (Android asks for permission).")
                if (now - startedAt > noGameTimeoutMs) fail(AutoStage.CONNECT, "The screen was not connected.", Recovery.CONNECT_SCREEN)
            }
            else -> {
                stage(AutoStage.CONNECT, StageStatus.DONE, "Screen connected")
                if (frames.isEmpty()) {
                    val waitingFor = when (origin) {
                        FrameOrigin.OWN_APP -> "Switch to the game and drive normally."
                        FrameOrigin.OTHER_APP -> "The app in front is not the selected game. Open the game, or mark the app in front as the game."
                        else -> "Waiting for pictures of the game."
                    }
                    stage(AutoStage.FRAMES, if (origin == FrameOrigin.OTHER_APP) StageStatus.NEEDS_YOU else StageStatus.RUNNING, waitingFor)
                }
                val since = if (lastGameAt == 0L) startedAt else lastGameAt
                if (now - since > noGameTimeoutMs) {
                    val (msg, rec) = when (origin) {
                        FrameOrigin.OTHER_APP -> "No pictures of the selected game arrived: another app was in front." to Recovery.CHOOSE_GAME
                        FrameOrigin.OWN_APP -> "No pictures of the game arrived: HaulPilot stayed in front." to Recovery.OPEN_GAME
                        else -> "No pictures of the game arrived for ${noGameTimeoutMs / 1000} s." to Recovery.OPEN_GAME
                    }
                    fail(AutoStage.FRAMES, msg, rec)
                }
            }
        }
    }

    /** Offers one captured picture. Only pictures of the game are kept, at most one every [spacingMs]. */
    fun offer(frame: Frame, origin: FrameOrigin) = synchronized(lock) {
        if (st.phase != RunPhase.COLLECTING) return
        if (origin != FrameOrigin.GAME && origin != FrameOrigin.UNKNOWN) return
        val now = clock.nowMs()
        lastGameAt = now
        if (now - lastTakenAt < spacingMs) return
        val first = frames.firstOrNull()
        if (first != null && (first.width != frame.width || first.height != frame.height)) {
            // Rotation or a different capture size: start again with the new layout instead of mixing two.
            frames.clear()
            stage(AutoStage.FRAMES, StageStatus.RUNNING, "The screen size changed; starting the collection again")
        }
        val c = FrameStats.of(frame).classify()
        if (c == FrameClass.ALL_BLACK || c == FrameClass.SOLID_COLOUR) {
            stage(AutoStage.FRAMES, StageStatus.RUNNING, "Black or blank pictures are being ignored (${frames.size}/$target usable)")
            return
        }
        lastTakenAt = now
        frames += frame
        stage(AutoStage.CONNECT, StageStatus.DONE, "Screen connected")
        stage(AutoStage.FRAMES, if (frames.size >= target) StageStatus.DONE else StageStatus.RUNNING, "${frames.size} of $target pictures of the game")
        st = st.copy(collected = frames.size)
        if (frames.size >= target) st = st.copy(phase = RunPhase.ANALYSING)
    }

    /** True when enough pictures were collected and [analyse] should be called (on a background thread). */
    fun readyToAnalyse(): Boolean = synchronized(lock) { st.phase == RunPhase.ANALYSING && st.result == null }

    fun collectedFrames(): List<Frame> = synchronized(lock) { frames.toList() }

    /** Runs all analysis stages on the collected pictures. Returns the representative picture for the preview. */
    fun analyse(): Frame? {
        val pics = synchronized(lock) { frames.toList() }
        if (pics.size < HudAnalyzer.MIN_FRAMES) {
            synchronized(lock) { fail(AutoStage.FRAMES, "Too few pictures of the game (${pics.size}).", Recovery.OPEN_GAME) }
            return null
        }
        // ---- viewport ----
        synchronized(lock) { stage(AutoStage.VIEWPORT, StageStatus.RUNNING, "Looking for the area the game draws in") }
        val vp = ViewportDetector.detect(pics)
        val vpShare = (vp.right - vp.left) * (vp.bottom - vp.top)
        if (vpShare < 0.5f) {
            synchronized(lock) {
                fail(AutoStage.VIEWPORT, "Only ${(vpShare * 100).toInt()}% of the picture shows the game; the rest stays black. The game may block capture, or capture shows only part of the screen.", Recovery.USE_SCREENSHOT_OR_CLIP)
            }
            return null
        }
        synchronized(lock) {
            stage(
                AutoStage.VIEWPORT, StageStatus.DONE,
                if (vpShare > 0.97f) "The game fills the screen (${pics.first().width}x${pics.first().height})"
                else "The game uses ${(vpShare * 100).toInt()}% of the screen (black bars ignored)",
            )
            stage(AutoStage.CONTROLS, StageStatus.RUNNING, "Separating fixed buttons from moving scenery")
        }
        // ---- controls (same evidence-based analysis as recorded clips) ----
        val first = pics.first()
        val info = VideoInfo(durationMs = max(VideoValidator.MIN_DURATION_MS, (pics.size.toLong() * spacingMs)), width = first.width, height = first.height)
        val video = VideoCalibrationAnalyzer.analyse(info, pics.size, pics)
        val hud = video.hud
        if (!video.report.usable || hud == null || !hud.ok) {
            val why = video.report.problems.firstOrNull() ?: hud?.problem ?: "No fixed buttons could be separated from the scenery."
            synchronized(lock) { fail(AutoStage.CONTROLS, "$why Drive so the scenery moves, and press the accelerator and brake once or twice.", Recovery.DRIVE_AND_RETRY) }
            return null
        }
        val evidence = video.detections.values.filter { it.status == DetectionStatus.NEEDS_CONFIRMATION && it.source == DetectionSource.VIDEO }.map { it.role }
        val guesses = video.detections.values.filter { it.status == DetectionStatus.NEEDS_CONFIRMATION && it.source == DetectionSource.PRIOR }.map { it.role }
        synchronized(lock) {
            stage(
                AutoStage.CONTROLS, if (CalibRole.ACCELERATOR in evidence && CalibRole.BRAKE in evidence) StageStatus.DONE else StageStatus.NEEDS_YOU,
                "${hud.elements.size} fixed elements; found from evidence: " + (evidence.joinToString { it.label }.ifEmpty { "none" }) +
                    (if (guesses.isNotEmpty()) "; position guesses: " + guesses.joinToString { it.label } else ""),
            )
            stage(AutoStage.ROAD, StageStatus.RUNNING, "Looking for the minimap and the route line")
        }
        // ---- road and vehicle ----
        val mm = video.minimap
        val truck = mm?.let { Point((it.box.left + it.box.right) / 2f, it.box.top + (it.box.bottom - it.box.top) * 0.72f) }
        synchronized(lock) {
            stage(
                AutoStage.ROAD, if (mm != null && mm.routeColorRgb != null) StageStatus.DONE else StageStatus.NEEDS_YOU,
                when {
                    mm == null -> "No minimap found. You will be asked to tap it."
                    mm.routeColorRgb == null -> "Minimap found; no route colour seen. You will be asked to tap the route line."
                    else -> "Minimap and a route colour found. The truck position on the map is a guess for you to check."
                },
            )
            stage(AutoStage.VALIDATE, StageStatus.RUNNING, "Checking the results")
        }
        // ---- validate ----
        val checks = ArrayList<String>()
        val half = pics.size / 2
        val stable = if (half >= HudAnalyzer.MIN_FRAMES) {
            val a = HudAnalyzer.analyse(pics.subList(0, half))
            val b = HudAnalyzer.analyse(pics.subList(half, pics.size))
            !(a.ok && b.ok) || LayoutStability.consistent(a, b)
        } else {
            true
        }
        if (!stable) {
            synchronized(lock) { fail(AutoStage.VALIDATE, "The game's interface changed during the collection (a menu or another screen). Stay on the driving screen and try again.", Recovery.RETRY) }
            return null
        }
        checks += "The dashboard stayed in place during the whole collection."
        val avoid = video.detections.values.mapNotNull { if (it.status == DetectionStatus.NONE) null else it.box } + listOfNotNull(mm?.box)
        val marker = GuidedSetup.pickDrivingMarker(hud, avoid)
        if (marker != null) checks += "A steady part of the dashboard can identify the driving screen." else checks += "No steady dashboard part was found to identify the driving screen."
        video.report.warnings.forEach { checks += it }

        val corrections = ArrayList<Correction>()
        for (r in listOf(CalibRole.ACCELERATOR, CalibRole.BRAKE)) {
            if (r !in evidence) corrections += Correction(r, "${r.label} not found", "Tap the ${r.label.lowercase()} on the picture.")
        }
        for (r in listOf(CalibRole.STEER_LEFT, CalibRole.STEER_RIGHT)) {
            corrections += if (r in guesses) Correction(r, "${r.label} is a guess", "Is the ${r.label.lowercase()} control where the box is? Tap Yes, or tap the right place.")
            else Correction(r, "${r.label} not found", "Tap the ${r.label.lowercase()} control on the picture.")
        }
        if (mm == null) corrections += Correction(null, "Minimap not found", "Tap the middle of the minimap.")
        else if (mm.routeColorRgb == null) corrections += Correction(null, "Route line not found", "Tap the coloured route line on the minimap.")
        if (truck != null) corrections += Correction(null, "Truck on the map is a guess", "Is your truck at the orange circle on the map? Tap Yes, or tap your truck.")
        if (marker == null) corrections += Correction(null, "Driving screen", "Retry Auto-Calibrate while the normal driving view is showing.")

        val result = AutoResult(vp, video, mm, truck, marker, evidence, corrections, checks)
        synchronized(lock) {
            stage(AutoStage.VALIDATE, StageStatus.DONE, checks.first())
            stage(
                AutoStage.READY, if (corrections.isEmpty()) StageStatus.DONE else StageStatus.NEEDS_YOU,
                if (corrections.isEmpty()) "Review the picture and tap Confirm." else "${corrections.size} small check(s) before you confirm.",
            )
            st = st.copy(phase = RunPhase.REVIEW, result = result, problem = null, recovery = null)
        }
        return pics.last()
    }

    private fun stage(s: AutoStage, status: StageStatus, detail: String) {
        st = st.copy(stages = st.stages.map { if (it.stage == s) StageLine(s, status, detail) else it })
    }

    private fun fail(s: AutoStage, why: String, recovery: Recovery) {
        stage(s, StageStatus.FAILED, why)
        st = st.copy(phase = RunPhase.FAILED, problem = why, recovery = recovery)
    }

    companion object {
        const val TARGET_FRAMES = 45
        const val SPACING_MS = 330L
        const val NO_GAME_TIMEOUT_MS = 60_000L
    }
}

/** Finds the part of the picture the game actually draws in (ignores black bars that stay black in every picture). */
object ViewportDetector {
    private const val DARK = 24

    fun detect(frames: List<Frame>): Roi {
        val f0 = frames.first()
        val w = f0.width
        val h = f0.height
        val colMax = IntArray(w)
        val rowMax = IntArray(h)
        for (f in frames) {
            if (f.width != w || f.height != h) continue
            var i = 0
            for (y in 0 until h) {
                for (x in 0 until w) {
                    val p = f.argb[i++]
                    val v = max((p shr 16) and 0xFF, max((p shr 8) and 0xFF, p and 0xFF))
                    if (v > colMax[x]) colMax[x] = v
                    if (v > rowMax[y]) rowMax[y] = v
                }
            }
        }
        val x0 = colMax.indexOfFirst { it > DARK }.let { if (it < 0) 0 else it }
        val x1 = colMax.indexOfLast { it > DARK }.let { if (it < 0) w - 1 else it }
        val y0 = rowMax.indexOfFirst { it > DARK }.let { if (it < 0) 0 else it }
        val y1 = rowMax.indexOfLast { it > DARK }.let { if (it < 0) h - 1 else it }
        if (x1 <= x0 || y1 <= y0) return Roi(0f, 0f, 1f / w, 1f / h)
        return Roi(x0.toFloat() / w, y0.toFloat() / h, (x1 + 1).toFloat() / w, (y1 + 1).toFloat() / h)
    }
}

/**
 * Tap-to-identify: when the person taps a control, use the fixed on-screen element under the finger (so the region fits the
 * button) instead of a box of arbitrary size. Falls back to a square around the tap.
 */
object TapSnap {
    fun boxFor(hud: HudAnalysis?, x: Float, y: Float, aspect: Float, fallbackHeight: Float = 0.12f): Roi {
        val hit = hud?.elements
            ?.filter { x >= it.box.left && x <= it.box.right && y >= it.box.top && y <= it.box.bottom && it.areaFraction <= 0.08f }
            ?.minByOrNull { it.areaFraction }
        if (hit != null) return hit.box
        val h = fallbackHeight
        val w = (h / aspect).coerceIn(0.03f, 0.3f)
        val l = (x - w / 2).coerceIn(0f, 1f - w)
        val t = (y - h / 2).coerceIn(0f, 1f - h)
        return Roi(l, t, l + w, t + h)
    }
}

/**
 * Zoom and pan of the calibration picture. A tap in view pixels is turned back into picture coordinates (0..1); taps
 * outside the picture are ignored so a pan near the edge never selects anything by accident.
 */
data class ViewTransform(val viewW: Float, val viewH: Float, val scale: Float = 1f, val offsetX: Float = 0f, val offsetY: Float = 0f) {
    fun toImage(tx: Float, ty: Float): Pair<Float, Float>? {
        if (viewW <= 0f || viewH <= 0f) return null
        val x = (tx - offsetX) / (viewW * scale)
        val y = (ty - offsetY) / (viewH * scale)
        return if (x in 0f..1f && y in 0f..1f) x to y else null
    }

    /** Applies a pinch/drag and keeps the picture covering the view (no empty space, scale 1..5). */
    fun transformed(zoom: Float, panX: Float, panY: Float, centroidX: Float, centroidY: Float): ViewTransform {
        val newScale = (scale * zoom).coerceIn(1f, MAX_SCALE)
        val k = newScale / scale
        var ox = centroidX - (centroidX - offsetX) * k + panX
        var oy = centroidY - (centroidY - offsetY) * k + panY
        ox = ox.coerceIn(viewW - viewW * newScale, 0f)
        oy = oy.coerceIn(viewH - viewH * newScale, 0f)
        return copy(scale = newScale, offsetX = ox, offsetY = oy)
    }

    companion object {
        const val MAX_SCALE = 5f
    }
}
