package dev.toe3autopilot.core.calibration

import dev.toe3autopilot.core.vision.Frame
import dev.toe3autopilot.core.vision.MotionEstimator
import dev.toe3autopilot.core.vision.Roi
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/** One captured frame with the time it was observed (milliseconds, any consistent clock). */
class TimedFrame(val timeMs: Long, val frame: Frame)

/** How one HUD element reacted during a demonstration. */
data class ElementResponse(
    val element: HudElement,
    /** Mean absolute grey-level change of the element's pixels between the idle and the "pressed" frames. */
    val diff: Float,
    /** Mean temporal noise of the element while idle. */
    val idleNoise: Float,
    /** Fraction of the settled part of the action window in which the change was present. 1 = held the whole time. */
    val sustain: Float,
    /** Mean temporal change of the element within the action window (digits that keep changing score high here). */
    val actionVariation: Float,
    val score: Float,
)

data class DemoResult(
    val detection: ControlDetection,
    val responses: List<ElementResponse>,
    val speedReadoutGuess: Alternative?,
)

/**
 * Works out which HUD element reacted when the person demonstrated an action.
 *
 * Input: frames while they touched nothing (baseline) and frames while they held a control (action). The control
 * is the HUD element whose pixels changed and STAYED changed during the hold (a pressed state / highlighted
 * state), more than any other element. This only uses the pictures; no touch data is read.
 *
 * Limits: a game that shows no visible pressed state gives no evidence, and the result is then NONE or low
 * confidence. The first ~30% of the action window is ignored to allow for human reaction time.
 */
object DemoAnalyzer {
    const val MIN_BASELINE_FRAMES = 4
    const val MIN_ACTION_FRAMES = 6
    private const val SETTLE_FRACTION = 0.3f
    private const val NOISE_FLOOR = 2f
    private const val STRONG_EFFECT = 24f
    private const val MIN_STRENGTH = 0.15f

    fun analyse(
        role: CalibRole,
        hud: HudAnalysis,
        baseline: List<TimedFrame>,
        action: List<TimedFrame>,
    ): DemoResult {
        val w = hud.frameWidth
        val h = hud.frameHeight
        val base = baseline.map { it.frame }.filter { it.width == w && it.height == h }
        val act = action.map { it.frame }.filter { it.width == w && it.height == h }
        if (base.size < MIN_BASELINE_FRAMES || act.size < MIN_ACTION_FRAMES) {
            return DemoResult(
                ControlDetection.none(role, "Too few frames were captured (idle ${base.size}, action ${act.size}); capture may be too slow"),
                emptyList(), null,
            )
        }
        if (hud.elements.isEmpty()) {
            return DemoResult(ControlDetection.none(role, "No HUD elements are known; observe the HUD first"), emptyList(), null)
        }

        val baseGray = base.map { it.toGray().px }
        val actGray = act.map { it.toGray().px }
        val n = w * h
        val baseMean = FloatArray(n)
        for (g in baseGray) for (i in 0 until n) baseMean[i] += g[i].toFloat()
        for (i in 0 until n) baseMean[i] /= baseGray.size
        val settledStart = (actGray.size * SETTLE_FRACTION).toInt().coerceAtMost(actGray.size - 3)
        val settled = actGray.subList(settledStart, actGray.size)
        val actMean = FloatArray(n)
        for (g in settled) for (i in 0 until n) actMean[i] += g[i].toFloat()
        for (i in 0 until n) actMean[i] /= settled.size

        val responses = hud.elements.map { e -> respond(e, w, h, baseGray, baseMean, actGray, actMean, settled) }
        val ranked = responses.sortedByDescending { it.score }
        val best = ranked.first()
        val second = ranked.getOrNull(1)?.score ?: 0f

        // Speed readout guess: something that keeps changing during the action while it was quiet when idle.
        val speed = if (role == CalibRole.ACCELERATOR) {
            responses
                .filter { it !== best && it.actionVariation >= 6f && it.actionVariation > 2.5f * (it.idleNoise + 1f) }
                .maxByOrNull { it.actionVariation }
                ?.let { Alternative(it.element.cx, it.element.cy, it.element.box, 0.3f, "its content kept changing while accelerating; the value is NOT read") }
        } else {
            null
        }

        if (best.score < MIN_STRENGTH * 0.5f) {
            return DemoResult(
                ControlDetection.none(
                    role,
                    "No HUD element visibly changed while you held the control; this game may show no pressed state, so place it manually",
                    alternatives = ranked.take(3).filter { it.score > 0f }.map { toAlt(it, 0.2f, "weak change") },
                ),
                responses, speed,
            )
        }

        // Evidence
        val strengthRaw = ((best.diff - best.idleNoise * 1.5f) / STRONG_EFFECT).coerceIn(0f, 1f)
        val strength = (strengthRaw * 1.25f).coerceAtMost(1f)
        val uniqueness = if (best.score <= 0f) 0f else (1f - second / best.score).coerceIn(0f, 1f)
        val many = responses.count { it.diff > 0.5f * best.diff && it.diff > 6f }
        val evidence = ArrayList<String>()
        evidence += "pixels changed by ${"%.0f".format(best.diff)} grey levels (idle noise ${"%.1f".format(best.idleNoise)})"
        evidence += "change present in ${(best.sustain * 100).toInt()}% of the settled hold window"
        evidence += "next-best element scored ${"%.0f".format(100f * if (best.score > 0f) second / best.score else 0f)}% of this one"
        var conf = 0.45f * strength + 0.35f * uniqueness + 0.20f * best.sustain
        if (many > max(3, hud.elements.size / 2)) {
            conf = min(conf, 0.5f)
            evidence += "many HUD elements changed together (flash or view change), so this is unreliable"
        }
        conf = conf.coerceIn(0f, 0.95f)
        val status = if (conf >= ControlDetection.AUTO_CONFIRM_MIN && many <= max(3, hud.elements.size / 2)) {
            DetectionStatus.AUTO_CONFIRMED
        } else {
            DetectionStatus.NEEDS_CONFIRMATION
        }
        val alternatives = ranked.drop(1).take(3).filter { it.score > 0f }.map { toAlt(it, (conf * it.score / best.score).coerceAtMost(conf), "also changed") }
        val det = ControlDetection(
            role = role, x = best.element.cx, y = best.element.cy, box = best.element.box,
            confidence = conf, status = status, source = DetectionSource.DEMONSTRATION,
            evidence = evidence, alternatives = alternatives,
        )
        return DemoResult(det, responses, speed)
    }

    private fun toAlt(r: ElementResponse, score: Float, note: String) =
        Alternative(r.element.cx, r.element.cy, r.element.box, score.coerceIn(0f, 1f), note)

    private fun respond(
        e: HudElement, w: Int, h: Int,
        baseGray: List<IntArray>, baseMean: FloatArray,
        actGray: List<IntArray>, actMean: FloatArray, settled: List<IntArray>,
    ): ElementResponse {
        val r = e.box.toRect(w, h)
        var diffSum = 0.0
        var noiseSum = 0.0
        var count = 0
        for (y in r.y0 until r.y1) for (x in r.x0 until r.x1) {
            val i = y * w + x
            diffSum += abs(actMean[i] - baseMean[i])
            var v = 0.0
            for (g in baseGray) {
                val d = g[i] - baseMean[i]
                v += d * d
            }
            noiseSum += sqrt(v / baseGray.size)
            count++
        }
        val diff = (diffSum / count).toFloat()
        val noise = max(NOISE_FLOOR, (noiseSum / count).toFloat())

        // How many of the settled action frames show at least half of the average change?
        var sustained = 0
        for (g in settled) {
            var s = 0.0
            for (y in r.y0 until r.y1) for (x in r.x0 until r.x1) {
                val i = y * w + x
                s += abs(g[i] - baseMean[i])
            }
            if (s / count >= 0.5f * diff && diff > noise) sustained++
        }
        val sustain = sustained.toFloat() / settled.size

        // Variation inside the action window (frame to frame).
        var varSum = 0.0
        var pairs = 0
        for (k in 1 until actGray.size) {
            var s = 0.0
            for (y in r.y0 until r.y1) for (x in r.x0 until r.x1) {
                val i = y * w + x
                s += abs(actGray[k][i] - actGray[k - 1][i])
            }
            varSum += s / count
            pairs++
        }
        val variation = if (pairs == 0) 0f else (varSum / pairs).toFloat()

        val effect = max(0f, diff - noise * 1.5f)
        val strength = (effect / STRONG_EFFECT).coerceIn(0f, 1f)
        // A pressed state is a change that stays; digits that tick over are a change that keeps moving.
        val steadiness = if (variation <= 0f) 1f else (1f - (variation / max(diff, 1f)).coerceIn(0f, 0.8f))
        return ElementResponse(e, diff, noise, sustain, variation, strength * sustain * steadiness)
    }
}

/** Estimates "stopped" motion level and response timing from an accelerate-then-release demonstration. */
object TimingAnalyzer {
    private const val MIN_SEPARATION = 0.003f

    /**
     * @param actionStartMs time of the "NOW" cue; @param releaseStartMs time of the "release" cue (or null).
     */
    fun estimate(
        baseline: List<TimedFrame>,
        action: List<TimedFrame>,
        release: List<TimedFrame>,
        actionStartMs: Long,
        releaseStartMs: Long?,
        worldRoi: Roi,
    ): TimingEstimate {
        val notes = ArrayList<String>()
        val est = MotionEstimator(worldRoi)
        val baseM = baseline.mapIndexedNotNull { i, f -> est.update(f.frame).let { m -> if (i == 0) null else f.timeMs to m } }
        val actM = action.map { it.timeMs to est.update(it.frame) }
        val relM = release.map { it.timeMs to est.update(it.frame) }
        if (baseM.size < 3 || actM.size < 4) {
            return TimingEstimate(null, 0f, 0f, null, null, null, listOf("Too few frames to estimate timing"))
        }
        val rest = median(baseM.map { it.second })
        val tail = actM.drop(actM.size / 2).map { it.second }
        val moving = median(tail)
        notes += "world motion at rest ${"%.4f".format(rest)}, while accelerating ${"%.4f".format(moving)}"
        if (moving - rest < MIN_SEPARATION) {
            notes += "the picture did not change enough when accelerating (truck blocked, still camera, or capture too slow); thresholds not estimated"
            return TimingEstimate(null, rest, moving, null, null, null, notes)
        }
        val threshold = max(0.001f, rest + 0.3f * (moving - rest))
        val moveLevel = rest + 0.5f * (moving - rest)
        val start = actM.firstOrNull { it.second >= moveLevel }?.let { it.first - actionStartMs }?.coerceAtLeast(0L)
        if (start != null) notes += "motion began ~${start} ms after the cue (includes your reaction time; an upper bound)"
        var stop: Long? = null
        var settle: Long? = null
        if (releaseStartMs != null && relM.isNotEmpty()) {
            val hit = relM.firstOrNull { it.first >= releaseStartMs && it.second <= threshold }
            if (hit != null) {
                stop = (hit.first - releaseStartMs).coerceAtLeast(0L)
                settle = (stop + 200L).coerceIn(300L, 3000L)
                notes += "motion fell below the threshold ~${stop} ms after the release cue (includes your reaction time)"
            } else {
                notes += "the truck did not come to rest within the release window; settle time not estimated"
            }
        }
        return TimingEstimate(threshold, rest, moving, start, stop, settle, notes)
    }

    private fun median(v: List<Float>): Float {
        if (v.isEmpty()) return 0f
        val s = v.sorted()
        return if (s.size % 2 == 1) s[s.size / 2] else (s[s.size / 2 - 1] + s[s.size / 2]) / 2f
    }
}
