package dev.toe3autopilot.core.overlay

import dev.toe3autopilot.core.calibration.CalibPhase
import dev.toe3autopilot.core.calibration.CalibrationProgress
import dev.toe3autopilot.core.calibration.CalibrationState
import dev.toe3autopilot.core.calibration.ControlSummary
import dev.toe3autopilot.core.calibration.StageState
import dev.toe3autopilot.core.calibration.AutoRunState
import dev.toe3autopilot.core.calibration.RunPhase
import dev.toe3autopilot.core.calibration.StageStatus
import dev.toe3autopilot.core.capture.LinkAction
import dev.toe3autopilot.core.capture.LinkState
import dev.toe3autopilot.core.capture.LinkStatus
import dev.toe3autopilot.core.session.SessionSnapshot
import dev.toe3autopilot.core.session.SessionStatus
import dev.toe3autopilot.core.session.UserState
import dev.toe3autopilot.core.session.userState
import kotlin.math.abs
import kotlin.math.roundToInt

/** Colour family of the floating button's state dot (mapped to real colours by the Android layer). */
enum class OverlayTone { NEUTRAL, ACTIVE, CALIBRATING, WARNING, DANGER, DONE }

/** Everything the floating controls show, taken from the app's real state at one moment. */
data class OverlayInputs(
    val snapshot: SessionSnapshot,
    val captureOn: Boolean,
    /** Countdown / arming message while START AUTO DRIVE is preparing, null otherwise. */
    val armedMessage: String?,
    val calibration: CalibrationState,
    val progress: CalibrationProgress,
    val controls: ControlSummary,
    /** One-off message from the last button press on the panel (for example why Start was refused). */
    val note: String?,
    val recordingSnapshots: Boolean,
    /** The person's "show floating controls while capture is on" setting. */
    val showWhileCaptureOn: Boolean,
    /** Screen connection status (null = not known yet). */
    val link: LinkStatus? = null,
    /** One-tap Auto-Calibrate run. */
    val auto: AutoRunState = AutoRunState(),
    /** The app in front could be the game but is not the selected one. */
    val canAdoptGame: Boolean = false,
)

/** Calibration block of the expanded panel. All numbers come from [CalibrationProgress] / [ControlSummary]. */
data class OverlayCalibration(
    val stageTitle: String,
    val stageDetail: String,
    /** 0..100 */
    val percent: Int,
    val confirmed: Int,
    val uncertain: Int,
    val missingRequired: Int,
    /** Why calibration cannot continue, null when it can. */
    val blocker: String?,
)

data class OverlayUi(
    val visible: Boolean,
    val state: UserState,
    val tone: OverlayTone,
    /** One or two lines: what is happening or what to do. */
    val status: String,
    val canStartDrive: Boolean,
    val canStartCalibration: Boolean,
    val canCancelCalibration: Boolean,
    val canPause: Boolean,
    val canResume: Boolean,
    /** Ends the drive or cancels the countdown. */
    val canEnd: Boolean,
    val endLabel: String,
    /** Emergency Stop is offered whenever the controls are visible. */
    val canEmergency: Boolean,
    /** Shown while calibration runs or has results to review; null otherwise. */
    val calibration: OverlayCalibration?,
    /** Draws attention on the collapsed button (help needed, emergency stop) without expanding it. */
    val attention: Boolean,
    /** Progress ring on the collapsed button, 0..1, only while calibrating. */
    val ring: Float?,
    val recording: Boolean,
    /** "Screen connected" etc. */
    val linkLabel: String? = null,
    /** Live pictures of the game are arriving. */
    val linkOk: Boolean = false,
    val canAutoCalibrate: Boolean = false,
    val canAdoptGame: Boolean = false,
)

object OverlayModel {
    fun toneOf(s: UserState): OverlayTone = when (s) {
        UserState.DRIVING, UserState.APPROACHING_TURN, UserState.APPROACHING_DELIVERY, UserState.PARKING -> OverlayTone.ACTIVE
        UserState.PARKED -> OverlayTone.DONE
        UserState.NEEDS_ASSISTANCE, UserState.EMERGENCY_STOP -> OverlayTone.DANGER
        UserState.PAUSED, UserState.STARTING -> OverlayTone.WARNING
        UserState.CALIBRATING -> OverlayTone.CALIBRATING
        UserState.READY -> OverlayTone.NEUTRAL
    }

    fun build(i: OverlayInputs): OverlayUi {
        val snap = i.snapshot
        val st = snap.status
        val live = st == SessionStatus.STARTING || st == SessionStatus.RUNNING || st == SessionStatus.PAUSED || st == SessionStatus.NEEDS_ASSIST
        val autoRunning = i.auto.running
        val calibrating = (i.calibration.phase != CalibPhase.IDLE && i.calibration.phase != CalibPhase.DONE) || autoRunning
        val armed = i.armedMessage != null
        val paused = st == SessionStatus.PAUSED || st == SessionStatus.NEEDS_ASSIST
        val state = when {
            live -> snap.userState(false)
            armed -> UserState.STARTING
            calibrating -> UserState.CALIBRATING
            else -> snap.userState(false)
        }
        val visible = live || armed || calibrating || (i.captureOn && i.showWhileCaptureOn)
        val autoStage = i.auto.stages.firstOrNull { it.status == StageStatus.FAILED }
            ?: i.auto.stages.firstOrNull { it.status == StageStatus.RUNNING || it.status == StageStatus.NEEDS_YOU }
        val status = when {
            i.note != null -> i.note
            autoRunning -> autoStage?.let { "${it.stage.title}: ${it.detail}" } ?: "Auto-Calibrate running"
            i.auto.phase == RunPhase.REVIEW -> "Auto-Calibrate finished. Open HaulPilot to review the result and tap Confirm."
            i.auto.phase == RunPhase.FAILED -> "Auto-Calibrate stopped: ${i.auto.problem ?: "see HaulPilot"}"
            calibrating -> i.calibration.cue ?: i.calibration.message
            live -> snap.assistHint ?: snap.lastError?.takeIf { paused } ?: snap.task
            armed -> i.armedMessage!!
            st == SessionStatus.EMERGENCY_STOPPED -> "Emergency stop. Inputs released. Start again when ready."
            !i.captureOn -> "Screen capture is off. Open HaulPilot to turn it on."
            else -> "Ready. Be in the normal driving view."
        }
        val autoShown = autoRunning || i.auto.phase == RunPhase.REVIEW || i.auto.phase == RunPhase.FAILED
        val showCal = calibrating || autoShown || (!live && !armed && i.calibration.framesSeen > 0)
        val cal = if (!showCal) null else if (autoShown) {
            // Real progress only: finished stages plus the share of pictures collected so far.
            val done = i.auto.stages.count { it.status == StageStatus.DONE || it.status == StageStatus.NEEDS_YOU }
            val partial = if (i.auto.phase == RunPhase.COLLECTING) i.auto.collected.toFloat() / i.auto.target.coerceAtLeast(1) else 0f
            val shown = autoStage ?: i.auto.stages.last()
            OverlayCalibration(
                stageTitle = shown.stage.title,
                stageDetail = shown.detail,
                percent = (((done + partial) / i.auto.stages.size) * 100f).roundToInt().coerceIn(0, 100),
                confirmed = i.controls.confirmed,
                uncertain = i.controls.uncertain,
                missingRequired = i.controls.missingRequired,
                blocker = i.auto.problem,
            )
        } else {
            val stage = i.progress.stages.firstOrNull { it.state == StageState.BLOCKED }
                ?: i.progress.stages.firstOrNull { it.state == StageState.ACTIVE }
                ?: i.progress.stages.lastOrNull { it.state == StageState.DONE }
                ?: i.progress.stages.first()
            OverlayCalibration(
                stageTitle = "Stage ${stage.key}: ${stage.title}",
                stageDetail = stage.detail,
                percent = (i.progress.fraction * 100f).roundToInt().coerceIn(0, 100),
                confirmed = i.controls.confirmed,
                uncertain = i.controls.uncertain,
                missingRequired = i.controls.missingRequired,
                blocker = i.progress.blocker,
            )
        }
        return OverlayUi(
            visible = visible,
            state = state,
            tone = toneOf(state),
            status = status,
            canStartDrive = i.captureOn && !live && !calibrating && !armed,
            canStartCalibration = i.captureOn && !live && !armed && !calibrating,
            canCancelCalibration = calibrating && !live,
            canPause = st.isActiveLoop,
            canResume = paused,
            canEnd = live || armed,
            endLabel = if (armed && !live) "Cancel start" else "End drive",
            canEmergency = visible,
            calibration = cal,
            attention = state == UserState.NEEDS_ASSISTANCE || state == UserState.EMERGENCY_STOP,
            ring = if (autoRunning) ((cal?.percent ?: 0) / 100f) else if (calibrating) i.progress.fraction.coerceIn(0f, 1f) else null,
            recording = i.recordingSnapshots,
            linkLabel = i.link?.state?.label,
            linkOk = i.link?.let { it.state == LinkState.CONNECTED && it.receivingGame } ?: false,
            canAutoCalibrate = i.captureOn && !live && !armed && !calibrating,
            canAdoptGame = i.canAdoptGame && i.link?.action == LinkAction.CHOOSE_GAME && !live,
        )
    }
}

/**
 * Where the collapsed button sits. Stored as the screen side plus a fraction of the usable height, so the position survives
 * rotation and a different screen size instead of landing off-screen.
 */
data class DockPosition(val rightSide: Boolean, val yFraction: Float) {
    companion object {
        /** Default: right edge, a little above the middle, away from the usual bottom-corner pedals. */
        val DEFAULT = DockPosition(rightSide = true, yFraction = 0.30f)
    }
}

object OverlayPlacement {
    /** Pixel position of a button of [size] for [pos] on a [screenW] x [screenH] screen, [margin] from the edge. */
    fun place(pos: DockPosition, size: Int, screenW: Int, screenH: Int, margin: Int): Pair<Int, Int> {
        val x = if (pos.rightSide) maxOf(0, screenW - size - margin) else margin.coerceAtMost(maxOf(0, screenW - size))
        val usable = maxOf(0, screenH - size - 2 * margin)
        val y = margin + (pos.yFraction.coerceIn(0f, 1f) * usable).roundToInt()
        return x to y.coerceIn(0, maxOf(0, screenH - size))
    }

    /** After a drag ends at ([x], [y]) the button snaps to the nearer side edge. */
    fun snap(x: Int, y: Int, size: Int, screenW: Int, screenH: Int, margin: Int): DockPosition {
        val centre = x + size / 2f
        val right = centre >= screenW / 2f
        val usable = maxOf(1, screenH - size - 2 * margin)
        val frac = ((y - margin).toFloat() / usable).coerceIn(0f, 1f)
        return DockPosition(right, frac)
    }

    /**
     * Top-left of the expanded panel ([panelW] x [panelH]) next to the button at ([bx], [by]): on the inner side of the
     * button, vertically aligned with it and kept fully on screen.
     */
    fun panelAnchor(bx: Int, by: Int, size: Int, panelW: Int, panelH: Int, screenW: Int, screenH: Int, gap: Int): Pair<Int, Int> {
        val buttonOnRight = bx + size / 2 >= screenW / 2
        val px = if (buttonOnRight) bx - gap - panelW else bx + size + gap
        val py = by
        return px.coerceIn(0, maxOf(0, screenW - panelW)) to py.coerceIn(0, maxOf(0, screenH - panelH))
    }
}

/**
 * Tells a deliberate tap from the end of a drag, and ignores taps that arrive right after the panel opened (a quick
 * double-tap on the button must not land on Emergency Stop or Start in the panel that appears under the finger).
 */
class TapGuard(private val slopPx: Float, private val armDelayMs: Long = ARM_DELAY_MS) {
    private var openedAt = Long.MIN_VALUE / 2

    fun panelOpened(nowMs: Long) {
        openedAt = nowMs
    }

    fun isTap(downX: Float, downY: Float, upX: Float, upY: Float): Boolean =
        abs(upX - downX) <= slopPx && abs(upY - downY) <= slopPx

    /** True when a press on a panel button at [nowMs] should be acted on. */
    fun accepts(nowMs: Long): Boolean = nowMs - openedAt >= armDelayMs

    companion object {
        const val ARM_DELAY_MS = 350L
    }
}
