package dev.toe3autopilot.app.ui

import android.graphics.Bitmap
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import dev.toe3autopilot.app.AutopilotRuntime
import dev.toe3autopilot.core.Control
import dev.toe3autopilot.core.Point
import dev.toe3autopilot.core.profile.GameProfile
import dev.toe3autopilot.core.profile.ProfileEditing
import dev.toe3autopilot.core.profile.ProfileReadiness
import dev.toe3autopilot.core.profile.SteeringMode
import dev.toe3autopilot.core.state.GameState
import dev.toe3autopilot.core.vision.Frame
import dev.toe3autopilot.core.vision.Roi
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Holds the calibration snapshot so it survives switching tabs. */
private object CalibrationHolder {
    var frame by mutableStateOf<Frame?>(null)
    var bitmap by mutableStateOf<Bitmap?>(null)

    fun set(f: Frame) {
        frame = f
        bitmap = Bitmap.createBitmap(f.argb, f.width, f.height, Bitmap.Config.ARGB_8888)
    }
}

private enum class Tool(val label: String, val help: String) {
    TEMPLATE("Template", "Drag a box around a distinctive piece of the screen that never changes (a HUD element), name it, then Save. For the driving screen use \"Use as driving screen marker\"."),
    BUTTON("Button/control", "Pick a control below, then TAP its centre on the snapshot."),
    MINIMAP("Minimap", "Drag a box around the whole navigation minimap (heading-up minimaps only)."),
    ROUTE_COLOR("Route colour", "Drag a small box over a stretch of the route line on the minimap; its average colour is used."),
    TRUCK("Truck marker", "TAP the truck's arrow on the minimap."),
    ZONE("Colour zone", "Drag a box over the highlighted parking zone; its average colour becomes the zone colour."),
    DESTINATION("Destination marker", "Drag a box over the destination marker on the minimap (mark the minimap first); its colour is saved as 'destination_marker'. The app can then tell when the marker is close to the truck."),
}

private val SUGGESTED = listOf(
    "hud_marker", "destination_near", "obstacle_ahead", "parking_hud", "parked_ok", "gear_reverse_indicator",
    "delivery_header", "loading_marker", "dialog_marker", "crash_marker",
)

@Composable
fun CalibrateTab() {
    val capture by AutopilotRuntime.captureActive.collectAsState()
    val profile by AutopilotRuntime.profile.collectAsState()
    val pkg by AutopilotRuntime.gamePackage.collectAsState()
    val scope = rememberCoroutineScope()

    var tool by remember { mutableStateOf(Tool.TEMPLATE) }
    var countdown by remember { mutableStateOf(0) }
    var message by remember { mutableStateOf<String?>(null) }
    var boxSize by remember { mutableStateOf(IntSize.Zero) }
    var dragStart by remember { mutableStateOf<Offset?>(null) }
    var dragEnd by remember { mutableStateOf<Offset?>(null) }
    var templateName by remember { mutableStateOf("") }
    var control by remember { mutableStateOf(Control.ACCELERATOR) }
    var ruleState by remember { mutableStateOf(GameState.DRIVING) }
    var ruleText by remember { mutableStateOf("") }
    var zoneName by remember { mutableStateOf("parking_zone") }

    val frame = CalibrationHolder.frame
    val bmp = CalibrationHolder.bitmap
    val current: GameProfile = profile ?: GameProfile.EMPTY.copy(name = "my-device", gamePackage = pkg)

    fun selection(): Roi? {
        val s = dragStart ?: return null
        val e = dragEnd ?: return null
        return ProfileEditing.roiFromDrag(s.x, s.y, e.x, e.y, boxSize.width.toFloat(), boxSize.height.toFloat())
    }

    fun commit(p: GameProfile, ok: String) {
        AutopilotRuntime.setProfile(p.copy(gamePackage = p.gamePackage.ifBlank { pkg }))
        message = ok
    }

    Column(
        Modifier.verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        SectionCard("1. Take a snapshot of a game screen") {
            Text(
                "The snapshot is the same low-resolution image the automation will see. Turn screen sharing on first (button above), " +
                    "then press \"Snapshot in 8 s\", switch to the game and show the screen you want to mark, then come back here.",
                style = MaterialTheme.typography.bodySmall,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(enabled = capture && countdown == 0, onClick = {
                    scope.launch {
                        for (i in 8 downTo 1) {
                            countdown = i
                            delay(1000)
                        }
                        countdown = 0
                        val f = AutopilotRuntime.frameSource.latest()
                        if (f == null) message = "No frame received yet. Is capture connected?" else {
                            CalibrationHolder.set(f)
                            message = "Snapshot taken (${f.width}×${f.height})."
                            dragStart = null
                            dragEnd = null
                        }
                    }
                }) { Text(if (countdown > 0) "Snapshot in $countdown…" else "Snapshot in 8 s") }
                OutlinedButton(enabled = capture, onClick = {
                    val f = AutopilotRuntime.frameSource.latest()
                    if (f == null) message = "No frame received yet." else {
                        CalibrationHolder.set(f)
                        message = "Snapshot taken (${f.width}×${f.height})."
                    }
                }) { Text("Snapshot now") }
            }
            if (!capture) Text("Screen capture is not connected.", color = MaterialTheme.colorScheme.error)
            message?.let { Text(it, fontWeight = FontWeight.Bold) }
        }

        if (frame != null && bmp != null) {
            SectionCard("2. Mark things on the snapshot") {
                Row(Modifier.horizontalScroll(rememberScrollState()).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Tool.entries.forEach { t ->
                        FilterChip(selected = tool == t, onClick = { tool = t; dragStart = null; dragEnd = null }, label = { Text(t.label) })
                    }
                }
                Text(tool.help, style = MaterialTheme.typography.bodySmall)

                Box(
                    Modifier.fillMaxWidth().aspectRatio(frame.width.toFloat() / frame.height)
                        .onSizeChanged { boxSize = it }
                        .pointerInput(tool, control) {
                            detectTapGestures { o ->
                                val nx = (o.x / size.width).coerceIn(0f, 1f)
                                val ny = (o.y / size.height).coerceIn(0f, 1f)
                                when (tool) {
                                    Tool.BUTTON -> commit(ProfileEditing.withControl(current, control, Point(nx, ny)), "Saved ${control.name} at (${"%.2f".format(nx)}, ${"%.2f".format(ny)}).")
                                    Tool.TRUCK -> {
                                        val p = ProfileEditing.withTruckMarker(current, Point(nx, ny))
                                        if (p == null) message = "Mark the minimap first." else commit(p, "Truck marker saved.")
                                    }
                                    else -> {}
                                }
                            }
                        }
                        .pointerInput(tool) {
                            if (tool != Tool.BUTTON && tool != Tool.TRUCK) {
                                detectDragGestures(
                                    onDragStart = { dragStart = it; dragEnd = it },
                                    onDrag = { change, _ -> dragEnd = change.position },
                                )
                            }
                        },
                ) {
                    Image(bmp.asImageBitmap(), contentDescription = "Game snapshot", contentScale = ContentScale.FillBounds, modifier = Modifier.fillMaxSize())
                    Canvas(Modifier.fillMaxSize()) {
                        val w = size.width
                        val h = size.height
                        current.controls.values.forEach { drawCircle(Color.Cyan, 10f, Offset(it.x * w, it.y * h), style = Stroke(3f)) }
                        current.nav?.let { n ->
                            drawRect(Color.Magenta, Offset(n.minimapRoi.left * w, n.minimapRoi.top * h), Size((n.minimapRoi.right - n.minimapRoi.left) * w, (n.minimapRoi.bottom - n.minimapRoi.top) * h), style = Stroke(2f))
                            drawCircle(Color.Green, 8f, Offset(n.truckX * w, n.truckY * h), style = Stroke(3f))
                        }
                        val s = dragStart
                        val e = dragEnd
                        if (s != null && e != null) {
                            drawRect(Color.Yellow, Offset(minOf(s.x, e.x), minOf(s.y, e.y)), Size(kotlin.math.abs(e.x - s.x), kotlin.math.abs(e.y - s.y)), style = Stroke(4f))
                        }
                    }
                }
                Text("Cyan = saved controls, magenta = minimap, green = truck marker, yellow = current selection.", style = MaterialTheme.typography.bodySmall)

                when (tool) {
                    Tool.TEMPLATE -> {
                        OutlinedTextField(value = templateName, onValueChange = { templateName = it.trim() }, label = { Text("Template name (a-z, 0-9, _)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        Row(Modifier.horizontalScroll(rememberScrollState()).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            SUGGESTED.forEach { s -> FilterChip(selected = templateName == s, onClick = { templateName = s }, label = { Text(s) }) }
                        }
                        Button(onClick = {
                            val sel = selection()
                            val problem = ProfileEditing.validateName(templateName) ?: ProfileEditing.widthProblem(current, frame.width)
                            when {
                                sel == null -> message = "Drag a box on the snapshot first."
                                problem != null -> message = problem
                                else -> {
                                    val r = ProfileEditing.cropRect(sel, frame)
                                    val crop = Bitmap.createBitmap(bmp, r.x0, r.y0, r.width, r.height)
                                    AutopilotRuntime.profileStore.saveTemplate(templateName, crop)
                                    commit(
                                        ProfileEditing.withTemplate(current, templateName, ProfileEditing.searchRoi(sel), frame.width, frameHeight = frame.height),
                                        "Saved template '$templateName' (${r.width}×${r.height}px).",
                                    )
                                    dragStart = null
                                    dragEnd = null
                                }
                            }
                        }) { Text("Save template") }
                        OutlinedButton(onClick = {
                            val sel = selection()
                            val problem = ProfileEditing.widthProblem(current, frame.width)
                            if (sel == null) {
                                message = "Drag a box around a fixed HUD element of the normal driving view first (something that is always there while driving)."
                            } else if (problem != null) {
                                message = problem
                            } else {
                                val r = ProfileEditing.cropRect(sel, frame)
                                val crop = Bitmap.createBitmap(bmp, r.x0, r.y0, r.width, r.height)
                                AutopilotRuntime.profileStore.saveTemplate(ProfileReadiness.HUD_MARKER, crop)
                                val withTpl = ProfileEditing.withTemplate(current, ProfileReadiness.HUD_MARKER, ProfileEditing.searchRoi(sel), frame.width, frameHeight = frame.height)
                                val rule = if (withTpl.templates.containsKey("parking_hud")) "${ProfileReadiness.HUD_MARKER}, !parking_hud" else ProfileReadiness.HUD_MARKER
                                val (p2, err) = ProfileEditing.withStateRule(withTpl, GameState.DRIVING, rule)
                                if (err != null) message = err else commit(p2, "Driving screen marker saved: the Driving screen is recognised by '${ProfileReadiness.HUD_MARKER}'.")
                                dragStart = null
                                dragEnd = null
                            }
                        }) { Text("Use as driving screen marker") }
                    }
                    Tool.BUTTON -> {
                        Row(Modifier.horizontalScroll(rememberScrollState()).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Control.entries.forEach { c ->
                                FilterChip(selected = control == c, onClick = { control = c }, label = { Text(c.name + if (current.controls.containsKey(c)) " ✔" else "") })
                            }
                        }
                        Text(
                            "Steering: in SLIDER mode mark STEER_CENTER (the wheel/slider centre); in BUTTONS mode mark STEER_LEFT and STEER_RIGHT.",
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                    Tool.MINIMAP -> Button(onClick = {
                        val sel = selection()
                        if (sel == null) message = "Drag a box first." else {
                            commit(ProfileEditing.withNavMinimap(current, sel), "Minimap region saved.")
                            dragStart = null
                            dragEnd = null
                        }
                    }) { Text("Save minimap region") }
                    Tool.ROUTE_COLOR -> Button(onClick = {
                        val sel = selection()
                        val p = sel?.let { ProfileEditing.withRouteColor(current, ProfileEditing.averageColor(frame, it)) }
                        if (sel == null) message = "Drag a box over the route line first."
                        else if (p == null) message = "Mark the minimap first."
                        else commit(p, "Route colour saved.")
                    }) { Text("Save route colour") }
                    Tool.TRUCK -> Text("Tap the truck marker on the snapshot.")
                    Tool.DESTINATION -> Button(onClick = {
                        val sel = selection()
                        val nav = current.nav
                        when {
                            nav == null -> message = "Mark the minimap first."
                            sel == null -> message = "Drag a small box over the destination marker on the minimap first."
                            else -> {
                                commit(
                                    ProfileEditing.withColor(current, "destination_marker", nav.minimapRoi, ProfileEditing.averageColor(frame, sel, 50)),
                                    "Destination marker colour saved. Pick a colour that nothing else on the minimap has.",
                                )
                                dragStart = null
                                dragEnd = null
                            }
                        }
                    }) { Text("Save destination marker colour") }
                    Tool.ZONE -> {
                        OutlinedTextField(value = zoneName, onValueChange = { zoneName = it.trim() }, label = { Text("Zone name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        Button(onClick = {
                            val sel = selection()
                            val problem = ProfileEditing.validateName(zoneName)
                            when {
                                sel == null -> message = "Drag a box over the zone first."
                                problem != null -> message = problem
                                else -> commit(
                                    ProfileEditing.withColor(current, zoneName, Roi(0.05f, 0.05f, 0.95f, 0.95f), ProfileEditing.averageColor(frame, sel, 50)),
                                    "Colour zone '$zoneName' saved. Searches the whole screen for this colour.",
                                )
                            }
                        }) { Text("Save colour zone") }
                    }
                }
            }
        }

        SectionCard("3. Say which templates identify which screen") {
            Row(Modifier.horizontalScroll(rememberScrollState()).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                GameState.entries.filter { it != GameState.UNKNOWN && it != GameState.GAME_NOT_FOREGROUND }.forEach { s ->
                    FilterChip(
                        selected = ruleState == s,
                        onClick = { ruleState = s; ruleText = current.stateRules[s]?.joinToString(", ") ?: "" },
                        label = { Text(s.label + if (current.stateRules.containsKey(s)) " ✔" else "") },
                    )
                }
            }
            OutlinedTextField(
                value = ruleText, onValueChange = { ruleText = it },
                label = { Text("Templates that must be visible (prefix ! = must be absent)") },
                modifier = Modifier.fillMaxWidth(),
            )
            Text(
                "Example: Driving = hud_marker, !parking_hud. All listed conditions must hold. Leave empty to remove the rule. The \"Driving\" rule is required.",
                style = MaterialTheme.typography.bodySmall,
            )
            Button(onClick = {
                val (p, err) = ProfileEditing.withStateRule(current, ruleState, ruleText)
                if (err != null) message = err else commit(p, "Rule for '${ruleState.label}' saved.")
            }) { Text("Save rule") }
        }

        SectionCard("4. Steering style") {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                SteeringMode.entries.forEach { m ->
                    FilterChip(
                        selected = current.steeringMode == m,
                        onClick = { commit(ProfileEditing.withSteering(current, m, current.steerRadius), "Steering mode: ${m.name}") },
                        label = { Text(if (m == SteeringMode.SLIDER) "Slider / wheel (drag)" else "Left/right buttons") },
                    )
                }
            }
            if (current.steeringMode == SteeringMode.SLIDER) {
                Text("Slider travel: ${(current.steerRadius * 100).toInt()}% of screen width each side")
                Slider(
                    value = current.steerRadius,
                    onValueChange = { v -> commit(ProfileEditing.withSteering(current, SteeringMode.SLIDER, v), "") },
                    valueRange = 0.02f..0.4f,
                )
            }
        }

        SectionCard("Saved templates (${current.templates.size})") {
            if (current.templates.isEmpty()) Text("None yet.")
            current.templates.keys.sorted().forEach { n ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(n + if (AutopilotRuntime.profileStore.hasTemplate(n)) "" else "  (image missing)")
                    TextButton(onClick = {
                        AutopilotRuntime.profileStore.deleteTemplate(n)
                        commit(ProfileEditing.withoutTemplate(current, n), "Deleted '$n'.")
                    }) { Text("Delete") }
                }
            }
            Text(
                "Reference width: ${current.referenceWidth}px. If you change the screen orientation or device, templates must be re-marked.",
                style = MaterialTheme.typography.bodySmall,
            )
        }
    }
}
