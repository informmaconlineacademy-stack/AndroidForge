package dev.toe3autopilot.core.vision

import kotlin.math.abs
import kotlin.math.sqrt

/** A template hit. x,y are the centre and w,h the size, all normalised to the searched image. score is NCC (-1..1). */
data class Match(val x: Float, val y: Float, val score: Float, val w: Float, val h: Float)

/**
 * Normalised cross-correlation template matching on grayscale images, implemented in plain Kotlin.
 *
 * NCC is invariant to uniform brightness/contrast changes, which makes it a reasonable "simplest thing
 * that works" for UI icons. It is NOT scale- or rotation-invariant: templates must be captured at the
 * same processing resolution (the profile scales them when the frame width differs).
 *
 * Small searches are exhaustive. Large ones (many positions x big template) use a half-resolution
 * pre-search whose best candidates are then refined at full resolution.
 */
object TemplateMatcher {

    /** Above this many multiply-adds an exhaustive search is replaced by the half-resolution pre-search. */
    private const val EXHAUSTIVE_WORK_LIMIT = 6_000_000L

    private class Stats(val mean: Double, val norm: Double)

    fun best(image: GrayImage, template: GrayImage, roi: Roi = Roi.FULL): Match? =
        search(image, template, roi, minScore = -1f, maxResults = 1).firstOrNull()

    fun all(image: GrayImage, template: GrayImage, roi: Roi, minScore: Float, maxResults: Int = 8): List<Match> =
        search(image, template, roi, minScore, maxResults)

    private fun stats(t: GrayImage): Stats? {
        val n = t.width * t.height
        var sum = 0L
        var sq = 0L
        for (v in t.px) {
            sum += v
            sq += v * v
        }
        val mean = sum.toDouble() / n
        val variance = sq - n * mean * mean
        if (variance < n * 2.0) return null // flat template: NCC is meaningless
        return Stats(mean, sqrt(variance))
    }

    private fun search(image: GrayImage, template: GrayImage, roi: Roi, minScore: Float, maxResults: Int): List<Match> {
        val rect = roi.toRect(image.width, image.height)
        val tw = template.width
        val th = template.height
        if (tw > rect.width || th > rect.height) return emptyList()
        val tStats = stats(template) ?: return emptyList()

        val work = (rect.width - tw + 1).toLong() * (rect.height - th + 1) * tw * th
        val candidates: List<Match> =
            if (work <= EXHAUSTIVE_WORK_LIMIT) scan(image, template, tStats, rect.x0, rect.y0, rect.x1, rect.y1, minScore)
            else pyramidSearch(image, template, tStats, rect, minScore, maxResults)

        // Non-maximum suppression: keep the best hit per template-sized neighbourhood.
        val picked = ArrayList<Match>()
        val halfW = tw.toFloat() / image.width
        val halfH = th.toFloat() / image.height
        for (c in candidates.sortedByDescending { it.score }) {
            if (picked.size >= maxResults) break
            if (picked.none { abs(it.x - c.x) < halfW && abs(it.y - c.y) < halfH }) picked.add(c)
        }
        return picked
    }

    /** Exhaustive NCC over every template position whose window lies inside [x0,x1) x [y0,y1). */
    private fun scan(image: GrayImage, tpl: GrayImage, st: Stats, x0: Int, y0: Int, x1: Int, y1: Int, minScore: Float): List<Match> {
        val out = ArrayList<Match>()
        val tw = tpl.width
        val th = tpl.height
        var y = y0
        while (y + th <= y1) {
            var x = x0
            while (x + tw <= x1) {
                val s = ncc(image, tpl, x, y, st)
                if (s >= minScore) out.add(toMatch(image, x, y, tw, th, s))
                x++
            }
            y++
        }
        return out
    }

    private fun pyramidSearch(image: GrayImage, template: GrayImage, st: Stats, rect: PixelRect, minScore: Float, maxResults: Int): List<Match> {
        val tw = template.width
        val th = template.height
        val smallImg = image.resize(maxOf(1, image.width / 2), maxOf(1, image.height / 2))
        val smallTpl = template.resize(maxOf(2, tw / 2), maxOf(2, th / 2))
        val smallStats = stats(smallTpl) ?: return scan(image, template, st, rect.x0, rect.y0, rect.x1, rect.y1, minScore)

        // Coarse pass: keep the strongest half-resolution candidates regardless of threshold.
        val coarse = scan(smallImg, smallTpl, smallStats, rect.x0 / 2, rect.y0 / 2, (rect.x1 + 1) / 2, (rect.y1 + 1) / 2, -1f)
            .sortedByDescending { it.score }
        val keep = maxOf(6, maxResults * 3)
        val refined = ArrayList<Match>()
        for (c in coarse) {
            if (refined.size >= keep) break
            // Skip coarse candidates sitting on top of one we already refined.
            if (refined.any { abs(it.x - c.x) * image.width < tw / 2f && abs(it.y - c.y) * image.height < th / 2f }) continue
            val cx = Math.round(c.x * smallImg.width - smallTpl.width / 2f) * 2
            val cy = Math.round(c.y * smallImg.height - smallTpl.height / 2f) * 2
            var bestM: Match? = null
            for (dy in -3..3) {
                for (dx in -3..3) {
                    val px = cx + dx
                    val py = cy + dy
                    if (px < rect.x0 || py < rect.y0 || px + tw > rect.x1 || py + th > rect.y1) continue
                    val s = ncc(image, template, px, py, st)
                    if (bestM == null || s > bestM.score) bestM = toMatch(image, px, py, tw, th, s)
                }
            }
            if (bestM != null) refined.add(bestM)
        }
        return refined.filter { it.score >= minScore }
    }

    private fun toMatch(image: GrayImage, x: Int, y: Int, tw: Int, th: Int, score: Float) = Match(
        x = (x + tw / 2f) / image.width,
        y = (y + th / 2f) / image.height,
        score = score,
        w = tw.toFloat() / image.width,
        h = th.toFloat() / image.height,
    )

    private fun ncc(image: GrayImage, tpl: GrayImage, x: Int, y: Int, st: Stats): Float {
        val iw = image.width
        val tw = tpl.width
        val th = tpl.height
        val img = image.px
        val t = tpl.px
        var sI = 0L
        var sII = 0L
        var sIT = 0L
        for (j in 0 until th) {
            var ii = (y + j) * iw + x
            var ti = j * tw
            for (i in 0 until tw) {
                val a = img[ii++]
                val b = t[ti++]
                sI += a
                sII += a * a
                sIT += a * b
            }
        }
        val n = (tw * th).toDouble()
        val iMean = sI / n
        val iVar = sII - n * iMean * iMean
        if (iVar < n * 2.0) return 0f // featureless window
        val cov = sIT - n * iMean * st.mean
        return (cov / (sqrt(iVar) * st.norm)).toFloat()
    }
}
