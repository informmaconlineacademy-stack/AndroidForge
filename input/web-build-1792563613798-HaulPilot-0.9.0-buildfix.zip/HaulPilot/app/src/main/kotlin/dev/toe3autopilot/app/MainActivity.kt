package dev.toe3autopilot.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionConfig
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.PickVisualMediaRequest
import androidx.core.content.ContextCompat
import dev.toe3autopilot.app.calibration.VideoCalibrationRunner
import dev.toe3autopilot.app.capture.ScreenCaptureService
import dev.toe3autopilot.app.ui.HaulPilotTheme
import dev.toe3autopilot.core.capture.CaptureFault
import dev.toe3autopilot.app.ui.AppScreen
import dev.toe3autopilot.app.ui.Actions
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onStart() {
        super.onStart()
        AutopilotRuntime.appVisible = true
    }

    override fun onStop() {
        AutopilotRuntime.appVisible = false
        super.onStop()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AutopilotRuntime.init(this)
        setContent {
            HaulPilotTheme {
                val projectionLauncher = rememberLauncherForActivityResult(
                    ActivityResultContracts.StartActivityForResult(),
                ) { result ->
                    AutopilotRuntime.setAwaitingPermission(false)
                    val data = result.data
                    if (result.resultCode == RESULT_OK && data != null) {
                        ScreenCaptureService.start(this, result.resultCode, data)
                    } else {
                        AutopilotRuntime.reportCaptureFault(CaptureFault.PERMISSION_DENIED, "resultCode=${result.resultCode}, data=${if (data == null) "null" else "present"}")
                        AutopilotRuntime.noteInputFailure("Screen-capture permission was not granted")
                    }
                }
                val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
                val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
                    if (uri != null) AutopilotRuntime.ioScope.launch { AutopilotRuntime.notice.value = writeExport(uri) }
                }
                val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
                    if (uri != null) AutopilotRuntime.ioScope.launch { AutopilotRuntime.notice.value = readImport(uri) }
                }
                val screenshotLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
                    if (uris.isNotEmpty()) AutopilotRuntime.ioScope.launch { AutopilotRuntime.notice.value = analyseScreenshots(uris) }
                }
                // A gameplay clip for calibration. Nothing is copied: the picker hands back a read-only content Uri that is
                // decoded on a background thread. The clip never produces input.
                val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
                    if (uri != null) startVideoCalibration(uri)
                }
                val videoBrowser = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
                    if (uri != null) startVideoCalibration(uri)
                }
                val actions = Actions(
                    connectCapture = {
                        if (Build.VERSION.SDK_INT >= 33 &&
                            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                        ) {
                            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        }
                        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                        val intent = if (Build.VERSION.SDK_INT >= 34) {
                            // Android 14+: let the user share the whole screen (single-app sharing would hide the game's touch targets).
                            mpm.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay())
                        } else {
                            mpm.createScreenCaptureIntent()
                        }
                        AutopilotRuntime.setAwaitingPermission(true)
                        try {
                            projectionLauncher.launch(intent)
                        } catch (e: Exception) {
                            AutopilotRuntime.setAwaitingPermission(false)
                            AutopilotRuntime.reportCaptureFault(CaptureFault.SERVICE_START_REJECTED, "the permission dialog could not be opened: ${e.javaClass.simpleName}")
                        }
                    },
                    disconnectCapture = {
                        AutopilotRuntime.stopSession()
                        ScreenCaptureService.stop(this)
                    },
                    openAccessibilitySettings = {
                        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    },
                    openAppDetails = {
                        startActivity(
                            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:$packageName"))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                        )
                    },
                    launchGame = {
                        val pkg = AutopilotRuntime.gamePackage.value
                        val i = packageManager.getLaunchIntentForPackage(pkg)
                        if (i == null) {
                            false
                        } else {
                            try {
                                startActivity(i)
                                true
                            } catch (e: Exception) {
                                false
                            }
                        }
                    },
                    installedLaunchables = { launchableApps() },
                    requestNotifications = {
                        if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    },
                    openNotificationSettings = {
                        startActivity(
                            Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                        )
                    },
                    openBatterySettings = {
                        // The list of apps exempt from battery optimisation. (Asking for the exemption directly needs a
                        // permission that is restricted on Google Play, so the user is sent to the list instead.)
                        try {
                            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        } catch (e: Exception) {
                            startActivity(
                                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                            )
                        }
                    },
                    pickScreenshots = { screenshotLauncher.launch(arrayOf("image/*")) },
                    pickVideo = { videoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) },
                    browseVideo = { videoBrowser.launch(arrayOf("video/*")) },
                    exportProfile = { exportLauncher.launch("haulpilot-calibration.zip") },
                    importProfile = { importLauncher.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) },
                )
                AppScreen(actions)
            }
        }
    }

    private fun startVideoCalibration(uri: Uri) {
        // Read access only for this run; a persisted grant is not needed and not requested.
        val app = applicationContext
        AutopilotRuntime.ioScope.launch {
            try {
                VideoCalibrationRunner.run(app, uri)
            } catch (e: Exception) {
                AutopilotRuntime.logWarn("Video calibration crashed: ${e.javaClass.simpleName}: ${e.message}")
                AutopilotRuntime.notice.value = "The video could not be processed: ${e.message ?: e.javaClass.simpleName}"
                VideoCalibrationRunner.reset()
            }
        }
    }

    private fun writeExport(uri: Uri): String {
        return try {
            val bytes = AutopilotRuntime.calibration.exportArchive()
            val out = contentResolver.openOutputStream(uri) ?: return "Export failed: the file could not be opened for writing."
            out.use { it.write(bytes) }
            "Exported the profile, learned calibration and ${bytes.size / 1024} KB of data."
        } catch (e: Exception) {
            "Export failed: ${e.message ?: e.javaClass.simpleName}"
        }
    }

    private fun readImport(uri: Uri): String {
        return try {
            val input = contentResolver.openInputStream(uri) ?: return "Import failed: the file could not be opened."
            val bytes = input.use { ScreenshotImport.readLimited(it, 21L * 1024 * 1024) }
            AutopilotRuntime.calibration.importArchive(bytes)
        } catch (e: Exception) {
            "Import failed: ${e.message ?: e.javaClass.simpleName}"
        }
    }

    private fun analyseScreenshots(uris: List<Uri>): String {
        val loaded = ScreenshotImport.load(this, uris)
        if (loaded.frames.isEmpty()) return "None of the ${uris.size} picture(s) could be read."
        val err = AutopilotRuntime.calibration.analyseSnapshots(loaded.frames)
        val st = AutopilotRuntime.calibration.state.value
        val failed = if (loaded.failed > 0) " ${loaded.failed} picture(s) could not be used." else ""
        return if (err != null) "Screenshot analysis did not run: $err.$failed" else "Analysed ${loaded.frames.size} screenshot(s): ${st.message}$failed"
    }

    /** Apps with a launcher icon, as (label, package), for picking the game. Needs only the launcher <queries> entry. */
    private fun launchableApps(): List<Pair<String, String>> {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(i, 0)
            .map { it.loadLabel(packageManager).toString() to it.activityInfo.packageName }
            .filter { it.second != packageName }
            .sortedBy { it.first.lowercase() }
    }
}
