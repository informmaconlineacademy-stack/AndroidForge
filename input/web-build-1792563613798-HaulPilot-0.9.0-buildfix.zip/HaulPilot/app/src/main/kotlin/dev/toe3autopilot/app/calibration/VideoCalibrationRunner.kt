package dev.toe3autopilot.app.calibration

import android.content.Context
import android.net.Uri
import dev.toe3autopilot.app.AutopilotRuntime
import dev.toe3autopilot.core.WallClock
import dev.toe3autopilot.core.calibration.VideoCalibrationAnalyzer
import dev.toe3autopilot.core.calibration.VideoCalibrationResult
import dev.toe3autopilot.core.calibration.VideoValidator
import dev.toe3autopilot.core.session.LogLevel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** What the clip import is doing, for the Smart Setup screen. */
sealed class VideoUiState {
    data object Idle : VideoUiState()
    class Working(val step: String, val progress: Float) : VideoUiState()

    /** The clip was analysed; [result] may still say "unusable" with reasons and advice. */
    class Done(val result: VideoCalibrationResult) : VideoUiState()

    /** The file itself could not be used. */
    class Failed(val message: String, val advice: List<String>) : VideoUiState()
}

/**
 * Runs: validate file -> read sampled pictures -> validate pictures -> analyse -> hand candidates to the calibration engine.
 * Never starts, resumes or influences an automation session; it refuses to run while one is active.
 */
object VideoCalibrationRunner {
    private val _state = MutableStateFlow<VideoUiState>(VideoUiState.Idle)
    val state: StateFlow<VideoUiState> = _state.asStateFlow()

    @Volatile
    private var cancelled = false

    fun cancel() {
        cancelled = true
    }

    fun reset() {
        _state.value = VideoUiState.Idle
    }

    /** Blocking; call from a background thread. */
    fun run(context: Context, uri: Uri) {
        val session = AutopilotRuntime.session?.currentSnapshot()?.status
        if (session != null && (session.isActiveLoop)) {
            _state.value = VideoUiState.Failed("A drive is running. Stop it before calibrating from a recorded clip.", emptyList())
            return
        }
        if (AutopilotRuntime.calibration.engine.isBusy) AutopilotRuntime.calibration.cancel()
        cancelled = false
        _state.value = VideoUiState.Working("Checking the file", 0f)
        val (info, failure) = VideoImporter.readInfo(context, uri)
        if (info == null) {
            fail(failure!!.message, failure.technical, emptyList())
            return
        }
        val infoReport = VideoValidator.checkInfo(info)
        if (!infoReport.usable) {
            fail(infoReport.problems.first(), "info check", infoReport.advice().ifEmpty { listOf("Record about 10 seconds of driving and try again.") })
            return
        }
        _state.value = VideoUiState.Working("Reading pictures from the video", 0f)
        val loaded = VideoImporter.load(context, uri, info, onProgress = { p ->
            _state.value = VideoUiState.Working("Reading pictures from the video", p)
        }, isCancelled = { cancelled })
        when (loaded) {
            is VideoImporter.Result.Failed -> {
                if (cancelled) {
                    _state.value = VideoUiState.Idle
                } else {
                    fail(loaded.message, loaded.technical, emptyList())
                }
            }
            is VideoImporter.Result.Ok -> {
                _state.value = VideoUiState.Working("Looking for controls", 1f)
                val result = VideoCalibrationAnalyzer.analyse(loaded.info, loaded.requested, loaded.frames)
                val preview = loaded.frames.lastOrNull { it.width == result.layout?.width && it.height == result.layout?.height }
                if (result.report.usable && preview != null) {
                    val err = AutopilotRuntime.calibration.importVideoResult(result, preview)
                    if (err != null) {
                        fail(err, "engine refused", emptyList())
                        return
                    }
                }
                AutopilotRuntime.logInfo(
                    "Video calibration: ${loaded.frames.size}/${loaded.requested} pictures, " +
                        (if (result.report.usable) "${result.detections.values.count { it.status.name == "NEEDS_CONFIRMATION" }} candidate(s)" else "unusable"),
                )
                _state.value = VideoUiState.Done(result)
            }
        }
    }

    private fun fail(message: String, technical: String, advice: List<String>) {
        AutopilotRuntime.logWarn("Video calibration failed: $technical")
        _state.value = VideoUiState.Failed(message, advice)
    }
}
