package dev.toe3autopilot.core.calibration

import dev.toe3autopilot.core.vision.Frame
import dev.toe3autopilot.core.vision.Roi
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Finds on-screen elements that stay in place while the scenery moves (buttons, wheels, readouts, minimap frames).
 *
 * Method: over a sequence of frames, count how often each pixel lies on a strong edge. Pixels that are on an edge in
 * (almost) every frame belong to something that does not move with the world, i.e. an overlay. Nearby persistent
 * edge pixels are grouped into elements. Using edges instead of flat colours lets semi-transparent buttons work,
 * as long as their outline survives the changing background.
 *
 * What this CANNOT do: tell what an element is. Meaning only comes from a demonstration (see [DemoAnalyzer]) or from
 * the user. A static scene (menu, paused game, parked truck with a still camera) gives no information, and the
 * analysis says so instead of guessing.
 */
object HudAnalyzer {
    const val MIN_FRAMES = 10
    const val MIN_SCENE_CHANGE = 0.04f
    private const val EDGE_THRESHOLD = 32
    private const val PERSISTENCE_THRESHOLD = 0.8f
    private const val MAX_ELEMENTS = 24
    private const val MIN_EDGE_DENSITY = 0.04f

    fun analyse(frames: List<Frame>): HudAnalysis {
        if (frames.isEmpty()) return failed(0, 0, 0, 0f, "No frames to analyse")
        val w = frames.last().width
        val h = frames.last().height
        val used = frames.filter { it.width == w && it.height == h }
        if (used.size < MIN_FRAMES) {
            return failed(w, h, used.size, 0f, "Need at least $MIN_FRAMES frames of the same size, have ${used.size}")
        }
        val n = used.size
        val grays = used.map { it.toGray().px }

        // 1. Is the scene changing enough to tell overlay from world?
        var changeSum = 0.0
        for (k in 1 until n) {
            val a = grays[k - 1]
            val b = grays[k]
            var c = 0
            for (i in a.indices) if (abs(a[i] - b[i]) > 10) c++
            changeSum += c.toDouble() / a.size
        }
        val sceneChange = (changeSum / (n - 1)).toFloat()
        if (sceneChange < MIN_SCENE_CHANGE) {
            return failed(
                w, h, n, sceneChange,
                "The picture barely changes (${(sceneChange * 100).roundToInt()}%), so fixed buttons cannot be told apart from the background. " +
                    "Drive or turn the camera while observing.",
            )
        }

        // 2. Edge persistence. An overlay edge keeps both its position AND its direction (bright-to-dark stays
        //    bright-to-dark); an edge of the moving world flips direction at random, so counting the four
        //    directions separately suppresses scenery that happens to have edges at the same place now and then.
        val counts = Array(4) { IntArray(w * h) }
        for (g in grays) {
            for (y in 1 until h - 1) {
                val row = y * w
                for (x in 1 until w - 1) {
                    val i = row + x
                    val gx = g[i + 1] - g[i - 1]
                    val gy = g[i + w] - g[i - w]
                    if (abs(gx) + abs(gy) > EDGE_THRESHOLD) {
                        val cls = if (abs(gx) >= abs(gy)) (if (gx > 0) 0 else 1) else (if (gy > 0) 2 else 3)
                        counts[cls][i]++
                    }
                }
            }
        }
        val count = IntArray(w * h) { i -> max(max(counts[0][i], counts[1][i]), max(counts[2][i], counts[3][i])) }
        val need = Math.ceil((PERSISTENCE_THRESHOLD * n).toDouble()).toInt()
        val mask = BooleanArray(w * h) { count[it] >= need }

        // 3. Group nearby persistent edge pixels (dilate, then connected components).
        // Small on purpose: neighbouring buttons (accelerator next to brake) must not be glued together.
        val r = max(1, (0.003f * max(w, h)).roundToInt())
        val dilated = dilate(mask, w, h, r)
        val label = IntArray(w * h)
        val stack = IntArray(w * h)
        val minSide = max(6f, 0.04f * min(w, h))
        val maxSideW = 0.5f * w
        val maxSideH = 0.6f * h
        val found = ArrayList<HudElement>()
        var next = 0
        for (start in dilated.indices) {
            if (!dilated[start] || label[start] != 0) continue
            next++
            var sp = 0
            stack[sp++] = start
            label[start] = next
            var minX = w
            var maxX = -1
            var minY = h
            var maxY = -1
            var edgePixels = 0
            var persSum = 0.0
            while (sp > 0) {
                val i = stack[--sp]
                val x = i % w
                val y = i / w
                if (mask[i]) {
                    edgePixels++
                    persSum += count[i].toDouble() / n
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y
                }
                if (x > 0 && dilated[i - 1] && label[i - 1] == 0) { label[i - 1] = next; stack[sp++] = i - 1 }
                if (x < w - 1 && dilated[i + 1] && label[i + 1] == 0) { label[i + 1] = next; stack[sp++] = i + 1 }
                if (y > 0 && dilated[i - w] && label[i - w] == 0) { label[i - w] = next; stack[sp++] = i - w }
                if (y < h - 1 && dilated[i + w] && label[i + w] == 0) { label[i + w] = next; stack[sp++] = i + w }
            }
            if (edgePixels < 10 || maxX < minX) continue
            val bw = maxX - minX + 1
            val bh = maxY - minY + 1
            // Real overlay elements have a solid outline; random persistent specks scattered over a large box do not.
            if (edgePixels.toFloat() / (bw * bh) < MIN_EDGE_DENSITY) continue
            if (bw < minSide || bh < minSide || bw > maxSideW || bh > maxSideH) continue
            val aspect = bw.toFloat() / bh
            val shortSide = min(w, h).toFloat()
            val side = max(bw, bh) / shortSide
            val sizeScore = when {
                side < 0.08f -> side / 0.08f
                side > 0.30f -> max(0.3f, 0.30f / side)
                else -> 1f
            }
            val shapeScore = if (aspect in 0.7f..1.43f) 1f else max(0.3f, 1f - abs(ln(aspect)) / 2f)
            val persistence = (persSum / edgePixels).toFloat()
            val box = Roi(minX.toFloat() / w, minY.toFloat() / h, (maxX + 1).toFloat() / w, (maxY + 1).toFloat() / h)
            found += HudElement(
                box = box,
                cx = (box.left + box.right) / 2f,
                cy = (box.top + box.bottom) / 2f,
                persistence = persistence,
                aspect = aspect,
                areaFraction = (bw * bh).toFloat() / (w * h),
                score = persistence * shapeScore * sizeScore,
            )
        }

        // 4. A button's icon and its ring are one control: drop elements nested inside a button-sized element.
        val byArea = found.sortedByDescending { it.areaFraction }
        val kept = ArrayList<HudElement>()
        for (e in byArea) {
            val nested = kept.any { k -> isButtonSized(k, w, h) && containedIn(e.box, k.box) }
            if (!nested) kept += e
        }
        val elements = kept.sortedByDescending { it.score }.take(MAX_ELEMENTS)
        if (elements.isEmpty()) return failed(w, h, n, sceneChange, "No persistent on-screen elements were found")
        return HudAnalysis(w, h, n, sceneChange, elements, ok = true, problem = null)
    }

    private fun failed(w: Int, h: Int, n: Int, change: Float, why: String) =
        HudAnalysis(w, h, n, change, emptyList(), ok = false, problem = why)

    private fun isButtonSized(e: HudElement, w: Int, h: Int): Boolean {
        val side = max((e.box.right - e.box.left) * w, (e.box.bottom - e.box.top) * h) / min(w, h)
        return side <= 0.30f
    }

    private fun containedIn(inner: Roi, outer: Roi): Boolean {
        val l = max(inner.left, outer.left)
        val t = max(inner.top, outer.top)
        val rr = min(inner.right, outer.right)
        val b = min(inner.bottom, outer.bottom)
        if (rr <= l || b <= t) return false
        val inter = (rr - l) * (b - t)
        val area = (inner.right - inner.left) * (inner.bottom - inner.top)
        return inter >= 0.9f * area
    }

    /** Box dilation by [r] pixels using an integral image. */
    private fun dilate(mask: BooleanArray, w: Int, h: Int, r: Int): BooleanArray {
        val iw = w + 1
        val integral = IntArray(iw * (h + 1))
        for (y in 0 until h) {
            var rowSum = 0
            for (x in 0 until w) {
                if (mask[y * w + x]) rowSum++
                integral[(y + 1) * iw + (x + 1)] = integral[y * iw + (x + 1)] + rowSum
            }
        }
        val out = BooleanArray(w * h)
        for (y in 0 until h) {
            val y0 = max(0, y - r)
            val y1 = min(h, y + r + 1)
            for (x in 0 until w) {
                val x0 = max(0, x - r)
                val x1 = min(w, x + r + 1)
                val s = integral[y1 * iw + x1] - integral[y0 * iw + x1] - integral[y1 * iw + x0] + integral[y0 * iw + x0]
                out[y * w + x] = s > 0
            }
        }
        return out
    }
}

/** Heuristic suggestions that are only ever shown as "please confirm" and never used automatically. */
object CalibrationGuesses {
    private fun inLowerRight(e: HudElement) = e.cx >= 0.5f && e.cy >= 0.45f && e.areaFraction < 0.05f
    private fun inLowerLeft(e: HudElement) = e.cx < 0.5f && e.cy >= 0.45f && e.areaFraction < 0.05f

    /** Typical-layout position guesses for ordering the confirmation list. Never above [ControlDetection.PRIOR_MAX_CONFIDENCE]. */
    fun positionGuesses(role: CalibRole, hud: HudAnalysis?): List<Alternative> {
        val elements = hud?.elements ?: return emptyList()
        val ordered: List<HudElement> = when (role) {
            CalibRole.ACCELERATOR -> elements.filter(::inLowerRight).sortedWith(compareByDescending<HudElement> { it.cx }.thenByDescending { it.cy })
            CalibRole.BRAKE -> elements.filter(::inLowerRight).sortedWith(compareByDescending<HudElement> { it.cx }.thenByDescending { it.cy }).drop(1)
            CalibRole.STEER_LEFT -> elements.filter(::inLowerLeft).sortedBy { it.cx }
            CalibRole.STEER_RIGHT -> elements.filter(::inLowerLeft).sortedByDescending { it.cx }
            else -> emptyList()
        }
        return ordered.take(3).mapIndexed { i, e ->
            Alternative(e.cx, e.cy, e.box, (0.35f - 0.08f * i).coerceAtLeast(0.1f), "position guess from typical layouts; NOT verified")
        }
    }

    /** Largest corner-placed, roughly square-to-wide persistent element: a minimap candidate. */
    fun minimapCandidate(hud: HudAnalysis?): HudElement? =
        hud?.elements
            ?.filter { it.areaFraction in 0.015f..0.25f && it.aspect in 0.7f..1.9f && (it.cx < 0.4f || it.cx > 0.6f) }
            ?.maxByOrNull { it.areaFraction * it.persistence }

    /** Most frequent vivid colour inside [box]; a guess at the route-line colour. Null if nothing vivid. */
    fun routeColorGuess(frame: Frame, box: Roi): Int? {
        val r = box.toRect(frame.width, frame.height)
        val buckets = HashMap<Int, Int>()
        var total = 0
        for (y in r.y0 until r.y1) for (x in r.x0 until r.x1) {
            total++
            val p = frame.argb[y * frame.width + x]
            val rr = (p shr 16) and 0xFF
            val gg = (p shr 8) and 0xFF
            val bb = p and 0xFF
            val mx = max(rr, max(gg, bb))
            val mn = min(rr, min(gg, bb))
            if (mx < 128 || mx == 0 || (mx - mn).toFloat() / mx < 0.5f) continue
            val key = ((rr shr 4) shl 8) or ((gg shr 4) shl 4) or (bb shr 4)
            buckets[key] = (buckets[key] ?: 0) + 1
        }
        val best = buckets.maxByOrNull { it.value } ?: return null
        if (best.value < total * 0.01f) return null
        val k = best.key
        return (((k shr 8) and 0xF) * 17 shl 16) or (((k shr 4) and 0xF) * 17 shl 8) or ((k and 0xF) * 17)
    }
}

/** Decides whether two HUD analyses describe the same interface. */
object LayoutStability {
    /**
     * Compares the strongest elements of [old] with those of [new]. At least [MIN_MATCH_SHARE] of the old ones must have an
     * overlapping counterpart. Fewer than three elements in the old analysis is too little to judge, so it is accepted.
     */
    fun consistent(old: HudAnalysis, new: HudAnalysis): Boolean {
        val a = old.elements.take(6)
        if (a.size < 3) return true
        val b = new.elements.take(12)
        var matched = 0
        for (e in a) if (b.any { overlap(e.box, it.box) >= 0.5f }) matched++
        return matched.toFloat() / a.size >= MIN_MATCH_SHARE
    }

    const val MIN_MATCH_SHARE = 0.5f

    private fun overlap(a: Roi, b: Roi): Float {
        val l = max(a.left, b.left)
        val t = max(a.top, b.top)
        val r = min(a.right, b.right)
        val bt = min(a.bottom, b.bottom)
        if (r <= l || bt <= t) return 0f
        val inter = (r - l) * (bt - t)
        val union = (a.right - a.left) * (a.bottom - a.top) + (b.right - b.left) * (b.bottom - b.top) - inter
        return if (union <= 0f) 0f else inter / union
    }
}
