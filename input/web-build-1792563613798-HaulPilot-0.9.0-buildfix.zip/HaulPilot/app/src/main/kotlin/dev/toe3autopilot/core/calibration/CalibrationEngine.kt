package dev.toe3autopilot.core.calibration

import dev.toe3autopilot.core.Clock
import dev.toe3autopilot.core.session.LogLevel
import dev.toe3autopilot.core.session.SessionLog
import dev.toe3autopilot.core.vision.Frame
import dev.toe3autopilot.core.vision.GrayImage
import dev.toe3autopilot.core.vision.Roi
import kotlin.math.max
import kotlin.math.min

/** How long each part of a guided demonstration lasts. */
data class DemoTimings(
    val prepareMs: Long = 3000,
    val baselineMs: Long = 2000,
    val actionMs: Long = 4000,
    val releaseMs: Long = 2500,
)

/** What the engine knows, in a form that survives an app restart (patch images are stored separately). */
data class PersistedCalibration(
    val layout: LayoutSignature?,
    val detections: Map<CalibRole, ControlDetection>,
    val timing: TimingEstimate?,
)

enum class CalibPhase { IDLE, OBSERVING, PREPARE, BASELINE, ACTION, RELEASE, DONE }

data class CalibrationState(
    val phase: CalibPhase = CalibPhase.IDLE,
    val role: CalibRole? = null,
    val message: String = "Idle",
    /** Short instruction to show prominently during a demonstration (for example "NOW: press and HOLD the brake"). */
    val cue: String? = null,
    val progress: Float = 0f,
    val framesSeen: Int = 0,
    val hud: HudAnalysis? = null,
    val detections: Map<CalibRole, ControlDetection> = emptyMap(),
    val speedGuess: Alternative? = null,
    val minimap: MinimapSuggestion? = null,
    val timing: TimingEstimate? = null,
    val layout: LayoutSignature? = null,
    /** Position guesses to help the user choose when nothing was detected. Never confirmed automatically. */
    val guesses: Map<CalibRole, List<Alternative>> = emptyMap(),
    val problem: String? = null,
    /** The on-screen layout changed while observing: results so far are not trustworthy and calibration is paused. */
    val layoutUnstable: Boolean = false,
    /** The current analysis came from an imported clip, not from live capture. */
    val fromVideo: Boolean = false,
)

/**
 * Self-calibration state machine. It never touches the game: it only receives frames ([offerFrame]) and time
 * ([tick]) and produces *proposals*. Nothing it finds is used by the automation until it is CONFIRMED by the user
 * or AUTO_CONFIRMED from a clear demonstration (see [ControlDetection]).
 *
 * Typical flow: [startObserving] while the user plays normally (HUD discovery) -> [startDemo] per control (the user
 * performs the action when the cue says so) -> review proposals ([confirm], [reject], [place], [chooseAlternative])
 * -> apply with [CalibrationApply].
 *
 * All methods are thread-safe. Frame analysis runs on the caller's thread, so call from a background thread.
 */
class CalibrationEngine(
    private val clock: Clock,
    val log: SessionLog = SessionLog(),
    private val timings: DemoTimings = DemoTimings(),
    private val worldRoi: Roi = Roi(0.2f, 0.25f, 0.8f, 0.7f),
) {
    private val lock = Any()

    private var phase = CalibPhase.IDLE
    private var role: CalibRole? = null
    private var phaseStartedAt = 0L
    private var message = "Idle"
    private var problem: String? = null
    private var layoutUnstable = false
    private var fromVideo = false

    /** The last HUD analysis that succeeded; a later success must agree with it or the layout is considered changed. */
    private var lastGoodHud: HudAnalysis? = null

    private val observation = ArrayDeque<TimedFrame>()
    private var lastObservationAt = 0L
    private var lastAnalysisAt = Long.MIN_VALUE / 2
    private var framesSinceAnalysis = 0
    private var framesSeen = 0
    private var lastOfferedTs = Long.MIN_VALUE
    private var lastFrame: Frame? = null

    private var hud: HudAnalysis? = null
    private var minimap: MinimapSuggestion? = null
    private var layout: LayoutSignature? = null
    private var timing: TimingEstimate? = null
    private var speedGuess: Alternative? = null
    private val detections = LinkedHashMap<CalibRole, ControlDetection>()
    private val patches = HashMap<CalibRole, GrayImage>()

    private val baseline = ArrayList<TimedFrame>()
    private val action = ArrayList<TimedFrame>()
    private val release = ArrayList<TimedFrame>()
    private var actionStartMs = 0L
    private var releaseStartMs: Long? = null

    // ---- queries ---------------------------------------------------------------------------------------

    fun state(): CalibrationState = synchronized(lock) {
        val now = clock.nowMs()
        val dur = phaseDuration()
        val progress = if (dur > 0 && phase in DEMO_PHASES) ((now - phaseStartedAt).toFloat() / dur).coerceIn(0f, 1f) else 0f
        val r = role
        val cue = when (phase) {
            CalibPhase.PREPARE -> "Get ready: you will ${r?.prompt}"
            CalibPhase.BASELINE -> "Don't touch any control"
            CalibPhase.ACTION -> "NOW: ${r?.prompt}"
            CalibPhase.RELEASE -> "Release it now"
            else -> null
        }
        val guesses = CalibRole.entries.filter { it.demonstrable && detections[it]?.status?.usable != true }
            .associateWith { CalibrationGuesses.positionGuesses(it, hud) }
            .filterValues { it.isNotEmpty() }
        CalibrationState(
            phase, r, message, cue, progress, framesSeen, hud, detections.toMap(), speedGuess, minimap, timing, layout, guesses, problem,
            layoutUnstable, fromVideo,
        )
    }

    /** Patch images (unpressed look) for detections made in this run; used to verify the layout later. */
    fun patches(): Map<CalibRole, GrayImage> = synchronized(lock) { patches.toMap() }

    fun persisted(): PersistedCalibration = synchronized(lock) { PersistedCalibration(layout, detections.toMap(), timing) }

    /** How often the host should deliver frames in the current phase. */
    fun desiredFrameIntervalMs(): Long = synchronized(lock) {
        when (phase) {
            CalibPhase.BASELINE, CalibPhase.ACTION, CalibPhase.RELEASE -> 150L
            CalibPhase.OBSERVING -> 250L
            CalibPhase.PREPARE -> 500L
            else -> 1000L
        }
    }

    val isBusy: Boolean get() = synchronized(lock) { phase != CalibPhase.IDLE && phase != CalibPhase.DONE }

    // ---- control ---------------------------------------------------------------------------------------

    fun restore(p: PersistedCalibration) = synchronized(lock) {
        layout = p.layout
        detections.clear()
        detections.putAll(p.detections)
        timing = p.timing
    }

    fun startObserving() = synchronized(lock) {
        if (phase in DEMO_PHASES) return
        observation.clear()
        framesSinceAnalysis = 0
        lastAnalysisAt = Long.MIN_VALUE / 2
        lastObservationAt = 0L
        hud = null
        minimap = null
        problem = null
        layoutUnstable = false
        fromVideo = false
        lastGoodHud = null
        role = null
        phase = CalibPhase.OBSERVING
        message = "Observing. Play normally (drive or turn the camera) so the scenery moves; fixed buttons will stand out."
        log.add(clock.nowMs(), LogLevel.INFO, "Calibration: observing")
    }

    fun stopObserving() = synchronized(lock) {
        if (phase == CalibPhase.OBSERVING) {
            phase = CalibPhase.IDLE
            message = "Stopped observing"
            log.add(clock.nowMs(), LogLevel.INFO, "Calibration: stopped observing")
        }
    }

    /** Returns null if started, otherwise the reason it could not start. */
    fun startDemo(r: CalibRole): String? = synchronized(lock) {
        if (!r.demonstrable) return "${r.label} cannot be demonstrated"
        if (phase in DEMO_PHASES) return "A demonstration is already running"
        val h = hud
        if (h == null || !h.ok) return "Observe the HUD first (play with moving scenery for a few seconds)"
        val l = layout
        val f = lastFrame
        if (l != null && f != null && (f.width != l.width || f.height != l.height)) return "The screen size changed; observe again"
        baseline.clear(); action.clear(); release.clear()
        releaseStartMs = null
        role = r
        problem = null
        enter(CalibPhase.PREPARE)
        message = "Demonstration: ${r.label}"
        log.add(clock.nowMs(), LogLevel.INFO, "Calibration: demonstrating ${r.label}")
        null
    }

    fun cancel() = synchronized(lock) {
        if (phase != CalibPhase.IDLE) {
            phase = CalibPhase.IDLE
            role = null
            message = "Cancelled"
            log.add(clock.nowMs(), LogLevel.INFO, "Calibration: cancelled")
        }
    }

    /** Forget everything learned (detections, HUD, timing, patches). */
    fun reset() = synchronized(lock) {
        phase = CalibPhase.IDLE
        role = null
        layoutUnstable = false
        fromVideo = false
        lastGoodHud = null
        observation.clear()
        hud = null
        minimap = null
        timing = null
        speedGuess = null
        layout = null
        detections.clear()
        patches.clear()
        problem = null
        message = "Calibration reset"
        log.add(clock.nowMs(), LogLevel.INFO, "Calibration: reset")
    }

    // ---- review ----------------------------------------------------------------------------------------

    fun confirm(r: CalibRole): Boolean = synchronized(lock) {
        val d = detections[r] ?: return false
        if (d.status == DetectionStatus.NONE) return false
        detections[r] = d.copy(status = DetectionStatus.CONFIRMED, evidence = d.evidence + "confirmed by you")
        log.add(clock.nowMs(), LogLevel.INFO, "Calibration: ${r.label} confirmed by user")
        true
    }

    fun reject(r: CalibRole): Boolean = synchronized(lock) {
        val d = detections[r] ?: return false
        detections[r] = d.copy(status = DetectionStatus.REJECTED, evidence = d.evidence + "rejected by you")
        patches.remove(r)
        log.add(clock.nowMs(), LogLevel.INFO, "Calibration: ${r.label} rejected by user")
        true
    }

    /** The user pointed at the control themselves. */
    fun place(r: CalibRole, x: Float, y: Float) = synchronized(lock) {
        val px = x.coerceIn(0f, 1f)
        val py = y.coerceIn(0f, 1f)
        detections[r] = ControlDetection(r, px, py, null, 1f, DetectionStatus.CONFIRMED, DetectionSource.USER, listOf("placed by you"))
        lastFrame?.let { patchAround(r, it, px, py) }
        log.add(clock.nowMs(), LogLevel.INFO, "Calibration: ${r.label} placed by user")
    }

    /**
     * The user moved and/or resized the region of [r] by hand. The box is clamped to the picture; a box that is too small to
     * hold a control is refused. The result counts as the user's own confirmation.
     */
    fun setBox(r: CalibRole, box: Roi): Boolean = synchronized(lock) {
        val l = box.left.coerceIn(0f, 1f)
        val t = box.top.coerceIn(0f, 1f)
        val rr = box.right.coerceIn(0f, 1f)
        val b = box.bottom.coerceIn(0f, 1f)
        if (rr - l < MIN_BOX || b - t < MIN_BOX) return false
        val clamped = Roi(l, t, rr, b)
        val old = detections[r]
        detections[r] = ControlDetection(
            r, (l + rr) / 2f, (t + b) / 2f, clamped, 1f, DetectionStatus.CONFIRMED, DetectionSource.USER,
            (old?.evidence?.filter { !it.startsWith("moved") } ?: emptyList()) + "region moved or resized by you",
        )
        patches.remove(r)
        lastFrame?.let { patchFromBox(r, it, clamped) }
        log.add(clock.nowMs(), LogLevel.INFO, "Calibration: ${r.label} region adjusted by user")
        true
    }

    /**
     * Takes the result of analysing an imported clip. Candidates arrive as NEEDS_CONFIRMATION, so the usual review applies;
     * anything the person already confirmed or placed is kept. This only stores pictures-derived proposals: it can never
     * start a demonstration, a session, or any input.
     * @param preview the picture the boxes refer to (used for the stored control pictures).
     */
    fun importVideoResult(res: VideoCalibrationResult, preview: Frame, sourceLabel: String = "clip"): String? = synchronized(lock) {
        if (phase in DEMO_PHASES) return "A demonstration is running"
        if (!res.report.usable || res.hud == null || res.layout == null) {
            problem = res.report.problems.firstOrNull() ?: "The clip could not be used"
            message = problem ?: message
            return problem
        }
        phase = CalibPhase.DONE
        role = null
        observation.clear()
        hud = res.hud
        lastGoodHud = null
        layout = res.layout
        lastFrame = preview
        fromVideo = true
        layoutUnstable = false
        problem = null
        minimap = res.minimap
        for ((r, d) in res.detections) {
            val keep = detections[r]
            if (keep != null && keep.status.usable) continue
            detections[r] = d
            patches.remove(r)
            if (d.status == DetectionStatus.NEEDS_CONFIRMATION) d.box?.let { patchFromBox(r, preview, it) }
        }
        val found = res.detections.values.count { it.status == DetectionStatus.NEEDS_CONFIRMATION }
        message = if (found > 0) "The $sourceLabel gave $found candidate control(s). Check each one on the picture and confirm it."
        else "The $sourceLabel did not show enough to propose any control. ${res.missing.firstOrNull() ?: ""}".trim()
        log.add(clock.nowMs(), LogLevel.INFO, "Calibration: analysed the $sourceLabel ($found candidate(s))")
        null
    }

    /** Current detections, for an undo step. */
    fun detectionsSnapshot(): Map<CalibRole, ControlDetection> = synchronized(lock) { detections.toMap() }

    /** Puts back an earlier set of detections (Undo). Control pictures are re-cut from the current picture. */
    fun restoreDetections(saved: Map<CalibRole, ControlDetection>) = synchronized(lock) {
        detections.clear()
        detections.putAll(saved)
        patches.clear()
        val f = lastFrame
        if (f != null) {
            for ((r, d) in saved) {
                if (d.status == DetectionStatus.NONE || d.status == DetectionStatus.REJECTED) continue
                val box = d.box
                if (box != null) patchFromBox(r, f, box) else patchAround(r, f, d.x, d.y)
            }
        }
        log.add(clock.nowMs(), LogLevel.INFO, "Calibration: last change undone")
    }

    /** The user picked one of the alternative candidates for [r]. */
    fun chooseAlternative(r: CalibRole, index: Int): Boolean = synchronized(lock) {
        val d = detections[r] ?: return false
        val alt = d.alternatives.getOrNull(index) ?: return false
        detections[r] = d.copy(
            x = alt.x, y = alt.y, box = alt.box, confidence = min(d.confidence, alt.score).coerceIn(0f, 1f),
            status = DetectionStatus.CONFIRMED, evidence = listOf("chosen by you among the candidates (${alt.note})"),
            alternatives = emptyList(),
        )
        patches.remove(r)
        lastFrame?.let { f -> alt.box?.let { b -> patchFromBox(r, f, b) } }
        true
    }

    // ---- input from the host ---------------------------------------------------------------------------

    fun offerFrame(frame: Frame) = synchronized(lock) {
        if (frame.timestampMs != 0L && frame.timestampMs == lastOfferedTs) return
        lastOfferedTs = frame.timestampMs
        val now = clock.nowMs()
        lastFrame = frame
        framesSeen++
        val l = layout
        val sig = LayoutSignature(frame.width, frame.height)
        if (l == null) {
            layout = sig
        } else if (l != sig) {
            // The picture changed size/orientation: everything learned about positions in the old layout is stale.
            layout = sig
            observation.clear()
            hud = null
            minimap = null
            framesSinceAnalysis = 0
            val wasDemo = phase in DEMO_PHASES
            if (wasDemo) {
                phase = CalibPhase.IDLE
                role = null
            }
            problem = "The screen size changed (${l.width}x${l.height} to ${sig.width}x${sig.height}); previous HUD analysis was discarded"
            message = problem ?: message
            log.add(now, LogLevel.WARN, "Calibration: $problem")
        }
        val t = TimedFrame(now, frame)
        when (phase) {
            CalibPhase.OBSERVING -> {
                if (now - lastObservationAt >= OBSERVE_SPACING_MS) {
                    lastObservationAt = now
                    observation.addLast(t)
                    while (observation.size > MAX_OBSERVATION) observation.removeFirst()
                    framesSinceAnalysis++
                    if (observation.size >= HudAnalyzer.MIN_FRAMES && framesSinceAnalysis >= 4 && now - lastAnalysisAt >= 1500) {
                        analyseHud(now)
                    }
                }
            }
            CalibPhase.BASELINE -> baseline += t
            CalibPhase.ACTION -> action += t
            CalibPhase.RELEASE -> release += t
            else -> {}
        }
    }

    /** Advances demonstration timers. Call regularly (every 100-200 ms is plenty). */
    fun tick() = synchronized(lock) {
        if (phase !in DEMO_PHASES) return
        val now = clock.nowMs()
        if (now - phaseStartedAt < phaseDuration()) return
        when (phase) {
            CalibPhase.PREPARE -> enter(CalibPhase.BASELINE)
            CalibPhase.BASELINE -> {
                actionStartMs = now
                enter(CalibPhase.ACTION)
            }
            CalibPhase.ACTION -> {
                val r = role
                if (r != null && r.measuresTiming) {
                    releaseStartMs = now
                    enter(CalibPhase.RELEASE)
                } else {
                    finishDemo()
                }
            }
            CalibPhase.RELEASE -> finishDemo()
            else -> {}
        }
    }

    // ---- internals -------------------------------------------------------------------------------------

    private fun enter(p: CalibPhase) {
        phase = p
        phaseStartedAt = clock.nowMs()
    }

    private fun phaseDuration(): Long = when (phase) {
        CalibPhase.PREPARE -> timings.prepareMs
        CalibPhase.BASELINE -> timings.baselineMs
        CalibPhase.ACTION -> timings.actionMs
        CalibPhase.RELEASE -> timings.releaseMs
        else -> 0L
    }

    private fun analyseHud(now: Long) {
        lastAnalysisAt = now
        framesSinceAnalysis = 0
        applyHud(HudAnalyzer.analyse(observation.map { it.frame }))
    }

    private fun applyHud(a: HudAnalysis) {
        val prev = lastGoodHud
        hud = a
        if (prev != null && a.ok && !LayoutStability.consistent(prev, a)) {
            // The fixed elements are not where they were a moment ago: the interface changed (menu, other screen,
            // dialog). Anything learned from mixed layouts would be wrong, so calibration pauses and says so.
            layoutUnstable = true
            problem = "The on-screen layout changed while observing, so calibration was paused. Return to the driving screen and start again."
            message = problem ?: message
            if (phase in DEMO_PHASES || phase == CalibPhase.OBSERVING) phase = CalibPhase.IDLE
            observation.clear()
            hud = null
            lastGoodHud = null
            minimap = null
            log.add(clock.nowMs(), LogLevel.WARN, "Calibration: layout changed while observing; paused")
            return
        }
        layoutUnstable = false
        if (a.ok) {
            lastGoodHud = a
            problem = null
            message = "Found ${a.elements.size} fixed on-screen elements. Now demonstrate controls one by one."
            val cand = CalibrationGuesses.minimapCandidate(a)
            minimap = cand?.let { c ->
                val color = lastFrame?.let { CalibrationGuesses.routeColorGuess(it, c.box) }
                MinimapSuggestion(
                    c.box, color,
                    "A corner-placed element of map-like size and shape. This is a guess; confirm it on the Calibrate tab. ${if (color != null) "Route colour is the most common vivid colour in it." else ""}".trim(),
                )
            }
        } else {
            minimap = null
            problem = a.problem
            message = a.problem ?: "HUD not found yet"
        }
    }

    /**
     * Finds the HUD in already-saved snapshots (for example the sampled frames kept by the recorder) instead of live
     * observation. Returns null when the analysis ran (check [state] for the outcome) or the reason it could not run.
     * Compression artefacts in stored snapshots add noise, so live observation is the more reliable route.
     */
    fun analyseSnapshots(frames: List<Frame>): String? = synchronized(lock) {
        if (phase in DEMO_PHASES) return "A demonstration is running"
        if (frames.size < HudAnalyzer.MIN_FRAMES) return "Need at least ${HudAnalyzer.MIN_FRAMES} snapshots (got ${frames.size})"
        val w = frames.first().width
        val h = frames.first().height
        if (frames.any { it.width != w || it.height != h }) return "The snapshots have different sizes; use snapshots from one session and orientation"
        observation.clear()
        lastFrame = frames.last()
        layout = LayoutSignature(w, h)
        hud = null // a new, separate set of pictures: not compared with what was seen before
        lastGoodHud = null
        fromVideo = false
        applyHud(HudAnalyzer.analyse(frames))
        log.add(clock.nowMs(), LogLevel.INFO, "Calibration: analysed ${frames.size} saved snapshots")
        null
    }

    private fun finishDemo() {
        val r = role ?: run { phase = CalibPhase.IDLE; return }
        val h = hud
        val now = clock.nowMs()
        if (h == null || !h.ok) {
            phase = CalibPhase.DONE
            problem = "The HUD analysis is no longer available"
            message = problem ?: ""
            return
        }
        val res = DemoAnalyzer.analyse(r, h, baseline, action)
        detections[r] = res.detection
        patches.remove(r)
        val det = res.detection
        val baseFrame = baseline.lastOrNull()?.frame
        if (det.status != DetectionStatus.NONE && baseFrame != null && det.box != null) patchFromBox(r, baseFrame, det.box)
        if (r == CalibRole.ACCELERATOR) {
            speedGuess = res.speedReadoutGuess
            timing = TimingAnalyzer.estimate(baseline, action, release, actionStartMs, releaseStartMs, worldRoi)
        }
        if (r == CalibRole.STEER_LEFT || r == CalibRole.STEER_RIGHT) reconcileSteering()
        phase = CalibPhase.DONE
        val shown = detections[r] ?: det
        message = when (shown.status) {
            DetectionStatus.NONE -> "${r.label}: nothing found. ${shown.evidence.firstOrNull() ?: ""}"
            DetectionStatus.AUTO_CONFIRMED -> "${r.label}: found with high confidence (${(shown.confidence * 100).toInt()}%). Check the highlighted box."
            else -> "${r.label}: found with ${(shown.confidence * 100).toInt()}% confidence; please confirm."
        }
        problem = null
        log.add(now, LogLevel.INFO, "Calibration: ${r.label} -> ${shown.status} (${"%.2f".format(shown.confidence)})")
    }

    /** One element reacting to both left and right means a wheel, not two buttons; ask the user either way. */
    private fun reconcileSteering() {
        val l = detections[CalibRole.STEER_LEFT]
        val r = detections[CalibRole.STEER_RIGHT]
        val lb = l?.box
        val rb = r?.box
        if (l == null || r == null || lb == null || rb == null) return
        if (l.status == DetectionStatus.NONE || r.status == DetectionStatus.NONE) return
        if (iou(lb, rb) >= 0.5f) {
            val note = "the same element reacted to both directions, so it is probably a steering wheel rather than two buttons"
            for (d in listOf(l, r)) {
                if (d.status == DetectionStatus.CONFIRMED && d.source == DetectionSource.USER) continue
                detections[d.role] = d.copy(
                    status = DetectionStatus.NEEDS_CONFIRMATION, confidence = min(d.confidence, 0.6f), evidence = d.evidence + note,
                )
            }
            val wheel = detections[CalibRole.STEER_WHEEL]
            if (wheel == null || !wheel.status.usable) {
                detections[CalibRole.STEER_WHEEL] = ControlDetection(
                    CalibRole.STEER_WHEEL, l.x, l.y, lb, min(min(l.confidence, r.confidence), 0.6f), DetectionStatus.NEEDS_CONFIRMATION,
                    DetectionSource.DEMONSTRATION, listOf(note, "confirm only if steering is done by dragging a wheel or slider"),
                )
            }
        } else {
            val wheel = detections[CalibRole.STEER_WHEEL]
            if (wheel != null && !wheel.status.usable) detections.remove(CalibRole.STEER_WHEEL)
        }
    }

    private fun iou(a: Roi, b: Roi): Float {
        val l = max(a.left, b.left)
        val t = max(a.top, b.top)
        val r = min(a.right, b.right)
        val bt = min(a.bottom, b.bottom)
        if (r <= l || bt <= t) return 0f
        val inter = (r - l) * (bt - t)
        val union = (a.right - a.left) * (a.bottom - a.top) + (b.right - b.left) * (b.bottom - b.top) - inter
        return if (union <= 0f) 0f else inter / union
    }

    private fun patchFromBox(r: CalibRole, f: Frame, box: Roi) {
        val rect = box.toRect(f.width, f.height)
        if (rect.width < 4 || rect.height < 4) return
        patches[r] = f.toGray().crop(rect.x0, rect.y0, rect.x1, rect.y1)
    }

    private fun patchAround(r: CalibRole, f: Frame, x: Float, y: Float) {
        val half = max(6, (0.05f * min(f.width, f.height)).toInt())
        val cx = (x * f.width).toInt()
        val cy = (y * f.height).toInt()
        val x0 = (cx - half).coerceAtLeast(0)
        val y0 = (cy - half).coerceAtLeast(0)
        val x1 = (cx + half).coerceAtMost(f.width)
        val y1 = (cy + half).coerceAtMost(f.height)
        if (x1 - x0 < 4 || y1 - y0 < 4) return
        patches[r] = f.toGray().crop(x0, y0, x1, y1)
    }

    companion object {
        private val DEMO_PHASES = setOf(CalibPhase.PREPARE, CalibPhase.BASELINE, CalibPhase.ACTION, CalibPhase.RELEASE)
        private const val OBSERVE_SPACING_MS = 250L
        private const val MAX_OBSERVATION = 40
        private const val MIN_BOX = 0.02f
    }
}
