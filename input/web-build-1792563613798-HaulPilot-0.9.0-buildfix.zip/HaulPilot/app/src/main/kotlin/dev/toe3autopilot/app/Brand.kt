package dev.toe3autopilot.app

/**
 * Product name, creator credit and the brand colours, in one place. Plain ARGB ints so both the Compose screens and the
 * View-based floating controls (which run in the accessibility service) use exactly the same values.
 *
 * The internal Kotlin package stays `dev.toe3autopilot` on purpose: renaming packages touches every file and the manifest for
 * no user-visible gain. Only user-facing text and the application id carry the product name (HaulPilot).
 */
object Brand {
    const val APP_NAME = "HaulPilot"
    const val TAGLINE = "Drive smarter. Deliver better."
    const val CREDIT = "Made by Praju (praju_12)"

    /** Support or documentation page shown on the About screen. Null until a real one exists; no link is invented. */
    val SUPPORT_URL: String? = null

    // Surfaces: midnight navy to graphite.
    const val BG = 0xFF0A0E14.toInt()
    const val SURFACE = 0xFF121821.toInt()
    const val RAISED = 0xFF1A222D.toInt()
    const val BORDER = 0xFF283342.toInt()

    const val TEXT_PRIMARY = 0xFFF4F7FB.toInt()
    const val TEXT_SECONDARY = 0xFFA9B5C3.toInt()
    const val TEXT_MUTED = 0xFF7D8B9C.toInt()

    /** Electric orange: primary actions only (Start Auto Drive, Save, Confirm). Dark text on it for contrast (about 8:1). */
    const val PRIMARY = 0xFFFF8A1F.toInt()
    const val ON_PRIMARY = 0xFF1A0D00.toInt()

    /** Cyan: secondary actions, selection and calibration indicators. */
    const val ACCENT = 0xFF2DD4E6.toInt()
    const val ON_ACCENT = 0xFF05161A.toInt()

    const val SUCCESS = 0xFF3DDC84.toInt()
    const val WARNING = 0xFFFFB020.toInt()
    const val DANGER = 0xFFFF4D4F.toInt()
    /** Emergency Stop fill; white text on it is about 4.8:1. */
    const val DANGER_FILL = 0xFFD92D2D.toInt()
    const val INFO = 0xFF5AA9FF.toInt()
}
