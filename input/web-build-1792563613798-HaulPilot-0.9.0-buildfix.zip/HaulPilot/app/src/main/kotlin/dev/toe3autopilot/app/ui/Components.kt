package dev.toe3autopilot.app.ui

import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

// ---------------------------------------------------------------------------------------------------------------------
// Icons: a tiny hand-drawn set so the app needs no icon library and every glyph shares one stroke weight.
// ---------------------------------------------------------------------------------------------------------------------

enum class IconKind { DASHBOARD, TARGET, PROFILE, SETTINGS, VIDEO, CHECK, WARN, STOP, PLAY, PAUSE, UPLOAD, REFRESH }

@Composable
fun AppIcon(kind: IconKind, tint: Color, size: Dp = 24.dp, modifier: Modifier = Modifier) {
    Canvas(modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val sw = w * 0.085f
        val stroke = Stroke(width = sw, cap = StrokeCap.Round)
        fun line(x1: Float, y1: Float, x2: Float, y2: Float) =
            drawLine(tint, Offset(x1 * w, y1 * h), Offset(x2 * w, y2 * h), strokeWidth = sw, cap = StrokeCap.Round)
        when (kind) {
            IconKind.DASHBOARD -> {
                val r = CornerRadius(w * 0.08f)
                for (i in 0..1) for (j in 0..1) {
                    drawRoundRect(tint, Offset((0.14f + i * 0.40f) * w, (0.14f + j * 0.40f) * h), Size(0.32f * w, 0.32f * h), r, style = stroke)
                }
            }
            IconKind.TARGET -> {
                drawCircle(tint, radius = w * 0.30f, center = Offset(w / 2, h / 2), style = stroke)
                drawCircle(tint, radius = w * 0.07f, center = Offset(w / 2, h / 2), style = Fill)
                line(0.5f, 0.06f, 0.5f, 0.2f); line(0.5f, 0.8f, 0.5f, 0.94f)
                line(0.06f, 0.5f, 0.2f, 0.5f); line(0.8f, 0.5f, 0.94f, 0.5f)
            }
            IconKind.PROFILE -> {
                drawRoundRect(tint, Offset(0.2f * w, 0.1f * h), Size(0.6f * w, 0.8f * h), CornerRadius(w * 0.08f), style = stroke)
                line(0.34f, 0.34f, 0.66f, 0.34f); line(0.34f, 0.50f, 0.66f, 0.50f); line(0.34f, 0.66f, 0.52f, 0.66f)
            }
            IconKind.SETTINGS -> {
                line(0.12f, 0.25f, 0.88f, 0.25f); line(0.12f, 0.5f, 0.88f, 0.5f); line(0.12f, 0.75f, 0.88f, 0.75f)
                drawCircle(tint, w * 0.09f, Offset(0.65f * w, 0.25f * h), style = Fill)
                drawCircle(tint, w * 0.09f, Offset(0.32f * w, 0.5f * h), style = Fill)
                drawCircle(tint, w * 0.09f, Offset(0.58f * w, 0.75f * h), style = Fill)
            }
            IconKind.VIDEO -> {
                drawRoundRect(tint, Offset(0.1f * w, 0.24f * h), Size(0.56f * w, 0.52f * h), CornerRadius(w * 0.08f), style = stroke)
                val p = Path().apply {
                    moveTo(0.72f * w, 0.44f * h); lineTo(0.92f * w, 0.30f * h); lineTo(0.92f * w, 0.70f * h); lineTo(0.72f * w, 0.56f * h); close()
                }
                drawPath(p, tint, style = Fill)
            }
            IconKind.CHECK -> {
                line(0.2f, 0.52f, 0.42f, 0.72f); line(0.42f, 0.72f, 0.82f, 0.28f)
            }
            IconKind.WARN -> {
                val p = Path().apply { moveTo(0.5f * w, 0.12f * h); lineTo(0.92f * w, 0.84f * h); lineTo(0.08f * w, 0.84f * h); close() }
                drawPath(p, tint, style = Stroke(width = sw, cap = StrokeCap.Round))
                line(0.5f, 0.38f, 0.5f, 0.58f)
                drawCircle(tint, w * 0.045f, Offset(0.5f * w, 0.70f * h), style = Fill)
            }
            IconKind.STOP -> drawRoundRect(tint, Offset(0.2f * w, 0.2f * h), Size(0.6f * w, 0.6f * h), CornerRadius(w * 0.08f), style = Fill)
            IconKind.PLAY -> {
                val p = Path().apply { moveTo(0.3f * w, 0.18f * h); lineTo(0.82f * w, 0.5f * h); lineTo(0.3f * w, 0.82f * h); close() }
                drawPath(p, tint, style = Fill)
            }
            IconKind.PAUSE -> {
                drawRoundRect(tint, Offset(0.24f * w, 0.2f * h), Size(0.18f * w, 0.6f * h), CornerRadius(w * 0.04f), style = Fill)
                drawRoundRect(tint, Offset(0.58f * w, 0.2f * h), Size(0.18f * w, 0.6f * h), CornerRadius(w * 0.04f), style = Fill)
            }
            IconKind.UPLOAD -> {
                line(0.5f, 0.7f, 0.5f, 0.2f); line(0.5f, 0.2f, 0.3f, 0.4f); line(0.5f, 0.2f, 0.7f, 0.4f); line(0.2f, 0.84f, 0.8f, 0.84f)
            }
            IconKind.REFRESH -> {
                drawArc(tint, startAngle = -50f, sweepAngle = 280f, useCenter = false, topLeft = Offset(0.18f * w, 0.18f * h), size = Size(0.64f * w, 0.64f * h), style = stroke)
                line(0.78f, 0.12f, 0.78f, 0.32f); line(0.78f, 0.32f, 0.58f, 0.32f)
            }
        }
    }
}

// ---------------------------------------------------------------------------------------------------------------------
// Surfaces
// ---------------------------------------------------------------------------------------------------------------------

/** The one card style. [accent] tints the border (use for state, never for decoration). */
@Composable
fun Panel(
    modifier: Modifier = Modifier,
    title: String? = null,
    subtitle: String? = null,
    accent: Color? = null,
    trailing: (@Composable () -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    Surface(
        modifier = modifier.fillMaxWidth().animateContentSize(),
        shape = RoundedCornerShape(Dim.radiusCard),
        color = Tokens.Surface,
        border = BorderStroke(1.dp, accent?.copy(alpha = 0.55f) ?: Tokens.Border),
        shadowElevation = 2.dp,
    ) {
        Column(Modifier.padding(Dim.l), verticalArrangement = Arrangement.spacedBy(Dim.m)) {
            if (title != null) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f)) {
                        Text(title, style = MaterialTheme.typography.titleMedium, color = Tokens.TextPrimary)
                        if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = Tokens.TextSecondary)
                    }
                    trailing?.invoke()
                }
            }
            content()
        }
    }
}

/** Old name kept so existing screens inherit the new look. */
@Composable
fun SectionCard(title: String, content: @Composable () -> Unit) {
    Panel(Modifier.padding(vertical = Dim.xs), title = title) { content() }
}

@Composable
fun Body(text: String, modifier: Modifier = Modifier, color: Color = Tokens.TextSecondary) {
    Text(text, modifier, style = MaterialTheme.typography.bodyMedium, color = color)
}

@Composable
fun Caption(text: String, modifier: Modifier = Modifier, color: Color = Tokens.TextMuted) {
    Text(text, modifier, style = MaterialTheme.typography.bodySmall, color = color)
}

// ---------------------------------------------------------------------------------------------------------------------
// Buttons
// ---------------------------------------------------------------------------------------------------------------------

enum class ButtonKind { Primary, Secondary, Danger, Ghost }

@Composable
fun AppButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    kind: ButtonKind = ButtonKind.Primary,
    enabled: Boolean = true,
    icon: IconKind? = null,
    minHeight: Dp = Dim.minTouch,
) {
    val shape = RoundedCornerShape(Dim.radiusControl)
    val size = Modifier.heightIn(min = minHeight)
    val label: @Composable () -> Unit = {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(Dim.s)) {
            if (icon != null) {
                val tint = when (kind) {
                    ButtonKind.Primary -> Tokens.OnPrimary
                    ButtonKind.Danger -> Color.White
                    else -> if (enabled) Tokens.Accent else Tokens.TextMuted
                }
                AppIcon(icon, tint, 20.dp)
            }
            Text(text, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
    }
    when (kind) {
        ButtonKind.Primary -> Button(
            onClick = onClick, modifier = modifier.then(size), enabled = enabled, shape = shape,
            colors = ButtonDefaults.buttonColors(
                containerColor = Tokens.Primary, contentColor = Tokens.OnPrimary,
                disabledContainerColor = Tokens.Raised, disabledContentColor = Tokens.TextMuted,
            ),
        ) { label() }
        ButtonKind.Danger -> Button(
            onClick = onClick, modifier = modifier.then(size), enabled = enabled, shape = shape,
            colors = ButtonDefaults.buttonColors(
                containerColor = Tokens.DangerFill, contentColor = Color.White,
                disabledContainerColor = Tokens.Raised, disabledContentColor = Tokens.TextMuted,
            ),
        ) { label() }
        ButtonKind.Secondary -> OutlinedButton(
            onClick = onClick, modifier = modifier.then(size), enabled = enabled, shape = shape,
            border = BorderStroke(1.dp, if (enabled) Tokens.Accent.copy(alpha = 0.7f) else Tokens.Border),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = Tokens.Accent, disabledContentColor = Tokens.TextMuted),
        ) { label() }
        ButtonKind.Ghost -> TextButton(
            onClick = onClick, modifier = modifier.then(size), enabled = enabled, shape = shape,
            colors = ButtonDefaults.textButtonColors(contentColor = Tokens.Accent, disabledContentColor = Tokens.TextMuted),
        ) { label() }
    }
}

/** A row of buttons that scrolls sideways instead of squeezing on narrow phones. */
@Composable
fun ButtonRow(content: @Composable () -> Unit) {
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(Dim.s), verticalAlignment = Alignment.CenterVertically) {
        content()
    }
}

// ---------------------------------------------------------------------------------------------------------------------
// Status
// ---------------------------------------------------------------------------------------------------------------------

@Composable
fun StatusChip(label: String, color: Color, modifier: Modifier = Modifier) {
    Row(
        modifier.clip(CircleShape).background(color.copy(alpha = 0.14f)).padding(horizontal = Dim.m, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(color))
        Text(label, style = MaterialTheme.typography.labelMedium, color = color, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

/** A dot that breathes while something is happening. Stays still (and fully visible) when [pulsing] is false. */
@Composable
fun StateDot(color: Color, pulsing: Boolean, size: Dp = 14.dp) {
    val transition = rememberInfiniteTransition(label = "dot")
    val a = transition.animateFloat(
        initialValue = 1f, targetValue = 0.35f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "dotAlpha",
    )
    Box(Modifier.size(size).alpha(if (pulsing) a.value else 1f).clip(CircleShape).background(color))
}

/** Horizontal bar 0..1. */
@Composable
fun MeterBar(value: Float, color: Color, modifier: Modifier = Modifier, height: Dp = 6.dp) {
    Box(modifier.fillMaxWidth().height(height).clip(RoundedCornerShape(height / 2)).background(Tokens.Raised)) {
        Box(Modifier.fillMaxWidth(value.coerceIn(0f, 1f)).fillMaxHeight().background(color))
    }
}

enum class BannerKind(val color: Color) { Info(Tokens.Info), Success(Tokens.Success), Warning(Tokens.Warning), Error(Tokens.Danger) }

@Composable
fun Banner(
    kind: BannerKind,
    title: String,
    text: String? = null,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null,
    modifier: Modifier = Modifier,
) {
    Surface(
        modifier.fillMaxWidth().semantics { contentDescription = "$title. ${text ?: ""}" },
        shape = RoundedCornerShape(Dim.radiusControl),
        color = kind.color.copy(alpha = 0.10f),
        border = BorderStroke(1.dp, kind.color.copy(alpha = 0.45f)),
    ) {
        Row(Modifier.padding(Dim.m), horizontalArrangement = Arrangement.spacedBy(Dim.m), verticalAlignment = Alignment.Top) {
            AppIcon(if (kind == BannerKind.Success) IconKind.CHECK else IconKind.WARN, kind.color, 22.dp, Modifier.padding(top = 2.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(Dim.xs)) {
                Text(title, style = MaterialTheme.typography.titleSmall, color = Tokens.TextPrimary)
                if (text != null) Text(text, style = MaterialTheme.typography.bodyMedium, color = Tokens.TextSecondary)
                if (actionLabel != null && onAction != null) {
                    AppButton(actionLabel, onAction, kind = ButtonKind.Secondary, minHeight = 40.dp)
                }
            }
        }
    }
}

/** ✓ / ✕ line used for readiness lists. */
@Composable
fun CheckRow(label: String, ok: Boolean, detail: String? = null) {
    Row(
        Modifier.fillMaxWidth().semantics { contentDescription = "$label: ${if (ok) "ok" else "not ready"}" },
        horizontalArrangement = Arrangement.spacedBy(Dim.m),
        verticalAlignment = Alignment.Top,
    ) {
        val c = if (ok) Tokens.Success else Tokens.Warning
        AppIcon(if (ok) IconKind.CHECK else IconKind.WARN, c, 20.dp, Modifier.padding(top = 1.dp))
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(label, style = MaterialTheme.typography.bodyMedium, color = Tokens.TextPrimary)
            if (detail != null && !ok) Text(detail, style = MaterialTheme.typography.bodySmall, color = Tokens.TextSecondary)
        }
    }
}

/** Rounded pill used as a tab or filter. */
@Composable
fun Segment(label: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    Box(
        Modifier
            .heightIn(min = 40.dp)
            .clip(shape)
            .background(if (selected) Tokens.Accent.copy(alpha = 0.16f) else Tokens.Raised)
            .clickable(role = Role.Tab, onClick = onClick)
            .padding(horizontal = Dim.l, vertical = Dim.s),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, style = MaterialTheme.typography.labelLarge, color = if (selected) Tokens.Accent else Tokens.TextSecondary)
    }
}

@Composable
fun SegmentRow(labels: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(Dim.s)) {
        labels.forEachIndexed { i, l -> Segment(l, selected == i) { onSelect(i) } }
    }
}

@Composable
fun EmptyState(title: String, text: String, actionLabel: String? = null, onAction: (() -> Unit)? = null, icon: IconKind = IconKind.TARGET) {
    Column(Modifier.fillMaxWidth().padding(vertical = Dim.l), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(Dim.s)) {
        AppIcon(icon, Tokens.TextMuted, 36.dp)
        Text(title, style = MaterialTheme.typography.titleSmall, color = Tokens.TextPrimary)
        Text(text, style = MaterialTheme.typography.bodyMedium, color = Tokens.TextSecondary)
        if (actionLabel != null && onAction != null) AppButton(actionLabel, onAction, kind = ButtonKind.Secondary)
    }
}
