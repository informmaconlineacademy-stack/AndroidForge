# HaulPilot 0.9.0

**Drive smarter. Deliver better.**
*Made by Praju (praju_12)*

HaulPilot is a native Kotlin / Jetpack Compose driving assistant for *Truckers of Europe 3* (other driving games may follow).
It watches the screen (with your permission), follows the route line on the minimap, slows for bends and near the delivery
area, and can try to park when it is set up for that. **You** choose the job, attach the trailer, unload, collect payment and
pick the next job. Touches go through Android's accessibility API, or use **Assisted mode**, which only shows what it would do.

HaulPilot is an independent app, not affiliated with or endorsed by the developer or publisher of Truckers of Europe 3.

> ## Read this first: what has and has not been verified
>
> * **No APK has been built and nothing has been compiled against the real Android SDK.** The authoring sandbox cannot reach
>   Google's Android download servers, and no GitHub account was connected to it. Your GitHub Actions run is the first real
>   compile; a debug APK exists only if that run is green. HaulPilot is **not release-ready** until that build passes and the
>   on-phone checks in `docs/RELEASE_CHECKLIST.md` are done.
> * **Tested on a JVM with synthetic pictures and a simulated game: all unit tests pass** (see the table below), including the
>   new Smart Setup navigation steps.
> * **Type-checked only against hand-written stand-ins for Android classes:** data stores, runtime, notifier, recorder, screenshot
>   and video import, calibration controller (incl. the new guided steps), floating controls, accessibility service.
> * **Never compiled:** every Compose screen, `MainActivity`, the capture service and the resources (the icon's vector files were
>   checked by rendering them in Chromium).
> * Nothing has run on a phone or in the real game. HaulPilot **cannot read hidden game state** and **does not guarantee**
>   driving the route, delivery or parking.
> * The request mentioned a "Truckers Automation 0.7.0". That version was not available here, so this is built on 0.6.0. If you
>   have 0.7.0 changes made elsewhere, they are not in this project.

## What is new in 0.9.0 (capture and calibration fix)
See `ROOT_CAUSE_REPORT.md` for the causes found in the code and `DEVICE_TEST_CHECKLIST.md` for what to test on the phone.
* One honest screen status everywhere: Screen not connected / Waiting for permission / Screen connected / Capture failed.
* The game is found automatically (by name, or by starting Auto-Calibrate from the floating button while the game is in front).
* Live picture of the game in Smart Setup, from the same frames the analysis uses; stale pictures fixed in the capture service.
* **One-tap Auto-Calibrate** with seven real stages, then a review: Yes or one tap per open item, zoom/pan, Undo, Reset, Confirm.
* Floating button shows connection and calibration progress, Auto-Calibrate, "This app is the game", Hide and Emergency Stop.
* New tests: screen link, frame gate, Auto-Calibrate run, viewport, tap snapping, zoom mapping, overlay sync.

## What is new in 0.8.0
* **HaulPilot brand:** name, tagline and credit on the splash screen (Android 12+ system splash; launch window on 8–11), About,
  Settings and the first-run welcome card; launcher label, notification and accessibility texts; docs. Not on the in-game overlay.
  Application id `com.praju12.haulpilot`, version 0.8.0 (code 8). Kotlin package names unchanged (no visible effect).
* **New original icon:** a heavy tractor-trailer cresting a curved road, cyan navigation arrow, electric-orange cab and lane marks,
  midnight-navy background. Adaptive (background + foreground + Android 13 themed layer), notification icon, 512 px store icon,
  feature graphic. Everything important sits inside the 66 dp safe zone; previews on light and dark wallpapers in `docs/store/`.
* **Smart Setup** (formerly Auto-Calibration) now covers the screen and the map too, by tapping instead of naming templates:
  1. *Driving screen*: one button; HaulPilot picks a steady part of the dashboard (never a control, the minimap or the speed readout).
  2. *Minimap*: use the one it found, or tap it; Larger / Smaller.
  3. *Route line* and 4. *your truck*: tap them on the map (grey/black taps and taps outside the map are refused with a reason).
  5. Optional *destination marker* (refused if it has the route's colour) and 6. *parking area*.
  Works on screenshots, an imported clip or live play. Every change can be undone.
* **The template editor is gone from normal use.** The expert editor and profile text only appear in Calibration Profiles when
  Settings → General → *Advanced tools* is switched on (off by default). Start-up and checklist messages point to Smart Setup.

## Using it (once built and installed)
1. Settings → General: pick the game. Settings → Permissions: turn on the accessibility service (accept the explanation). Start in
   Assisted mode (Settings → Driving).
2. **Smart Setup**: pick a few screenshots of the driving view, or import ~10 s of gameplay, or observe live play. Confirm only the
   controls it is unsure about, then **Save profile**.
3. **Smart Setup → Navigation and screen**: steps 1–4 (and optionally 5–6).
4. In the game: take a job, attach the trailer, drive to a safe start. Press **START AUTO DRIVE**.
5. Pause / Resume / Emergency Stop: Dashboard, the floating button's panel, or the notification.

## Background operation and storage

* Capture runs in a foreground service (type *mediaProjection*) with a persistent notification (Pause/Resume, End, Emergency stop).
  A small floating button (accessibility overlay, no branding on it) can be dragged to a screen edge and remembers its place; tap it for the
  state, live calibration progress, Start / Pause / Resume / End and Emergency Stop. Keep it off the calibrated controls.
* The service is not sticky. If Android ends capture the session stops and you must start again (Android asks consent each time).
  Some phones (MIUI/HyperOS, Oppo, Vivo, Huawei, Samsung "sleeping apps") need *No restrictions* in battery settings.
* Frames are analysed in memory at ~480 px and discarded. **No video is recorded.** Stored pictures are only control pictures
  you accept and optional low-rate sample snapshots (off by default, capped, deletable). Imported clips are read in place and
  never copied. The app has no `INTERNET` permission.

## Building from a phone (GitHub Actions)

Easiest: the single file **`haulpilot-build.yml`** (sent separately) contains the whole project. Put it in any GitHub repository
as `.github/workflows/haulpilot-build.yml`; GitHub unpacks the project, runs the tests, compiles and offers
**haulpilot-debug-apk** under *Artifacts* only if everything succeeded (otherwise a `build-log`).

This project also contains the regular workflows in `.github/workflows/` (`build.yml`: tests, debug APK, lint report, release
configuration check, optional emulator tests; `unpack-zip.yml`: unpacks an uploaded `project.zip`).

With a computer: JDK 17 + Android SDK 36, then `./gradlew testDebugUnitTest assembleDebug`. Release signing:
`tools/make-keystore.sh`, then `./gradlew assembleRelease` (keystore and passwords stay out of git).

## Permissions

| Permission / capability | Why |
|---|---|
| Screen capture (MediaProjection, consent each time) | See the game screen. In memory only. |
| `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_MEDIA_PROJECTION` | Required to capture while the game is in front. |
| `POST_NOTIFICATIONS` (optional) | State notification and arrival/help alerts. |
| `VIBRATE` (optional) | Countdown and alert buzz. |
| Accessibility service (you enable it) | `dispatchGesture` touches, foreground package name, floating panel. Window content is **not** read. |
| Photo Picker / file picker | Chosen videos and screenshots are read once through Android's own pickers; no storage permission. |
| Launcher `<queries>` | List launchable apps to choose the game. |

## Privacy and store publishing
* `PRIVACY.md` — privacy policy (add contact details and host it publicly before publishing).
* `docs/STORE_LISTING.md` — honest listing text, graphics, and what Google Play asks for (Accessibility declaration with a video,
  data safety form). Approval by any store is **not** guaranteed; Play Protect may warn about sideloaded apps using accessibility.
* `docs/RELEASE_CHECKLIST.md`, `docs/ASSETS.md` (icon sources and licences).
* Supported Android versions: 8.0 (API 26) to 16 (API 36). Phone screens; tablets untested.
* Dependencies (Apache 2.0): AndroidX Core, Activity Compose, Compose BOM 2025.09.00, kotlinx-coroutines; JUnit 4 and AndroidX Test.
  Pinned in `gradle/libs.versions.toml`; not checked against vulnerability databases from the sandbox. Dependabot proposes updates.

## Tests: simulated versus real
| Area | Suite (JVM, synthetic) |
|---|---|
| Capture faults, black/protected frames, permission denial, projection stop | `CaptureHealthTest`, `StatusAdviceTest` |
| Video clip validation, sampling, invalid clips, candidate caps | `VideoCalibrationTest` |
| Calibration confidence, false positives, layout instability, stages | `CalibrationEngineTest`, `CalibrationSupportTest`, `CalibrationProgressTest` |
| Road tracking and its loss | `RoadTrackingTest`, `SessionManagerTest` |
| Delivery detection, parking verification | `DeliveryAreaDetectorTest`, `AgentsTest` |
| Emergency Stop, pause/resume, no auto-resume, typed stop reasons | `SessionManagerTest` |
| Screen rotation / size change | `CalibrationSupportTest`, `LayoutGateTest`, `OverlayModelTest` |
| Floating controls state sync, placement, tap guard | `OverlayModelTest` |
| Error / empty / progress states | `StatusAdviceTest` |
| Driving states | `UserStateMappingTest` |
| Smart Setup navigation steps (driving screen, minimap, route line, truck, destination, parking area) | `GuidedSetupTest` |
| Closed loop | `SimulatedGameTest` (simulated game, not the real one) |

Instrumented tests (`app/src/androidTest`: stores, floating-button position, disclosure consent) exist but were never run.
**Real-device validation is still required** for everything Android-specific and for behaviour in the real game.

## Layout
```
app/src/main/kotlin/dev/toe3autopilot/
  core/   Android-free logic: vision/, agents/, session/, profile/, calibration/ (incl. GuidedSetup), capture/, overlay/, status/
  app/    Android layer: Brand.kt, capture/, input/ (accessibility service, FloatingControls), calibration/, data/,
          ui/ (Theme, Components, BrandUi, Dashboard, Smart Setup, Navigation setup, Profiles, Settings, About, Help)
app/src/main/res/   icon, splash, themes, strings
app/src/test/       JVM unit + simulation tests
docs/               store listing, release checklist, assets, store graphics
tools/              icon generator, keystore script, offline core verification
.github/            workflows, dependabot
```
