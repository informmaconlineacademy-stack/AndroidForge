# HaulPilot 0.9.0 — Phone test checklist

Do these on your phone after the GitHub build succeeds. Tick only what you actually saw.

## Screen connection
- [ ] Status shows **Screen not connected** before connecting.
- [ ] Tap Connect: status shows **Waiting for permission** while Android's dialog is open.
- [ ] Decline: status shows **Capture failed** (permission not granted) with "Try again".
- [ ] Accept ("Entire screen"): status shows **Screen connected**.
- [ ] Open the game for a few seconds, return: Smart Setup shows a picture of the game and its age.
- [ ] Use "stop sharing" from the notification/status bar: status shows **Capture failed** and nothing restarts by itself.
- [ ] Rotate the phone with capture on: the picture keeps updating.
- [ ] If the floating button says another app is in front while you are in the game: tap **This app is the game**, then Auto-Calibrate.

## Auto-Calibrate
- [ ] From the floating button in the game: tap Auto-Calibrate and drive ~15 s, pressing accelerator and brake once or twice.
- [ ] The button's panel shows the stages and "N of 45 pictures" rising only while the game is in front.
- [ ] Back in HaulPilot: stages end in Done / Check, never stuck on Working.
- [ ] Boxes for accelerator and brake are on the right buttons (zoom in to check).
- [ ] Steering and truck position ask for Yes or a tap; tapping a button snaps the box onto it.
- [ ] Undo reverts the last tap; Reset starts over; Confirm is only enabled when all checks are done.
- [ ] After Confirm: Calibration Profiles → Checklist shows the driving screen, minimap and controls as done.
- [ ] Try with the truck parked (no movement): Auto-Calibrate fails at "Identifying driving controls" with "Drive … and retry".

## Fallbacks
- [ ] More options → Screenshots / Recorded clip still work and say they do not give live control.

## Driving (only after calibration)
- [ ] Assisted mode first: hints appear, no touches are sent.
- [ ] A short real drive with a finger near Emergency Stop. Emergency Stop on the panel and the notification releases all touches.
