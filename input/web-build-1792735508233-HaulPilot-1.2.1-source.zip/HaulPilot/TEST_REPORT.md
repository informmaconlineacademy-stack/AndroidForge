# HaulPilot 1.2.0 — Test report

Date: 21 October 2026. Environment: Linux container, JDK 17, Kotlin compiler 2.2.20 (same version as the project), JUnit
4.13.2. **No Android SDK, no Gradle dependency download** (Google's Maven repository and the Android SDK servers are
blocked from this environment), **no emulator, no phone, no game.**

## 000. 1.2.1 — floating button

`OverlayGeometryTest` (9 tests, passing; synthetic): tap vs drag with wobble inside the slop; a drag is never a tap even if it
returns to the start; no drift over 400 events; clamping at every edge with system bars; place/snap round trip and rotation;
panel fully on screen and shrinking on narrow screens; repeated shows create one window, removal is idempotent, a refused
`addView` leaves nothing; a reconnected service takes over and the old owner is released once; a burst of changes is one refresh
and a cancelled one never runs. Everything else (WindowManager, rendering, real touches, rotation, permission revocation,
over the game, with live capture) **requires a physical device and was NOT tested**. No Gradle build possible here (Maven 403);
no APK.

## 00. 1.2.0 — game identity, driving-screen recognition, readiness (results first)

**Everything in this section was run on SYNTHETIC pictures and fakes. Nothing was verified on the phone or in the game.**
The user's 46 pictures and the Diagnostics log of the failing run were not supplied, so none of the failures was reproduced on
real input; the causes are traced in the code (`ROOT_CAUSE_REPORT.md`, section 1.2.0, status "Inferred" where that applies).

| Check | Result |
|---|---|
| All JVM unit tests, Kotlin 2.2.20 | **OK (441 tests), 0 failures** (410 in 1.1.0; +31) |
| Same tests, Gradle's embedded Kotlin 2.0.21 (`tools/verify-core-offline.sh`) | **OK (441 tests)** |
| Type-check of the app layer (78 files) against `android.jar` + stand-ins (`tools/typecheck/typecheck.sh`) | **0 errors, 0 warnings** |
| Same with the Compose compiler plugin (`--plugin`) | front-end checks passed; code generation stops as expected (no real Compose runtime here) |
| Stand-ins versus published API files (`verify_stubs.py`) | 229 match; the same 8 documented exceptions |
| Gradle `testDebugUnitTest`, `assembleDebug`, `assembleRelease` | **NOT RUN: Google Maven / Android SDK servers return 403 here. No 1.2.0 APK exists.** The first real compile is the GitHub Actions run. |

New tests (all passing):

| Requirement | Test |
|---|---|
| Package-switching bug: Play services / Play Store / permission windows, HaulPilot and system UI can never be the selected game; a saved wrong value is repaired, a good one kept | `GameIdentityTest` (9) |
| Selected game and app in front are separate; helper pop-up neither replaces nor counts as the game, blocks touch for 6 s, then releases | `GameIdentityTest` |
| Foreground loss pauses, the message names both packages, resume refused until the game is confirmed in front ("unknown" is not confirmed), nothing sent meanwhile | `GameIdentityTest` |
| Weighted matching of translucent controls: raw patch passes 30 % of pictures, weighted 100 %; control pictures are masked; recognised across driving pictures | `RecognitionTest` (12) |
| Dark but valid frames recognised; faint HUD on a black world is a usable picture | `RecognitionTest` |
| Black, one-colour, menu and other-app pictures never recognised | `RecognitionTest` |
| Score flicker around the threshold (3 of 5 rule) | `RecognitionTest` |
| 15 s timeout produces a report (last picture, reason, per-check scores) and **Try again** resumes and succeeds; a black capture is reported as a capture problem, not a wrong screen | `RecognitionTest` (via the session) |
| Start refused while the newest picture is black / one flat colour, nothing sent | `RecognitionTest`, `SimulatedGameTest` |
| Profile test judges several pictures, names the app in front, rejects stale and black pictures, and never lets a complete saved profile imply a live picture (`verifiedLive` vs `profileComplete`) | `SetupSessionTest` (+4) |
| Connected screen with unusable pictures is not "Ready" | `DriveReadinessTest` (+1) |
| Minimap found when no pedal / steering is; lone pedal not assigned but listed; unassigned outlines exclude placed controls; reverse optional | `ControlDetectionRegressionTest` (4) |

Existing tests changed, and why: the synthetic "game" background was one flat colour, which is now (correctly) an invalid
capture, so `Synth.blankPixels` is a gentle brightness ramp; `theSessionNeverActsOnAGame…` now uses ramp scenery and a new
test covers the flat-colour refusal; `ScreenLinkTest.theWrongAppInFrontIsSaidAndCanBeFixed` now expects "Open the game"
(the selected game is never re-chosen from what is in front); the "This app is the game" button test became a test that the
floating button has no way to change the game.

Real-picture evidence is unchanged from 1.1.0 (two single screenshots, section 0). **No real gameplay frames were used for
the new recognition work.** If you send a screen recording or numbered frames, they can be added as fixtures
(`app/src/test/resources/fixtures/toe3/README.md`).

## 0. Auto-Calibrate (new in 1.1.0) — results first

### On the user's REAL Truckers of Europe 3 pictures (`RealScreenshotTest`, `RealScreenshotRobustnessTest`)
Two pictures cut out of the user's phone screenshots of HaulPilot, scaled to the app's 480 px analysis size
(`tools/fixtures/make_fixture.py` reproduces them byte for byte). Ground truth was marked by hand on enlarged, gridded
views (`*.expected.properties`). Both are **single pictures**, so they exercise the weaker single-picture path.

| Picture | What must be found | Result |
|---|---|---|
| `toe3_v09_review` — chase camera, translucent pedals over grass, arrows almost invisible over bushes, two gauges, trailer, HaulPilot's own button | brake, accelerator; nothing on gauges, trailer, top-left indicator or the own button | **PASS**: brake and accelerator proposed on the pedals (evidence 45 % = the cap for one picture, "single picture" stated); arrows not proposed (too faint: allowed); nothing on any distractor |
| `toe3_v1_editor` — same HUD on asphalt, round translucent arrow buttons; pedals hidden under HaulPilot's editor UI in this screenshot | steer left, steer right; no pedal (they are not visible); nothing on trailer, gauges, two small round buttons, own UI | **PASS**: left/right proposed on the arrow buttons (44 %, mirror-image insides stated); no wheel; no pedal; nothing on any distractor |
| Same, without telling the analysis where HaulPilot's button is | the own button must still not become a control or the marker | **PASS** |

Robustness (the detector was developed while looking at these pictures, so each was also changed: darker ×0.8,
brighter ×1.15, noise ±8, 3×3 blur, a 14 px black cut-out band, 6 px cropped at the top, 400 px and 560 px wide):

| Picture | Found correctly | Wrong proposals |
|---|---|---|
| `toe3_v09_review` | **8 of 9** (heavy blur: "not found") | **0 of 9** |
| `toe3_v1_editor` | **9 of 9** | **0 of 9** |

Annotated pictures and reports of these runs are written to `build/fixture-reports/` (CI: the `reports` artifact).

### On synthetic many-picture driving scenes (`Toe3RealSceneTest`, 11 tests)
`Toe3RealScene` imitates the user's screen (arrows or wheel, translucent pedals with grip dots, gauges cut by the edge,
fixed trailer whose doors look like a pedal pair, signs, HaulPilot's button, noise). 45 moving pictures each:
arrows 20:9; wheel; 19.5:9 with a black cut-out band, status-bar strip and dusk light; 16:9; 4:3; faint controls
(alpha 0.3); own button not excluded; no HUD (nothing proposed); parked truck (single-picture result, said so); the whole
`SetupAnalysis` with real progress and cancellation. **All pass.** This shows the many-picture method; it is **not** the
real game.

### Flow, review and overlay (`AutoCalibrateTest`, 20 tests)
Only moving pictures count; a standing truck keeps ≤ 3 pictures and is asked to drive; the 75 s limit analyses what was
collected and says it is weaker; black and frozen pictures are not used; other apps / HaulPilot itself ignored; cancel
keeps pictures and a retry starts clean; stop early analyses; the full flow collect → analyse → review → confirm → validate
→ save → restore (draft codec) with undo/redo; a moved marker is "placed by you", the rest stay candidates; a marker
dragged onto another control cannot be saved; an analysis of another screen shape starts empty (undo restores);
stale progress ignored; steering style inferred or asked; touch hit-testing; "Next spot" cycles without confirming;
confirming confirms only shown candidates; stage derivation; own-window regions; floating-button labels and honest
percentages. **All pass.**

## 1. What was run and the real results

| # | Check | Command | Result |
|---|---|---|---|
| 1 | All JVM unit tests (core: geometry, detection incl. the real screenshots, Smart Setup and Auto-Calibrate state, profiles, sessions, safety, status models, simulated game) | kotlinc 2.2.20 `-jvm-target 17`, then `JUnitCore` on every `*Test` class (`tools/verify-core-offline.sh` does the same with Gradle's embedded Kotlin) | **OK (441 tests)**, 0 failures |
| 2 | The same tests compiled with **Gradle's own embedded Kotlin** (2.0.21, from the Gradle 8.14 distribution) instead of 2.2.20 | `tools/verify-core-offline.sh` | **OK (441 tests)**, exit 0 |
| 3 | Type-check of the whole app layer (all screens incl. the new Auto-Calibrate screen, MainActivity, services, floating controls, stores) plus the core, against `android.jar` (API 36) and hand-written AndroidX/Compose stand-ins | `tools/typecheck/typecheck.sh` | **0 errors, 0 warnings** (78 source files) |
| 4 | Same, with the Compose compiler plugin's checks (e.g. "@Composable invocations can only happen from a @Composable function") | `tools/typecheck/typecheck.sh --plugin` | **0 front-end errors.** The plugin then stops at code generation because the real Compose runtime is not available here (expected; no classes are produced). A deliberate wrong call in a probe file *is* reported by the plugin, so its checks were active. |
| 5 | Stand-ins versus the published AndroidX API signature files (Compose UI/foundation/runtime 1.9.0-beta01, Material3 1.4.0-beta03, Activity 1.11.0-beta01, Lifecycle runtime-compose 2.9.0-beta01, Core 1.11.0-beta02) | `tools/typecheck/verify_stubs.py` | **229 Kotlin declarations match** (names, order, required/optional parameters). The 8 remaining entries are Java methods whose parameters have no names in the signature files (checked by hand: same types and order) plus `enableEdgeToEdge` (published under its JVM name `EdgeToEdge.enable`, same parameters) and `ServiceCompat.startForeground` (added in androidx.core 1.12; the project uses core-ktx 1.17; already used by 0.9.0). |
| 6 | CI file check steps of `.github/workflows/build.yml` run locally on the project | step scripts extracted and run with `bash -eo pipefail` | "All expected files are present" (78 main / 40 test Kotlin files) |

### Unit tests per class (all passing)
| Area | Test class (tests) |
|---|---|
| Coordinates: display, capture surface letterbox and crop, frame, editor fit, zoom/pan, inverse round trips, rotation of the unit square | `GeometryTest` (20) |
| Editor boxes: corners, resize without flipping, move at edges, hit testing at any zoom | `BoxEditingTest` (7) |
| Candidate detection on a synthetic TOE3-like scene (pedals, wheel or arrow buttons, minimap, hidden brake, no HUD, still frames, never confirmed, confidence cap) | `ControlCandidateTest` (13), `ControlDetectionRegressionTest` (4), `GameIdentityTest` (9), `RecognitionTest` (12) |
| **Auto-Calibrate on the user's real screenshots**, and on changed versions of them | `RealScreenshotTest` (4), `RealScreenshotRobustnessTest` (2) |
| **Many-picture detection on the harder synthetic TOE3 scene** (layouts, screen shapes, cut-out, own button, distractors, progress, cancel) | `Toe3RealSceneTest` (11) |
| **Auto-Calibrate flow**: collection, analysis, review, confirm/save/restore, cancel/retry, duplicates, overlay | `AutoCalibrateTest` (20) |
| Fixed-element separation | `HudAnalyzerTest` (4) |
| Smart Setup state model: capture, duplicate jobs, interruption, permission loss, black/blank/corrupt frames, rotation, stale results, cancel, undo/redo, validation, save, restore, reset, step states, safe test | `SetupSessionTest` (38) |
| Profiles: atomic save, interrupted save recovery, previous version, delete/undo, import, migration | `ProfileRepositoryTest` (12), `ProfileTest` (12), `ProfileArchiveTest` (5), `ProfileEditingTest` (10), `CalibrationChecklistTest` (3) |
| Dashboard readiness ("Ready" only when every prerequisite holds) | `DriveReadinessTest` (7) |
| Automation safety: emergency stop releases only, pause/resume, watchdogs, no auto-resume, typed stop reasons | `SessionManagerTest` (41) |
| Status texts and recovery actions | `StatusAdviceTest` (14), `UserStateMappingTest` (5), `UserStateTest` (2) |
| Floating controls model | `OverlayModelTest` (15) |
| Capture health, frame gate, screen link, frame statistics | `CaptureHealthMonitorTest` (14), `FrameGateTest` (3), `ScreenLinkTest` (5), `FrameStatsTest` (7) |
| Clip import validation and analysis | `VideoValidatorTest` (7), `VideoSamplePlanTest` (4), `VideoCalibrationAnalyzerTest` (10) |
| Driving logic (simulated) | `RoadTrackerTest` (11), `DrivingControllerTest` (10), `NavigationDriveAgentTest` (7), `ParkingAgentTest` (6), `RecoveryAgentTest` (9), `DeliveryAreaDetectorTest` (14), `ControlMapperTest` (8), `PulseDriverTest` (3), `StateDetectorTest` (8), `LayoutCheckTest` (4), `LayoutGateTest` (6), `VisionTest` (14), `SimulatedGameTest` (14) |
| Misc. | `AnalyzerDiagnosisTest` (3), `GuidedSetupTest` (1), `TapSnapTest` (1), `SessionHistoryTest` (2) |

## 2. What was NOT run (and must not be read as passed)

| Not done | Why | Where it happens instead |
|---|---|---|
| Gradle build, `assembleDebug`, lint, resource merging, dexing | Google Maven / Android SDK blocked here | `.github/workflows/build.yml` on GitHub |
| **Debug APK** | as above — **no APK exists from this work** | the `haulpilot-debug-apk` artifact of a green CI run |
| Release APK | no signing material is configured (none was invented) | `tools/make-keystore.sh` + `keystore.properties`, then `assembleRelease` |
| Compose UI tests, screenshot tests | need the real Compose runtime and a device | — (not written) |
| Instrumented tests (`app/src/androidTest`: settings, profile PNG round trip, unfinished-setup restore, floating button position, disclosure consent) | need an emulator | `build.yml` → Run workflow → "device tests" |
| Anything on a phone, MediaProjection, accessibility gestures, the real game | no device | `DEVICE_TEST_CHECKLIST.md` |
| **Auto-Calibrate on live gameplay** (the many-picture path on the real game; the review screen on a real screen) | no device; only two single real pictures were available | `DEVICE_TEST_CHECKLIST.md` → "Auto-Calibrate" |

The type-check (rows 3–5) proves that the Android and Compose code resolves against faithful stand-ins of the APIs. It
cannot find problems that only appear in a real build (for example resource or manifest errors, Gradle dependency
resolution, R8/lint findings) or at run time.
