# HaulPilot 1.2.0 — Phone test checklist

Do these on a phone after the GitHub build succeeds. **None of them has been done yet.** Tick only what you actually saw,
and note the phone model, Android version and game version.

## 1.2.1 — floating button over Truckers of Europe 3 (the glitch must be judged here)
- [ ] Exactly one button. Turn the accessibility service off and on, force-stop and reopen HaulPilot: still one.
- [ ] Over the running game (with screen sharing on): the button is steady, crisp and fully drawn for 2 minutes; note any flicker.
- [ ] Drag slowly and fast to every edge, also over the status/navigation bar areas: follows the finger, no jumps, stays inside.
- [ ] Release: it snaps to the nearer side and stays there after leaving and reopening the app.
- [ ] A drag never opens the panel; a tap does; tap again or ✕ closes it; panel stays on screen and compact.
- [ ] Rotate the phone with the button and with the panel open: one button, re-placed on screen, no leftovers.
- [ ] Emergency Stop from the panel and from the notification.
- [ ] Revoke the accessibility permission while the panel is open: all windows disappear; re-grant: one button.
- [ ] Screen capture keeps delivering pictures and Auto-Calibrate still ignores the button while it is moved.
- [ ] If it still glitches: screen recording + phone model + Android version + Diagnostics log.

## 1.2.0 — game identity, return to the game, recognition, live picture (do these first)
- [ ] Settings → Game & screen capture shows `com.WandaSoftware.TruckersofEurope3` (installed name) and an "In front right
      now" line. Try choosing Google Play services / HaulPilot / the launcher: refused with a reason.
- [ ] Start Auto-Calibrate from the floating button while a Google Play Games / sign-in banner is on screen: the selected game
      does **not** change (Diagnostics: "Helper window opened: com.google.android.gms (selected game: …TruckersofEurope3 …)").
- [ ] With a drive running, pull down a Play services pop-up or switch to another app: HaulPilot pauses, the message names
      the selected game AND the app in front, and nothing is pressed in the other app. Return to the game: Resume works only
      once the game is in front (and 6 s after a pop-up).
- [ ] Open HaulPilot itself during a drive: paused, nothing sent.
- [ ] Start Auto Drive with the game open on the driving view: recognised, no timeout. Then deliberately start from the
      main menu: after 15 s the **card** appears with the last picture, the area looked for, the reason, **Try again**,
      **Open the game**, **Auto-Calibrate again** (each does something). Go to the driving view, Try again: it starts.
- [ ] Night driving / a tunnel: still recognised (or the card says the marker score was too low, with the score).
- [ ] Smart Setup step 10 → Run the test with the game in front: "A live picture of the selected game" ok, "Recognised in N of
      the last M pictures", and the summary says "recognised on live pictures". Run it with another app in front: the summary
      says "complete, but NOT verified on a live picture" and the first failing line names both apps.
- [ ] Dashboard: "Ready to drive" only when the capture delivers pictures; if the game arrives black, it says so.
- [ ] Auto-Calibrate review: faint dashed outlines = other fixed elements; select a control, tap one: it snaps there. Is any
      outline a real control that was missed (note which)? Does the minimap appear even if a pedal/steering is missing?
- [ ] Send: the Diagnostics log of any failed run, and a short screen recording of driving. They become fixtures.

## First start and permissions
- [ ] First start: Dashboard shows the welcome card and **"Setup needed"**, never "Ready". Start Auto Drive is disabled and
      "Before you drive" lists what is missing, each with a working button.
- [ ] Bottom navigation: Dashboard, Smart Setup, Profiles, Settings. Back closes a settings page, then returns to Dashboard.
- [ ] Smart Setup step 1 → Connect screen: on Android 13+ the notification question comes first, then Android's
      screen-sharing dialog (choose "Entire screen"). Decline → "Capture failed" with "Ask again".
- [ ] Accept → the top chip shows Connected; with the game in front for a few seconds it shows Live.
- [ ] Settings → Permissions → Turn on (accessibility): HaulPilot's explanation appears first; "Not now" changes nothing;
      "I agree" opens Android's accessibility settings. Coming back, the page shows the new state.
- [ ] Stop sharing from the status bar: the chip and Dashboard say capture ended; nothing restarts by itself.

## Auto-Calibrate (the main thing to test in 1.1.0)
Use the normal driving view of Truckers of Europe 3 with your usual control layout. Note which steering you use (wheel or
arrows) and whether the minimap is shown.
- [ ] Smart Setup → **Auto-Calibrate** (big button at the top) → Connect screen (if needed) → **Start Auto-Calibrate**:
      the game opens; the floating button's ring fills only while you DRIVE FORWARD (standing still: "Drive forward…").
- [ ] Or start it from the floating button in the game (panel → Auto-Calibrate): the panel closes so it does not hide the
      game; the count rises while driving.
- [ ] After about 15 s of driving the collection stops by itself and the analysis starts by itself; the floating button
      shows "Analysing · NN %" moving in steps, then "Auto-Calibrate found N control(s)" and **Review in HaulPilot**.
- [ ] Review in HaulPilot opens the review directly. For each control: is the marker ON the right control?
      Accelerator ___ Brake ___ Steer left ___ Steer right ___ (or Wheel ___). Nothing on the truck, the gauges or
      HaulPilot's own button? The "Screen marker" box (if any) is NOT on HaulPilot's button?
- [ ] Drag a marker a little: it follows the finger and stays where dropped. Tap a missing control's chip, then tap the
      picture: it is placed there. "Next spot" (if shown) moves the marker to another place the analysis considered.
      Pinch / + zoom; the markers stay on the picture.
- [ ] If your game uses arrows, the review shows Left/Right (no wheel question). "My game uses a steering wheel instead"
      switches the controls shown.
- [ ] Confirm → the check shows no blocking problem → Save (new profile or update the active one) → Safe test (open the
      game, come back within 15 s, Run the test): no touch is sent; the checks show.
- [ ] Park the truck and run Auto-Calibrate without driving: after 75 s it analyses the few still pictures and says the
      evidence is weaker (single picture).
- [ ] Open the floating panel while it collects: the count stops rising while the panel is open and continues after it
      closes. Drag the button somewhere else during the collection: it is still never proposed as a control.
- [ ] Cancel during collection and during the analysis (in the app and from the floating button): nothing is lost; Start
      again works.
- [ ] Screenshots instead of live capture: Auto-Calibrate → "Use screenshots" (2–5 screenshots taken while driving) →
      Analyse → review as above (weaker evidence is stated).
- [ ] Please send: a few screenshots of the review (markers on the picture), and if possible a 10–20 s screen recording of
      you driving with the normal HUD. They become regression tests (`app/src/test/resources/fixtures/toe3/README.md`).

## Smart Setup (live, manual steps)
- [ ] Step 2 → Start collecting: the game opens; the floating button shows the count rising only while the game is in
      front; drive normally for ~15 s. Back in HaulPilot the count is 45 (or "Stop and use these" earlier).
- [ ] Collecting while HaulPilot or another app is in front adds nothing; after 60 s without game pictures it stops with
      the right recovery button.
- [ ] Lock the screen while collecting: the collection stops (cancelled), the pictures so far are kept.
- [ ] Rotate while collecting: the collection restarts for the new shape instead of mixing shapes.
- [ ] Step 3: the suggested picture is marked "Suggested", not chosen, until "This is the driving screen" is tapped.
- [ ] Step 4: Analyse shows progress and can be cancelled; tapping Analyse twice starts only one job.
- [ ] Step 5: candidates (if any) are drawn on the right controls; evidence ≤ 60 %; Confirm / Move / Reject work.
- [ ] Step 6 editor: tap places the crosshair; one-finger drag moves it; the loupe shows pixels; arrows move one pixel;
      pinch and ± zoom; the markers stay exactly on the picture while zooming and panning; Undo/Redo; Reset; Confirm.
- [ ] Place two controls on the same spot: the editor refuses to confirm and step 8 reports an error.
- [ ] Step 7: mark the minimap (drag, resize by a corner, move), pick the route colour (grey is refused), mark the truck
      (outside the box is refused). Optional destination marker: the route colour is refused, another colour is
      accepted. "Skip for now" leaves steps 8–10 usable.
- [ ] Step 8 → Check for problems; step 9 → save to a new profile; the result lists what was saved and what is still
      missing.
- [ ] Step 10 → with the game on the driving view and back within 15 s → Run the test: no touch is sent; the checks show.
- [ ] Close HaulPilot from the recent apps during step 6 and open it again: the setup comes back with its picture.

## Smart Setup (imports)
- [ ] Screenshots (Photo Picker, several taken a moment apart while driving) → added, step 3 opens.
- [ ] A screen recording of yourself driving (Photo Picker, and "Find a video in files") → progress, cancel works.

## Profiles
- [ ] New, Rename, Duplicate, Make active, Export (.zip) and Import (the imported copy is not active until you choose).
- [ ] Delete → confirmation → snackbar Undo brings it back.
- [ ] After saving twice: Undo last change restores the earlier version (positions and control pictures).
- [ ] Edit in Smart Setup loads the profile's controls onto the current picture.

## Driving (only after a complete setup)
- [ ] Dashboard shows "Ready to drive" only when all six checks are green.
- [ ] Assisted mode first: the countdown, then hints; no touches are sent.
- [ ] A short real drive with a finger near Emergency Stop. The red bar appears on every screen (also in the editor).
- [ ] Emergency Stop from the app bar, the floating button and the notification releases all touches at once and does
      not press the brake.
- [ ] Pause / Resume; game sent to the background → pause; frozen picture → stop; route lost → asks for help.
- [ ] Settings → Automation & safety is locked during the drive.

## Look and accessibility
- [ ] Text readable in sunlight and at the largest font size; no clipped buttons at 360 dp width.
- [ ] TalkBack reads headings, icon buttons, the step rail and the drive status.
