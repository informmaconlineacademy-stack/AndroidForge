# HaulPilot — Privacy Policy

*HaulPilot — Drive smarter. Deliver better. Made by Praju (praju_12). Applies to version 1.0.0 and later. Last updated: 21 October 2026.*

HaulPilot is a driving assistant for mobile truck-driving games, currently *Truckers of Europe 3*. It works entirely on your phone.

## What the app accesses, and why

| What | When | Why | Where it goes |
|---|---|---|---|
| **Pictures of your screen** (Android screen capture) | Only after you allow it in Android's screen-sharing dialog, each time | To see the game's driving screen, minimap and controls | Analysed in memory and discarded. **Never recorded as video, never uploaded.** |
| **Accessibility service** | Only if you turn it on, after an in-app explanation you must accept | To press the driving controls you set up, to know which app is in front (package name only), and to show the floating control button | Nothing is stored or sent. It does not read other apps' text or content and does not record touches, keystrokes or passwords. |
| **Screenshots or a gameplay video you pick** (Smart Setup) | Only when you choose them with Android's photo/file picker | To find the on-screen controls and the map | Read on the phone, not copied, not uploaded. |
| **Calibration profiles** | When you save Smart Setup results | So you do not have to set up again | App-private storage on your phone: positions plus small grey pictures of the controls and of one steady dashboard part. Removed when you delete the profile or uninstall. |
| **Unfinished Smart Setup** | While you set up | So a setup survives the app being closed | App-private storage: the positions you placed and the one game picture you chose as the driving screen. Removed by Smart Setup → Start over, Settings → Reset, or uninstalling. |
| **Sample snapshots** (optional, off by default) | Only while you switch them on | Diagnosing setup problems | App-private storage, limited in number, deletable in the app. |
| **Exported backup (.zip)** | Only when you export | Your own backup | Saved only where you choose. |

## What the app does not do

* It has **no internet permission**, so it cannot send anything anywhere.
* No analytics, advertising, tracking, crash-reporting services or accounts.
* No access to contacts, location, camera, microphone or other apps' data.
* It does not try to get around apps or Android blocking screen capture.

## Your choices

* Screen capture: Android asks every time; stop it from the notification or the app.
* Accessibility service: switch it off any time in Android Settings → Accessibility. Assisted mode works without it.
* Delete data: Profiles → Delete (each profile), Settings → Reset (setup, settings, preferences), Settings → Diagnostics
  (log, drive history, recorded snapshots), or uninstall the app to remove everything.

## Children

The app is not directed at children.

## Changes and contact

Changes will be published with new versions of the app. Contact: *add a contact email or website here before publishing* (stores require one).

HaulPilot is an independent app and is not affiliated with, endorsed by or supported by the developer or publisher of Truckers of Europe 3 or any other game.
