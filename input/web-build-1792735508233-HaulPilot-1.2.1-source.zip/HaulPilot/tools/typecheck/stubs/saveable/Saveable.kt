@file:Suppress("unused", "UNUSED_PARAMETER")
package androidx.compose.runtime.saveable

import androidx.compose.runtime.Composable

interface Saver<Original, Saveable : Any>

@Composable
fun <T> rememberSaveable(vararg inputs: Any?, init: () -> T): T = TODO()

@Composable
fun <T> rememberSaveable(vararg inputs: Any?, saver: Saver<T, out Any>, init: () -> T): T = TODO()
