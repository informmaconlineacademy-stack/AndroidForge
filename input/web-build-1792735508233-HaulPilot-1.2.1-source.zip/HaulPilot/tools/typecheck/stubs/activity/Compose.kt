@file:Suppress("unused", "UNUSED_PARAMETER")
package androidx.activity.compose

import androidx.activity.ComponentActivity
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContract
import androidx.compose.runtime.Composable

fun ComponentActivity.setContent(parent: Any? = null, content: @Composable () -> Unit): Unit = TODO()

@Composable
fun BackHandler(enabled: Boolean = true, onBack: () -> Unit): Unit = TODO()

class ManagedActivityResultLauncher<I, O> : ActivityResultLauncher<I>() {
    override fun launch(input: I, options: Any?): Unit = TODO()
    override fun unregister(): Unit = TODO()
}

@Composable
fun <I, O> rememberLauncherForActivityResult(contract: ActivityResultContract<I, O>, onResult: (O) -> Unit): ManagedActivityResultLauncher<I, O> = TODO()
