@file:Suppress("unused", "UNUSED_PARAMETER")
package androidx.activity.result.contract

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.result.ActivityResult
import androidx.activity.result.PickVisualMediaRequest

abstract class ActivityResultContract<I, O> {
    abstract fun createIntent(context: Context, input: I): Intent
    abstract fun parseResult(resultCode: Int, intent: Intent?): O
}

class ActivityResultContracts private constructor() {
    class StartActivityForResult : ActivityResultContract<Intent, ActivityResult>() {
        override fun createIntent(context: Context, input: Intent): Intent = TODO()
        override fun parseResult(resultCode: Int, intent: Intent?): ActivityResult = TODO()
    }

    class RequestPermission : ActivityResultContract<String, Boolean>() {
        override fun createIntent(context: Context, input: String): Intent = TODO()
        override fun parseResult(resultCode: Int, intent: Intent?): Boolean = TODO()
    }

    open class CreateDocument(mimeType: String) : ActivityResultContract<String, Uri?>() {
        override fun createIntent(context: Context, input: String): Intent = TODO()
        final override fun parseResult(resultCode: Int, intent: Intent?): Uri? = TODO()
    }

    open class OpenDocument : ActivityResultContract<Array<String>, Uri?>() {
        override fun createIntent(context: Context, input: Array<String>): Intent = TODO()
        final override fun parseResult(resultCode: Int, intent: Intent?): Uri? = TODO()
    }

    open class PickVisualMedia : ActivityResultContract<PickVisualMediaRequest, Uri?>() {
        sealed interface VisualMediaType
        object ImageOnly : VisualMediaType
        object VideoOnly : VisualMediaType
        object ImageAndVideo : VisualMediaType
        class DefaultTab private constructor() {
            companion object {
                val PhotosTab = DefaultTab()
                val AlbumsTab = DefaultTab()
            }
        }

        override fun createIntent(context: Context, input: PickVisualMediaRequest): Intent = TODO()
        final override fun parseResult(resultCode: Int, intent: Intent?): Uri? = TODO()
    }

    open class PickMultipleVisualMedia(maxItems: Int = 100) : ActivityResultContract<PickVisualMediaRequest, List<Uri>>() {
        override fun createIntent(context: Context, input: PickVisualMediaRequest): Intent = TODO()
        final override fun parseResult(resultCode: Int, intent: Intent?): List<Uri> = TODO()
    }
}
