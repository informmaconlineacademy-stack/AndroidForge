@file:Suppress("unused", "UNUSED_PARAMETER")
package androidx.activity.result

import android.content.Intent
import androidx.activity.result.contract.ActivityResultContracts

abstract class ActivityResultLauncher<I> {
    fun launch(input: I): Unit = launch(input, null)
    abstract fun launch(input: I, options: Any?)
    abstract fun unregister()
}

class ActivityResult(val resultCode: Int, val data: Intent?)

class PickVisualMediaRequest internal constructor()

@Deprecated("Use the overload with more parameters")
fun PickVisualMediaRequest(mediaType: ActivityResultContracts.PickVisualMedia.VisualMediaType = ActivityResultContracts.PickVisualMedia.ImageAndVideo): PickVisualMediaRequest = TODO()

@Deprecated("Use the overload with more parameters")
fun PickVisualMediaRequest(mediaType: ActivityResultContracts.PickVisualMedia.VisualMediaType = ActivityResultContracts.PickVisualMedia.ImageAndVideo, maxItems: Int = 2): PickVisualMediaRequest = TODO()

fun PickVisualMediaRequest(
    mediaType: ActivityResultContracts.PickVisualMedia.VisualMediaType = ActivityResultContracts.PickVisualMedia.ImageAndVideo,
    maxItems: Int = 2,
    isOrderedSelection: Boolean = false,
    defaultTab: ActivityResultContracts.PickVisualMedia.DefaultTab = ActivityResultContracts.PickVisualMedia.DefaultTab.PhotosTab,
): PickVisualMediaRequest = TODO()
