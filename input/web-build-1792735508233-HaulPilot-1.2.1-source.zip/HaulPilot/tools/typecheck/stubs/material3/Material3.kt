@file:Suppress("unused", "UNUSED_PARAMETER")
package androidx.compose.material3

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.shape.CornerBasedShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.Stable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit

private val U: Color = Color.Unspecified

@Stable
class ColorScheme

fun darkColorScheme(
    primary: Color = U, onPrimary: Color = U, primaryContainer: Color = U, onPrimaryContainer: Color = U, inversePrimary: Color = U,
    secondary: Color = U, onSecondary: Color = U, secondaryContainer: Color = U, onSecondaryContainer: Color = U,
    tertiary: Color = U, onTertiary: Color = U, tertiaryContainer: Color = U, onTertiaryContainer: Color = U,
    background: Color = U, onBackground: Color = U, surface: Color = U, onSurface: Color = U, surfaceVariant: Color = U,
    onSurfaceVariant: Color = U, surfaceTint: Color = U, inverseSurface: Color = U, inverseOnSurface: Color = U,
    error: Color = U, onError: Color = U, errorContainer: Color = U, onErrorContainer: Color = U, outline: Color = U,
    outlineVariant: Color = U, scrim: Color = U, surfaceBright: Color = U, surfaceContainer: Color = U,
    surfaceContainerHigh: Color = U, surfaceContainerHighest: Color = U, surfaceContainerLow: Color = U,
    surfaceContainerLowest: Color = U, surfaceDim: Color = U,
): ColorScheme = TODO()

@Immutable
class Typography(
    val displayLarge: TextStyle = TextStyle.Default,
    val displayMedium: TextStyle = TextStyle.Default,
    val displaySmall: TextStyle = TextStyle.Default,
    val headlineLarge: TextStyle = TextStyle.Default,
    val headlineMedium: TextStyle = TextStyle.Default,
    val headlineSmall: TextStyle = TextStyle.Default,
    val titleLarge: TextStyle = TextStyle.Default,
    val titleMedium: TextStyle = TextStyle.Default,
    val titleSmall: TextStyle = TextStyle.Default,
    val bodyLarge: TextStyle = TextStyle.Default,
    val bodyMedium: TextStyle = TextStyle.Default,
    val bodySmall: TextStyle = TextStyle.Default,
    val labelLarge: TextStyle = TextStyle.Default,
    val labelMedium: TextStyle = TextStyle.Default,
    val labelSmall: TextStyle = TextStyle.Default,
)

@Immutable
class Shapes(
    val extraSmall: CornerBasedShape = TODO(),
    val small: CornerBasedShape = TODO(),
    val medium: CornerBasedShape = TODO(),
    val large: CornerBasedShape = TODO(),
    val extraLarge: CornerBasedShape = TODO(),
)

object MaterialTheme {
    val colorScheme: ColorScheme @Composable @ReadOnlyComposable get() = TODO()
    val typography: Typography @Composable @ReadOnlyComposable get() = TODO()
    val shapes: Shapes @Composable @ReadOnlyComposable get() = TODO()
}

@Composable
fun MaterialTheme(colorScheme: ColorScheme = TODO(), shapes: Shapes = TODO(), typography: Typography = TODO(), content: @Composable () -> Unit): Unit = TODO()

@Composable
fun Text(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = Color.Unspecified,
    autoSize: Any? = null,
    fontSize: TextUnit = TextUnit.Unspecified,
    fontStyle: Any? = null,
    fontWeight: FontWeight? = null,
    fontFamily: FontFamily? = null,
    letterSpacing: TextUnit = TextUnit.Unspecified,
    textDecoration: Any? = null,
    textAlign: TextAlign? = null,
    lineHeight: TextUnit = TextUnit.Unspecified,
    overflow: TextOverflow = TextOverflow.Clip,
    softWrap: Boolean = true,
    maxLines: Int = Int.MAX_VALUE,
    minLines: Int = 1,
    onTextLayout: ((Any) -> Unit)? = null,
    style: TextStyle = TextStyle.Default,
): Unit = TODO()

@Immutable
class ButtonColors

object ButtonDefaults {
    @Composable fun buttonColors(containerColor: Color = U, contentColor: Color = U, disabledContainerColor: Color = U, disabledContentColor: Color = U): ButtonColors = TODO()
    @Composable fun outlinedButtonColors(containerColor: Color = U, contentColor: Color = U, disabledContainerColor: Color = U, disabledContentColor: Color = U): ButtonColors = TODO()
    @Composable fun textButtonColors(containerColor: Color = U, contentColor: Color = U, disabledContainerColor: Color = U, disabledContentColor: Color = U): ButtonColors = TODO()
    val ContentPadding: PaddingValues get() = TODO()
    val shape: Shape @Composable get() = TODO()
}

@Composable
fun Button(
    onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true, shape: Shape = TODO(), colors: ButtonColors = TODO(),
    elevation: Any? = null, border: BorderStroke? = null, contentPadding: PaddingValues = TODO(), interactionSource: Any? = null,
    content: @Composable RowScope.() -> Unit,
): Unit = TODO()

@Composable
fun OutlinedButton(
    onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true, shape: Shape = TODO(), colors: ButtonColors = TODO(),
    elevation: Any? = null, border: BorderStroke? = null, contentPadding: PaddingValues = TODO(), interactionSource: Any? = null,
    content: @Composable RowScope.() -> Unit,
): Unit = TODO()

@Composable
fun TextButton(
    onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true, shape: Shape = TODO(), colors: ButtonColors = TODO(),
    elevation: Any? = null, border: BorderStroke? = null, contentPadding: PaddingValues = TODO(), interactionSource: Any? = null,
    content: @Composable RowScope.() -> Unit,
): Unit = TODO()

@Composable
fun AlertDialog(
    onDismissRequest: () -> Unit,
    confirmButton: @Composable () -> Unit,
    modifier: Modifier = Modifier,
    dismissButton: @Composable (() -> Unit)? = null,
    icon: @Composable (() -> Unit)? = null,
    title: @Composable (() -> Unit)? = null,
    text: @Composable (() -> Unit)? = null,
    shape: Shape = TODO(),
    containerColor: Color = U,
    iconContentColor: Color = U,
    titleContentColor: Color = U,
    textContentColor: Color = U,
    tonalElevation: Dp = Dp(0f),
    properties: Any? = null,
): Unit = TODO()

@Composable
fun Scaffold(
    modifier: Modifier = Modifier,
    topBar: @Composable () -> Unit = {},
    bottomBar: @Composable () -> Unit = {},
    snackbarHost: @Composable () -> Unit = {},
    floatingActionButton: @Composable () -> Unit = {},
    floatingActionButtonPosition: Any? = null,
    containerColor: Color = U,
    contentColor: Color = U,
    contentWindowInsets: WindowInsets = TODO(),
    content: @Composable (PaddingValues) -> Unit,
): Unit = TODO()

@Composable
fun NavigationBar(
    modifier: Modifier = Modifier,
    containerColor: Color = U,
    contentColor: Color = U,
    tonalElevation: Dp = Dp(0f),
    windowInsets: WindowInsets = TODO(),
    content: @Composable RowScope.() -> Unit,
): Unit = TODO()

@Immutable
class NavigationBarItemColors

object NavigationBarItemDefaults {
    @Composable
    fun colors(
        selectedIconColor: Color = U, selectedTextColor: Color = U, indicatorColor: Color = U, unselectedIconColor: Color = U,
        unselectedTextColor: Color = U, disabledIconColor: Color = U, disabledTextColor: Color = U,
    ): NavigationBarItemColors = TODO()
}

@Composable
fun RowScope.NavigationBarItem(
    selected: Boolean,
    onClick: () -> Unit,
    icon: @Composable () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    label: @Composable (() -> Unit)? = null,
    alwaysShowLabel: Boolean = true,
    colors: NavigationBarItemColors = TODO(),
    interactionSource: Any? = null,
): Unit = TODO()

enum class SnackbarDuration { Short, Long, Indefinite }

enum class SnackbarResult { Dismissed, ActionPerformed }

interface SnackbarData

@Stable
class SnackbarHostState {
    val currentSnackbarData: SnackbarData? get() = TODO()
    suspend fun showSnackbar(
        message: String,
        actionLabel: String? = null,
        withDismissAction: Boolean = false,
        duration: SnackbarDuration = if (actionLabel == null) SnackbarDuration.Short else SnackbarDuration.Indefinite,
    ): SnackbarResult = TODO()
}

@Composable
fun SnackbarHost(hostState: SnackbarHostState, modifier: Modifier = Modifier, snackbar: @Composable (SnackbarData) -> Unit = {}): Unit = TODO()

@Composable
fun DropdownMenu(
    expanded: Boolean,
    onDismissRequest: () -> Unit,
    modifier: Modifier = Modifier,
    offset: Any? = null,
    scrollState: Any? = null,
    properties: Any? = null,
    shape: Shape = TODO(),
    containerColor: Color = U,
    tonalElevation: Dp = Dp(0f),
    shadowElevation: Dp = Dp(0f),
    border: BorderStroke? = null,
    content: @Composable ColumnScope.() -> Unit,
): Unit = TODO()

@Composable
fun DropdownMenuItem(
    text: @Composable () -> Unit,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    leadingIcon: @Composable (() -> Unit)? = null,
    trailingIcon: @Composable (() -> Unit)? = null,
    enabled: Boolean = true,
    colors: Any? = null,
    contentPadding: PaddingValues = TODO(),
    interactionSource: Any? = null,
): Unit = TODO()

@Immutable
class SwitchColors

object SwitchDefaults {
    @Composable
    fun colors(
        checkedThumbColor: Color = U, checkedTrackColor: Color = U, checkedBorderColor: Color = U, checkedIconColor: Color = U,
        uncheckedThumbColor: Color = U, uncheckedTrackColor: Color = U, uncheckedBorderColor: Color = U, uncheckedIconColor: Color = U,
        disabledCheckedThumbColor: Color = U, disabledCheckedTrackColor: Color = U, disabledCheckedBorderColor: Color = U,
        disabledCheckedIconColor: Color = U, disabledUncheckedThumbColor: Color = U, disabledUncheckedTrackColor: Color = U,
        disabledUncheckedBorderColor: Color = U, disabledUncheckedIconColor: Color = U,
    ): SwitchColors = TODO()
}

@Composable
fun Switch(
    checked: Boolean,
    onCheckedChange: ((Boolean) -> Unit)?,
    modifier: Modifier = Modifier,
    thumbContent: (@Composable () -> Unit)? = null,
    enabled: Boolean = true,
    colors: SwitchColors = TODO(),
    interactionSource: Any? = null,
): Unit = TODO()

@Immutable
class SliderColors

object SliderDefaults {
    @Composable
    fun colors(
        thumbColor: Color = U, activeTrackColor: Color = U, activeTickColor: Color = U, inactiveTrackColor: Color = U,
        inactiveTickColor: Color = U, disabledThumbColor: Color = U, disabledActiveTrackColor: Color = U,
        disabledActiveTickColor: Color = U, disabledInactiveTrackColor: Color = U, disabledInactiveTickColor: Color = U,
    ): SliderColors = TODO()
}

@Composable
fun Slider(
    value: Float,
    onValueChange: (Float) -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    valueRange: ClosedFloatingPointRange<Float> = 0f..1f,
    steps: Int = 0,
    onValueChangeFinished: (() -> Unit)? = null,
    colors: SliderColors = TODO(),
    interactionSource: Any? = null,
): Unit = TODO()

@Composable
fun LinearProgressIndicator(
    progress: () -> Float,
    modifier: Modifier = Modifier,
    color: Color = U,
    trackColor: Color = U,
    strokeCap: StrokeCap = StrokeCap.Butt,
    gapSize: Dp = Dp(0f),
    drawStopIndicator: Any? = null,
): Unit = TODO()

@Composable
fun LinearProgressIndicator(
    modifier: Modifier = Modifier,
    color: Color = U,
    trackColor: Color = U,
    strokeCap: StrokeCap = StrokeCap.Butt,
    gapSize: Dp = Dp(0f),
): Unit = TODO()

@Composable
fun OutlinedTextField(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    readOnly: Boolean = false,
    textStyle: TextStyle = TextStyle.Default,
    label: @Composable (() -> Unit)? = null,
    placeholder: @Composable (() -> Unit)? = null,
    leadingIcon: @Composable (() -> Unit)? = null,
    trailingIcon: @Composable (() -> Unit)? = null,
    prefix: @Composable (() -> Unit)? = null,
    suffix: @Composable (() -> Unit)? = null,
    supportingText: @Composable (() -> Unit)? = null,
    isError: Boolean = false,
    visualTransformation: Any? = null,
    keyboardOptions: Any? = null,
    keyboardActions: Any? = null,
    singleLine: Boolean = false,
    maxLines: Int = Int.MAX_VALUE,
    minLines: Int = 1,
    interactionSource: Any? = null,
    shape: Shape = TODO(),
    colors: Any? = null,
): Unit = TODO()

@Immutable
class RadioButtonColors

object RadioButtonDefaults {
    @Composable
    fun colors(selectedColor: Color = U, unselectedColor: Color = U, disabledSelectedColor: Color = U, disabledUnselectedColor: Color = U): RadioButtonColors = TODO()
}

@Composable
fun RadioButton(
    selected: Boolean,
    onClick: (() -> Unit)?,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    colors: RadioButtonColors = TODO(),
    interactionSource: Any? = null,
): Unit = TODO()

@Composable
fun Surface(
    modifier: Modifier = Modifier,
    shape: Shape = TODO(),
    color: Color = U,
    contentColor: Color = U,
    tonalElevation: Dp = Dp(0f),
    shadowElevation: Dp = Dp(0f),
    border: BorderStroke? = null,
    content: @Composable () -> Unit,
): Unit = TODO()
