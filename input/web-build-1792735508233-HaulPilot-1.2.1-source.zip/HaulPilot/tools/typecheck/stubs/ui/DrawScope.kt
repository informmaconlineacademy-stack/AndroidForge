@file:Suppress("unused", "UNUSED_PARAMETER")
package androidx.compose.ui.graphics.drawscope

import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection

sealed class DrawStyle

object Fill : DrawStyle()

class Stroke(
    val width: Float = 0.0f,
    val miter: Float = DefaultMiter,
    val cap: StrokeCap = DefaultCap,
    val join: StrokeJoin = StrokeJoin.Miter,
    val pathEffect: PathEffect? = null,
) : DrawStyle() {
    companion object {
        const val HairlineWidth = 0.0f
        const val DefaultMiter: Float = 4.0f
        val DefaultCap = StrokeCap.Butt
    }
}

interface DrawScope : Density {
    val size: Size get() = TODO()
    val center: Offset get() = TODO()
    val layoutDirection: LayoutDirection

    fun drawLine(
        color: Color, start: Offset, end: Offset, strokeWidth: Float = Stroke.HairlineWidth, cap: StrokeCap = Stroke.DefaultCap,
        pathEffect: PathEffect? = null, alpha: Float = 1.0f, colorFilter: ColorFilter? = null, blendMode: BlendMode = DefaultBlendMode,
    )

    fun drawRect(
        color: Color, topLeft: Offset = Offset.Zero, size: Size = Size.Zero, alpha: Float = 1.0f, style: DrawStyle = Fill,
        colorFilter: ColorFilter? = null, blendMode: BlendMode = DefaultBlendMode,
    )

    fun drawRoundRect(
        color: Color, topLeft: Offset = Offset.Zero, size: Size = Size.Zero, cornerRadius: CornerRadius = CornerRadius.Zero,
        style: DrawStyle = Fill, alpha: Float = 1.0f, colorFilter: ColorFilter? = null, blendMode: BlendMode = DefaultBlendMode,
    )

    fun drawCircle(
        color: Color, radius: Float = 0f, center: Offset = Offset.Zero, alpha: Float = 1.0f, style: DrawStyle = Fill,
        colorFilter: ColorFilter? = null, blendMode: BlendMode = DefaultBlendMode,
    )

    fun drawArc(
        color: Color, startAngle: Float, sweepAngle: Float, useCenter: Boolean, topLeft: Offset = Offset.Zero, size: Size = Size.Zero,
        alpha: Float = 1.0f, style: DrawStyle = Fill, colorFilter: ColorFilter? = null, blendMode: BlendMode = DefaultBlendMode,
    )

    fun drawPath(path: Path, color: Color, alpha: Float = 1.0f, style: DrawStyle = Fill, colorFilter: ColorFilter? = null, blendMode: BlendMode = DefaultBlendMode)

    fun drawImage(image: ImageBitmap, topLeft: Offset = Offset.Zero, alpha: Float = 1.0f, style: DrawStyle = Fill, colorFilter: ColorFilter? = null, blendMode: BlendMode = DefaultBlendMode)

    @Deprecated("use the overload with filterQuality")
    fun drawImage(
        image: ImageBitmap, srcOffset: IntOffset = IntOffset.Zero, srcSize: IntSize = IntSize.Zero, dstOffset: IntOffset = IntOffset.Zero,
        dstSize: IntSize = srcSize, alpha: Float = 1.0f, style: DrawStyle = Fill, colorFilter: ColorFilter? = null, blendMode: BlendMode = DefaultBlendMode,
    )

    fun drawImage(
        image: ImageBitmap, srcOffset: IntOffset = IntOffset.Zero, srcSize: IntSize = IntSize.Zero, dstOffset: IntOffset = IntOffset.Zero,
        dstSize: IntSize = srcSize, alpha: Float = 1.0f, style: DrawStyle = Fill, colorFilter: ColorFilter? = null,
        blendMode: BlendMode = DefaultBlendMode, filterQuality: FilterQuality = FilterQuality.Low,
    ) {}

    companion object {
        val DefaultBlendMode: BlendMode = BlendMode.SrcOver
        val DefaultFilterQuality: FilterQuality = FilterQuality.Low
    }
}

interface DrawTransform {
    val size: Size
    val center: Offset get() = TODO()
    fun clipPath(path: Path, clipOp: ClipOp = ClipOp.Intersect)
    fun clipRect(left: Float = 0.0f, top: Float = 0.0f, right: Float = 0f, bottom: Float = 0f, clipOp: ClipOp = ClipOp.Intersect)
    fun translate(left: Float = 0.0f, top: Float = 0.0f)
    fun rotate(degrees: Float, pivot: Offset = Offset.Zero)
    fun scale(scaleX: Float, scaleY: Float, pivot: Offset = Offset.Zero)
}

inline fun DrawScope.withTransform(transformBlock: DrawTransform.() -> Unit, drawBlock: DrawScope.() -> Unit): Unit = TODO()

inline fun DrawScope.clipPath(path: Path, clipOp: ClipOp = ClipOp.Intersect, block: DrawScope.() -> Unit): Unit = TODO()

inline fun DrawScope.translate(left: Float = 0.0f, top: Float = 0.0f, block: DrawScope.() -> Unit): Unit = TODO()

inline fun DrawScope.scale(scaleX: Float, scaleY: Float, pivot: Offset = Offset.Zero, block: DrawScope.() -> Unit): Unit = TODO()
