@file:Suppress("unused", "UNUSED_PARAMETER")
package androidx.compose.ui.semantics

import androidx.compose.ui.Modifier

interface SemanticsPropertyReceiver

fun Modifier.semantics(mergeDescendants: Boolean = false, properties: SemanticsPropertyReceiver.() -> Unit): Modifier = TODO()

fun Modifier.clearAndSetSemantics(properties: SemanticsPropertyReceiver.() -> Unit): Modifier = TODO()

var SemanticsPropertyReceiver.contentDescription: String
    get() = TODO()
    set(value) = TODO()

var SemanticsPropertyReceiver.stateDescription: String
    get() = TODO()
    set(value) = TODO()

var SemanticsPropertyReceiver.liveRegion: LiveRegionMode
    get() = TODO()
    set(value) = TODO()

var SemanticsPropertyReceiver.selected: Boolean
    get() = TODO()
    set(value) = TODO()

var SemanticsPropertyReceiver.role: Role
    get() = TODO()
    set(value) = TODO()

fun SemanticsPropertyReceiver.heading(): Unit = TODO()

@JvmInline
value class LiveRegionMode private constructor(private val value: Int) {
    companion object {
        val Polite = LiveRegionMode(0)
        val Assertive = LiveRegionMode(1)
    }
}

@JvmInline
value class Role private constructor(private val value: Int) {
    companion object {
        val Button = Role(0)
        val Checkbox = Role(1)
        val Switch = Role(2)
        val RadioButton = Role(3)
        val Tab = Role(4)
        val Image = Role(5)
        val DropdownList = Role(6)
    }
}
