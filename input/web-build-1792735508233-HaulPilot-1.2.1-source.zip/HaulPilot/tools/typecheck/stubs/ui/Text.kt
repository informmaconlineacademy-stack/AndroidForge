@file:Suppress("unused", "UNUSED_PARAMETER")
package androidx.compose.ui.text

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.Stable
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.DrawStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.TextUnit

@Immutable
class TextStyle(
    val color: Color = Color.Unspecified,
    val fontSize: TextUnit = TextUnit.Unspecified,
    val fontWeight: FontWeight? = null,
    val fontStyle: Any? = null,
    val fontSynthesis: Any? = null,
    val fontFamily: FontFamily? = null,
    val fontFeatureSettings: String? = null,
    val letterSpacing: TextUnit = TextUnit.Unspecified,
    val baselineShift: Any? = null,
    val textGeometricTransform: Any? = null,
    val localeList: Any? = null,
    val background: Color = Color.Unspecified,
    val textDecoration: Any? = null,
    val shadow: Shadow? = null,
    val drawStyle: DrawStyle? = null,
    val textAlign: TextAlign = TextAlign.Unspecified,
    val textDirection: Any? = null,
    val lineHeight: TextUnit = TextUnit.Unspecified,
) {
    fun copy(
        color: Color = this.color,
        fontSize: TextUnit = this.fontSize,
        fontWeight: FontWeight? = this.fontWeight,
        fontStyle: Any? = null,
        fontSynthesis: Any? = null,
        fontFamily: FontFamily? = this.fontFamily,
        fontFeatureSettings: String? = this.fontFeatureSettings,
        letterSpacing: TextUnit = this.letterSpacing,
        baselineShift: Any? = null,
        textGeometricTransform: Any? = null,
        localeList: Any? = null,
        background: Color = this.background,
        textDecoration: Any? = null,
        shadow: Shadow? = this.shadow,
        drawStyle: DrawStyle? = this.drawStyle,
        textAlign: TextAlign = this.textAlign,
        textDirection: Any? = null,
        lineHeight: TextUnit = this.lineHeight,
    ): TextStyle = TODO()

    companion object {
        val Default: TextStyle = TextStyle()
    }
}

class TextLayoutResult {
    val size: IntSize get() = TODO()
}

@Immutable
class TextMeasurer {
    @Stable
    fun measure(
        text: String,
        style: TextStyle = TextStyle.Default,
        overflow: TextOverflow = TextOverflow.Clip,
        softWrap: Boolean = true,
        maxLines: Int = Int.MAX_VALUE,
    ): TextLayoutResult = TODO()
}

@Composable
fun rememberTextMeasurer(cacheSize: Int = 8): TextMeasurer = TODO()

fun DrawScope.drawText(
    textLayoutResult: TextLayoutResult,
    color: Color = Color.Unspecified,
    topLeft: Offset = Offset.Zero,
    alpha: Float = Float.NaN,
    shadow: Shadow? = null,
    textDecoration: Any? = null,
    drawStyle: DrawStyle? = null,
    blendMode: BlendMode = DrawScope.DefaultBlendMode,
): Unit = TODO()
