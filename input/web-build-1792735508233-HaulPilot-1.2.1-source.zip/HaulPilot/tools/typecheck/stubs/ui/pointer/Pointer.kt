@file:Suppress("unused", "UNUSED_PARAMETER")
package androidx.compose.ui.input.pointer

import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.ViewConfiguration
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.IntSize

enum class PointerEventPass { Initial, Main, Final }

class PointerEvent(val changes: List<PointerInputChange>)

class PointerInputChange(
    val id: Long,
    val uptimeMillis: Long,
    val position: Offset,
    val pressed: Boolean,
    val previousUptimeMillis: Long,
    val previousPosition: Offset,
    val previousPressed: Boolean,
) {
    val isConsumed: Boolean get() = TODO()
    fun consume(): Unit = TODO()
}

interface AwaitPointerEventScope : Density {
    val size: IntSize
    val viewConfiguration: ViewConfiguration
    val currentEvent: PointerEvent
    suspend fun awaitPointerEvent(pass: PointerEventPass = PointerEventPass.Main): PointerEvent
}

interface PointerInputScope : Density {
    val size: IntSize
    val viewConfiguration: ViewConfiguration
    suspend fun <R> awaitPointerEventScope(block: suspend AwaitPointerEventScope.() -> R): R
}

fun Modifier.pointerInput(key1: Any?, block: suspend PointerInputScope.() -> Unit): Modifier = TODO()

fun Modifier.pointerInput(key1: Any?, key2: Any?, block: suspend PointerInputScope.() -> Unit): Modifier = TODO()

fun Modifier.pointerInput(vararg keys: Any?, block: suspend PointerInputScope.() -> Unit): Modifier = TODO()
