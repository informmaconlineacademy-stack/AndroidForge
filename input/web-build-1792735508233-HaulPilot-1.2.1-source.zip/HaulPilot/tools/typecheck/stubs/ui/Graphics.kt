@file:Suppress("unused", "UNUSED_PARAMETER")
package androidx.compose.ui.graphics

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.Stable
import androidx.compose.ui.geometry.Rect

@Immutable
@JvmInline
value class Color(val value: ULong) {
    val red: Float get() = TODO()
    val green: Float get() = TODO()
    val blue: Float get() = TODO()
    val alpha: Float get() = TODO()
    @Stable
    fun copy(alpha: Float = this.alpha, red: Float = this.red, green: Float = this.green, blue: Float = this.blue): Color = TODO()
    companion object {
        val Black: Color = Color(0UL)
        val White: Color = Color(0UL)
        val Transparent: Color = Color(0UL)
        val Unspecified: Color = Color(0UL)
        val Red: Color = Color(0UL)
    }
}

@Stable
fun Color(color: Int): Color = TODO()

@Stable
fun Color(color: Long): Color = TODO()

@Stable
fun Color(red: Int, green: Int, blue: Int, alpha: Int = 0xFF): Color = TODO()

@Stable
fun Color(red: Float, green: Float, blue: Float, alpha: Float = 1f): Color = TODO()

fun Color.toArgb(): Int = TODO()

interface ImageBitmap {
    val width: Int
    val height: Int
}

fun android.graphics.Bitmap.asImageBitmap(): ImageBitmap = TODO()

fun ImageBitmap.asAndroidBitmap(): android.graphics.Bitmap = TODO()

@Immutable
@JvmInline
value class PathFillType internal constructor(val value: Int) {
    companion object {
        val NonZero: PathFillType = PathFillType(0)
        val EvenOdd: PathFillType = PathFillType(1)
    }
}

interface Path {
    var fillType: PathFillType
    fun moveTo(x: Float, y: Float)
    fun lineTo(x: Float, y: Float)
    fun cubicTo(x1: Float, y1: Float, x2: Float, y2: Float, x3: Float, y3: Float)
    fun quadraticTo(x1: Float, y1: Float, x2: Float, y2: Float)
    fun close()
    fun reset()
    fun addRect(rect: Rect, direction: Direction = Direction.CounterClockwise)
    fun addOval(oval: Rect, direction: Direction = Direction.CounterClockwise)
    enum class Direction { CounterClockwise, Clockwise }
}

fun Path(): Path = TODO()

interface PathEffect {
    companion object {
        fun dashPathEffect(intervals: FloatArray, phase: Float = 0f): PathEffect = TODO()
        fun cornerPathEffect(radius: Float): PathEffect = TODO()
    }
}

@Immutable
@JvmInline
value class StrokeCap internal constructor(val value: Int) {
    companion object {
        val Butt: StrokeCap = StrokeCap(0)
        val Round: StrokeCap = StrokeCap(1)
        val Square: StrokeCap = StrokeCap(2)
    }
}

@Immutable
@JvmInline
value class StrokeJoin internal constructor(val value: Int) {
    companion object {
        val Miter: StrokeJoin = StrokeJoin(0)
        val Round: StrokeJoin = StrokeJoin(1)
        val Bevel: StrokeJoin = StrokeJoin(2)
    }
}

@Immutable
@JvmInline
value class FilterQuality internal constructor(val value: Int) {
    companion object {
        val None: FilterQuality = FilterQuality(0)
        val Low: FilterQuality = FilterQuality(1)
        val Medium: FilterQuality = FilterQuality(2)
        val High: FilterQuality = FilterQuality(3)
    }
}

@Immutable
@JvmInline
value class BlendMode internal constructor(val value: Int) {
    companion object {
        val SrcOver: BlendMode = BlendMode(3)
    }
}

@Immutable
@JvmInline
value class ClipOp internal constructor(val value: Int) {
    companion object {
        val Difference: ClipOp = ClipOp(0)
        val Intersect: ClipOp = ClipOp(1)
    }
}

@Immutable
class ColorFilter

@Immutable
interface Shape

@Immutable
object RectangleShape : Shape

@Immutable
sealed class Brush

@Immutable
class Shadow
