@file:Suppress("unused", "UNUSED_PARAMETER")
package androidx.compose.ui.text.font

import androidx.compose.runtime.Immutable

@Immutable
class FontWeight(val weight: Int) : Comparable<FontWeight> {
    override fun compareTo(other: FontWeight): Int = weight.compareTo(other.weight)
    companion object {
        val Thin = FontWeight(100)
        val Light = FontWeight(300)
        val Normal = FontWeight(400)
        val Medium = FontWeight(500)
        val SemiBold = FontWeight(600)
        val Bold = FontWeight(700)
        val ExtraBold = FontWeight(800)
    }
}

@Immutable
sealed class FontFamily {
    companion object {
        val Default: FontFamily get() = TODO()
        val SansSerif: FontFamily get() = TODO()
        val Monospace: FontFamily get() = TODO()
    }
}
