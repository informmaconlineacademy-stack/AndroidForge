@file:Suppress("unused", "UNUSED_PARAMETER")
package androidx.compose.ui.platform

import android.content.Context
import androidx.compose.runtime.ProvidableCompositionLocal
import androidx.compose.ui.unit.Density

interface ViewConfiguration {
    val longPressTimeoutMillis: Long
    val doubleTapTimeoutMillis: Long
    val doubleTapMinTimeMillis: Long
    val touchSlop: Float
}

val LocalContext: ProvidableCompositionLocal<Context> = TODO()

val LocalDensity: ProvidableCompositionLocal<Density> = TODO()
