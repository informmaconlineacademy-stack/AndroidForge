@file:Suppress("unused", "UNUSED_PARAMETER")
package androidx.compose.ui.draw

import androidx.compose.runtime.Stable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.DrawScope

@Stable
fun Modifier.clip(shape: Shape): Modifier = TODO()

@Stable
fun Modifier.clipToBounds(): Modifier = TODO()

fun Modifier.drawBehind(onDraw: DrawScope.() -> Unit): Modifier = TODO()

@Stable
fun Modifier.alpha(alpha: Float): Modifier = TODO()
