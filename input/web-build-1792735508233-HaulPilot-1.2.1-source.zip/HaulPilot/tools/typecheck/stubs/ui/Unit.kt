@file:Suppress("unused", "UNUSED_PARAMETER", "NOTHING_TO_INLINE")
package androidx.compose.ui.unit

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.Stable

@Immutable
@JvmInline
value class Dp(val value: Float) : Comparable<Dp> {
    override fun compareTo(other: Dp): Int = value.compareTo(other.value)
    inline operator fun plus(other: Dp): Dp = Dp(value + other.value)
    inline operator fun minus(other: Dp): Dp = Dp(value - other.value)
    inline operator fun times(other: Float): Dp = Dp(value * other)
    inline operator fun times(other: Int): Dp = Dp(value * other)
    inline operator fun div(other: Float): Dp = Dp(value / other)
    inline operator fun div(other: Int): Dp = Dp(value / other)
    companion object {
        val Hairline: Dp = Dp(0f)
        val Infinity: Dp = Dp(Float.POSITIVE_INFINITY)
        val Unspecified: Dp = Dp(Float.NaN)
    }
}

@Stable
inline val Int.dp: Dp get() = Dp(this.toFloat())

@Stable
inline val Float.dp: Dp get() = Dp(this)

@Stable
inline val Double.dp: Dp get() = Dp(this.toFloat())

@Immutable
@JvmInline
value class TextUnit(val packedValue: Long) {
    companion object {
        val Unspecified: TextUnit = TextUnit(0L)
    }
}

@Stable
val Int.sp: TextUnit get() = TODO()

@Stable
val Float.sp: TextUnit get() = TODO()

@Stable
val Double.sp: TextUnit get() = TODO()

@Immutable
@JvmInline
value class IntSize(val packedValue: Long) {
    val width: Int get() = TODO()
    val height: Int get() = TODO()
    companion object {
        val Zero: IntSize = IntSize(0L)
    }
}

@Stable
fun IntSize(width: Int, height: Int): IntSize = TODO()

@Immutable
@JvmInline
value class IntOffset(val packedValue: Long) {
    val x: Int get() = TODO()
    val y: Int get() = TODO()
    companion object {
        val Zero: IntOffset = IntOffset(0L)
    }
}

@Stable
fun IntOffset(x: Int, y: Int): IntOffset = TODO()

@Immutable
interface Density : FontScaling {
    val density: Float
    @Stable fun Dp.toPx(): Float = value * density
    @Stable fun Dp.roundToPx(): Int = TODO()
    @Stable fun Int.toDp(): Dp = TODO()
    @Stable fun Float.toDp(): Dp = TODO()
    @Stable fun TextUnit.toPx(): Float = TODO()
}

interface FontScaling {
    val fontScale: Float
}

enum class LayoutDirection { Ltr, Rtl }
