@file:Suppress("unused", "UNUSED_PARAMETER")
package androidx.compose.ui

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.Stable

@Stable
interface Modifier {
    infix fun then(other: Modifier): Modifier = TODO()
    interface Element : Modifier
    companion object : Modifier
}

@Stable
fun interface Alignment {
    fun align(size: Long, space: Long, layoutDirection: androidx.compose.ui.unit.LayoutDirection): Long

    @Stable
    fun interface Horizontal {
        fun align(size: Int, space: Int, layoutDirection: androidx.compose.ui.unit.LayoutDirection): Int
    }

    @Stable
    fun interface Vertical {
        fun align(size: Int, space: Int): Int
    }

    companion object {
        @Stable val TopStart: Alignment = TODO()
        @Stable val TopCenter: Alignment = TODO()
        @Stable val TopEnd: Alignment = TODO()
        @Stable val CenterStart: Alignment = TODO()
        @Stable val Center: Alignment = TODO()
        @Stable val CenterEnd: Alignment = TODO()
        @Stable val BottomStart: Alignment = TODO()
        @Stable val BottomCenter: Alignment = TODO()
        @Stable val BottomEnd: Alignment = TODO()
        @Stable val Top: Vertical = TODO()
        @Stable val CenterVertically: Vertical = TODO()
        @Stable val Bottom: Vertical = TODO()
        @Stable val Start: Horizontal = TODO()
        @Stable val CenterHorizontally: Horizontal = TODO()
        @Stable val End: Horizontal = TODO()
    }
}

