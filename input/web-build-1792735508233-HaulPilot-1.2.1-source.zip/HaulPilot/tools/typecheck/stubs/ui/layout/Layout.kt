@file:Suppress("unused", "UNUSED_PARAMETER")
package androidx.compose.ui.layout

import androidx.compose.runtime.Stable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.IntSize

@Stable
fun Modifier.onSizeChanged(onSizeChanged: (IntSize) -> Unit): Modifier = TODO()

@Stable
interface ContentScale {
    companion object {
        @Stable val Crop: ContentScale = TODO()
        @Stable val Fit: ContentScale = TODO()
        @Stable val FillBounds: ContentScale = TODO()
        @Stable val FillWidth: ContentScale = TODO()
        @Stable val Inside: ContentScale = TODO()
    }
}
