@file:Suppress("unused", "UNUSED_PARAMETER")
package androidx.compose.ui.geometry

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.Stable

@Immutable
@JvmInline
value class Offset(val packedValue: Long) {
    val x: Float get() = TODO()
    val y: Float get() = TODO()
    @Stable fun getDistance(): Float = TODO()
    @Stable operator fun minus(other: Offset): Offset = TODO()
    @Stable operator fun plus(other: Offset): Offset = TODO()
    @Stable operator fun times(operand: Float): Offset = TODO()
    @Stable operator fun div(operand: Float): Offset = TODO()
    @Stable operator fun unaryMinus(): Offset = TODO()
    fun copy(x: Float = this.x, y: Float = this.y): Offset = TODO()
    companion object {
        val Zero: Offset = Offset(0L)
        val Unspecified: Offset = Offset(0L)
    }
}

@Stable
fun Offset(x: Float, y: Float): Offset = TODO()

@Immutable
@JvmInline
value class Size(val packedValue: Long) {
    val width: Float get() = TODO()
    val height: Float get() = TODO()
    val minDimension: Float get() = TODO()
    val maxDimension: Float get() = TODO()
    companion object {
        val Zero: Size = Size(0L)
        val Unspecified: Size = Size(0L)
    }
}

@Stable
fun Size(width: Float, height: Float): Size = TODO()

@Immutable
@JvmInline
value class CornerRadius(val packedValue: Long) {
    val x: Float get() = TODO()
    val y: Float get() = TODO()
    companion object {
        val Zero: CornerRadius = CornerRadius(0L)
    }
}

@Stable
fun CornerRadius(x: Float, y: Float = x): CornerRadius = TODO()

@Immutable
data class Rect(val left: Float, val top: Float, val right: Float, val bottom: Float) {
    val width: Float get() = right - left
    val height: Float get() = bottom - top
    companion object {
        val Zero: Rect = Rect(0f, 0f, 0f, 0f)
    }
}
