@file:Suppress("unused", "UNUSED_PARAMETER")
package androidx.compose.runtime

import kotlinx.coroutines.CoroutineScope
import kotlin.coroutines.CoroutineContext
import kotlin.coroutines.EmptyCoroutineContext
import kotlin.reflect.KProperty

@Target(AnnotationTarget.FUNCTION, AnnotationTarget.TYPE, AnnotationTarget.TYPE_PARAMETER, AnnotationTarget.PROPERTY_GETTER)
@MustBeDocumented
annotation class Composable

@Target(AnnotationTarget.FUNCTION, AnnotationTarget.PROPERTY_GETTER)
annotation class ReadOnlyComposable

@Target(AnnotationTarget.FUNCTION, AnnotationTarget.TYPE)
annotation class DisallowComposableCalls

@Target(AnnotationTarget.CLASS, AnnotationTarget.FUNCTION, AnnotationTarget.PROPERTY)
annotation class Stable

@Target(AnnotationTarget.CLASS)
annotation class Immutable

@Stable
interface State<out T> {
    val value: T
}

@Stable
interface MutableState<T> : State<T> {
    override var value: T
    operator fun component1(): T
    operator fun component2(): (T) -> Unit
}

interface IntState : State<Int> {
    val intValue: Int
    override val value: Int get() = intValue
}

interface MutableIntState : IntState, MutableState<Int> {
    override var intValue: Int
    override var value: Int
        get() = intValue
        set(v) {
            intValue = v
        }
}

interface SnapshotMutationPolicy<T> {
    fun equivalent(a: T, b: T): Boolean
}

fun <T> structuralEqualityPolicy(): SnapshotMutationPolicy<T> = TODO()

fun <T> mutableStateOf(value: T, policy: SnapshotMutationPolicy<T> = structuralEqualityPolicy()): MutableState<T> = TODO()

fun mutableIntStateOf(value: Int): MutableIntState = TODO()

@Suppress("NOTHING_TO_INLINE")
inline operator fun <T> State<T>.getValue(thisObj: Any?, property: KProperty<*>): T = value

@Suppress("NOTHING_TO_INLINE")
inline operator fun <T> MutableState<T>.setValue(thisObj: Any?, property: KProperty<*>, value: T) {
    this.value = value
}

@Suppress("NOTHING_TO_INLINE")
inline operator fun IntState.getValue(thisObj: Any?, property: KProperty<*>): Int = intValue

@Suppress("NOTHING_TO_INLINE")
inline operator fun MutableIntState.setValue(thisObj: Any?, property: KProperty<*>, value: Int) {
    this.intValue = value
}

@Composable
inline fun <T> remember(crossinline calculation: @DisallowComposableCalls () -> T): T = calculation()

@Composable
inline fun <T> remember(key1: Any?, crossinline calculation: @DisallowComposableCalls () -> T): T = calculation()

@Composable
inline fun <T> remember(key1: Any?, key2: Any?, crossinline calculation: @DisallowComposableCalls () -> T): T = calculation()

@Composable
inline fun <T> remember(key1: Any?, key2: Any?, key3: Any?, crossinline calculation: @DisallowComposableCalls () -> T): T = calculation()

@Composable
inline fun <T> remember(vararg keys: Any?, crossinline calculation: @DisallowComposableCalls () -> T): T = calculation()

@Composable
fun <T> rememberUpdatedState(newValue: T): State<T> = TODO()

@Composable
fun LaunchedEffect(key1: Any?, block: suspend CoroutineScope.() -> Unit): Unit = TODO()

@Composable
fun LaunchedEffect(key1: Any?, key2: Any?, block: suspend CoroutineScope.() -> Unit): Unit = TODO()

@Composable
fun LaunchedEffect(key1: Any?, key2: Any?, key3: Any?, block: suspend CoroutineScope.() -> Unit): Unit = TODO()

@Composable
fun LaunchedEffect(vararg keys: Any?, block: suspend CoroutineScope.() -> Unit): Unit = TODO()

class DisposableEffectScope {
    inline fun onDispose(crossinline onDisposeEffect: () -> Unit): DisposableEffectResult = object : DisposableEffectResult {
        override fun dispose() = onDisposeEffect()
    }
}

interface DisposableEffectResult {
    fun dispose()
}

@Composable
fun DisposableEffect(key1: Any?, effect: DisposableEffectScope.() -> DisposableEffectResult): Unit = TODO()

@Composable
fun DisposableEffect(key1: Any?, key2: Any?, effect: DisposableEffectScope.() -> DisposableEffectResult): Unit = TODO()

@Composable
inline fun rememberCoroutineScope(crossinline getContext: @DisallowComposableCalls () -> CoroutineContext = { EmptyCoroutineContext }): CoroutineScope = TODO()

@Stable
sealed class CompositionLocal<T> {
    val current: T
        @Composable @ReadOnlyComposable get() = TODO()
}

@Stable
abstract class ProvidableCompositionLocal<T> internal constructor() : CompositionLocal<T>()
