@file:Suppress("unused", "UNUSED_PARAMETER")
package androidx.core.app

import android.app.Notification
import android.app.Service
import android.content.Context

class NotificationManagerCompat private constructor() {
    fun areNotificationsEnabled(): Boolean = TODO()

    companion object {
        @JvmStatic
        fun from(context: Context): NotificationManagerCompat = TODO()
    }
}

object ServiceCompat {
    const val STOP_FOREGROUND_REMOVE = 1
    const val STOP_FOREGROUND_DETACH = 2

    /** Added in androidx.core 1.12 (the project uses core-ktx 1.17). */
    @JvmStatic
    fun startForeground(service: Service, id: Int, notification: Notification, foregroundServiceType: Int): Unit = TODO()

    @JvmStatic
    fun stopForeground(service: Service, flags: Int): Unit = TODO()
}
