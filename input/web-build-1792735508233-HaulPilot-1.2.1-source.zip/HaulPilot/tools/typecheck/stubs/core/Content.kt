@file:Suppress("unused", "UNUSED_PARAMETER")
package androidx.core.content

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter

object ContextCompat {
    const val RECEIVER_VISIBLE_TO_INSTANT_APPS = 1
    const val RECEIVER_EXPORTED = 2
    const val RECEIVER_NOT_EXPORTED = 4

    @JvmStatic
    fun checkSelfPermission(context: Context, permission: String): Int = TODO()

    @JvmStatic
    fun registerReceiver(context: Context, receiver: BroadcastReceiver?, filter: IntentFilter, flags: Int): Intent? = TODO()

    @JvmStatic
    fun startForegroundService(context: Context, intent: Intent): Unit = TODO()
}

object IntentCompat {
    @JvmStatic
    fun <T> getParcelableExtra(`in`: Intent, name: String?, clazz: Class<T>): T? = TODO()
}
