@file:Suppress("unused", "UNUSED_PARAMETER")
package androidx.compose.foundation.shape

import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp

abstract class CornerBasedShape : Shape

class RoundedCornerShape internal constructor() : CornerBasedShape()

fun RoundedCornerShape(size: Dp): RoundedCornerShape = TODO()

fun RoundedCornerShape(percent: Int): RoundedCornerShape = TODO()

fun RoundedCornerShape(size: Float): RoundedCornerShape = TODO()

fun RoundedCornerShape(topStart: Dp = Dp(0f), topEnd: Dp = Dp(0f), bottomEnd: Dp = Dp(0f), bottomStart: Dp = Dp(0f)): RoundedCornerShape = TODO()

val CircleShape: RoundedCornerShape = TODO()
