@file:Suppress("unused", "UNUSED_PARAMETER")
package androidx.compose.foundation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.Stable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.Dp

@Immutable
class BorderStroke(val width: Dp, val brush: Any?) {
    constructor(width: Dp, color: Color) : this(width, null as Any?)
}

@Composable
fun Canvas(modifier: Modifier, onDraw: DrawScope.() -> Unit): Unit = TODO()

@Composable
fun Canvas(modifier: Modifier, contentDescription: String, onDraw: DrawScope.() -> Unit): Unit = TODO()

@Composable
fun Image(
    bitmap: ImageBitmap,
    contentDescription: String?,
    modifier: Modifier = Modifier,
    alignment: Alignment = Alignment.Center,
    contentScale: ContentScale = ContentScale.Fit,
    alpha: Float = 1.0f,
    colorFilter: ColorFilter? = null,
    filterQuality: FilterQuality = FilterQuality.Low,
): Unit = TODO()

@Stable
fun Modifier.background(color: Color, shape: Shape = RectangleShape): Modifier = TODO()

@Stable
fun Modifier.border(width: Dp, color: Color, shape: Shape = RectangleShape): Modifier = TODO()

@Stable
fun Modifier.border(border: BorderStroke, shape: Shape = RectangleShape): Modifier = TODO()

fun Modifier.clickable(
    enabled: Boolean = true,
    onClickLabel: String? = null,
    role: Role? = null,
    interactionSource: Any? = null,
    onClick: () -> Unit,
): Modifier = TODO()

@Stable
class ScrollState(initial: Int) {
    val value: Int get() = TODO()
    val maxValue: Int get() = TODO()
    suspend fun scrollTo(value: Int): Float = TODO()
    suspend fun animateScrollTo(value: Int): Unit = TODO()
}

@Composable
fun rememberScrollState(initial: Int = 0): ScrollState = TODO()

fun Modifier.verticalScroll(state: ScrollState, enabled: Boolean = true, flingBehavior: Any? = null, reverseScrolling: Boolean = false): Modifier = TODO()

fun Modifier.horizontalScroll(state: ScrollState, enabled: Boolean = true, flingBehavior: Any? = null, reverseScrolling: Boolean = false): Modifier = TODO()
