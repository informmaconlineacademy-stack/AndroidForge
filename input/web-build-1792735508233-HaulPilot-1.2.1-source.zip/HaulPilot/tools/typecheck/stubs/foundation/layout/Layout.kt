@file:Suppress("unused", "UNUSED_PARAMETER")
package androidx.compose.foundation.layout

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.Stable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.Dp

@Immutable
object Arrangement {
    @Stable
    interface Horizontal {
        val spacing: Dp get() = Dp(0f)
    }

    @Stable
    interface Vertical {
        val spacing: Dp get() = Dp(0f)
    }

    @Stable
    interface HorizontalOrVertical : Horizontal, Vertical {
        override val spacing: Dp get() = Dp(0f)
    }

    @Stable val Start: Horizontal = TODO()
    @Stable val End: Horizontal = TODO()
    @Stable val Top: Vertical = TODO()
    @Stable val Bottom: Vertical = TODO()
    @Stable val Center: HorizontalOrVertical = TODO()
    @Stable val SpaceEvenly: HorizontalOrVertical = TODO()
    @Stable val SpaceBetween: HorizontalOrVertical = TODO()
    @Stable val SpaceAround: HorizontalOrVertical = TODO()

    @Stable fun spacedBy(space: Dp): HorizontalOrVertical = TODO()
    @Stable fun spacedBy(space: Dp, alignment: Alignment.Horizontal): Horizontal = TODO()
    @Stable fun spacedBy(space: Dp, alignment: Alignment.Vertical): Vertical = TODO()
}

@Stable
interface PaddingValues

@Stable
fun PaddingValues(all: Dp): PaddingValues = TODO()

@Stable
fun PaddingValues(horizontal: Dp = Dp(0f), vertical: Dp = Dp(0f)): PaddingValues = TODO()

@Stable
fun PaddingValues(start: Dp = Dp(0f), top: Dp = Dp(0f), end: Dp = Dp(0f), bottom: Dp = Dp(0f)): PaddingValues = TODO()

@Immutable
interface BoxScope {
    @Stable fun Modifier.align(alignment: Alignment): Modifier
    @Stable fun Modifier.matchParentSize(): Modifier
}

@Immutable
interface ColumnScope {
    @Stable fun Modifier.weight(weight: Float, fill: Boolean = true): Modifier
    @Stable fun Modifier.align(alignment: Alignment.Horizontal): Modifier
}

@Immutable
interface RowScope {
    @Stable fun Modifier.weight(weight: Float, fill: Boolean = true): Modifier
    @Stable fun Modifier.align(alignment: Alignment.Vertical): Modifier
}

@Composable
inline fun Box(
    modifier: Modifier = Modifier,
    contentAlignment: Alignment = Alignment.TopStart,
    propagateMinConstraints: Boolean = false,
    content: @Composable BoxScope.() -> Unit,
): Unit = TODO()

@Composable
fun Box(modifier: Modifier): Unit = TODO()

@Composable
inline fun Column(
    modifier: Modifier = Modifier,
    verticalArrangement: Arrangement.Vertical = Arrangement.Top,
    horizontalAlignment: Alignment.Horizontal = Alignment.Start,
    content: @Composable ColumnScope.() -> Unit,
): Unit = TODO()

@Composable
inline fun Row(
    modifier: Modifier = Modifier,
    horizontalArrangement: Arrangement.Horizontal = Arrangement.Start,
    verticalAlignment: Alignment.Vertical = Alignment.Top,
    content: @Composable RowScope.() -> Unit,
): Unit = TODO()

@Composable
fun Spacer(modifier: Modifier): Unit = TODO()

@Stable fun Modifier.padding(all: Dp): Modifier = TODO()
@Stable fun Modifier.padding(horizontal: Dp = Dp(0f), vertical: Dp = Dp(0f)): Modifier = TODO()
@Stable fun Modifier.padding(start: Dp = Dp(0f), top: Dp = Dp(0f), end: Dp = Dp(0f), bottom: Dp = Dp(0f)): Modifier = TODO()
@Stable fun Modifier.padding(paddingValues: PaddingValues): Modifier = TODO()
@Stable fun Modifier.fillMaxSize(fraction: Float = 1f): Modifier = TODO()
@Stable fun Modifier.fillMaxWidth(fraction: Float = 1f): Modifier = TODO()
@Stable fun Modifier.fillMaxHeight(fraction: Float = 1f): Modifier = TODO()
@Stable fun Modifier.size(size: Dp): Modifier = TODO()
@Stable fun Modifier.size(width: Dp, height: Dp): Modifier = TODO()
@Stable fun Modifier.width(width: Dp): Modifier = TODO()
@Stable fun Modifier.height(height: Dp): Modifier = TODO()
@Stable fun Modifier.heightIn(min: Dp = Dp.Unspecified, max: Dp = Dp.Unspecified): Modifier = TODO()
@Stable fun Modifier.widthIn(min: Dp = Dp.Unspecified, max: Dp = Dp.Unspecified): Modifier = TODO()
@Stable fun Modifier.sizeIn(minWidth: Dp = Dp.Unspecified, minHeight: Dp = Dp.Unspecified, maxWidth: Dp = Dp.Unspecified, maxHeight: Dp = Dp.Unspecified): Modifier = TODO()
@Stable fun Modifier.aspectRatio(ratio: Float, matchHeightConstraintsFirst: Boolean = false): Modifier = TODO()
@Stable fun Modifier.offset(x: Dp = Dp(0f), y: Dp = Dp(0f)): Modifier = TODO()

@Stable
interface WindowInsets {
    companion object
}

val WindowInsets.Companion.statusBars: WindowInsets
    @Composable get() = TODO()

val WindowInsets.Companion.navigationBars: WindowInsets
    @Composable get() = TODO()

val WindowInsets.Companion.systemBars: WindowInsets
    @Composable get() = TODO()

val WindowInsets.Companion.safeDrawing: WindowInsets
    @Composable get() = TODO()

fun Modifier.windowInsetsPadding(insets: WindowInsets): Modifier = TODO()

fun Modifier.statusBarsPadding(): Modifier = TODO()

fun Modifier.navigationBarsPadding(): Modifier = TODO()
