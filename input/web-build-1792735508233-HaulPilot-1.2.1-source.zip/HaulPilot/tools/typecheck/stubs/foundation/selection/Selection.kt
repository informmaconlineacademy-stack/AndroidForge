@file:Suppress("unused", "UNUSED_PARAMETER")
package androidx.compose.foundation.selection

import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role

fun Modifier.selectable(selected: Boolean, enabled: Boolean = true, role: Role? = null, interactionSource: Any? = null, onClick: () -> Unit): Modifier = TODO()

fun Modifier.toggleable(value: Boolean, enabled: Boolean = true, role: Role? = null, interactionSource: Any? = null, onValueChange: (Boolean) -> Unit): Modifier = TODO()
