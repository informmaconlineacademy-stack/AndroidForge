@file:Suppress("unused", "UNUSED_PARAMETER")
package androidx.compose.foundation.gestures

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.AwaitPointerEventScope
import androidx.compose.ui.input.pointer.PointerEvent
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.PointerInputChange
import androidx.compose.ui.input.pointer.PointerInputScope

suspend fun PointerInputScope.awaitEachGesture(block: suspend AwaitPointerEventScope.() -> Unit): Unit = TODO()

suspend fun AwaitPointerEventScope.awaitFirstDown(requireUnconsumed: Boolean = true, pass: PointerEventPass = PointerEventPass.Main): PointerInputChange = TODO()

fun PointerEvent.calculateZoom(): Float = TODO()

fun PointerEvent.calculatePan(): Offset = TODO()

fun PointerEvent.calculateCentroid(useCurrent: Boolean = true): Offset = TODO()

fun PointerEvent.calculateRotation(): Float = TODO()
