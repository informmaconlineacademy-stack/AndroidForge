#!/usr/bin/env python3
"""Usage: verify_stubs.py <folder with the AndroidX API .txt signature files>

Checks every function/constructor in the hand-written AndroidX stubs against the published API signature files.

For each stub declaration it looks for an API method/ctor with the same name such that:
  * every stub parameter name exists in the API declaration, in the same order;
  * every API parameter WITHOUT a default ("optional") is also in the stub (so no call compiles against the stub but
    misses a required argument in the real library);
  * a stub parameter with a default value is optional in the API.
Prints one line per stub declaration: OK / MISMATCH / NOT FOUND."""
import re, sys, pathlib

API = pathlib.Path(sys.argv[1]) if len(sys.argv) > 1 else pathlib.Path(__file__).resolve().parent / 'api'
STUBS = pathlib.Path(__file__).resolve().parent / 'stubs'

api_decls = {}  # name -> list of [(param, optional)]
for f in API.glob('*.txt'):
    for line in f.read_text().splitlines():
        line = line.strip()
        if 'BytecodeOnly' in line or not (line.startswith('method') or line.startswith('ctor')):
            continue
        m = re.search(r'([A-Za-z_][A-Za-z0-9_]*)\((.*)\)\s*(throws [^;]*)?;$', line)
        if not m:
            continue
        name, plist = m.group(1), m.group(2)
        if line.startswith('ctor'):
            name = name.split('.')[-1]
        # split params at top-level commas
        parts, depth, cur = [], 0, ''
        for ch in plist:
            if ch in '<(': depth += 1
            if ch in '>)': depth -= 1
            if ch == ',' and depth == 0:
                parts.append(cur.strip()); cur = ''
            else:
                cur += ch
        if cur.strip(): parts.append(cur.strip())
        params = []
        for pp in parts:
            toks = pp.replace('@FloatRange(from=0.0, to=1.0)', '').split()
            if not toks: continue
            optional = toks[0] == 'optional'
            toks = [t for t in toks if t != 'optional' and not t.startswith('@')]
            if len(toks) >= 2 and re.fullmatch(r'[a-z][A-Za-z0-9_]*', toks[-1]):
                params.append((toks[-1], optional))
            # unnamed = extension receiver or Java-style param: skipped
        api_decls.setdefault(name, []).append(params)

decl_re = re.compile(r'(?:^|\n)[ \t]*(?:@[A-Za-z.]+(?:\([^)]*\))?\s+)*(?:(?:inline|suspend|operator|override|abstract|open|final|infix|private|internal)\s+)*(fun|class|constructor)\s*(?:<[^>]*>\s*)?([A-Za-z_.`<> ,]+?)?\s*\(', re.S)

def params_of(src, start):
    depth, i, buf = 1, start, ''
    while i < len(src) and depth:
        ch = src[i]
        if ch in '(<[{': depth += 1
        if ch in ')>]}': depth -= 1
        if depth: buf += ch
        i += 1
    parts, d, cur = [], 0, ''
    for ch in buf:
        if ch in '(<[{': d += 1
        if ch in ')>]}': d -= 1
        if ch == ',' and d == 0:
            parts.append(cur); cur = ''
        else:
            cur += ch
    if cur.strip(): parts.append(cur)
    out = []
    for p in parts:
        p = p.strip()
        if not p: continue
        p = re.sub(r'^(?:vararg|noinline|crossinline|val|var|private|override)\s+', '', p)
        p = re.sub(r'^(?:vararg|noinline|crossinline|val|var)\s+', '', p)
        m = re.match(r'`?([A-Za-z_][A-Za-z0-9_]*)`?\s*:', p)
        if m:
            out.append((m.group(1), '=' in p.split(':', 1)[1] and not re.search(r'->[^=]*$', p.split('=')[0]) or bool(re.search(r'\)\s*=|[^=!<>]=[^=>]', p.split(':', 1)[1]))))
    return out

results = {'OK': 0, 'MISMATCH': 0, 'NOT FOUND': 0}
skip_names = {'TODO', 'onDispose', 'equivalent', 'compareTo', 'align', 'dispose', 'unregister', 'createIntent', 'parseResult',
              'isAtLeast', 'onStateChanged', 'addObserver', 'removeObserver', 'moveTo', 'lineTo', 'close', 'reset', 'copy',
              'getDistance', 'minus', 'plus', 'times', 'div', 'unaryMinus', 'toPx', 'roundToPx', 'toDp', 'then', 'weight', 'matchParentSize',
              'consume', 'awaitPointerEvent', 'awaitPointerEventScope', 'launch', 'item', 'items', 'component1', 'component2', 'scrollTo', 'animateScrollTo'}
for f in sorted(STUBS.rglob('*.kt')):
    src = f.read_text().replace('->', '→')
    for m in re.finditer(r'\bfun\s+(?:<[^>]*>\s*)?(?:[A-Za-z_.]+\.)?([A-Za-z_][A-Za-z0-9_]*)\s*\(', src):
        name = m.group(1)
        stub = params_of(src, m.end())
        cands = api_decls.get(name)
        line = src[:m.start()].count('\n') + 1
        if name in skip_names and not cands:
            continue
        if not cands:
            print(f'NOT FOUND  {f.relative_to(STUBS)}:{line} {name}({", ".join(p for p,_ in stub)})'); results['NOT FOUND'] += 1; continue
        ok = False
        best = None
        for api in cands:
            names = [n for n, _ in api]
            if not all(n in names for n, _ in stub):
                best = best or f'unknown params {[n for n,_ in stub if n not in names]} vs {names}'; continue
            idx = [names.index(n) for n, _ in stub]
            if idx != sorted(idx):
                best = f'order differs: {[n for n,_ in stub]} vs {names}'; continue
            req_missing = [n for n, opt in api if not opt and n not in [s for s, _ in stub]]
            if req_missing:
                best = f'stub lacks required {req_missing}'; continue
            bad_default = [n for n, d in stub if d and not dict(api)[n]]
            if bad_default:
                best = f'stub default but API required: {bad_default}'; continue
            ok = True; break
        if ok:
            results['OK'] += 1
        else:
            print(f'MISMATCH   {f.relative_to(STUBS)}:{line} {name}: {best}'); results['MISMATCH'] += 1
print(results)
