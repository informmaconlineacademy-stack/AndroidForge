# Offline type-check (not a build)

Used while developing HaulPilot 1.0.0 in an environment that could not download the Android SDK or AndroidX libraries.
It is **not** part of the Gradle build and does not produce an APK.

* `stubs/` — hand-written stand-ins for exactly the AndroidX / Compose declarations the app uses (bodies are `TODO()`).
* `api/` — the published API signature files those stand-ins were checked against (from the AndroidX project, Apache
  License 2.0): Compose runtime/UI/foundation 1.9.0-beta01, Material3 1.4.0-beta03, Activity 1.11.0-beta01,
  Lifecycle runtime-compose 2.9.0-beta01, Core 1.11.0-beta02. The project itself builds with the stable versions in
  `gradle/libs.versions.toml` (Compose BOM 2025.09.00, Activity 1.11.0, Core 1.17.0, Lifecycle 2.9.0).
* `verify_stubs.py` — checks every stand-in function against `api/` (names, order, required and optional parameters).
* `typecheck.sh` — compiles `app/src/main/kotlin` against `android.jar` + the stand-ins. `--plugin` adds the Compose
  compiler plugin's front-end checks.

```
python3 tools/typecheck/verify_stubs.py
KOTLINC_HOME=/opt/kotlinc ANDROID_JAR=$ANDROID_HOME/platforms/android-36/android.jar tools/typecheck/typecheck.sh
```

With an Android SDK available, use the real build instead: `./gradlew testDebugUnitTest assembleDebug`.
