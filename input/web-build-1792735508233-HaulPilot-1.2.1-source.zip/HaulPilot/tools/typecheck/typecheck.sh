#!/usr/bin/env bash
# OFFLINE TYPE-CHECK of the Android app layer — NOT a build.
#
# Compiles app/src/main/kotlin (app + core) with kotlinc against:
#   * android.jar (Android API 36, from an SDK or AOSP prebuilts),
#   * the hand-written AndroidX / Compose stand-ins in tools/typecheck/stubs (checked against the published API
#     signature files with verify_stubs.py),
#   * the Kotlin stdlib and kotlinx-coroutines-core shipped with kotlinc.
# No resources, no manifest merge, no Compose code generation, no dex, no APK. It only proves that names, types and call
# signatures resolve. The real build is ./gradlew assembleDebug (CI: .github/workflows/build.yml).
#
# Usage: tools/typecheck/typecheck.sh [--plugin]
#   KOTLINC_HOME=/path/to/kotlinc  (default: kotlinc on PATH)   ANDROID_JAR=/path/to/android.jar (required)
#   --plugin   also run the Compose compiler plugin's front-end checks (it then stops at code generation, see TEST_REPORT.md)
set -uo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$HERE/../.." && pwd)"
if [ -n "${KOTLINC_HOME:-}" ]; then KC="$KOTLINC_HOME"; else KC="$(cd "$(dirname "$(readlink -f "$(command -v kotlinc)")")/.." && pwd)"; fi
ANDROID="${ANDROID_JAR:?set ANDROID_JAR to an android.jar for API 36}"
OUT="${OUT:-$(mktemp -d)}"
STD="$KC/lib/kotlin-stdlib.jar"
CORO="$KC/lib/kotlinx-coroutines-core-jvm.jar"
mkdir -p "$OUT/stubs" "$OUT/app" "$OUT/gen"

# Stand-ins for the classes Gradle generates (BuildConfig, R).
cat > "$OUT/gen/BuildConfig.kt" <<'KT'
package dev.toe3autopilot
object BuildConfig {
    const val DEBUG = true
    const val APPLICATION_ID = "com.praju12.haulpilot.debug"
    const val BUILD_TYPE = "debug"
    const val VERSION_CODE = 0
    const val VERSION_NAME = "typecheck"
}
KT
python3 - "$ROOT" "$OUT/gen/R.kt" <<'PY'
import re, sys, pathlib
root = pathlib.Path(sys.argv[1]) / "app/src/main/kotlin"
used = {}
for f in root.rglob("*.kt"):
    for t, n in re.findall(r"\bR\.([a-z]+)\.([A-Za-z0-9_]+)", f.read_text()):
        used.setdefault(t, set()).add(n)
lines = ["package dev.toe3autopilot", "object R {"]
for t, names in sorted(used.items()):
    lines.append(f"    object {t} {{")
    lines += [f"        const val {n} = 0" for n in sorted(names)]
    lines.append("    }")
lines.append("}")
pathlib.Path(sys.argv[2]).write_text("\n".join(lines) + "\n")
PY

echo "== compiling the AndroidX/Compose stand-ins"
"$KC/bin/kotlinc" -nowarn -jvm-target 17 -cp "$ANDROID:$STD:$CORO" -d "$OUT/stubs" $(find "$HERE/stubs" -name '*.kt') 2>&1 | grep -v JAVA_TOOL
test -d "$OUT/stubs/androidx" || { echo "STUB COMPILE FAILED"; exit 1; }

echo "== type-checking app + core"
PLUGIN=""
[ "${1:-}" = "--plugin" ] && PLUGIN="-Xplugin=$KC/lib/compose-compiler-plugin.jar"
"$KC/bin/kotlinc" -jvm-target 17 $PLUGIN -cp "$ANDROID:$STD:$CORO:$OUT/stubs" -d "$OUT/app" \
  $(find "$ROOT/app/src/main/kotlin" -name '*.kt') "$OUT/gen/BuildConfig.kt" "$OUT/gen/R.kt" 2>&1 | grep -v JAVA_TOOL > "$OUT/log.txt"
ERR=$(grep -c "error:" "$OUT/log.txt")
WARN=$(grep -c "warning:" "$OUT/log.txt")
grep -E "error:|warning:" "$OUT/log.txt" | head -80
echo "errors: $ERR, warnings: $WARN (log: $OUT/log.txt)"
if [ "$ERR" -ne 0 ]; then echo "TYPECHECK FAILED"; exit 1; fi
if [ -n "$PLUGIN" ]; then
  echo "Compose front-end checks passed (code generation needs the real Compose runtime and is expected to stop)."
else
  test -d "$OUT/app/dev" && echo "TYPECHECK OK" || { echo "TYPECHECK FAILED"; exit 1; }
fi
