#!/usr/bin/env bash
# Compiles and unit-tests the Android-free core (package dev.toe3autopilot.core) WITHOUT Gradle
# dependency resolution or the Android SDK. It only needs a JDK and a Gradle distribution, because
# Gradle ships a Kotlin compiler and JUnit in its lib/ directory.
#
# This is a convenience for sandboxes without network access. In Android Studio / CI use:
#     ./gradlew testDebugUnitTest
#
# Usage: tools/verify-core-offline.sh [path/to/gradle/lib]
set -euo pipefail

GRADLE_LIB="${1:-${GRADLE_LIB:-/opt/gradle-8.14.3/lib}}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="${OUT:-$(mktemp -d)}"
KV="$(ls "$GRADLE_LIB"/kotlin-compiler-embeddable-*.jar | head -1 | sed -E 's/.*embeddable-(.*)\.jar/\1/')"

STD="$GRADLE_LIB/kotlin-stdlib-$KV.jar"
JUNIT="$GRADLE_LIB/junit-4.13.2.jar:$GRADLE_LIB/hamcrest-core-1.3.jar"
KC="$GRADLE_LIB/kotlin-compiler-embeddable-$KV.jar:$STD:$GRADLE_LIB/kotlin-script-runtime-$KV.jar:$GRADLE_LIB/kotlin-reflect-$KV.jar:$GRADLE_LIB/kotlin-daemon-embeddable-$KV.jar:$(ls "$GRADLE_LIB"/trove4j-*.jar | head -1):$(ls "$GRADLE_LIB"/annotations-*.jar | head -1):$(ls "$GRADLE_LIB"/kotlinx-coroutines-core-jvm-*.jar | head -1)"

kotlinc() { java -cp "$KC" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler -no-stdlib -no-reflect "$@"; }

echo "Kotlin $KV, output in $OUT"
echo "== compiling core"
kotlinc -cp "$STD" -d "$OUT/main" -Werror=false $(find "$ROOT/app/src/main/kotlin/dev/toe3autopilot/core" -name '*.kt')

echo "== compiling tests"
kotlinc -cp "$STD:$JUNIT:$OUT/main" -d "$OUT/test" $(find "$ROOT/app/src/test/kotlin" -name '*.kt')

echo "== running tests"
CLASSES=$(cd "$OUT/test" && find . -name '*Test.class' | sed 's#^\./##; s#\.class$##; s#/#.#g' | sort)
# The real-screenshot tests read their pictures from the test resources and write reports next to the build output.
java -Dhaulpilot.fixtures="$ROOT/app/src/test/resources/fixtures/toe3" -Dhaulpilot.fixtureReports="$OUT/fixture-reports" \
    -cp "$STD:$JUNIT:$OUT/main:$OUT/test" org.junit.runner.JUnitCore $CLASSES
