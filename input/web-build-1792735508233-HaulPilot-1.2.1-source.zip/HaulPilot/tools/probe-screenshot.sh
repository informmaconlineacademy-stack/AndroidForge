#!/usr/bin/env bash
# Runs Auto-Calibrate's detector on your own screenshots WITHOUT Gradle and shows what it proposes.
#
#   tools/probe-screenshot.sh [--exclude x0,y0,x1,y1] PICTURE.png [MORE.png ...]
#
# Needs a JDK and a Kotlin compiler (kotlinc on PATH, or KOTLINC_HOME). Writes an annotated picture and a text report to
# build/fixture-reports/. With Gradle you can instead copy the picture into app/src/test/resources/fixtures/toe3 and run
#   ./gradlew :app:testDebugUnitTest --tests '*RealScreenshotTest*'
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
if [ -n "${KOTLINC_HOME:-}" ]; then KC="$KOTLINC_HOME"; else KC="$(cd "$(dirname "$(readlink -f "$(command -v kotlinc)")")/.." && pwd)"; fi
OUT="$ROOT/build/probe"
mkdir -p "$OUT/classes"
"$KC/bin/kotlinc" -nowarn -cp "$KC/lib/kotlin-stdlib.jar" -d "$OUT/classes" \
    $(find "$ROOT/app/src/main/kotlin/dev/toe3autopilot/core" -name '*.kt') \
    "$ROOT/app/src/test/kotlin/dev/toe3autopilot/core/RealScreenshots.kt" \
    "$ROOT/app/src/test/kotlin/dev/toe3autopilot/core/FixtureProbe.kt" 2>&1 | grep -v '^warning' || true
java -cp "$OUT/classes:$KC/lib/kotlin-stdlib.jar" dev.toe3autopilot.core.FixtureProbeKt --out "$ROOT/build/fixture-reports" "$@"
