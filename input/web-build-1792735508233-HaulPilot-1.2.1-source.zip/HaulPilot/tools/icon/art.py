"""HaulPilot icon artwork, defined once as geometry on the 108 x 108 adaptive-icon canvas.
A heavy tractor-trailer cresting a curved road, with a navigation arrow ahead of it.
Midnight navy background, electric-orange primary accent, cyan highlight. Original artwork; no third-party logos."""
import math

NAVY = "#0F1B30"; NAVY2 = "#16263F"; WHITE = "#F3F6FA"; DARK = "#0A111C"; ROAD = "#2B3648"
ORANGE = "#FF8A1F"; CYAN = "#2DD4E6"; HUB = "#5B6B80"

BACKGROUND = [("rect", 0, 0, 108, 108, NAVY)]

# Road: an arc band (crest under the truck), centre (54, CY), outer radius R_TOP, thickness T.
CX, CY, R_TOP, T = 54.0, 128.0, 60.0, 11.0

def arc_band(r_out, r_in, a0, a1, n=48):
    pts = []
    for i in range(n + 1):
        a = math.radians(a0 + (a1 - a0) * i / n)
        pts.append((CX + r_out * math.cos(a), CY + r_out * math.sin(a)))
    for i in range(n + 1):
        a = math.radians(a1 - (a1 - a0) * i / n)
        pts.append((CX + r_in * math.cos(a), CY + r_in * math.sin(a)))
    return pts

def dash(r, a0, a1, w, color):
    return ("poly", arc_band(r + w / 2, r - w / 2, a0, a1, 10), color)

_RAW = [
    # road surface and its lit outer edge
    ("poly", arc_band(R_TOP, R_TOP - T, 205, 335), ROAD),
    ("poly", arc_band(R_TOP + 0.2, R_TOP - 2.0, 205, 335), CYAN),
    # orange lane dashes along the curve
    dash(R_TOP - T * 0.62, 214, 228, 1.8, ORANGE),
    dash(R_TOP - T * 0.62, 240, 254, 1.8, ORANGE),
    dash(R_TOP - T * 0.62, 266, 280, 1.8, ORANGE),
    dash(R_TOP - T * 0.62, 292, 306, 1.8, ORANGE),
    dash(R_TOP - T * 0.62, 318, 330, 1.8, ORANGE),
    # ---- truck group (index 7..) : semi-trailer + conventional tractor, facing right ----
    ("rrect", 14.0, 33.0, 55.0, 59.0, 2.4, WHITE),                    # 7 trailer box
    ("rrect", 18.0, 52.0, 51.0, 54.4, 1.0, ORANGE),                   # 8 trailer stripe
    ("rrect", 15.5, 59.0, 54.0, 61.2, 0.6, ROAD),                     # 9 trailer chassis
    ("poly", [(57.0, 61.0), (57.0, 34.0), (60.0, 31.0), (68.0, 31.0), (71.0, 34.0),
              (72.0, 46.0), (84.5, 47.5), (86.5, 50.0), (86.5, 61.0)], ORANGE),   # 10 tractor: sleeper cab + hood
    ("poly", [(63.0, 36.0), (68.6, 36.0), (70.2, 45.0), (63.0, 45.0)], DARK),     # 11 window
    ("rrect", 74.5, 50.0, 76.0, 59.0, 0.5, DARK),                     # 12 door line / hood seam
    ("rrect", 85.0, 52.0, 87.5, 61.0, 0.8, WHITE),                    # 13 grille / bumper highlight
    ("rrect", 72.6, 27.0, 74.4, 46.0, 0.8, WHITE),                    # 14 exhaust stack
    ("circle", 22.5, 62.5, 4.4, DARK), ("circle", 22.5, 62.5, 1.6, HUB),   # 15,16
    ("circle", 32.0, 62.5, 4.4, DARK), ("circle", 32.0, 62.5, 1.6, HUB),   # 17,18
    ("circle", 63.0, 62.5, 4.4, DARK), ("circle", 63.0, 62.5, 1.6, HUB),   # 19,20
    ("circle", 80.0, 62.5, 4.4, DARK), ("circle", 80.0, 62.5, 1.6, HUB),   # 21,22
    # navigation arrow ahead of the truck (cyan)
    ("poly", [(61.0, 22.5), (67.0, 35.5), (61.0, 32.4), (55.0, 35.5)], CYAN),   # 23 (placed directly, not scaled)
]

# Fit the truck group (and arrow) inside the 66 dp safe circle: uniform scale about a pivot, then a shift.
TRUCK_SCALE = 0.80
PIVOT = (50.0, 66.6)        # scaled about the wheel line; TARGET puts the tyres on the road crest
TARGET = (54.0, 67.6)

def _xf(x, y):
    return TARGET[0] + (x - PIVOT[0]) * TRUCK_SCALE, TARGET[1] + (y - PIVOT[1]) * TRUCK_SCALE

def _fit(sh):
    k = sh[0]
    if k == "rrect":
        a = _xf(sh[1], sh[2]); b = _xf(sh[3], sh[4]); return ("rrect", a[0], a[1], b[0], b[1], sh[5] * TRUCK_SCALE, sh[6])
    if k == "circle":
        a = _xf(sh[1], sh[2]); return ("circle", a[0], a[1], sh[3] * TRUCK_SCALE, sh[4])
    if k == "poly":
        return ("poly", [_xf(x, y) for x, y in sh[1]], sh[2])
    return sh

FOREGROUND = [(_fit(sh) if 7 <= i <= 22 else sh) for i, sh in enumerate(_RAW)]

# One-colour version (themed icons / notification): drop details that only make sense in colour, cut the cab window.
MONO_HOLES = {10: [11], 7: [8]}
MONO_DROP = {1, 9, 12, 13, 16, 18, 20, 22}
