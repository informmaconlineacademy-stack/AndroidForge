import sys, re, xml.etree.ElementTree as ET
A='{http://schemas.android.com/apk/res/android}'
def conv(files, out, bg=None):
    parts=[]
    for fpath in files:
        r=ET.parse(fpath).getroot()
        for p in r.iter('path'):
            d=p.get(A+'pathData'); fill=p.get(A+'fillColor'); stroke=p.get(A+'strokeColor')
            sw=p.get(A+'strokeWidth','0'); rule='evenodd' if p.get(A+'fillType')=='evenOdd' else 'nonzero'
            color=lambda c: '#'+c[-6:] if c else 'none'
            parts.append(f'<path d="{d}" fill="{color(fill) if fill else "none"}" fill-rule="{rule}" stroke="{color(stroke) if stroke else "none"}" stroke-width="{sw}" stroke-linecap="round"/>')
    bgr=f'<rect width="108" height="108" fill="{bg}"/>' if bg else ''
    open(out,'w').write(f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 108 108" width="432" height="432">{bgr}{"".join(parts)}</svg>')
conv(['vec/ic_launcher_background.xml','vec/ic_launcher_foreground.xml'],'check_color.svg')
conv(['vec/ic_launcher_monochrome.xml'],'check_mono.svg', bg='#3B4A5E')
