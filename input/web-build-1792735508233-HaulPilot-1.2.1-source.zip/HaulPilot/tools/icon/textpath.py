"""Turns a line of text into SVG/VectorDrawable path data using the glyph outlines of an OFL-licensed font (Poppins).
Used only for the splash-screen branding image, so no font file has to ship in the app."""
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.transformPen import TransformPen
from fontTools.pens.boundsPen import BoundsPen

def text_path(font_path, text, size, x, baseline, align='center', width=None):
    f = TTFont(font_path); gs = f.getGlyphSet(); cmap = f.getBestCmap(); upm = f['head'].unitsPerEm
    k = size / upm
    names = [cmap[ord(ch)] for ch in text]
    total = sum(f['hmtx'][n][0] for n in names) * k
    if align == 'center': x0 = x - total / 2
    else: x0 = x
    pen = SVGPathPen(gs, ntos=lambda v: ('%.2f' % v).rstrip('0').rstrip('.'))
    cx = x0
    for n in names:
        tp = TransformPen(pen, (k, 0, 0, -k, cx, baseline))
        gs[n].draw(tp)
        cx += f['hmtx'][n][0] * k
    return pen.getCommands(), total
