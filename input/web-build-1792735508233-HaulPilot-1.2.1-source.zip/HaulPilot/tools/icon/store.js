const { chromium } = require('playwright');
const fs = require('fs');
const color = fs.readFileSync('check_color.svg', 'utf8').replace('width="432" height="432"', 'width="100%" height="100%"');
const mono = fs.readFileSync('mono_nobg.svg', 'utf8').replace('width="432" height="432"', 'width="100%" height="100%"');
const ff = (f) => 'data:font/ttf;base64,' + fs.readFileSync('/usr/share/fonts/truetype/google-fonts/' + f).toString('base64');
const font = `@font-face{font-family:P;src:url(${ff('Poppins-Bold.ttf')});font-weight:700}
@font-face{font-family:P;src:url(${ff('Poppins-Medium.ttf')});font-weight:500}
@font-face{font-family:P;src:url(${ff('Poppins-Regular.ttf')});font-weight:400}
body{margin:0;font-family:P} .themed path[fill='#FFFFFF']{fill:#1B3A6B} .themed path[stroke='#FFFFFF']{stroke:#1B3A6B}`;
// adaptive mask shows the middle 72/108 of the layers
const masked = (r) => `<div style="width:100%;height:100%;border-radius:${r};overflow:hidden;position:relative"><div style="position:absolute;left:-25%;top:-25%;width:150%;height:150%">${color}</div></div>`;
(async () => {
  const b = await chromium.launch();
  async function shot(w, h, html, out) {
    const p = await b.newPage({ viewport: { width: w, height: h } });
    await p.setContent(`<html><head><style>${font}</style></head><body>${html}</body></html>`, { waitUntil: 'load' });
    await p.evaluate(() => document.fonts.ready);
    await p.screenshot({ path: out, omitBackground: true }); await p.close();
  }
  // Play Store icon: 512 x 512, full square (Play applies its own mask).
  await shot(512, 512, `<div style="width:512px;height:512px">${masked('0')}</div>`, 'store/icon-512.png');
  // Feature graphic 1024 x 500.
  await shot(1024, 500, `
  <div style="width:1024px;height:500px;background:#0A0E14;position:relative;overflow:hidden">
    <div style="position:absolute;inset:0;background:linear-gradient(180deg,#12203A 0%,#0A0E14 100%)"></div>
    <div style="position:absolute;left:0;right:0;bottom:0;height:132px;background:#16253F"></div>
    <div style="position:absolute;left:0;right:0;bottom:130px;height:4px;background:#2DD4E6;opacity:.85"></div>
    <div style="position:absolute;left:84px;top:110px;width:240px;height:240px;filter:drop-shadow(0 10px 24px rgba(0,0,0,.45))">${masked('54px')}</div>
    <div style="position:absolute;left:372px;top:150px;color:#F4F7FB">
      <div style="font-weight:700;font-size:78px;line-height:1.0;letter-spacing:.5px">Haul<span style="color:#FF8A1F">Pilot</span></div>
      <div style="margin-top:18px;font-weight:500;font-size:28px;color:#E6ECF3">Drive smarter. Deliver better.</div>
      <div style="margin-top:10px;font-weight:400;font-size:19px;color:#A9B5C3">Smart Setup · Road tracking · Parking assistance</div>
    </div>
    <div style="position:absolute;right:36px;bottom:28px;font-weight:500;font-size:18px;color:#A9B5C3">Made by Praju (praju_12)</div>
  </div>`, 'store/feature-graphic-1024x500.png');
  // Preview sheet: masks, sizes, light/dark wallpapers, themed (monochrome) icon.
  const cell = (r, s) => `<div style="width:${s}px;height:${s}px;flex-shrink:0">${masked(r)}</div>`;
  const row = (bg, fg) => `<div style="background:${bg};padding:24px;display:flex;gap:28px;align-items:center;color:${fg};font-size:14px">
     ${cell('50%',144)}${cell('30%',144)}${cell('16%',144)}${cell('50%',72)}${cell('50%',48)}${cell('50%',36)}${cell('50%',24)}
     <div style="width:144px;height:144px;border-radius:50%;overflow:hidden;position:relative;background:#cfe3ff;flex-shrink:0"><div class="themed" style="position:absolute;left:-25%;top:-25%;width:150%;height:150%">${mono}</div></div>
     <div>circle · squircle · rounded square · 72/48/36/24 px · themed</div></div>`;
  await shot(1300, 384, row('#EEF1F5', '#333') + row('#111317', '#ccc'), 'store/icon-preview.png');
  await b.close();
})();
