import sys, os
from PIL import Image, ImageDraw, ImageFont
sys.path.insert(0, os.path.dirname(__file__))
import art

def hexc(h, a=255):
    h = h.lstrip('#'); return (int(h[0:2],16), int(h[2:4],16), int(h[4:6],16), a)

# ---------------- VectorDrawable ----------------
def f(v): return ('%.2f' % v).rstrip('0').rstrip('.')
def rrect_path(x0,y0,x1,y1,r):
    return (f"M{f(x0+r)},{f(y0)}H{f(x1-r)}A{f(r)},{f(r)} 0,0 1,{f(x1)},{f(y0+r)}V{f(y1-r)}"
            f"A{f(r)},{f(r)} 0,0 1,{f(x1-r)},{f(y1)}H{f(x0+r)}A{f(r)},{f(r)} 0,0 1,{f(x0)},{f(y1-r)}"
            f"V{f(y0+r)}A{f(r)},{f(r)} 0,0 1,{f(x0+r)},{f(y0)}Z")
import math
def circle_path(x,y,r):
    return f"M{f(x-r)},{f(y)}A{f(r)},{f(r)} 0,1 1,{f(x+r)},{f(y)}A{f(r)},{f(r)} 0,1 1,{f(x-r)},{f(y)}Z"
def arc_pts(x,y,r,a0,a1):
    p = lambda a: (x + r*math.cos(math.radians(a)), y + r*math.sin(math.radians(a)))
    return p(a0), p(a1)
def arc_path(x,y,r,a0,a1):
    (sx,sy),(ex,ey) = arc_pts(x,y,r,a0,a1)
    large = 1 if (a1-a0) > 180 else 0
    return f"M{f(sx)},{f(sy)}A{f(r)},{f(r)} 0,{large} 1,{f(ex)},{f(ey)}"
def poly_path(pts):
    return "M" + "L".join(f"{f(x)},{f(y)}" for x,y in pts) + "Z"
def fill_path(s):
    if s[0]=='rrect': return rrect_path(*s[1:6])
    if s[0]=='poly': return poly_path(s[1])
    if s[0]=='circle': return circle_path(*s[1:4])
    if s[0]=='rect': x0,y0,x1,y1 = s[1:5]; return f"M{f(x0)},{f(y0)}H{f(x1)}V{f(y1)}H{f(x0)}Z"
    raise ValueError(s[0])
def shape_xml(s, color=None):
    k = s[0]
    if k == 'rect':
        _,x0,y0,x1,y1,c = s; return f'    <path android:fillColor="{color or c}" android:pathData="M{f(x0)},{f(y0)}H{f(x1)}V{f(y1)}H{f(x0)}Z"/>'
    if k == 'rrect':
        _,x0,y0,x1,y1,r,c = s; return f'    <path android:fillColor="{color or c}" android:pathData="{rrect_path(x0,y0,x1,y1,r)}"/>'
    if k == 'poly':
        _,pts,c = s; d = "M" + "L".join(f"{f(x)},{f(y)}" for x,y in pts) + "Z"
        return f'    <path android:fillColor="{color or c}" android:pathData="{d}"/>'
    if k == 'circle':
        _,x,y,r,c = s
        return f'    <path android:fillColor="{color or c}" android:pathData="{circle_path(x,y,r)}"/>'
    if k == 'arc':
        _,x,y,r,a0,a1,w,c = s
        return (f'    <path android:strokeColor="{color or c}" android:strokeWidth="{f(w)}" android:strokeLineCap="round" '
                f'android:pathData="{arc_path(x,y,r,a0,a1)}"/>')
    if k == 'line':
        _,x0,y0,x1,y1,w,c = s
        return (f'    <path android:strokeColor="{color or c}" android:strokeWidth="{f(w)}" android:strokeLineCap="round" '
                f'android:pathData="M{f(x0)},{f(y0)}L{f(x1)},{f(y1)}"/>')
def vector(shapes, size_dp=108, color=None, extra=""):
    body = "\n".join(shape_xml(s, color) for s in shapes)
    return (f'<?xml version="1.0" encoding="utf-8"?>\n<!-- Generated from tools/icon/art.py. Original artwork for HaulPilot. -->\n'
            f'<vector xmlns:android="http://schemas.android.com/apk/res/android"\n    android:width="{size_dp}dp"\n    android:height="{size_dp}dp"\n'
            f'    android:viewportWidth="108"\n    android:viewportHeight="108">\n{body}\n{extra}</vector>\n')
def mono_vector(size_dp=108):
    col = "#FFFFFFFF"
    hole_ids = {h for hs in art.MONO_HOLES.values() for h in hs}
    parts = []
    for idx, s in enumerate(art.FOREGROUND):
        if idx in art.MONO_DROP or idx in hole_ids:
            continue
        if idx in art.MONO_HOLES:
            d = fill_path(s) + "".join(fill_path(art.FOREGROUND[h]) for h in art.MONO_HOLES[idx])
            parts.append(f'    <path android:fillColor="{col}" android:fillType="evenOdd" android:pathData="{d}"/>')
        else:
            parts.append(shape_xml(s, col))
    return (f'<?xml version="1.0" encoding="utf-8"?>\n<!-- Generated from tools/icon/art.py. One-colour version (themed icon / notification). -->\n'
            f'<vector xmlns:android="http://schemas.android.com/apk/res/android"\n    android:width="{size_dp}dp"\n    android:height="{size_dp}dp"\n'
            f'    android:viewportWidth="108"\n    android:viewportHeight="108">\n' + "\n".join(parts) + "\n</vector>\n")

# ---------------- PIL renderer (same geometry) ----------------
def render(shapes, px, ss=4, bg=None, img=None, offset=(0,0), scale=None):
    S = px*ss; k = (scale or px)/108*ss
    im = img or Image.new('RGBA', (S,S), bg or (0,0,0,0))
    d = ImageDraw.Draw(im)
    ox, oy = offset[0]*ss, offset[1]*ss
    for s in shapes:
        t = s[0]
        if t == 'rect':
            _,x0,y0,x1,y1,c = s; d.rectangle([ox+x0*k,oy+y0*k,ox+x1*k,oy+y1*k], fill=hexc(c))
        elif t == 'rrect':
            _,x0,y0,x1,y1,r,c = s; d.rounded_rectangle([ox+x0*k,oy+y0*k,ox+x1*k,oy+y1*k], radius=r*k, fill=hexc(c))
        elif t == 'poly':
            _,pts,c = s; d.polygon([(ox+x*k,oy+y*k) for x,y in pts], fill=hexc(c))
        elif t == 'circle':
            _,x,y,r,c = s; d.ellipse([ox+(x-r)*k,oy+(y-r)*k,ox+(x+r)*k,oy+(y+r)*k], fill=hexc(c))
        elif t == 'arc':
            _,x,y,r,a0,a1,w,c = s; W=w*k
            d.arc([ox+(x-r)*k,oy+(y-r)*k,ox+(x+r)*k,oy+(y+r)*k], a0, a1, fill=hexc(c), width=int(round(W)))
            for (px_,py_) in arc_pts(x,y,r,a0,a1):
                d.ellipse([ox+px_*k-W/2+0.0,oy+py_*k-W/2,ox+px_*k+W/2,oy+py_*k+W/2], fill=hexc(c))
        elif t == 'line':
            _,x0,y0,x1,y1,w,c = s; W=w*k
            d.line([ox+x0*k,oy+y0*k,ox+x1*k,oy+y1*k], fill=hexc(c), width=int(round(W)))
            for x,y in ((x0,y0),(x1,y1)):
                d.ellipse([ox+x*k-W/2,oy+y*k-W/2,ox+x*k+W/2,oy+y*k+W/2], fill=hexc(c))
    return im

def icon_png(px, mask=None):
    ss=4; S=px*ss
    im = render(art.BACKGROUND, px, ss)
    im = render(art.FOREGROUND, px, ss, img=im)
    if mask:
        m = Image.new('L', (S,S), 0); md = ImageDraw.Draw(m)
        if mask == 'circle': md.ellipse([0,0,S,S], fill=255)
        elif mask == 'squircle': md.rounded_rectangle([0,0,S,S], radius=S*0.3, fill=255)
        elif mask == 'square': md.rounded_rectangle([0,0,S,S], radius=S*0.12, fill=255)
        # adaptive icons show the inner 72/108 of the layers
        im = im.crop((int(S*18/108), int(S*18/108), int(S*90/108), int(S*90/108))).resize((S,S), Image.LANCZOS)
        out = Image.new('RGBA', (S,S), (0,0,0,0)); out.paste(im, (0,0), m); im = out
    return im.resize((px,px), Image.LANCZOS)

if __name__ == '__main__':
    out = sys.argv[1]
    os.makedirs(out, exist_ok=True)
    open(f'{out}/ic_launcher_background.xml','w').write(vector(art.BACKGROUND))
    open(f'{out}/ic_launcher_foreground.xml','w').write(vector(art.FOREGROUND))
    open(f'{out}/ic_launcher_monochrome.xml','w').write(mono_vector())
    open(f'{out}/ic_stat_truck.xml','w').write(mono_vector(24))
    print('vectors written')
