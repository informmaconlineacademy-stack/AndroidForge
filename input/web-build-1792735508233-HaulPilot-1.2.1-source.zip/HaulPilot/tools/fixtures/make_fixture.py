#!/usr/bin/env python3
"""Turns a phone screenshot into a detector fixture: crops the game picture and scales it to 480 px wide.

Usage: make_fixture.py SCREENSHOT x0,y0,x1,y1 OUT.png
  x0,y0,x1,y1  pixel box of the game picture inside the screenshot (use 0,0,W,H for a plain in-game screenshot)

Scaling uses box (area) averaging, like the app's capture downscale. Needs Pillow (pip install pillow).

The two fixtures in app/src/test/resources/fixtures/toe3 were made from the user's screenshots of HaulPilot itself
(1166 x 2576 portrait screenshots showing the captured game picture):
  toe3_v1_editor.png   <- HaulPilot 1.0 placement editor screenshot, box 0,753,1166,1281
  toe3_v09_review.png  <- HaulPilot 0.9 "Check the result" screenshot, box 101,1838,1065,2254 (bottom hidden by the nav bar)
"""
import sys
from PIL import Image


def main(argv):
    if len(argv) != 4:
        print(__doc__)
        return 2
    src, box, out = argv[1], argv[2], argv[3]
    x0, y0, x1, y1 = (int(v) for v in box.split(","))
    im = Image.open(src).convert("RGB").crop((x0, y0, x1, y1))
    w = 480
    h = round(im.height * w / im.width)
    im.resize((w, h), Image.BOX).save(out)
    print(f"{out}: {w}x{h} from {src} box {x0},{y0},{x1},{y1}")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
