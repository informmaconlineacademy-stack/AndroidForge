#!/usr/bin/env python3
"""Regenerates .github/one-file-build/haulpilot-build.yml: one GitHub Actions workflow file that carries the whole project
(xz-compressed tar, base64) and builds the debug APK from it. Run after every change:

    python3 tools/make-one-file-workflow.py

The steps outside the embedded payload are kept from the existing file; only the payload and its SHA-256 are replaced.
Excluded from the payload: build outputs, Git data, local signing files, the one-file workflow itself, the offline
type-check API files (not needed to build) and the real-screenshot test pictures (their tests skip without them)."""
import base64, hashlib, io, lzma, os, pathlib, re, sys, tarfile

ROOT = pathlib.Path(__file__).resolve().parent.parent
OUT = ROOT / ".github/one-file-build/haulpilot-build.yml"
EXCLUDE_DIRS = {".git", ".gradle", "build", ".idea", ".kotlin", "captures"}
# The real-screenshot fixtures (~350 KB of PNG) would double the workflow file; their tests skip without them. The normal
# repository build (.github/workflows/build.yml) has and runs them.
EXCLUDE_PATHS = {".github/one-file-build", "tools/typecheck/api", "local.properties", "keystore.properties", "project.zip",
                 "app/src/test/resources/fixtures"}


def included(rel: str) -> bool:
    parts = rel.split("/")
    if any(p in EXCLUDE_DIRS for p in parts):
        return False
    if any(rel == e or rel.startswith(e + "/") for e in EXCLUDE_PATHS):
        return False
    return not (rel.endswith(".jks") or rel.endswith(".keystore"))


def payload() -> bytes:
    files = []
    for dirpath, dirnames, filenames in os.walk(ROOT):
        dirnames.sort()
        for f in sorted(filenames):
            p = pathlib.Path(dirpath) / f
            rel = p.relative_to(ROOT).as_posix()
            if included(rel):
                files.append((rel, p))
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w", format=tarfile.GNU_FORMAT) as tar:
        for rel, p in sorted(files):
            info = tarfile.TarInfo(rel)
            data = p.read_bytes()
            info.size = len(data)
            info.mtime = 1_760_000_000  # fixed, so the payload only changes when a file does
            info.mode = 0o755 if os.access(p, os.X_OK) else 0o644
            tar.addfile(info, io.BytesIO(data))
    return lzma.compress(buf.getvalue(), preset=9 | lzma.PRESET_EXTREME), len(files)


def main() -> None:
    old = OUT.read_text()
    head, rest = old.split("base64 -d > payload.tar.xz <<'PAYLOAD'\n", 1)
    _, tail = re.split(r"\n\s*PAYLOAD\n", rest, maxsplit=1)
    data, count = payload()
    digest = hashlib.sha256(data).hexdigest()
    b64 = base64.b64encode(data).decode()
    lines = [" " * 10 + b64[i:i + 100] for i in range(0, len(b64), 100)]
    tail = re.sub(r'echo "[0-9a-f]{64}  payload.tar.xz"', f'echo "{digest}  payload.tar.xz"', tail, count=1)
    OUT.write_text(head + "base64 -d > payload.tar.xz <<'PAYLOAD'\n" + "\n".join(lines) + "\n          PAYLOAD\n" + tail)
    print(f"{OUT.relative_to(ROOT)}: {count} files, {len(data)} bytes compressed, sha256 {digest}")


if __name__ == "__main__":
    sys.exit(main())
