#!/usr/bin/env bash
# Creates YOUR OWN release signing key and the git-ignored keystore.properties that app/build.gradle.kts reads.
# The private key is generated on your machine and must never be committed or shared.
# Back it up: if you lose it you cannot publish updates that install over earlier versions.
set -euo pipefail
cd "$(dirname "$0")/.."
[ -e release.keystore ] && { echo "release.keystore already exists; refusing to overwrite."; exit 1; }
read -rp "Key alias [haulpilot]: " ALIAS; ALIAS="${ALIAS:-haulpilot}"
read -rsp "Keystore/key password (min 6 chars): " PASS; echo
read -rp "Your name or organisation (certificate CN): " CN
keytool -genkeypair -v -keystore release.keystore -alias "$ALIAS" -keyalg RSA -keysize 4096 -validity 10000 \
  -storepass "$PASS" -keypass "$PASS" -dname "CN=$CN"
cat > keystore.properties <<P
storeFile=release.keystore
storePassword=$PASS
keyAlias=$ALIAS
keyPassword=$PASS
P
chmod 600 keystore.properties release.keystore
echo "Created release.keystore and keystore.properties (both git-ignored). Build with: ./gradlew assembleRelease"
