package dev.toe3autopilot

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import dev.toe3autopilot.app.data.AndroidImageCodec
import dev.toe3autopilot.app.data.SettingsStore
import dev.toe3autopilot.app.data.SetupDraftStore
import dev.toe3autopilot.core.AutomationSettings
import dev.toe3autopilot.core.WallClock
import dev.toe3autopilot.core.calibration.CalibRole
import dev.toe3autopilot.core.calibration.LayoutSignature
import dev.toe3autopilot.core.profile.GameProfile
import dev.toe3autopilot.core.profile.ProfileLoad
import dev.toe3autopilot.core.profile.ProfileRepository
import dev.toe3autopilot.core.setup.DraftCodec
import dev.toe3autopilot.core.setup.DraftEdits
import dev.toe3autopilot.core.setup.SetupDraft
import dev.toe3autopilot.core.vision.Frame
import dev.toe3autopilot.core.vision.GrayImage
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File

/**
 * On-device tests for the persistence layer with the real Android image codec (PNG through Bitmap). They need an
 * emulator or a device and were NOT run in the authoring environment (no Android SDK there). CI runs them only when the
 * "device tests" option of the build workflow is chosen.
 */
@RunWith(AndroidJUnit4::class)
class StoresInstrumentedTest {
    private val ctx = InstrumentationRegistry.getInstrumentation().targetContext

    @Test
    fun settingsRoundTrip() {
        val store = SettingsStore(ctx)
        val s = AutomationSettings(
            speedLevel = 0.3f, approachSpeed = 0.2f, sensitivity = 1.5f, tryParking = false, assistedMode = true,
            recognitionTimeoutSec = 20, frozenPictureSec = 6, foregroundGraceSec = 3, unknownScreenSec = 9, roadLostSec = 4,
        )
        store.save(s)
        assertEquals(s, SettingsStore(ctx).load())
    }

    @Test
    fun profileTemplatesSurviveThePngCodec() {
        val dir = File(ctx.cacheDir, "repo-test").also { it.deleteRecursively() }
        val repo = ProfileRepository(dir, AndroidImageCodec, WallClock)
        val id = repo.create("Device test", "com.example.game")
        val px = IntArray(16 * 8) { i -> if (i % 7 == 0) 255 else 40 }
        val img = GrayImage(16, 8, px)
        val p = GameProfile.EMPTY.copy(name = "Device test", gamePackage = "com.example.game", referenceWidth = 480)
        assertTrue(repo.save(id, p, mapOf("hud_marker" to img)).ok)
        val back = repo.storeFor(id).gray("hud_marker")
        assertNotNull(back)
        assertEquals(16, back!!.width)
        assertEquals(img.px.toList(), back.px.toList())
        assertTrue(repo.load(id) is ProfileLoad.Ok)
        dir.deleteRecursively()
    }

    @Test
    fun unfinishedSetupSurvivesARestart() {
        val store = SetupDraftStore(ctx)
        val frame = Frame(32, 16, IntArray(32 * 16) { i -> 0xFF000000.toInt() or (i * 997 and 0xFFFFFF) }, 1L)
        var d = SetupDraft.EMPTY.copy(layout = LayoutSignature(32, 16), drivingConfirmed = true)
        d = DraftEdits.place(d, CalibRole.ACCELERATOR, 0.8f, 0.7f)
        store.write(DraftCodec.format(d, null, true), frame)
        val text = store.readText()
        assertNotNull(text)
        val parsed = DraftCodec.parse(text!!)
        assertEquals(d.controls[CalibRole.ACCELERATOR]?.x, parsed.draft.controls[CalibRole.ACCELERATOR]?.x)
        val pic = store.readPicture()
        assertNotNull(pic)
        assertEquals(frame.argb.toList(), pic!!.argb.toList())
        store.clear()
    }
}
