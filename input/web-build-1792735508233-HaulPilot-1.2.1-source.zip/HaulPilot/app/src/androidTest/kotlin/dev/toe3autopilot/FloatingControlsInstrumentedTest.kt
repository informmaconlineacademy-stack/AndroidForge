package dev.toe3autopilot

import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import dev.toe3autopilot.app.data.AppOptions
import dev.toe3autopilot.app.data.OptionsStore
import dev.toe3autopilot.app.input.DockStore
import dev.toe3autopilot.core.overlay.DockPosition
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

/**
 * On-device persistence checks for the floating button position and the accessibility disclosure consent.
 * Need an emulator or device; NOT run in the authoring environment.
 */
@RunWith(AndroidJUnit4::class)
class FloatingControlsInstrumentedTest {
    private val ctx = InstrumentationRegistry.getInstrumentation().targetContext

    @Test
    fun dockPositionIsRemembered() {
        val store = DockStore(ctx)
        store.save(DockPosition(rightSide = false, yFraction = 0.72f))
        val back = DockStore(ctx).load()
        assertFalse(back.rightSide)
        assertEquals(0.72f, back.yFraction, 0.0001f)
    }

    @Test
    fun disclosureConsentIsRemembered() {
        val store = OptionsStore(ctx)
        store.save(AppOptions(accessibilityDisclosureAccepted = true))
        assertTrue(OptionsStore(ctx).load().accessibilityDisclosureAccepted)
        store.save(AppOptions(accessibilityDisclosureAccepted = false))
        assertFalse(OptionsStore(ctx).load().accessibilityDisclosureAccepted)
    }
}
