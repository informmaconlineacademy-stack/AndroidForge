# Real Truckers of Europe 3 pictures (regression fixtures)

Each `NAME.png` is a picture of the game; `NAME.expected.properties` is its hand-marked ground truth. `RealScreenshotTest`
runs Auto-Calibrate's detector on every pair and checks the result. A `NAME.png` WITHOUT an `.expected.properties` file is
analysed in "probe mode": no assertions, but an annotated picture and a text report are written to
`app/build/fixture-reports/` so you can see what the detector proposes.

## Adding your own screenshot

1. Take a normal Android screenshot while DRIVING in the game (power + volume down), in landscape, with the normal
   driving view: pedals and steering controls visible, no menu or pop-up. A full, uncropped screenshot is best.
2. Copy it here as `something.png` (PNG; JPEG is accepted too). Any size: it is scaled to 480 px on the long side, as the
   app does with live pictures.
3. Run `./gradlew :app:testDebugUnitTest --tests '*RealScreenshotTest*'` and look at `app/build/fixture-reports/`.
4. To make it a regression test, add `something.expected.properties` with the boxes (fractions of the picture,
   `x0,y0,x1,y1`) of the controls you can see:

```
required.accelerator=0.917,0.681,0.985,1.0
required.brake=0.817,0.787,0.906,1.0
required.steer_left=...
required.steer_right=...
# required.steer_wheel=... if your layout uses the wheel
optional.ROLE=...          # visible but faint: if proposed it must be here
absent=accelerator,brake   # controls that are NOT in this picture (any proposal is wrong)
exclude.NAME=...           # HaulPilot's own button / panels visible in the screenshot
distractor.NAME=...        # things that must never become a control (truck, gauges, other buttons)
```

Several pictures of one drive (`drive_001.png`, `drive_002.png`, … with one `drive.expected.properties`) are analysed
together, like live collection: that is the strong, many-picture evidence.

The two pictures here come from the user's phone screenshots of HaulPilot (0.9 "Check the result" and the 1.0
placement editor), so they are upscaled copies of the 480 px live capture with some HaulPilot UI drawn on top (marked as
`exclude`). They are single pictures: they test the weaker single-picture path. A screen recording of real driving,
imported as frames, is what the many-picture path needs next.
