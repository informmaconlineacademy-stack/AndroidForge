package dev.toe3autopilot.core

import dev.toe3autopilot.core.session.SessionHistoryCodec
import dev.toe3autopilot.core.session.SessionRecord
import dev.toe3autopilot.core.session.SessionRecorder
import dev.toe3autopilot.core.session.SessionSnapshot
import dev.toe3autopilot.core.session.SessionStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class SessionHistoryTest {
    private fun snap(s: SessionStatus, err: String? = null) = SessionSnapshot(status = s, task = s.label, lastError = err)

    @Test
    fun aDriveIsRecordedFromStartToItsEndAndAPauseContinuesIt() {
        val r = SessionRecorder()
        assertNull(r.onSnapshot(snap(SessionStatus.STARTING), 1_000, "Pixel"))
        assertNull(r.onSnapshot(snap(SessionStatus.RUNNING), 2_000, "Pixel"))
        assertNull(r.onSnapshot(snap(SessionStatus.PAUSED), 3_000, "Pixel"))
        assertNull(r.onSnapshot(snap(SessionStatus.STARTING), 4_000, "Pixel"))
        assertNull(r.onSnapshot(snap(SessionStatus.RUNNING), 5_000, "Pixel"))
        val rec = r.onSnapshot(snap(SessionStatus.EMERGENCY_STOPPED, "pressed"), 9_000, "Pixel")!!
        assertEquals(8_000, rec.durationMs)
        assertEquals("pressed", rec.reason)
        assertEquals("Pixel", rec.profile)
        assertNull("no record without a start", r.onSnapshot(snap(SessionStatus.IDLE), 10_000, "Pixel"))
    }

    @Test
    fun historyTextRoundTripsAndSkipsGarbage() {
        val recs = listOf(SessionRecord(1, 2, SessionStatus.FINISHED, "Parked\twith tab", "P1"))
        val text = SessionHistoryCodec.format(recs) + "garbage line\n1\t2\tNOPE\tx\ty\n"
        val back = SessionHistoryCodec.parse(text)
        assertEquals(1, back.size)
        assertEquals("Parked with tab", back[0].reason)
        assertEquals("P1", back[0].profile)
    }
}
