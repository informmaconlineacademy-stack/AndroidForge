package dev.toe3autopilot.core

import dev.toe3autopilot.core.calibration.CalibRole
import dev.toe3autopilot.core.calibration.ControlCandidateDetector
import dev.toe3autopilot.core.calibration.DetectionStatus
import dev.toe3autopilot.core.calibration.PictureEvidence
import dev.toe3autopilot.core.vision.Frame
import dev.toe3autopilot.core.vision.Roi
import java.awt.BasicStroke
import java.awt.Color
import java.awt.RenderingHints
import java.awt.image.BufferedImage
import java.io.File
import java.util.Properties
import javax.imageio.ImageIO
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Real pictures of the game for the detector: loading (any size, scaled to the app's 480 px processing size), their
 * hand-marked ground truth, running the detector exactly as Auto-Calibrate does, checking the result, and drawing an
 * annotated report. Used by RealScreenshotTest and by the FixtureProbe command-line tool.
 */
object RealScreenshots {
    const val LONG_SIDE = 480

    /**
     * Where the fixtures are: the system property `haulpilot.fixtures`, the environment variable `HAULPILOT_FIXTURES`,
     * the test resources on the classpath, or `app/src/test/resources/fixtures/toe3` below the working directory.
     */
    fun dir(): File? {
        val explicit = listOfNotNull(System.getProperty("haulpilot.fixtures"), System.getenv("HAULPILOT_FIXTURES")).map(::File)
        explicit.firstOrNull { it.isDirectory }?.let { return it }
        val res = RealScreenshots::class.java.getResource("/fixtures/toe3")
        if (res != null && res.protocol == "file") File(res.toURI()).takeIf { it.isDirectory }?.let { return it }
        return listOf("src/test/resources/fixtures/toe3", "app/src/test/resources/fixtures/toe3").map(::File).firstOrNull { it.isDirectory }
    }

    /** One case: a single picture, or a numbered sequence (`name_001.png`, `name_002.png`, …) analysed together. */
    data class Case(val name: String, val files: List<File>, val spec: Spec?)

    data class Spec(
        val description: String,
        val required: Map<CalibRole, Roi>,
        val optional: Map<CalibRole, Roi>,
        val absent: Set<CalibRole>,
        val exclusions: Map<String, Roi>,
        val distractors: Map<String, Roi>,
    )

    fun cases(dir: File): List<Case> {
        val pics = dir.listFiles { f -> f.isFile && f.name.lowercase().let { it.endsWith(".png") || it.endsWith(".jpg") || it.endsWith(".jpeg") } }
            ?.sortedBy { it.name } ?: return emptyList()
        val seq = Regex("^(.*)_(\\d{3})\\.(png|jpe?g)$", RegexOption.IGNORE_CASE)
        val groups = LinkedHashMap<String, MutableList<File>>()
        for (f in pics) {
            val m = seq.matchEntire(f.name)
            val key = m?.groupValues?.get(1) ?: f.nameWithoutExtension
            groups.getOrPut(key) { ArrayList() } += f
        }
        return groups.map { (name, files) ->
            val p = File(dir, "$name.expected.properties")
            Case(name, files, if (p.isFile) parse(p) else null)
        }
    }

    fun parse(file: File): Spec {
        val p = Properties()
        file.reader().use { p.load(it) }
        fun roi(v: String): Roi {
            val n = v.split(",").map { it.trim().toFloat() }
            require(n.size == 4 && n[2] > n[0] && n[3] > n[1]) { "${file.name}: bad box '$v' (x0,y0,x1,y1 as fractions)" }
            return Roi(n[0], n[1], n[2], n[3])
        }
        fun role(k: String): CalibRole = when (k.lowercase()) {
            "accelerator" -> CalibRole.ACCELERATOR
            "brake" -> CalibRole.BRAKE
            "steer_left" -> CalibRole.STEER_LEFT
            "steer_right" -> CalibRole.STEER_RIGHT
            "steer_wheel", "wheel" -> CalibRole.STEER_WHEEL
            "reverse", "gear_reverse" -> CalibRole.GEAR_REVERSE
            else -> throw IllegalArgumentException("${file.name}: unknown control '$k'")
        }
        val req = LinkedHashMap<CalibRole, Roi>()
        val opt = LinkedHashMap<CalibRole, Roi>()
        val excl = LinkedHashMap<String, Roi>()
        val dist = LinkedHashMap<String, Roi>()
        for (k in p.stringPropertyNames().sorted()) {
            val v = p.getProperty(k)
            when {
                k.startsWith("required.") -> req[role(k.removePrefix("required."))] = roi(v)
                k.startsWith("optional.") -> opt[role(k.removePrefix("optional."))] = roi(v)
                k.startsWith("exclude.") -> excl[k.removePrefix("exclude.")] = roi(v)
                k.startsWith("distractor.") -> dist[k.removePrefix("distractor.")] = roi(v)
            }
        }
        val absent = p.getProperty("absent")?.split(",")?.map { it.trim() }?.filter { it.isNotEmpty() }?.map(::role)?.toSet() ?: emptySet()
        return Spec(p.getProperty("description") ?: file.name, req, opt, absent, excl, dist)
    }

    /** Reads a picture and scales it like the app's capture: [LONG_SIDE] px on the long side, aspect ratio kept. */
    fun load(file: File, timestampMs: Long = 0L): Frame {
        val src = ImageIO.read(file) ?: throw IllegalArgumentException("${file.name} is not a readable picture")
        val long = max(src.width, src.height)
        val img = if (long > LONG_SIDE * 1.05f) {
            val k = LONG_SIDE.toFloat() / long
            val w = max(1, (src.width * k).roundToInt())
            val h = max(1, (src.height * k).roundToInt())
            // Area averaging, like a GPU downscale of the capture surface: no aliasing of fine HUD lines.
            val scaled = src.getScaledInstance(w, h, java.awt.Image.SCALE_AREA_AVERAGING)
            val out = BufferedImage(w, h, BufferedImage.TYPE_INT_RGB)
            out.createGraphics().apply { drawImage(scaled, 0, 0, null); dispose() }
            out
        } else {
            src
        }
        val px = IntArray(img.width * img.height)
        img.getRGB(0, 0, img.width, img.height, px, 0, img.width)
        for (i in px.indices) px[i] = px[i] or (0xFF shl 24).toInt()
        return Frame(img.width, img.height, px, timestampMs)
    }

    /** Runs the detector as Auto-Calibrate does (same evidence, same exclusion of HaulPilot's own UI). */
    fun analyse(frames: List<Frame>, exclusions: List<Roi>): ControlCandidateDetector.Result {
        val ev = PictureEvidence.build(frames, frames.last(), exclusions)
        return ControlCandidateDetector.detect(ev) ?: error("analysis cancelled")
    }

    /** Everything the result gets wrong against [spec]; empty = passes. Misses and wrong proposals together. */
    fun check(r: ControlCandidateDetector.Result, spec: Spec): List<String> = verdict(r, spec).all

    /**
     * [missed]: a control that should have been found was not (the person then taps it; honest but unhelpful).
     * [wrong]: something was proposed where it must not be (a marker on the wrong thing).
     */
    data class Verdict(val missed: List<String>, val wrong: List<String>) {
        val all: List<String> get() = missed + wrong
    }

    fun verdict(r: ControlCandidateDetector.Result, spec: Spec): Verdict {
        val missed = ArrayList<String>()
        val out = ArrayList<String>()
        val proposed = r.detections.values.filter { it.status == DetectionStatus.NEEDS_CONFIRMATION }
        fun inside(b: Roi, x: Float, y: Float, tol: Float = 0.006f) = x >= b.left - tol && x <= b.right + tol && y >= b.top - tol && y <= b.bottom + tol
        for ((role, truth) in spec.required) {
            val d = r.detections[role]
            if (d == null || d.status != DetectionStatus.NEEDS_CONFIRMATION) {
                missed += "${role.label}: not found (${d?.evidence?.firstOrNull() ?: "no result"})"
                continue
            }
            if (!inside(truth, d.x, d.y)) out += "${role.label}: proposed at (${f(d.x)}, ${f(d.y)}), outside the marked box ${fmt(truth)}"
            // The outline must mark (a part of) the control, not reach into something else. Hand-marked boxes on a blurry
            // picture are approximate, so a little tolerance is allowed; covering the whole control is not required (the
            // outline of a pedal's grip area is still the pedal).
            val b = d.box
            val within = if (b == null) 0f else insideShare(b, truth, BOX_TOLERANCE)
            if (within < MIN_WITHIN) out += "${role.label}: only ${(within * 100).roundToInt()}% of its outline ${b?.let(::fmt)} lies on the marked control"
            val cover = if (b == null) 0f else insideShare(truth, b)
            if (cover < MIN_COVER) out += "${role.label}: its outline covers only ${(cover * 100).roundToInt()}% of the marked control"
        }
        for ((role, truth) in spec.optional) {
            val d = r.detections[role] ?: continue
            if (d.status == DetectionStatus.NEEDS_CONFIRMATION && !inside(truth, d.x, d.y)) {
                out += "${role.label}: proposed at (${f(d.x)}, ${f(d.y)}), outside where it really is ${fmt(truth)}"
            }
        }
        for (role in spec.absent) {
            val d = r.detections[role]
            if (d != null && d.status == DetectionStatus.NEEDS_CONFIRMATION) out += "${role.label}: proposed at (${f(d.x)}, ${f(d.y)}) although it is not in this picture"
        }
        for (d in proposed) {
            for ((name, b) in spec.distractors) if (inside(b, d.x, d.y, 0f)) out += "${d.role.label}: proposed on '$name', which is not a control"
            for ((name, b) in spec.exclusions) if (inside(b, d.x, d.y, 0f)) out += "${d.role.label}: proposed on HaulPilot's own UI ('$name')"
        }
        r.marker?.let { m ->
            val cx = (m.left + m.right) / 2f
            val cy = (m.top + m.bottom) / 2f
            for ((name, b) in spec.exclusions) if (inside(b, cx, cy, 0f)) out += "The driving-screen marker was put on HaulPilot's own UI ('$name')"
        }
        val l = r.detections[CalibRole.STEER_LEFT]
        val rr = r.detections[CalibRole.STEER_RIGHT]
        if (l != null && rr != null && l.status == DetectionStatus.NEEDS_CONFIRMATION && rr.status == DetectionStatus.NEEDS_CONFIRMATION && l.x >= rr.x) {
            out += "Steer left is proposed to the right of steer right"
        }
        return Verdict(missed, out)
    }

    /** Share of a proposed outline that must lie on the marked control (grown by [BOX_TOLERANCE]). */
    const val MIN_WITHIN = 0.85f

    /** Share of the marked control a proposed outline must cover at least (a pedal's grip area is enough; a dot is not). */
    const val MIN_COVER = 0.20f

    /** Hand-marked boxes may be off by about a pixel or two at 480 px. */
    const val BOX_TOLERANCE = 0.008f

    /** Share of [a]'s area that lies inside [b] grown by [grow] on every side. */
    fun insideShare(a: Roi, b: Roi, grow: Float = 0f): Float {
        val l = max(a.left, b.left - grow)
        val t = max(a.top, b.top - grow)
        val r = kotlin.math.min(a.right, b.right + grow)
        val bt = kotlin.math.min(a.bottom, b.bottom + grow)
        val area = (a.right - a.left) * (a.bottom - a.top)
        if (r <= l || bt <= t || area <= 0f) return 0f
        return (r - l) * (bt - t) / area
    }

    /** Writes the picture, 3x enlarged, with the truth (thin white), HaulPilot's UI (magenta) and every proposal. */
    fun annotate(frame: Frame, r: ControlCandidateDetector.Result, spec: Spec?, out: File) {
        val sc = 3
        val img = BufferedImage(frame.width * sc, frame.height * sc, BufferedImage.TYPE_INT_RGB)
        val g = img.createGraphics()
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON)
        val src = BufferedImage(frame.width, frame.height, BufferedImage.TYPE_INT_RGB)
        src.setRGB(0, 0, frame.width, frame.height, frame.argb, 0, frame.width)
        g.drawImage(src, 0, 0, frame.width * sc, frame.height * sc, null)
        fun rect(b: Roi, c: Color, w: Float, label: String?) {
            g.color = c
            g.stroke = BasicStroke(w)
            val x = (b.left * frame.width * sc).toInt()
            val y = (b.top * frame.height * sc).toInt()
            g.drawRect(x, y, ((b.right - b.left) * frame.width * sc).toInt(), ((b.bottom - b.top) * frame.height * sc).toInt())
            if (label != null) g.drawString(label, x + 2, max(12, y - 3))
        }
        spec?.exclusions?.forEach { (n, b) -> rect(b, Color.MAGENTA, 2f, "HaulPilot UI: $n") }
        spec?.required?.forEach { (role, b) -> rect(b, Color.WHITE, 1f, "truth ${role.name.lowercase()}") }
        spec?.optional?.forEach { (role, b) -> rect(b, Color.LIGHT_GRAY, 1f, "faint ${role.name.lowercase()}") }
        for ((role, d) in r.detections) {
            if (d.status != DetectionStatus.NEEDS_CONFIRMATION) continue
            val c = when (role) {
                CalibRole.ACCELERATOR -> Color.GREEN
                CalibRole.BRAKE -> Color.RED
                CalibRole.STEER_WHEEL -> Color.ORANGE
                else -> Color.CYAN
            }
            d.box?.let { rect(it, c, 3f, "${role.name} ${(d.confidence * 100).roundToInt()}%") }
            g.color = c
            g.fillOval((d.x * frame.width * sc).toInt() - 5, (d.y * frame.height * sc).toInt() - 5, 10, 10)
        }
        r.marker?.let { rect(it, Color(80, 160, 255), 2f, "screen marker") }
        r.minimap?.let { rect(it.box, Color.YELLOW, 2f, "minimap?") }
        g.dispose()
        out.parentFile?.mkdirs()
        ImageIO.write(img, "png", out)
    }

    fun report(case: Case, frames: List<Frame>, r: ControlCandidateDetector.Result, problems: List<String>?): String = buildString {
        appendLine("== ${case.name} (${frames.size} picture(s), ${frames.first().width}x${frames.first().height})")
        case.spec?.let { appendLine("   ${it.description}") }
        r.notes.forEach { appendLine("   note: $it") }
        for ((role, d) in r.detections) {
            if (d.status == DetectionStatus.NEEDS_CONFIRMATION) {
                appendLine("   ${role.name}: FOUND at (${f(d.x)}, ${f(d.y)}) box ${d.box?.let(::fmt)} evidence ${(d.confidence * 100).roundToInt()}%")
                d.evidence.take(4).forEach { appendLine("       - $it") }
                d.alternatives.forEach { appendLine("       alternative (${f(it.x)}, ${f(it.y)}) ${(it.score * 100).roundToInt()}%: ${it.note}") }
            } else {
                appendLine("   ${role.name}: ${d.status} (${d.evidence.firstOrNull()})")
            }
        }
        appendLine("   driving-screen marker: ${r.marker?.let(::fmt) ?: "none"}; minimap: ${r.minimap?.box?.let(::fmt) ?: "none"}")
        when {
            problems == null -> appendLine("   (no .expected.properties: probe only, nothing checked)")
            problems.isEmpty() -> appendLine("   RESULT: matches the hand-marked ground truth")
            else -> problems.forEach { appendLine("   PROBLEM: $it") }
        }
    }

    private fun f(v: Float) = String.format(java.util.Locale.US, "%.3f", v)

    fun fmt(r: Roi) = "${f(r.left)},${f(r.top)},${f(r.right)},${f(r.bottom)}"
}
