package dev.toe3autopilot.core

import dev.toe3autopilot.core.overlay.BoundedPlacement
import dev.toe3autopilot.core.overlay.DockPosition
import dev.toe3autopilot.core.overlay.DragTracker
import dev.toe3autopilot.core.overlay.OverlayOwnerSlot
import dev.toe3autopilot.core.overlay.RefreshCoalescer
import dev.toe3autopilot.core.overlay.SingleWindow
import dev.toe3autopilot.core.overlay.TapGuard
import dev.toe3autopilot.core.overlay.UsableBounds
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test

/** Synthetic tests of the floating-button logic. The WindowManager, rendering and real touches need a phone. */
class OverlayGeometryTest {
    // 1080x2400 display with a 90 px status bar and a 130 px navigation bar
    private val b = UsableBounds(0, 90, 1080, 2270)
    private val size = 140
    private val margin = 24

    private fun tracker() = DragTracker(TapGuard(16f))

    @Test
    fun aTapThatWobblesWithinTheSlopIsATapAndNeverMovesTheButton() {
        val t = tracker()
        t.down(500f, 500f, 900, 400)
        assertNull(t.move(508f, 506f, size, b))
        assertNull(t.move(495f, 492f, size, b))
        assertEquals(DragTracker.End.TAP, t.up())
    }

    @Test
    fun onceItHasDraggedPastTheSlopItsEndIsNeverATap() {
        val t = tracker()
        t.down(500f, 500f, 900, 400)
        val s = t.move(540f, 500f, size, b)!!
        assertTrue(s.started)
        // coming back to the start does not turn it back into a tap
        assertEquals(900, t.move(500f, 500f, size, b)!!.x)
        assertEquals(DragTracker.End.DRAG, t.up())
    }

    @Test
    fun theDragFollowsTheFingerExactlyAndDoesNotDriftOverManyEvents() {
        val t = tracker()
        t.down(500f, 500f, 400, 400)
        var last: DragTracker.Step? = null
        // 400 tiny events that end 100 px right and 60 px down from the touch-down
        for (i in 1..400) last = t.move(500f + i * 0.25f, 500f + i * 0.15f, size, b) ?: last
        assertEquals(500, last!!.x)
        assertEquals(460, last.y)
    }

    @Test
    fun theButtonStaysInsideTheUsableAreaOnEveryEdge() {
        val t = tracker()
        t.down(500f, 500f, 400, 400)
        var s = t.move(-5000f, -5000f, size, b)!!
        assertEquals(0, s.x); assertEquals(b.top, s.y)
        s = t.move(9000f, 9000f, size, b)!!
        assertEquals(b.right - size, s.x); assertEquals(b.bottom - size, s.y)
    }

    @Test
    fun placementAndSnapRespectSystemBarsAndRoundTrip() {
        for (right in listOf(true, false)) for (f in listOf(0f, 0.3f, 1f)) {
            val (x, y) = BoundedPlacement.place(DockPosition(right, f), size, b, margin)
            assertTrue(x >= b.left && x + size <= b.right && y >= b.top && y + size <= b.bottom)
            val d = BoundedPlacement.snap(x, y, size, b, margin)
            assertEquals(right, d.rightSide)
            assertEquals(f, d.yFraction, 0.01f)
        }
        // a different screen (rotation): the remembered side and height fraction still land inside
        val land = UsableBounds(0, 0, 2270, 1080 - 0)
        val (x, y) = BoundedPlacement.place(DockPosition(true, 1f), size, land, margin)
        assertTrue(x + size <= land.right && y + size <= land.bottom)
    }

    @Test
    fun theExpandedPanelIsFullyOnScreenAndNarrowScreensShrinkIt() {
        val (x, y) = BoundedPlacement.panelAnchor(940, 2100, size, 800, 900, b, 24)
        assertTrue(x >= b.left && x + 800 <= b.right && y >= b.top && y + 900 <= b.bottom)
        val taller = BoundedPlacement.panelAnchor(940, 500, size, 800, 5000, b, 24)
        assertEquals(b.top, taller.second)
        assertEquals(500, BoundedPlacement.panelWidth(800, UsableBounds(0, 0, 548, 1000), 24))
        assertEquals(800, BoundedPlacement.panelWidth(800, b, 24))
    }

    // ---- one window, one owner, one refresh --------------------------------------------------------------------------

    private class Wm {
        val attached = ArrayList<Any>()
        var failNext = false
    }

    @Test
    fun repeatedShowsCreateExactlyOneWindowAndRemovalIsClean() {
        val wm = Wm()
        var created = 0
        val w = SingleWindow<Any>({ if (wm.failNext) { wm.failNext = false; error("denied") }; wm.attached += it }, { wm.attached -= it })
        repeat(50) { w.ensure { created++; Any() } }
        assertEquals(1, created)
        assertEquals(1, wm.attached.size)
        w.remove(); w.remove()
        assertEquals(0, wm.attached.size)
        assertFalse(w.isShown)
        // permission revoked: attaching fails, nothing is left behind and no view is considered shown
        wm.failNext = true
        assertNull(w.ensure { Any() })
        assertEquals(0, wm.attached.size)
        assertFalse(w.isShown)
        // and it recovers
        assertTrue(w.ensure { Any() } != null)
        assertEquals(1, wm.attached.size)
    }

    @Test
    fun aReconnectedServiceTakesOverAndThePreviousOneIsReleasedOnce() {
        val released = ArrayList<String>()
        val slot = OverlayOwnerSlot<String> { released += it }
        slot.claim("service-1")
        slot.claim("service-1")
        assertEquals(emptyList<String>(), released)
        slot.claim("service-2")
        assertEquals(listOf("service-1"), released)
        assertSame("service-2", slot.current)
        slot.drop("service-1") // a late teardown of the old one must not clear the new owner
        assertSame("service-2", slot.current)
        slot.drop("service-2")
        assertNull(slot.current)
    }

    @Test
    fun aBurstOfStateChangesIsOneRefreshAndACancelledOneNeverRuns() {
        val queue = ArrayList<() -> Unit>()
        var runs = 0
        val c = RefreshCoalescer({ queue += it }, { runs++ })
        repeat(30) { c.request() }
        assertEquals(1, queue.size)
        queue.removeAt(0)()
        assertEquals(1, runs)
        c.request()
        c.cancel()
        queue.removeAt(0)()
        assertEquals("cancelled refresh does nothing", 1, runs)
        c.request()
        assertEquals("a new request after cancel is queued again", 1, queue.size)
        queue.removeAt(0)()
        assertEquals(2, runs)
    }
}
