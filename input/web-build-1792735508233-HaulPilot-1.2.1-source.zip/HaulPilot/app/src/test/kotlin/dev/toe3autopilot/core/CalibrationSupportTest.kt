package dev.toe3autopilot.core

import dev.toe3autopilot.core.calibration.CalibRole
import dev.toe3autopilot.core.calibration.DetectionStatus
import dev.toe3autopilot.core.calibration.LayoutCheck
import dev.toe3autopilot.core.calibration.LayoutSignature
import dev.toe3autopilot.core.profile.GameProfile
import dev.toe3autopilot.core.profile.ProfileArchive
import dev.toe3autopilot.core.profile.ProfileCodec
import dev.toe3autopilot.core.profile.SteeringMode
import dev.toe3autopilot.core.vision.TemplateProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.math.abs


class LayoutCheckTest {
    /** A profile with the accelerator and brake placed on SynthHud's buttons, saved the way Smart Setup saves it. */
    private fun calibrated(): Pair<GameProfile, MapTemplateStore> {
        val scene = SynthHud()
        val picture = scene.frame(5, 5_000, moving = true)
        fun box(name: String): dev.toe3autopilot.core.vision.Roi {
            val (x, y) = scene.center(name)
            val r = scene.rings.first { it.name == name }.r + 2f
            return dev.toe3autopilot.core.vision.Roi((x * 320 - r) / 320, (y * 180 - r) / 180, (x * 320 + r) / 320, (y * 180 + r) / 180)
        }
        var d = dev.toe3autopilot.core.setup.SetupDraft(layout = LayoutSignature(320, 180))
        for ((role, name) in listOf(CalibRole.ACCELERATOR to "accel", CalibRole.BRAKE to "brake")) {
            val (x, y) = scene.center(name)
            d = dev.toe3autopilot.core.setup.DraftEdits.place(d, role, x, y, box(name))
        }
        val res = dev.toe3autopilot.core.setup.DraftApply.apply(null, d, picture, "t", "g", 0L)
        assertTrue(res.problem, res.ok)
        val store = MapTemplateStore(HashMap(TestProfiles.templateImages()))
        for ((n, img) in res.patches) store.map[n] = img
        return res.profile!! to store
    }

    private fun verify(p: GameProfile, store: MapTemplateStore, scene: SynthHud, skip: Set<CalibRole> = emptySet()): LayoutCheck.Verification {
        val f = scene.frame(99, 99_000, moving = true)
        return LayoutCheck.verifyControls(p, f.toGray(), TemplateProvider(store, p.referenceWidth), f.width, skip)
    }

    @Test
    fun aspectRatioChangesAreDetectedAndSameAspectIsAccepted() {
        val p = TestProfiles.full().copy(extras = mapOf(LayoutCheck.HEIGHT_KEY to "180"))
        assertNull(LayoutCheck.layoutProblem(p, 320, 180))
        assertNull("same aspect at another resolution is fine", LayoutCheck.layoutProblem(p, 1280, 720))
        assertNotNull("rotation", LayoutCheck.layoutProblem(p, 180, 320))
        assertNotNull("different aspect", LayoutCheck.layoutProblem(p, 320, 150))
        assertNull("profiles that do not record a height are not judged", LayoutCheck.layoutProblem(TestProfiles.full(), 180, 320))
    }

    @Test
    fun unchangedInterfaceVerifiesAndMovedInterfaceIsStale() {
        val (p, store) = calibrated()
        val same = verify(p, store, SynthHud())
        assertEquals(2, same.evaluated)
        assertEquals("scores=${same.scores}", 2, same.matched)
        assertFalse(same.stale)

        val moved = SynthHud()
        moved.rings.replaceAll { it.copy(y = it.y - 0.15f) }
        val v = verify(p, store, moved)
        assertEquals(2, v.evaluated)
        assertEquals("scores=${v.scores}", 0, v.matched)
        assertTrue(v.stale)
    }

    @Test
    fun heldControlsAreNotJudgedAndOneControlIsNeverEnoughForAVerdict() {
        val (p, store) = calibrated()
        val moved = SynthHud()
        moved.rings.replaceAll { it.copy(y = it.y - 0.15f) }
        val v = verify(p, store, moved, skip = setOf(CalibRole.ACCELERATOR))
        assertEquals(1, v.evaluated)
        assertFalse("a single control is not enough evidence", v.stale)
    }

    @Test
    fun movedControlsAreRelocatedAsProposals() {
        val (p, store) = calibrated()
        val moved = SynthHud()
        moved.rings.replaceAll { it.copy(y = it.y - 0.15f) }
        val f = moved.frame(50, 50_000, moving = true)
        val rel = LayoutCheck.relocate(p, f.toGray(), TemplateProvider(store, p.referenceWidth), f.width)
        val accel = rel.firstOrNull { it.role == CalibRole.ACCELERATOR }
        assertNotNull("relocations=$rel", accel)
        assertTrue(abs(accel!!.x - 0.90f) < 0.04f && abs(accel.y - 0.65f) < 0.05f)
        assertTrue(accel.movedBy > 0.1f)
        // The two pedals look identical in this scene, so the match must be flagged as uncertain.
        assertTrue(accel.ambiguous)
    }
}


class ProfileArchiveTest {
    private val profileText = ProfileCodec.format(
        TestProfiles.full().let { p -> p.copy(templates = p.templates.filterKeys { it == "hud_marker" }, stateRules = mapOf()) },
    )

    @Test
    fun roundTrip() {
        val bytes = ProfileArchive.pack(profileText, "version=1\n", mapOf("hud_marker" to byteArrayOf(1, 2, 3)))
        val c = ProfileArchive.unpack(bytes)
        assertEquals("test", c.profile.name)
        assertEquals(listOf<Byte>(1, 2, 3), c.templatesPng["hud_marker"]!!.toList())
        assertEquals("version=1\n", c.calibrationText)
        assertTrue(c.warnings.isEmpty())
    }

    @Test
    fun missingTemplateImagesAreReported() {
        val c = ProfileArchive.unpack(ProfileArchive.pack(profileText, null, emptyMap()))
        assertTrue(c.warnings.any { it.contains("hud_marker") })
    }

    private fun zip(vararg entries: Pair<String, ByteArray>): ByteArray {
        val out = ByteArrayOutputStream()
        ZipOutputStream(out).use { z ->
            for ((n, b) in entries) {
                z.putNextEntry(ZipEntry(n))
                z.write(b)
                z.closeEntry()
            }
        }
        return out.toByteArray()
    }

    private fun assertRejected(bytes: ByteArray) {
        try {
            ProfileArchive.unpack(bytes)
            fail("expected the archive to be rejected")
        } catch (e: IllegalArgumentException) {
            // expected
        }
    }

    @Test
    fun malformedArchivesAreRejected() {
        assertRejected(byteArrayOf(1, 2, 3, 4))
        assertRejected(zip("readme.txt" to "hi".toByteArray())) // no profile
        assertRejected(zip(ProfileArchive.PROFILE_ENTRY to "bogus.key=1".toByteArray())) // invalid profile
    }

    @Test
    fun oversizedEntriesAndUnsafeNamesAreHandled() {
        assertRejected(zip(ProfileArchive.PROFILE_ENTRY to ByteArray(600 * 1024) { 'a'.code.toByte() }))
        val c = ProfileArchive.unpack(
            zip(
                ProfileArchive.PROFILE_ENTRY to profileText.toByteArray(),
                "templates/../../evil.png" to byteArrayOf(9),
                "templates/UPPER.png" to byteArrayOf(9),
                "other/thing.bin" to byteArrayOf(9),
            ),
        )
        assertTrue(c.templatesPng.isEmpty())
        assertTrue(c.warnings.size >= 3)
    }

    @Test
    fun tooManyEntriesAreRejected() {
        val many = (0..310).map { "templates/t$it.png" to byteArrayOf(1) }.toTypedArray()
        assertRejected(zip(ProfileArchive.PROFILE_ENTRY to profileText.toByteArray(), *many))
    }
}
