package dev.toe3autopilot.core

import dev.toe3autopilot.core.profile.ProfileCodec
import dev.toe3autopilot.core.profile.ProfileLoad
import dev.toe3autopilot.core.profile.ProfileRepository
import dev.toe3autopilot.core.state.GameState
import dev.toe3autopilot.core.vision.GrayImage
import org.junit.After
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.io.File
import java.nio.file.Files

class ProfileRepositoryTest {
    private lateinit var dir: File
    private val clock = FakeClock()
    private val codec = FakeImageCodec()

    @Before
    fun setUp() {
        dir = Files.createTempDirectory("hp-repo").toFile()
    }

    @After
    fun tearDown() {
        dir.deleteRecursively()
    }

    private fun repo() = ProfileRepository(File(dir, "profiles"), codec, clock)

    private fun img(seed: Int) = GrayImage(8, 6, IntArray(48) { (it * 7 + seed) % 256 })

    @Test
    fun createListActivate() {
        val r = repo()
        val a = r.create("Pixel 8", "com.game")
        val b = r.create("Tablet", "com.game")
        assertEquals(a, r.activeId())
        val list = r.list()
        assertEquals(2, list.size)
        assertTrue(list.first().active)
        assertTrue(r.activate(b))
        assertEquals(b, r.activeId())
        assertEquals("Tablet", r.active()!!.name)
        assertFalse(r.activate("nope"))
    }

    @Test
    fun saveKeepsThePreviousVersionAndUndoRestoresProfileAndPictures() {
        val r = repo()
        val id = r.create("P", "g")
        val v1 = TestProfiles.full().copy(name = "P")
        assertTrue(r.save(id, v1, mapOf("hud_marker" to img(1)), replaceTemplates = true).ok)
        val v2 = v1.copy(controls = v1.controls - Control.BRAKE)
        assertTrue(r.save(id, v2, mapOf("hud_marker" to img(2))).ok)
        assertArrayEquals(img(2).px, r.gray("hud_marker")!!.px)
        assertNull(r.active()!!.control(Control.BRAKE))
        assertTrue(r.canUndoLastChange(id))
        assertTrue(r.undoLastChange(id).ok)
        assertNotNull(r.active()!!.control(Control.BRAKE))
        assertArrayEquals("the picture comes back too", img(1).px, r.gray("hud_marker")!!.px)
    }

    @Test
    fun anInvalidProfileIsRefusedAndNothingChanges() {
        val r = repo()
        val id = r.create("P", "g")
        val good = TestProfiles.full().copy(name = "P")
        assertTrue(r.save(id, good, emptyMap()).ok)
        val before = r.profileText(id)
        val bad = good.copy(stateRules = good.stateRules + (GameState.LOADING to listOf("no_such_template")))
        val res = r.save(id, bad, emptyMap())
        assertFalse(res.ok)
        assertTrue(res.error!!.contains("not valid"))
        assertEquals(before, r.profileText(id))
    }

    @Test
    fun anInterruptedSaveIsRolledBackOnStartUp() {
        val r = repo()
        val id = r.create("P", "g")
        assertTrue(r.save(id, TestProfiles.full().copy(name = "P"), emptyMap()).ok)
        val root = File(dir, "profiles")
        // Simulate a crash between the two renames: current moved aside, new version not yet in place.
        assertTrue(File(root, id).renameTo(File(root, "$id.old")))
        File(root, "$id.staging/templates").mkdirs()
        val fresh = repo()
        val notes = fresh.recover()
        assertTrue(notes.joinToString(), notes.any { it.contains("Restored") })
        assertTrue(fresh.load(id) is ProfileLoad.Ok)
        assertFalse(File(root, "$id.staging").exists())
    }

    @Test
    fun noTemporaryFilesAreLeftBehind() {
        val r = repo()
        val id = r.create("P", "g")
        r.save(id, TestProfiles.full().copy(name = "P"), mapOf("hud_marker" to img(3)))
        val leftovers = File(dir, "profiles").walkTopDown().filter { it.name.endsWith(".tmp") || it.name.endsWith(".staging") || it.name.endsWith(".old") }.toList()
        assertTrue(leftovers.toString(), leftovers.isEmpty())
    }

    @Test
    fun renameDuplicateAndDeleteWithUndo() {
        val r = repo()
        val id = r.create("Phone", "g")
        r.save(id, TestProfiles.full().copy(name = "Phone"), mapOf("hud_marker" to img(4)))
        assertTrue(r.rename(id, "My phone").ok)
        assertEquals("My phone", (r.load(id) as ProfileLoad.Ok).profile.name)
        val copy = r.duplicate(id, "My phone copy")!!
        assertArrayEquals(img(4).px, r.storeFor(copy).gray("hud_marker")!!.px)
        val del = r.delete(id)!!
        assertTrue(del.wasActive)
        assertEquals("another profile becomes active", copy, r.activeId())
        assertTrue(r.load(id) is ProfileLoad.Missing)
        assertTrue(r.undoDelete(del))
        assertEquals(id, r.activeId())
        assertTrue(r.load(id) is ProfileLoad.Ok)
    }

    @Test
    fun aDamagedProfileIsListedButNotUsed() {
        val r = repo()
        val id = r.create("P", "g")
        File(File(dir, "profiles"), "$id/profile.properties").writeText("control.ACCELERATOR=not,numbers\n")
        val s = r.list().single()
        assertFalse(s.readable)
        assertNotNull(s.error)
        assertNull(r.active())
        assertTrue(r.load(id) is ProfileLoad.Damaged)
    }

    @Test
    fun theOldSingleProfileLayoutIsMigratedOnce() {
        val legacy = File(dir, "profile").also { File(it, "templates").mkdirs() }
        File(legacy, "profile.properties").writeText(ProfileCodec.format(TestProfiles.full().copy(name = "Old")))
        File(legacy, "templates/hud_marker.png").writeBytes(codec.encode(img(9)))
        val r = repo()
        val id = r.migrateLegacy(legacy)
        assertNotNull(id)
        assertEquals(id, r.activeId())
        assertEquals("Old", r.active()!!.name)
        assertArrayEquals(img(9).px, r.gray("hud_marker")!!.px)
        assertNull("only once", r.migrateLegacy(legacy))
        assertTrue("old files are left alone", File(legacy, "profile.properties").exists())
    }

    @Test
    fun aDamagedLegacyProfileStillShowsUpAsDamaged() {
        val legacy = File(dir, "profile").also { it.mkdirs() }
        File(legacy, "profile.properties").writeText("steering.mode=SIDEWAYS\n")
        val r = repo()
        val id = r.migrateLegacy(legacy)!!
        assertTrue(r.load(id) is ProfileLoad.Damaged)
    }

    @Test(expected = IllegalArgumentException::class)
    fun importRejectsUnreadablePictures() {
        repo().importProfile(ProfileCodec.format(TestProfiles.full()), mapOf("hud_marker" to byteArrayOf(1, 2, 3)))
    }

    @Test
    fun importCreatesASeparateProfile() {
        val r = repo()
        val a = r.create("Mine", "g")
        val id = r.importProfile(ProfileCodec.format(TestProfiles.full().copy(name = "Shared")), mapOf("hud_marker" to codec.encode(img(5))))
        assertTrue(id != a)
        assertEquals(2, r.ids().size)
        assertEquals("the active profile is not switched by an import", a, r.activeId())
    }

    @Test
    fun summaryReportsReadiness() {
        val r = repo()
        val id = r.create("Fresh", "g")
        val s = r.list().single { it.id == id }
        assertTrue(s.notReady.isNotEmpty())
        assertTrue(s.controls.isEmpty())
    }
}
