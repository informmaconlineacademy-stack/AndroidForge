package dev.toe3autopilot.core

import dev.toe3autopilot.core.agents.ParkingAgent
import dev.toe3autopilot.core.agents.PulseDriver
import dev.toe3autopilot.core.agents.PulsePhase
import dev.toe3autopilot.core.agents.RecoveryAgent
import dev.toe3autopilot.core.state.GameState
import dev.toe3autopilot.core.vision.Blob
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

private val profile = TestProfiles.full()
private val settings = AutomationSettings(speedLevel = 0.5f, sensitivity = 1f)

class PulseDriverTest {
    @Test
    fun alternatesBoundedMovesWithSettlePauses() {
        val p = PulseDriver()
        assertEquals(PulsePhase.SETTLE, p.tick(0, true, 500, 300))
        assertEquals(PulsePhase.SETTLE, p.tick(299, true, 500, 300))
        assertEquals(PulsePhase.MOVE, p.tick(300, true, 500, 300))
        assertTrue(p.newPulse)
        assertEquals(1, p.pulseCount)
        assertEquals(PulsePhase.MOVE, p.tick(700, true, 500, 300))
        assertFalse(p.newPulse)
        assertEquals(PulsePhase.SETTLE, p.tick(800, true, 500, 300))
        assertEquals(PulsePhase.MOVE, p.tick(1100, true, 500, 300))
        assertEquals(2, p.pulseCount)
    }

    @Test
    fun doesNotStartMovingWhenNotWanted() {
        val p = PulseDriver()
        p.tick(0, false, 500, 300)
        assertEquals(PulsePhase.SETTLE, p.tick(10_000, false, 500, 300))
        assertEquals(0, p.pulseCount)
    }

    @Test
    fun theBurstLengthCanChangeBetweenPulses() {
        val p = PulseDriver()
        p.tick(0, true, 200, 100)
        assertEquals(PulsePhase.MOVE, p.tick(100, true, 200, 100))
        assertEquals(PulsePhase.SETTLE, p.tick(300, true, 200, 100))
        assertEquals(PulsePhase.MOVE, p.tick(400, true, 1000, 100))
        assertEquals(PulsePhase.MOVE, p.tick(1300, true, 1000, 100))
        assertEquals(PulsePhase.SETTLE, p.tick(1400, true, 1000, 100))
    }
}

class ParkingAgentTest {
    private fun cmd(d: Decision) = (d as Decision.Drive).command

    private fun zoneVision(x: Float) = FakeVision().also {
        it.colors["parking_zone"] = Blob(500, 0.05f, x, 0.6f)
    }

    @Test
    fun reversesInShortPulsesSteeringTowardTheZone() {
        val a = ParkingAgent()
        val v = zoneVision(0.62f)
        assertEquals(1f, cmd(a.decide(v, profile, settings, 0)).brake, 0f)
        val move = cmd(a.decide(v, profile, settings, 800))
        assertEquals(Gear.REVERSE, move.gear)
        assertTrue(move.steer > 0f)
        assertEquals(1f, move.throttle, 0f)
        assertEquals(1f, cmd(a.decide(v, profile, settings, 1500)).brake, 0f)
    }

    @Test
    fun noSteeringWhenAlreadyAligned() {
        val a = ParkingAgent()
        val v = zoneVision(0.51f)
        a.decide(v, profile, settings, 0)
        assertEquals(0f, cmd(a.decide(v, profile, settings, 800)).steer, 0f)
    }

    @Test
    fun parkedCueMeansStopAndWait() {
        val a = ParkingAgent()
        val v = zoneVision(0.5f)
        v.put("parked_ok", 0.5f, 0.2f)
        val c = cmd(a.decide(v, profile, settings, 0))
        assertEquals(1f, c.brake, 0f)
        assertEquals(0f, c.throttle, 0f)
    }

    @Test
    fun losingTheZoneStopsAndEventuallyAsksForHelp() {
        val a = ParkingAgent()
        val v = FakeVision()
        assertEquals(1f, cmd(a.decide(v, profile, settings, 0)).brake, 0f)
        assertTrue(a.decide(v, profile, settings, 16_000) is Decision.NeedHelp)
    }

    @Test
    fun forwardParkingIsConfigurable() {
        val p = TestProfiles.full(extras = mapOf("parking.direction" to "FORWARD"))
        val a = ParkingAgent()
        val v = zoneVision(0.5f)
        a.decide(v, p, settings, 0)
        assertEquals(Gear.FORWARD, cmd(a.decide(v, p, settings, 800)).gear)
    }

    @Test
    fun boundedNumberOfCorrections() {
        val a = ParkingAgent()
        val v = zoneVision(0.7f)
        var t = 0L
        var helped = false
        // The session stops calling an agent once it asks for help, so do the same here.
        while (!helped && t < 400 * 350L) {
            if (a.decide(v, profile, settings, t) is Decision.NeedHelp) helped = true
            t += 350
        }
        assertTrue(helped)
        assertEquals(61, a.pulsesUsed) // maxPulses (60) corrections were allowed; the 61st is refused
    }
}

class RecoveryAgentTest {
    private val v = FakeVision()

    @Test
    fun anUnexpectedDialogStopsTheTruckAndIsNeverTapped() {
        val d = RecoveryAgent().check(GameState.UNEXPECTED_DIALOG, v, profile, 0, 0f)
        assertTrue(d is Decision.NeedHelp)
        assertTrue(d!!.note.contains("dialog"))
    }

    @Test
    fun aCrashScreenStopsTheTruckAndIsNeverTapped() {
        val d = RecoveryAgent().check(GameState.CRASH_OR_PENALTY, v, profile, 0, 0f)
        assertTrue(d is Decision.NeedHelp)
        assertTrue(d!!.note.contains("crash", ignoreCase = true))
    }

    @Test
    fun loadingIsPatientButNotForever() {
        val r = RecoveryAgent()
        assertTrue(r.check(GameState.LOADING, v, profile, 0, 0f) is Decision.Wait)
        assertTrue(r.check(GameState.LOADING, v, profile, 59_000, 0f) is Decision.Wait)
        assertTrue(r.check(GameState.LOADING, v, profile, 61_000, 0f) is Decision.NeedHelp)
    }

    @Test
    fun unknownScreenEscalatesAfterEightSeconds() {
        val r = RecoveryAgent()
        assertTrue(r.check(GameState.UNKNOWN, v, profile, 0, 0f) is Decision.Wait)
        assertTrue(r.check(GameState.UNKNOWN, v, profile, 7_000, 0f) is Decision.Wait)
        assertTrue(r.check(GameState.UNKNOWN, v, profile, 9_000, 0f) is Decision.NeedHelp)
    }

    @Test
    fun healthyDrivingStatesPassThrough() {
        val r = RecoveryAgent()
        assertNull(r.check(GameState.DRIVING, v, profile, 0, 0.5f))
        assertNull(r.check(GameState.PARKING, v, profile, 10, 0f))
    }

    @Test
    fun theParkingViewHasADwellLimit() {
        val r = RecoveryAgent()
        assertNull(r.check(GameState.PARKING, v, profile, 0, 0f))
        assertNull(r.check(GameState.PARKING, v, profile, 599_000, 0f))
        assertTrue(r.check(GameState.PARKING, v, profile, 601_000, 0f) is Decision.NeedHelp)
    }

    @Test
    fun aStuckTruckIsStoppedNotReversedBlindly() {
        val r = RecoveryAgent()
        v.motionValue = 0f
        var t = 0L
        var reversals = 0
        var helped = false
        repeat(300) {
            val d = r.check(GameState.DRIVING, v, profile, t, 0.5f)
            if (d is Decision.Drive && d.command.gear == Gear.REVERSE) reversals++
            if (d is Decision.NeedHelp) helped = true
            t += 200
        }
        assertEquals(0, reversals)
        assertTrue(helped)
    }

    @Test
    fun aMovingTruckIsNeverStuckAndABrakingOneIsNotTryingToMove() {
        val r = RecoveryAgent()
        v.motionValue = 0.05f
        var t = 0L
        repeat(200) {
            assertNull(r.check(GameState.DRIVING, v, profile, t, 0.5f))
            t += 200
        }
        v.motionValue = 0f
        repeat(200) {
            assertNull(r.check(GameState.DRIVING, v, profile, t, 0f))
            t += 200
        }
    }

    @Test
    fun theStuckTimerRestartsWhenTheStateChanges() {
        val r = RecoveryAgent()
        v.motionValue = 0f
        r.check(GameState.DRIVING, v, profile, 0, 0.5f)
        r.check(GameState.DRIVING, v, profile, 6_000, 0.5f)
        r.check(GameState.PARKING, v, profile, 7_000, 0.5f)
        assertNull(r.check(GameState.PARKING, v, profile, 12_000, 0.5f))
    }
}
