package dev.toe3autopilot.core

import dev.toe3autopilot.core.agents.DeliveryAreaDetector
import dev.toe3autopilot.core.agents.DeliveryCue
import dev.toe3autopilot.core.vision.Blob
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class DeliveryAreaDetectorTest {
    // Test minimap: Roi(0.0, 0.5, 0.3, 1.0) (0.3 x 0.5 of the frame), truck marker at (0.15, 0.95).
    private val profile = TestProfiles.full()

    private fun withMarker(v: FakeVision, cx: Float, cy: Float, fraction: Float = 0.02f) {
        v.colors["destination_marker"] = Blob(80, fraction, cx, cy)
    }

    private fun feed(d: DeliveryAreaDetector, v: FakeVision, start: Long, n: Int, step: Long = 100, p: dev.toe3autopilot.core.profile.GameProfile = profile): Long {
        var t = start
        repeat(n) { d.update(v, p, t); t += step }
        return t
    }

    @Test
    fun nothingCalibratedMeansNoCue() {
        val d = DeliveryAreaDetector()
        feed(d, FakeVision(), 0, 20)
        assertEquals(DeliveryCue.NONE, d.level)
        assertNull(d.reason)
    }

    @Test
    fun theDestinationMarkerFarAwayIsNotAnArrival() {
        val d = DeliveryAreaDetector()
        val v = FakeVision().also { withMarker(it, 0.15f, 0.55f) } // 0.8 minimap-heights away
        feed(d, v, 0, 20)
        assertEquals(DeliveryCue.NONE, d.level)
    }

    @Test
    fun aCloseDestinationMarkerMeansNear() {
        val d = DeliveryAreaDetector()
        val v = FakeVision().also { withMarker(it, 0.15f, 0.75f) } // 0.4 away
        feed(d, v, 0, 5)
        assertEquals(DeliveryCue.NEAR, d.level)
        assertTrue(d.reason!!.contains("minimap"))
    }

    @Test
    fun aDestinationMarkerAtTheTruckMeansAt() {
        val d = DeliveryAreaDetector()
        val v = FakeVision().also { withMarker(it, 0.16f, 0.93f) }
        feed(d, v, 0, 5)
        assertEquals(DeliveryCue.AT, d.level)
    }

    @Test
    fun thresholdsComeFromTheProfile() {
        val d = DeliveryAreaDetector()
        val p = TestProfiles.full(extras = mapOf("delivery.nearDist" to "0.2", "delivery.atDist" to "0.05"))
        val v = FakeVision().also { withMarker(it, 0.15f, 0.75f) } // 0.4 away: beyond the tightened near distance
        feed(d, v, 0, 5, p = p)
        assertEquals(DeliveryCue.NONE, d.level)
        withMarker(v, 0.15f, 0.88f) // 0.14 away
        feed(d, v, 1000, 5, p = p)
        assertEquals(DeliveryCue.NEAR, d.level)
    }

    @Test
    fun aTinyMarkerBlobIsNoise() {
        val d = DeliveryAreaDetector()
        val v = FakeVision().also { withMarker(it, 0.15f, 0.95f, fraction = 0.0005f) }
        feed(d, v, 0, 10)
        assertEquals(DeliveryCue.NONE, d.level)
    }

    @Test
    fun theMarkerIsIgnoredWithoutAMinimapCalibration() {
        val d = DeliveryAreaDetector()
        val v = FakeVision().also { withMarker(it, 0.15f, 0.95f) }
        feed(d, v, 0, 10, p = profile.copy(nav = null))
        assertEquals(DeliveryCue.NONE, d.level)
    }

    @Test
    fun theDestinationNearTemplateMeansNear() {
        val d = DeliveryAreaDetector()
        val v = FakeVision().also { it.put("destination_near", 0.5f, 0.3f) }
        feed(d, v, 0, 5)
        assertEquals(DeliveryCue.NEAR, d.level)
        assertTrue(d.reason!!.contains("destination-near"))
    }

    @Test
    fun aVisibleParkingAreaMeansNear() {
        val d = DeliveryAreaDetector()
        val v = FakeVision().also { it.colors["parking_zone"] = Blob(500, 0.05f, 0.5f, 0.6f) }
        feed(d, v, 0, 5)
        assertEquals(DeliveryCue.NEAR, d.level)
        assertTrue(d.reason!!.contains("parking"))
    }

    @Test
    fun aCueNeedsSeveralConsecutiveObservations() {
        val d = DeliveryAreaDetector(confirmTicks = 3)
        val v = FakeVision().also { it.put("destination_near", 0.5f, 0.3f) }
        d.update(v, profile, 0)
        d.update(v, profile, 100)
        assertEquals(DeliveryCue.NONE, d.level)
        d.update(v, profile, 200)
        assertEquals(DeliveryCue.NEAR, d.level)
    }

    @Test
    fun aFlickeringCueNeverConfirms() {
        val d = DeliveryAreaDetector(confirmTicks = 3)
        val v = FakeVision()
        var t = 0L
        repeat(30) { i ->
            if (i % 2 == 0) v.put("destination_near", 0.5f, 0.3f) else v.remove("destination_near")
            d.update(v, profile, t)
            t += 100
        }
        assertEquals(DeliveryCue.NONE, d.level)
    }

    @Test
    fun aConfirmedCueIsHeldThroughShortDropoutsAndFallsBackLater() {
        val d = DeliveryAreaDetector(confirmTicks = 3, holdMs = 8000)
        val v = FakeVision().also { it.put("destination_near", 0.5f, 0.3f) }
        feed(d, v, 0, 3) // confirmed at t=200
        assertEquals(DeliveryCue.NEAR, d.level)
        v.remove("destination_near")
        d.update(v, profile, 5000)
        assertEquals("still held", DeliveryCue.NEAR, d.level)
        d.update(v, profile, 8100)
        assertEquals("held 7.9 s after the last sighting", DeliveryCue.NEAR, d.level)
        d.update(v, profile, 8500)
        assertEquals(DeliveryCue.NONE, d.level)
        assertNull(d.reason)
    }

    @Test
    fun anAtCueNeedsConfirmationAndCanFallBackToNear() {
        val d = DeliveryAreaDetector(confirmTicks = 3, holdMs = 4000)
        val v = FakeVision().also { withMarker(it, 0.15f, 0.75f) }
        feed(d, v, 0, 4)
        assertEquals(DeliveryCue.NEAR, d.level)
        withMarker(v, 0.16f, 0.93f)
        d.update(v, profile, 1000)
        d.update(v, profile, 1100)
        assertEquals("not yet", DeliveryCue.NEAR, d.level)
        d.update(v, profile, 1200)
        assertEquals(DeliveryCue.AT, d.level)
        withMarker(v, 0.15f, 0.75f) // the marker moves away again (overshoot / turn)
        d.update(v, profile, 3000)
        assertEquals(DeliveryCue.AT, d.level)
        d.update(v, profile, 6000)
        assertEquals(DeliveryCue.NEAR, d.level)
    }

    @Test
    fun resetForgetsTheCue() {
        val d = DeliveryAreaDetector()
        val v = FakeVision().also { it.put("destination_near", 0.5f, 0.3f) }
        feed(d, v, 0, 5)
        assertNotNull(d.reason)
        d.reset()
        assertEquals(DeliveryCue.NONE, d.level)
        assertNull(d.reason)
    }
}
