package dev.toe3autopilot.core

import dev.toe3autopilot.core.geometry.BoxEditing
import dev.toe3autopilot.core.geometry.BoxHandle
import dev.toe3autopilot.core.geometry.EditorTransform
import dev.toe3autopilot.core.geometry.FitTransform
import dev.toe3autopilot.core.geometry.ZoomPan
import dev.toe3autopilot.core.vision.Roi
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class BoxEditingTest {
    private val eps = 1e-5f

    private fun assertBox(l: Float, t: Float, r: Float, b: Float, box: Roi) {
        assertEquals(l, box.left, eps)
        assertEquals(t, box.top, eps)
        assertEquals(r, box.right, eps)
        assertEquals(b, box.bottom, eps)
    }

    @Test
    fun `corners in any order make the same box`() {
        assertBox(0.2f, 0.3f, 0.6f, 0.7f, BoxEditing.fromCorners(0.6f, 0.7f, 0.2f, 0.3f))
        assertBox(0.2f, 0.3f, 0.6f, 0.7f, BoxEditing.fromCorners(0.2f, 0.7f, 0.6f, 0.3f))
    }

    @Test
    fun `degenerate and out-of-picture drags still give a valid box`() {
        val tiny = BoxEditing.fromCorners(0.5f, 0.5f, 0.5f, 0.5f)
        assertEquals(BoxEditing.MIN_SIZE, tiny.right - tiny.left, eps)
        assertEquals(BoxEditing.MIN_SIZE, tiny.bottom - tiny.top, eps)
        val edge = BoxEditing.fromCorners(1.3f, 1.2f, 1.1f, 1.5f)
        assertBox(1f - BoxEditing.MIN_SIZE, 1f - BoxEditing.MIN_SIZE, 1f, 1f, edge)
        val neg = BoxEditing.fromCorners(-0.5f, -0.2f, 0.3f, 0.4f)
        assertBox(0f, 0f, 0.3f, 0.4f, neg)
    }

    @Test
    fun `resizing keeps the opposite corner and never flips the box`() {
        val box = Roi(0.2f, 0.2f, 0.6f, 0.6f)
        assertBox(0.2f, 0.2f, 0.8f, 0.9f, BoxEditing.resize(box, BoxHandle.BOTTOM_RIGHT, 0.8f, 0.9f))
        assertBox(0.1f, 0.05f, 0.6f, 0.6f, BoxEditing.resize(box, BoxHandle.TOP_LEFT, 0.1f, 0.05f))
        // Dragging the top-left corner past the bottom-right one stops short of it.
        val crossed = BoxEditing.resize(box, BoxHandle.TOP_LEFT, 0.9f, 0.9f)
        assertBox(0.6f - BoxEditing.MIN_SIZE, 0.6f - BoxEditing.MIN_SIZE, 0.6f, 0.6f, crossed)
        val tr = BoxEditing.resize(box, BoxHandle.TOP_RIGHT, 0.7f, 0.1f)
        assertBox(0.2f, 0.1f, 0.7f, 0.6f, tr)
        val bl = BoxEditing.resize(box, BoxHandle.BOTTOM_LEFT, -1f, 2f)
        assertBox(0f, 0.2f, 0.6f, 1f, bl)
    }

    @Test
    fun `moving keeps the size and stops at the edges`() {
        val box = Roi(0.2f, 0.2f, 0.5f, 0.4f)
        assertBox(0.3f, 0.25f, 0.6f, 0.45f, BoxEditing.move(box, 0.1f, 0.05f))
        val far = BoxEditing.move(box, 5f, -5f)
        assertBox(0.7f, 0f, 1f, 0.2f, far)
    }

    @Test
    fun `around shifts instead of shrinking`() {
        val b = BoxEditing.around(0.98f, 0.02f, 0.2f, 0.3f)
        assertBox(0.8f, 0f, 1f, 0.3f, b)
    }

    @Test
    fun `hit test works in screen pixels at any zoom`() {
        val fit = FitTransform(480f, 216f, 1080f, 600f)
        val box = Roi(0.25f, 0.25f, 0.75f, 0.75f)
        for (zoom in listOf(ZoomPan.NONE, ZoomPan(3f, -800f, -300f))) {
            val t = EditorTransform(fit, zoom)
            val tl = t.toScreen(box.left, box.top)
            assertEquals(BoxHandle.TOP_LEFT, BoxEditing.hitTest(t, box, tl.x + 10f, tl.y - 10f, 40f))
            val br = t.toScreen(box.right, box.bottom)
            assertEquals(BoxHandle.BOTTOM_RIGHT, BoxEditing.hitTest(t, box, br.x - 5f, br.y + 5f, 40f))
            val c = t.toScreen(0.5f, 0.5f)
            assertEquals(BoxHandle.MOVE, BoxEditing.hitTest(t, box, c.x, c.y, 40f))
            val out = t.toScreen(0.05f, 0.95f)
            assertNull(BoxEditing.hitTest(t, box, out.x, out.y, 10f))
        }
    }

    @Test
    fun `same ignores sub-pixel noise only`() {
        val a = Roi(0.1f, 0.1f, 0.3f, 0.3f)
        assertTrue(BoxEditing.same(a, Roi(0.1004f, 0.1f, 0.3f, 0.3f)))
        assertTrue(!BoxEditing.same(a, Roi(0.11f, 0.1f, 0.3f, 0.3f)))
        assertTrue(BoxEditing.same(null, null))
        assertTrue(!BoxEditing.same(a, null))
    }
}
