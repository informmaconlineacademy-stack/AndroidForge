package dev.toe3autopilot.core

import dev.toe3autopilot.core.calibration.CalibRole
import dev.toe3autopilot.core.calibration.ControlCandidateDetector
import dev.toe3autopilot.core.calibration.DetectionStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assume.assumeTrue
import org.junit.Test
import java.io.File

/**
 * Auto-Calibrate's detector on REAL pictures of Truckers of Europe 3 (src/test/resources/fixtures/toe3, see the README
 * there). Every picture with a hand-marked `.expected.properties` must match it; pictures without one are analysed in
 * probe mode (report only). Reports and annotated pictures go to build/fixture-reports/.
 *
 * What these pictures can and cannot show: they are single pictures (the weaker path), taken from screenshots of the
 * app on the user's phone. They do not show the many-picture path on live gameplay; that still needs a phone test.
 */
class RealScreenshotTest {
    private val dir = RealScreenshots.dir()
    private val reports = File(System.getProperty("haulpilot.fixtureReports") ?: "build/fixture-reports")

    private fun case(name: String): RealScreenshots.Case {
        assumeTrue("fixtures folder not found (set -Dhaulpilot.fixtures=…)", dir != null)
        val c = RealScreenshots.cases(dir!!).firstOrNull { it.name == name }
        assumeTrue("fixture $name is missing from $dir", c != null)
        return c!!
    }

    private fun run(c: RealScreenshots.Case): Pair<ControlCandidateDetector.Result, List<String>?> {
        val frames = c.files.mapIndexed { i, f -> RealScreenshots.load(f, i * 330L) }
        val spec = c.spec
        val r = RealScreenshots.analyse(frames, spec?.exclusions?.values?.toList() ?: emptyList())
        val problems = spec?.let { RealScreenshots.check(r, it) }
        val text = RealScreenshots.report(c, frames, r, problems)
        println(text)
        try {
            reports.mkdirs()
            File(reports, "${c.name}.txt").writeText(text)
            RealScreenshots.annotate(frames.last(), r, spec, File(reports, "${c.name}.png"))
        } catch (_: Exception) {
            // A report that cannot be written does not change the result.
        }
        return r to problems
    }

    /** The user's 0.9 screenshot: translucent pedals over grass must be found; gauges, trailer and HaulPilot's button never. */
    @Test
    fun pedalsAreFoundOnTheUsersScreenshot() {
        val c = case("toe3_v09_review")
        val (r, problems) = run(c)
        assertEquals("problems: $problems", emptyList<String>(), problems)
        val brake = r.detections.getValue(CalibRole.BRAKE)
        val acc = r.detections.getValue(CalibRole.ACCELERATOR)
        assertEquals(DetectionStatus.NEEDS_CONFIRMATION, brake.status)
        assertTrue("brake left of the accelerator", brake.x < acc.x)
        // From one picture the evidence is capped lower, and it is said so.
        assertTrue(brake.confidence <= ControlCandidateDetector.SINGLE_PICTURE_MAX_CONFIDENCE + 1e-6f)
        assertTrue(brake.evidence.any { it.contains("single picture") })
        assertTrue("HaulPilot's own button was left out", r.notes.any { it.contains("HaulPilot's own button") })
    }

    /** The user's 1.0 screenshot: the round translucent arrow buttons must be found as steer left / steer right. */
    @Test
    fun arrowButtonsAreFoundOnTheUsersScreenshot() {
        val c = case("toe3_v1_editor")
        val (r, problems) = run(c)
        assertEquals("problems: $problems", emptyList<String>(), problems)
        val l = r.detections.getValue(CalibRole.STEER_LEFT)
        val rr = r.detections.getValue(CalibRole.STEER_RIGHT)
        assertEquals(DetectionStatus.NEEDS_CONFIRMATION, l.status)
        assertEquals(DetectionStatus.NEEDS_CONFIRMATION, rr.status)
        // A button pair, so no steering wheel is proposed at the same time.
        assertEquals(DetectionStatus.NONE, r.detections.getValue(CalibRole.STEER_WHEEL).status)
        // Their insides are mirror images (a left and a right arrow): that is part of the stated evidence.
        assertTrue(l.evidence.joinToString().contains("mirror"))
    }

    /** Without being told where HaulPilot's button is, it must still never become the driving-screen marker or a control there. */
    @Test
    fun theUsersScreenshotWithoutExclusionsStillHasNoMarkerOnTheOwnButton() {
        val c = case("toe3_v09_review")
        val frames = c.files.map { RealScreenshots.load(it) }
        val r = RealScreenshots.analyse(frames, emptyList())
        // A single picture never yields a driving-screen marker (that needs pictures where the scenery moves).
        assertEquals(null, r.marker)
        val own = c.spec!!.exclusions.getValue("own_button")
        for (d in r.detections.values) {
            if (d.status != DetectionStatus.NEEDS_CONFIRMATION) continue
            assertTrue("${d.role} on HaulPilot's button", !(d.x in own.left..own.right && d.y in own.top..own.bottom))
        }
    }

    /** Every fixture in the folder: checked when it has ground truth, reported otherwise (drop your own screenshots in). */
    @Test
    fun everyFixtureInTheFolder() {
        assumeTrue("fixtures folder not found", dir != null)
        val all = RealScreenshots.cases(dir!!)
        assumeTrue("no pictures in $dir", all.isNotEmpty())
        val failures = ArrayList<String>()
        for (c in all) {
            val (_, problems) = run(c)
            if (problems != null && problems.isNotEmpty()) failures += "${c.name}: " + problems.joinToString("; ")
        }
        assertEquals(emptyList<String>(), failures)
    }
}
