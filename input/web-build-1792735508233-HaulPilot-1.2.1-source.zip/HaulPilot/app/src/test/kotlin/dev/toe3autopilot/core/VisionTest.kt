package dev.toe3autopilot.core

import dev.toe3autopilot.core.profile.NavProfile
import dev.toe3autopilot.core.vision.ColorMask
import dev.toe3autopilot.core.vision.ColorTarget
import dev.toe3autopilot.core.vision.Frame
import dev.toe3autopilot.core.vision.GrayImage
import dev.toe3autopilot.core.vision.MotionEstimator
import dev.toe3autopilot.core.vision.Roi
import dev.toe3autopilot.core.vision.RouteEstimator
import dev.toe3autopilot.core.vision.TemplateMatcher
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class VisionTest {
    private val fw = 320
    private val fh = 180

    private fun frameWith(draw: (IntArray) -> Unit): Frame {
        val px = Synth.blankPixels(fw, fh)
        draw(px)
        return Frame(fw, fh, px)
    }

    @Test
    fun grayConversionKeepsExtremes() {
        val f = Frame(2, 1, intArrayOf(0xFFFFFFFF.toInt(), 0xFF000000.toInt()))
        val g = f.toGray()
        assertEquals(255, g.px[0])
        assertEquals(0, g.px[1])
    }

    @Test
    fun cropAndResize() {
        val img = GrayImage(4, 4, IntArray(16) { it })
        val c = img.crop(1, 1, 3, 3)
        assertEquals(listOf(5, 6, 9, 10), c.px.toList())
        val half = img.resize(2, 2)
        assertEquals(2, half.width)
        assertEquals((0 + 1 + 4 + 5) / 4, half.px[0])
        val up = GrayImage(1, 1, intArrayOf(77)).resize(3, 3)
        assertTrue(up.px.all { it == 77 })
    }

    @Test
    fun roiValidationAndParsing() {
        assertEquals(Roi(0.1f, 0.2f, 0.3f, 0.4f), Roi.parse("0.1, 0.2, 0.3, 0.4"))
        assertEquals(Roi.parse("0.1,0.2,0.3,0.4").format(), Roi(0.1f, 0.2f, 0.3f, 0.4f).format())
        try {
            Roi(0.5f, 0.5f, 0.4f, 0.9f)
            error("expected failure")
        } catch (e: IllegalArgumentException) {
            // expected
        }
        try {
            Roi.parse("0.1,0.2,0.3")
            error("expected failure")
        } catch (e: IllegalArgumentException) {
            // expected
        }
        val r = Roi(0f, 0f, 0.001f, 0.001f).toRect(100, 100)
        assertTrue(r.width >= 1 && r.height >= 1)
    }

    @Test
    fun templateIsFoundAtItsPosition() {
        val tpl = Synth.patch(1, 20, 20)
        val frame = frameWith { Synth.drawPatch(it, fw, fh, tpl, 101, 53) }
        val m = TemplateMatcher.best(frame.toGray(), tpl)
        assertNotNull(m)
        assertEquals((101 + 10) / fw.toFloat(), m!!.x, 0.002f)
        assertEquals((53 + 10) / fh.toFloat(), m.y, 0.002f)
        assertTrue("score ${m.score}", m.score > 0.99f)
    }

    @Test
    fun differentPatternScoresLow() {
        val tpl = Synth.patch(1, 20, 20)
        val other = Synth.patch(2, 20, 20)
        val frame = frameWith { Synth.drawPatch(it, fw, fh, other, 100, 50) }
        val m = TemplateMatcher.best(frame.toGray(), tpl)
        assertTrue(m == null || m.score < 0.5f)
    }

    @Test
    fun matchingToleratesBrightnessAndContrastChange() {
        val tpl = Synth.patch(3, 20, 20)
        val dimmed = GrayImage(20, 20, IntArray(400) { tpl.px[it] / 2 + 30 })
        val frame = frameWith { Synth.drawPatch(it, fw, fh, dimmed, 60, 90) }
        val m = TemplateMatcher.best(frame.toGray(), tpl)
        assertNotNull(m)
        assertTrue("score ${m!!.score}", m.score > 0.97f)
    }

    @Test
    fun flatTemplateCannotBeMatched() {
        val flat = GrayImage(10, 10, IntArray(100) { 128 })
        val frame = frameWith { }
        assertNull(TemplateMatcher.best(frame.toGray(), flat))
    }

    @Test
    fun roiRestrictsTheSearch() {
        val tpl = Synth.patch(4, 20, 20)
        val frame = frameWith { Synth.drawPatch(it, fw, fh, tpl, 250, 120) }
        val left = TemplateMatcher.all(frame.toGray(), tpl, Roi(0f, 0f, 0.5f, 1f), 0.9f)
        assertTrue(left.isEmpty())
        val right = TemplateMatcher.all(frame.toGray(), tpl, Roi(0.6f, 0.5f, 1f, 1f), 0.9f)
        assertEquals(1, right.size)
    }

    @Test
    fun findsSeveralInstancesWithNonMaximumSuppression() {
        val tpl = Synth.patch(5, 20, 20)
        val frame = frameWith {
            Synth.drawPatch(it, fw, fh, tpl, 20, 20)
            Synth.drawPatch(it, fw, fh, tpl, 150, 60)
            Synth.drawPatch(it, fw, fh, tpl, 250, 140)
        }
        val all = TemplateMatcher.all(frame.toGray(), tpl, Roi.FULL, 0.9f, 8)
        assertEquals(3, all.size)
    }

    @Test
    fun coarseSearchStillLocatesOddCoordinates() {
        // Full-frame search of a 20x20 template exceeds the coarse-search work limit, so this exercises refinement.
        val tpl = Synth.patch(6, 20, 20)
        val frame = frameWith { Synth.drawPatch(it, fw, fh, tpl, 201, 97) }
        val m = TemplateMatcher.best(frame.toGray(), tpl, Roi.FULL)
        assertNotNull(m)
        assertEquals((201 + 10) / fw.toFloat(), m!!.x, 0.002f)
        assertEquals((97 + 10) / fh.toFloat(), m.y, 0.002f)
    }

    @Test
    fun colorMaskFindsCentroidAndFraction() {
        val frame = frameWith { Synth.drawRect(it, fw, fh, 100, 50, 120, 70, 0x00C800) }
        val b = ColorMask.measure(frame, Roi.FULL, ColorTarget(0, 200, 0, 20))
        assertTrue(b.found)
        assertEquals(400, b.count)
        assertEquals(110f / fw, b.cx, 0.005f)
        assertEquals(60f / fh, b.cy, 0.005f)
        assertFalse(ColorMask.measure(frame, Roi.FULL, ColorTarget(255, 0, 0, 10)).found)
    }

    private val nav = NavProfile(Roi(0.0f, 0.5f, 0.3f, 1.0f), ColorTarget(255, 215, 0, 40), 0.15f, 0.95f, 0.8f)

    private fun routeFrame(nearX: Int?, farX: Int?): Frame = frameWith { px ->
        // near band is y in [0.75, 0.95) of 180 => 135..171; far band is [0.55, 0.75) => 99..135
        if (nearX != null) Synth.drawRect(px, fw, fh, nearX, 137, nearX + 4, 170, 0xFFD700)
        if (farX != null) Synth.drawRect(px, fw, fh, farX, 100, farX + 4, 133, 0xFFD700)
    }

    @Test
    fun routeEstimatorReadsOffsetAndCurvature() {
        val est = RouteEstimator(nav)
        val truckPx = (0.15f * fw).toInt() // 48
        val straight = est.read(routeFrame(truckPx - 2, truckPx - 2))!!
        assertEquals(0f, straight.offset, 0.05f)
        assertEquals(0f, straight.curvature, 0.05f)
        assertTrue(straight.confidence > 0.9f)

        val right = est.read(routeFrame(truckPx + 14, truckPx + 14))!!
        assertTrue("offset ${right.offset}", right.offset > 0.25f)
        val left = est.read(routeFrame(truckPx - 18, truckPx - 18))!!
        assertTrue("offset ${left.offset}", left.offset < -0.25f)

        val bend = est.read(routeFrame(truckPx - 2, truckPx + 20))!!
        assertTrue("curvature ${bend.curvature}", bend.curvature > 0.3f)
    }

    @Test
    fun routeEstimatorReportsLossAndEndOfRoute() {
        val est = RouteEstimator(nav)
        assertNull(est.read(routeFrame(null, null)))
        val ending = est.read(routeFrame(46, null))!!
        assertFalse(ending.farVisible)
        assertEquals(0f, ending.curvature, 0f)
    }

    @Test
    fun motionEstimatorSeesChangeAndStillness() {
        val roi = Roi(0.2f, 0.2f, 0.8f, 0.8f)
        val m = MotionEstimator(roi)
        val a = Frame.solid(fw, fh, 0x404040)
        assertEquals(0f, m.update(a), 0f) // first frame: nothing to compare with
        assertEquals(0f, m.update(Frame.solid(fw, fh, 0x404040)), 0f)
        val moved = m.update(Frame.solid(fw, fh, 0x808080))
        assertTrue("motion $moved", moved > 0.2f)
    }
}
