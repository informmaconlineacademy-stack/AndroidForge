package dev.toe3autopilot.core

import dev.toe3autopilot.core.vision.Frame
import dev.toe3autopilot.core.vision.Roi
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Synthetic pictures shaped like a Truckers of Europe 3 driving screen at the 480 x 216 processing size: sky and a moving
 * road, a static truck/trailer in the middle (chase camera), and a TRANSLUCENT HUD drawn with alpha blending:
 * brake and accelerator pedals bottom-right, either a steering wheel or two arrow buttons bottom-left, a small reverse
 * button, a minimap top-right whose content scrolls, a few small top-bar icons and a speed read-out.
 *
 * Unlike the older SynthHud the pedals have NO pressed state: they look the same whether pressed or not, which is the
 * case the requirements call out. This is not the real game; it proves the analysis works on pictures with this
 * structure (translucent overlays, static non-HUD objects, a scrolling minimap).
 */
class Toe3Scene(val w: Int = 480, val h: Int = 216) {
    var wheel = true
    var showPedals = true
    var showBrake = true
    var showMinimap = true
    var showHud = true
    var hudAlpha = 0.55f

    // Ground-truth boxes (NDS).
    val brake = Roi(0.760f, 0.640f, 0.830f, 0.930f)
    val accelerator = Roi(0.855f, 0.560f, 0.915f, 0.930f)
    val wheelCenter = 0.135f to 0.720f
    val wheelRadiusPx = 36
    val left = Roi(0.050f, 0.700f, 0.125f, 0.880f)
    val right = Roi(0.165f, 0.700f, 0.240f, 0.880f)
    val reverse = Roi(0.680f, 0.400f, 0.730f, 0.510f)
    val minimap = Roi(0.790f, 0.050f, 0.975f, 0.420f)

    val wheelBox: Roi
        get() {
            val (cx, cy) = wheelCenter
            val rx = (wheelRadiusPx + 2).toFloat() / w
            val ry = (wheelRadiusPx + 2).toFloat() / h
            return Roi(cx - rx, cy - ry, cx + rx, cy + ry)
        }

    fun frame(t: Int, moving: Boolean = true, ts: Long = t * 330L): Frame {
        val px = IntArray(w * h)
        val offset = if (moving) t * 9 else 0
        val horizon = (0.42f * h).toInt()
        for (y in 0 until h) for (x in 0 until w) {
            px[y * w + x] = if (y < horizon) sky(x, y, if (moving) t else 0) else ground(x, y, horizon, offset)
        }
        // Static truck + trailer seen from behind (persistent, but not a control).
        fillRect(px, (0.40f * w).toInt(), (0.28f * h).toInt(), (0.60f * w).toInt(), (0.82f * h).toInt(), rgb(70, 74, 82), 1f)
        fillRect(px, (0.42f * w).toInt(), (0.32f * h).toInt(), (0.58f * w).toInt(), (0.78f * h).toInt(), rgb(120, 126, 136), 1f)
        if (!showHud) return Frame(w, h, px, ts)

        if (showPedals) {
            if (showBrake) pedal(px, brake)
            pedal(px, accelerator)
        }
        if (wheel) steeringWheel(px, (t * 13) % 60 - 30) else {
            arrowButton(px, left, pointsLeft = true)
            arrowButton(px, right, pointsLeft = false)
        }
        roundButton(px, reverse)
        if (showMinimap) minimap(px, if (moving) t else 0)
        // Top-bar icons (small squares) and the speed read-out (changes while moving).
        for (i in 0 until 3) outlineRect(px, 8 + i * 26, 6, 28 + i * 26, 26, 2)
        speed(px, if (moving) (40 + t * 3) % 120 else 0)
        return Frame(w, h, px, ts)
    }

    // ---- background ----------------------------------------------------------------------------------------------

    private fun sky(x: Int, y: Int, t: Int): Int {
        val base = 200 - y / 2
        val cloud = if (((x + t * 3) / 40 + y / 25) % 5 == 0) 20 else 0
        return rgb((base - 40 + cloud).coerceIn(0, 255), (base - 10 + cloud).coerceIn(0, 255), (base + 40 + cloud).coerceIn(0, 255))
    }

    private fun ground(x: Int, y: Int, horizon: Int, offset: Int): Int {
        val depth = (y - horizon + 1).toFloat() / (h - horizon)
        val roadHalf = 0.08f + 0.42f * depth
        val nx = x.toFloat() / w - 0.5f
        val row = ((y * 3 + offset * (0.5f + depth * 2f)).toInt() / 6)
        val n = hash(row * 7919 + (x / 7)) % 50
        return if (abs(nx) < roadHalf) {
            val lane = abs(nx) < 0.006f + 0.01f * depth && (row / 3) % 2 == 0
            if (lane) rgb(235, 235, 220) else rgb(60 + n / 3, 60 + n / 3, 64 + n / 3)
        } else {
            rgb(70 + n, 110 + n, 50 + n / 2)
        }
    }

    private fun hash(i: Int): Int {
        var z = i.toLong() * -7046029254386353131L
        z = (z xor (z ushr 30)) * -4658895280553007687L
        z = z xor (z ushr 31)
        return ((z ushr 33) and 0x7FFFFFFF).toInt()
    }

    // ---- HUD (alpha-blended) ---------------------------------------------------------------------------------------

    private fun pedal(px: IntArray, r: Roi) {
        val x0 = (r.left * w).toInt()
        val y0 = (r.top * h).toInt()
        val x1 = (r.right * w).toInt()
        val y1 = (r.bottom * h).toInt()
        fillRect(px, x0, y0, x1, y1, rgb(30, 30, 30), hudAlpha * 0.6f)
        outlineRect(px, x0, y0, x1, y1, 2)
        // ribs
        var y = y0 + 6
        while (y < y1 - 4) {
            fillRect(px, x0 + 4, y, x1 - 4, y + 2, rgb(255, 255, 255), hudAlpha)
            y += 8
        }
    }

    private fun steeringWheel(px: IntArray, angleDeg: Int) {
        val cx = wheelCenter.first * w
        val cy = wheelCenter.second * h
        val r = wheelRadiusPx.toFloat()
        for (y in (cy - r - 2).toInt()..(cy + r + 2).toInt()) for (x in (cx - r - 2).toInt()..(cx + r + 2).toInt()) {
            if (x !in 0 until w || y !in 0 until h) continue
            val d = hypot(x - cx, y - cy)
            if (d in (r - 4f)..r) blend(px, x, y, rgb(255, 255, 255), hudAlpha)
        }
        // three spokes (the hub turns with the steering; the rim does not change)
        for (k in 0 until 3) {
            val a = (angleDeg + k * 120 - 90) * PI / 180.0
            for (s in 6 until (r - 4).toInt()) {
                val x = (cx + cos(a) * s).roundToInt()
                val y = (cy + sin(a) * s).roundToInt()
                if (x in 0 until w && y in 0 until h) blend(px, x, y, rgb(255, 255, 255), hudAlpha)
            }
        }
    }

    private fun arrowButton(px: IntArray, r: Roi, pointsLeft: Boolean) {
        val x0 = (r.left * w).toInt()
        val y0 = (r.top * h).toInt()
        val x1 = (r.right * w).toInt()
        val y1 = (r.bottom * h).toInt()
        fillRect(px, x0, y0, x1, y1, rgb(30, 30, 30), hudAlpha * 0.6f)
        outlineRect(px, x0, y0, x1, y1, 2)
        val cy = (y0 + y1) / 2
        val bw = x1 - x0
        for (i in 0 until bw / 2) {
            val x = if (pointsLeft) x0 + bw / 4 + i else x1 - bw / 4 - i
            val half = i * (y1 - y0) / (bw * 2)
            for (y in cy - half..cy + half) if (x in 0 until w && y in 0 until h) blend(px, x, y, rgb(255, 255, 255), hudAlpha)
        }
    }

    private fun roundButton(px: IntArray, r: Roi) {
        val cx = (r.left + r.right) / 2f * w
        val cy = (r.top + r.bottom) / 2f * h
        val rad = (r.right - r.left) * w / 2f
        for (y in (cy - rad - 1).toInt()..(cy + rad + 1).toInt()) for (x in (cx - rad - 1).toInt()..(cx + rad + 1).toInt()) {
            if (x !in 0 until w || y !in 0 until h) continue
            val d = hypot(x - cx, y - cy)
            if (d <= rad - 2f) blend(px, x, y, rgb(30, 30, 30), hudAlpha * 0.6f) else if (d <= rad) blend(px, x, y, rgb(255, 255, 255), hudAlpha)
        }
        // "R"
        fillRect(px, (cx - 3).toInt(), (cy - 5).toInt(), (cx - 1).toInt(), (cy + 5).toInt(), rgb(255, 255, 255), hudAlpha)
        fillRect(px, (cx - 3).toInt(), (cy - 5).toInt(), (cx + 3).toInt(), (cy - 3).toInt(), rgb(255, 255, 255), hudAlpha)
    }

    private fun minimap(px: IntArray, t: Int) {
        val x0 = (minimap.left * w).toInt()
        val y0 = (minimap.top * h).toInt()
        val x1 = (minimap.right * w).toInt()
        val y1 = (minimap.bottom * h).toInt()
        for (y in y0 until y1) for (x in x0 until x1) {
            val n = hash(((y + t * 4) / 5) * 131 + x / 5) % 30
            px[y * w + x] = rgb(40 + n, 48 + n, 40 + n)
        }
        // route line (vivid orange) bending over time, truck arrow near the bottom centre
        val cx = (x0 + x1) / 2
        for (y in y0 + 4 until y1 - 10) {
            val bend = ((y1 - y) * (t % 20 - 10)) / 60
            for (dx in -2..2) {
                val x = cx + bend + dx
                if (x in x0 until x1) px[y * w + x] = rgb(255, 140, 20)
            }
        }
        fillRect(px, cx - 3, y1 - 12, cx + 3, y1 - 6, rgb(80, 160, 255), 1f)
        outlineRect(px, x0, y0, x1, y1, 2, alpha = 0.9f)
    }

    private fun speed(px: IntArray, v: Int) {
        val x0 = (0.47f * w).toInt()
        val y0 = (0.86f * h).toInt()
        for (i in 0 until 3) {
            val hh = 2 + ((v / (i + 1)) % 9)
            fillRect(px, x0 + i * 8, y0 + 10 - hh, x0 + i * 8 + 5, y0 + 10, rgb(255, 255, 255), 0.9f)
        }
    }

    // ---- primitives ------------------------------------------------------------------------------------------------

    private fun rgb(r: Int, g: Int, b: Int) = (0xFF shl 24) or (r shl 16) or (g shl 8) or b

    private fun blend(px: IntArray, x: Int, y: Int, c: Int, a: Float) {
        val i = y * w + x
        val o = px[i]
        fun ch(s: Int) = ((((c shr s) and 0xFF) * a) + (((o shr s) and 0xFF) * (1 - a))).roundToInt().coerceIn(0, 255)
        px[i] = rgb(ch(16), ch(8), ch(0))
    }

    private fun fillRect(px: IntArray, x0: Int, y0: Int, x1: Int, y1: Int, c: Int, a: Float) {
        for (y in maxOf(0, y0) until minOf(h, y1)) for (x in maxOf(0, x0) until minOf(w, x1)) blend(px, x, y, c, a)
    }

    private fun outlineRect(px: IntArray, x0: Int, y0: Int, x1: Int, y1: Int, t: Int, alpha: Float = hudAlpha) {
        val white = rgb(255, 255, 255)
        fillRect(px, x0, y0, x1, y0 + t, white, alpha)
        fillRect(px, x0, y1 - t, x1, y1, white, alpha)
        fillRect(px, x0, y0 + t, x0 + t, y1 - t, white, alpha)
        fillRect(px, x1 - t, y0 + t, x1, y1 - t, white, alpha)
    }
}

/** Intersection over union of two NDS boxes. */
fun iouOf(a: Roi, b: Roi): Float {
    val l = maxOf(a.left, b.left)
    val t = maxOf(a.top, b.top)
    val r = minOf(a.right, b.right)
    val bt = minOf(a.bottom, b.bottom)
    if (r <= l || bt <= t) return 0f
    val inter = (r - l) * (bt - t)
    val union = (a.right - a.left) * (a.bottom - a.top) + (b.right - b.left) * (b.bottom - b.top) - inter
    return if (union <= 0f) 0f else inter / union
}
