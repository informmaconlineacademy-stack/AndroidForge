package dev.toe3autopilot.core

import dev.toe3autopilot.core.profile.ColorSpec
import dev.toe3autopilot.core.profile.GameProfile
import dev.toe3autopilot.core.profile.NavProfile
import dev.toe3autopilot.core.profile.SteeringMode
import dev.toe3autopilot.core.profile.TemplateSpec
import dev.toe3autopilot.core.profile.TemplateStore
import dev.toe3autopilot.core.session.FrameSource
import dev.toe3autopilot.core.session.GameMonitor
import dev.toe3autopilot.core.session.InputController
import dev.toe3autopilot.core.session.InputKind
import dev.toe3autopilot.core.state.GameState
import dev.toe3autopilot.core.vision.Blob
import dev.toe3autopilot.core.vision.ColorTarget
import dev.toe3autopilot.core.vision.Frame
import dev.toe3autopilot.core.vision.GrayImage
import dev.toe3autopilot.core.vision.Match
import dev.toe3autopilot.core.vision.Roi
import dev.toe3autopilot.core.vision.RouteReading
import dev.toe3autopilot.core.vision.Vision
import java.util.Random

class FakeClock(var now: Long = 1_000_000L) : Clock {
    override fun nowMs(): Long = now
    fun advance(ms: Long) {
        now += ms
    }
}

/** Deterministic texture patches and tiny drawing helpers for synthetic screenshots. */
object Synth {
    fun patch(seed: Int, w: Int, h: Int): GrayImage {
        val r = Random(seed.toLong())
        return GrayImage(w, h, IntArray(w * h) { 20 + r.nextInt(216) })
    }

    /**
     * A quiet background that is a plausible picture of a game (a slow brightness ramp across the screen), NOT one flat colour:
     * a flat colour is an invalid capture (FrameChecks.FLAT) and the session refuses to drive on it.
     */
    fun blankPixels(w: Int, h: Int, rgb: Int = 0x303030): IntArray = IntArray(w * h) { i ->
        val ramp = (i % w) * 40 / w
        val r = ((rgb shr 16) and 0xFF) + ramp
        val g = ((rgb shr 8) and 0xFF) + ramp
        val b = (rgb and 0xFF) + ramp
        (0xFF shl 24) or (r.coerceAtMost(255) shl 16) or (g.coerceAtMost(255) shl 8) or b.coerceAtMost(255)
    }

    fun drawPatch(px: IntArray, fw: Int, fh: Int, p: GrayImage, x0: Int, y0: Int) {
        for (y in 0 until p.height) for (x in 0 until p.width) {
            val fx = x0 + x
            val fy = y0 + y
            if (fx in 0 until fw && fy in 0 until fh) {
                val g = p.px[y * p.width + x]
                px[fy * fw + fx] = (0xFF shl 24) or (g shl 16) or (g shl 8) or g
            }
        }
    }

    /** Draws a route line on the test minimap (heading-up; truck marker at 0.15,0.95; see [TestProfiles.full]). offset/farOffset: -1..1. */
    fun drawRoute(px: IntArray, fw: Int, fh: Int, offset: Float = 0f, farOffset: Float = offset, far: Boolean = true) {
        val half = 0.15f
        val nearX = ((0.15f + offset * half) * fw).toInt()
        val farX = ((0.15f + farOffset * half) * fw).toInt()
        drawRect(px, fw, fh, nearX - 2, (0.76f * fh).toInt(), nearX + 2, (0.94f * fh).toInt(), 0xFFD700)
        if (far) drawRect(px, fw, fh, farX - 2, (0.56f * fh).toInt(), farX + 2, (0.74f * fh).toInt(), 0xFFD700)
    }

    fun drawRect(px: IntArray, fw: Int, fh: Int, x0: Int, y0: Int, x1: Int, y1: Int, rgb: Int) {
        for (y in maxOf(0, y0) until minOf(fh, y1)) for (x in maxOf(0, x0) until minOf(fw, x1)) {
            px[y * fw + x] = (0xFF shl 24) or (rgb and 0xFFFFFF)
        }
    }
}

class MapTemplateStore(val map: MutableMap<String, GrayImage> = HashMap()) : TemplateStore {
    override fun gray(name: String): GrayImage? = map[name]
}

class FakeVision : Vision {
    val matches = HashMap<String, List<Match>>()
    val knownNames = HashSet<String>()
    val colors = HashMap<String, Blob>()
    var routeReading: RouteReading? = null
    var motionValue = 0.1f

    fun put(name: String, x: Float, y: Float, score: Float = 0.95f, w: Float = 0.06f, h: Float = 0.1f) {
        matches[name] = listOf(Match(x, y, score, w, h))
        knownNames += name
    }

    fun putAll(name: String, vararg pts: Pair<Float, Float>) {
        matches[name] = pts.map { Match(it.first, it.second, 0.95f, 0.1f, 0.1f) }
        knownNames += name
    }

    fun remove(name: String) {
        matches.remove(name)
    }

    override fun find(name: String): Match? = matches[name]?.firstOrNull()
    override fun findAll(name: String, max: Int): List<Match> = matches[name].orEmpty().take(max)
    override fun known(name: String): Boolean = knownNames.contains(name) || matches.containsKey(name) || colors.containsKey(name)
    override fun color(name: String): Blob? = colors[name]
    override fun route(): RouteReading? = routeReading
    override fun motion(): Float = motionValue
}

class FakeFrames(var active: Boolean = true, var frame: Frame? = null) : FrameSource {
    override val isActive: Boolean get() = active
    override fun latest(): Frame? = frame
}

class FakeMonitor(var foreground: Boolean? = true, var note: String = "") : GameMonitor {
    override fun isGameForeground(): Boolean? = foreground
    override fun foregroundNote(): String = note
}

class FakeInput(override val kind: InputKind = InputKind.INJECTED) : InputController {
    @Volatile
    override var isReady: Boolean = true

    @Volatile
    override var isHealthy: Boolean = true
    var holds: Map<Control, Point> = emptyMap()
        private set
    val taps = ArrayList<Point>()
    var releaseAllCalls = 0
        private set
    var setHoldsCalls = 0
        private set

    override fun setHolds(holds: Map<Control, Point>) {
        this.holds = HashMap(holds)
        setHoldsCalls++
    }

    override fun tapAt(point: Point) {
        taps.add(point)
    }

    override fun releaseAll() {
        holds = emptyMap()
        releaseAllCalls++
    }
}

/** A complete drive-only profile used by several tests. Positions are chosen so test frames can draw matching markers. */
object TestProfiles {
    const val FW = 320
    const val FH = 180

    val CONTROLS: Map<Control, Point> = mapOf(
        Control.ACCELERATOR to Point(0.90f, 0.80f),
        Control.BRAKE to Point(0.80f, 0.80f),
        Control.STEER_CENTER to Point(0.15f, 0.75f),
        Control.GEAR_DRIVE to Point(0.60f, 0.90f),
        Control.GEAR_REVERSE to Point(0.70f, 0.90f),
    )

    private fun box(cx: Float, cy: Float, hx: Float = 0.12f, hy: Float = 0.2f) =
        Roi((cx - hx).coerceAtLeast(0f), (cy - hy).coerceAtLeast(0f), (cx + hx).coerceAtMost(1f), (cy + hy).coerceAtMost(1f))

    /** name -> (centre x, centre y, seed, w px, h px) */
    val FIXED: Map<String, List<Number>> = mapOf(
        "hud_marker" to listOf(0.9f, 0.10f, 4, 20, 20),
        "parking_hud" to listOf(0.1f, 0.9f, 6, 20, 20),
        "delivery_header" to listOf(0.5f, 0.10f, 7, 20, 20),
        "loading_spinner" to listOf(0.5f, 0.5f, 9, 20, 20),
        "dialog_marker" to listOf(0.5f, 0.4f, 10, 20, 20),
        "crash_marker" to listOf(0.5f, 0.45f, 11, 20, 20),
        "parked_ok" to listOf(0.5f, 0.20f, 13, 20, 20),
        "destination_near" to listOf(0.5f, 0.30f, 14, 20, 20),
        "obstacle_ahead" to listOf(0.5f, 0.55f, 15, 20, 20),
    )

    fun templateImages(): MutableMap<String, GrayImage> {
        val m = HashMap<String, GrayImage>()
        for ((n, v) in FIXED) m[n] = Synth.patch(v[2].toInt(), v[3].toInt(), v[4].toInt())
        return m
    }

    fun full(
        steering: SteeringMode = SteeringMode.SLIDER,
        extras: Map<String, String> = emptyMap(),
    ): GameProfile {
        val templates = HashMap<String, TemplateSpec>()
        for ((n, v) in FIXED) templates[n] = TemplateSpec(n, box(v[0].toFloat(), v[1].toFloat()), 0.85f)
        val rules = mapOf(
            GameState.DRIVING to listOf("hud_marker", "!parking_hud"),
            GameState.PARKING to listOf("parking_hud"),
            GameState.DELIVERY_COMPLETE to listOf("delivery_header"),
            GameState.LOADING to listOf("loading_spinner"),
            GameState.UNEXPECTED_DIALOG to listOf("dialog_marker"),
            GameState.CRASH_OR_PENALTY to listOf("crash_marker"),
        )
        val colors = mapOf(
            "parking_zone" to ColorSpec("parking_zone", Roi(0.05f, 0.25f, 0.95f, 0.95f), ColorTarget(0, 200, 0, 30)),
        )
        val nav = NavProfile(Roi(0.0f, 0.5f, 0.3f, 1.0f), ColorTarget(255, 215, 0, 40), 0.15f, 0.95f, 0.8f)
        return GameProfile(
            name = "test", gamePackage = "com.example.game", referenceWidth = FW, templates = templates, colors = colors,
            stateRules = rules, controls = CONTROLS, steeringMode = steering, steerRadius = 0.12f, nav = nav, extras = extras,
        )
    }

    /** [full] without the optional cues, so tests can check the fall-back behaviour. */
    fun minimal(): GameProfile {
        val p = full()
        return p.copy(
            templates = p.templates.filterKeys { it in setOf("hud_marker", "parking_hud") },
            colors = emptyMap(),
            stateRules = mapOf(GameState.DRIVING to listOf("hud_marker", "!parking_hud")),
            controls = p.controls - Control.GEAR_REVERSE - Control.GEAR_DRIVE,
        )
    }
}
