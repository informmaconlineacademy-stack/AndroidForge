package dev.toe3autopilot.core

import dev.toe3autopilot.core.agents.DrivingController
import dev.toe3autopilot.core.agents.NavigationDriveAgent
import dev.toe3autopilot.core.vision.RoadQuality
import dev.toe3autopilot.core.vision.RoadTracker
import dev.toe3autopilot.core.vision.RouteReading
import dev.toe3autopilot.core.vision.TrackedRoad
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

private fun reading(offset: Float, bend: Float = 0f, confidence: Float = 1f, far: Boolean = true) =
    RouteReading(offset, kotlin.math.abs(bend), confidence, far, bend)

class RoadTrackerTest {
    @Test
    fun theFirstGoodReadingIsTakenAsIs() {
        val t = RoadTracker()
        val r = t.update(reading(0.4f, bend = 0.2f), 1000)
        assertEquals(RoadQuality.TRACKING, r.quality)
        assertEquals(0.4f, r.offset, 0.0001f)
        assertEquals(0.2f, r.bend, 0.0001f)
        assertEquals(0.2f, r.curvature, 0.0001f)
        assertEquals(0L, r.missingForMs)
    }

    @Test
    fun readingsAreSmoothedTowardTheNewValue() {
        val t = RoadTracker(smoothing = 0.5f)
        t.update(reading(0f), 0)
        assertEquals(0.25f, t.update(reading(0.5f), 100).offset, 0.0001f)
        assertEquals(0.375f, t.update(reading(0.5f), 200).offset, 0.0001f)
    }

    @Test
    fun noReadingAtAllMeansLostRightAway() {
        val r = RoadTracker().update(null, 0)
        assertEquals(RoadQuality.LOST, r.quality)
        assertEquals(0f, r.confidence, 0f)
    }

    @Test
    fun aWeakReadingCountsAsNotSeen() {
        val t = RoadTracker(minConfidence = 0.25f)
        assertEquals(RoadQuality.LOST, t.update(reading(0.1f, confidence = 0.2f), 0).quality)
        t.update(reading(0.1f), 100)
        val r = t.update(reading(0.9f, confidence = 0.2f), 200)
        assertEquals(RoadQuality.DEGRADED, r.quality)
        assertEquals("a weak reading must not move the held offset", 0.1f, r.offset, 0.0001f)
    }

    @Test
    fun aMissingRouteIsHeldThenDegradedThenLost() {
        val t = RoadTracker(lostMs = 3000)
        t.update(reading(0.3f, bend = 0.1f), 1000)
        val held = t.update(null, 1500)
        assertEquals(RoadQuality.DEGRADED, held.quality)
        assertEquals(0.3f, held.offset, 0.0001f)
        assertEquals(500L, held.missingForMs)
        assertEquals(RoadQuality.DEGRADED, t.update(null, 3900).quality)
        val lost = t.update(null, 4100)
        assertEquals(RoadQuality.LOST, lost.quality)
        assertEquals(3100L, lost.missingForMs)
    }

    @Test
    fun seeingTheRouteAgainRecoversFromLost() {
        val t = RoadTracker()
        t.update(reading(0f), 0)
        assertEquals(RoadQuality.LOST, t.update(null, 10_000).quality)
        val back = t.update(reading(-0.2f), 10_100)
        assertEquals(RoadQuality.TRACKING, back.quality)
        assertEquals(0L, back.missingForMs)
    }

    @Test
    fun aSuddenWeakJumpIsRejectedUntilItPersists() {
        val t = RoadTracker(jumpConfirmFrames = 3)
        t.update(reading(0f), 0)
        val a = t.update(reading(0.95f, confidence = 0.4f), 100)
        val b = t.update(reading(0.95f, confidence = 0.4f), 200)
        assertEquals(RoadQuality.DEGRADED, a.quality)
        assertEquals(RoadQuality.DEGRADED, b.quality)
        assertEquals(0f, b.offset, 0.0001f)
        val c = t.update(reading(0.95f, confidence = 0.4f), 300)
        assertEquals(RoadQuality.TRACKING, c.quality)
        assertTrue("offset ${c.offset}", c.offset > 0.4f)
    }

    @Test
    fun anIsolatedGlitchBetweenGoodReadingsNeverMovesTheOffset() {
        val t = RoadTracker(jumpConfirmFrames = 3)
        t.update(reading(0f), 0)
        t.update(reading(-0.95f, confidence = 0.3f), 100)
        val ok = t.update(reading(0.02f), 200)
        assertEquals(RoadQuality.TRACKING, ok.quality)
        assertTrue(kotlin.math.abs(ok.offset) < 0.05f)
        // The glitch counter restarted: two more glitches are still not enough.
        t.update(reading(0.95f, confidence = 0.3f), 300)
        assertEquals(RoadQuality.DEGRADED, t.update(reading(0.95f, confidence = 0.3f), 400).quality)
    }

    @Test
    fun aStrongJumpIsBelievedImmediately() {
        val t = RoadTracker()
        t.update(reading(0f), 0)
        val r = t.update(reading(0.95f, confidence = 0.9f), 100)
        assertEquals(RoadQuality.TRACKING, r.quality)
        assertTrue(r.offset > 0.4f)
    }

    @Test
    fun routeEndingFollowsTheFarVisibleFlag() {
        val t = RoadTracker()
        assertFalse(t.update(reading(0f, far = true), 0).routeEnding)
        assertTrue(t.update(reading(0f, far = false), 100).routeEnding)
        assertTrue("held while degraded", t.update(null, 200).routeEnding)
    }

    @Test
    fun resetForgetsEverything() {
        val t = RoadTracker()
        t.update(reading(0.5f), 0)
        t.reset()
        assertEquals(RoadQuality.LOST, t.update(null, 100).quality)
        assertEquals(0f, t.update(null, 200).offset, 0f)
    }
}

class DrivingControllerTest {
    private val settings = AutomationSettings(speedLevel = 0.6f, sensitivity = 1f)

    private fun road(
        offset: Float = 0f,
        bend: Float = 0f,
        quality: RoadQuality = RoadQuality.TRACKING,
        ending: Boolean = false,
        missing: Long = 0,
    ) = TrackedRoad(offset, bend, kotlin.math.abs(bend), 1f, ending, quality, missing)

    @Test
    fun steersTowardTheRoute() {
        val right = DrivingController().step(road(0.5f), false, settings, 1f, 1000)
        val left = DrivingController().step(road(-0.5f), false, settings, 1f, 1000)
        assertTrue(right.steer > 0f)
        assertTrue(left.steer < 0f)
        assertEquals(0f, DrivingController().step(road(0f), false, settings, 1f, 1000).steer, 0.001f)
    }

    @Test
    fun aBendAheadSteersIntoItBeforeTheTruckIsOffCentre() {
        val right = DrivingController().step(road(0f, bend = 0.8f), false, settings, 1f, 1000)
        val left = DrivingController().step(road(0f, bend = -0.8f), false, settings, 1f, 1000)
        assertTrue("right ${right.steer}", right.steer > 0.1f)
        assertTrue("left ${left.steer}", left.steer < -0.1f)
        assertEquals(right.steer, -left.steer, 0.0001f)
    }

    @Test
    fun steeringCannotJumpLockToLock() {
        val c = DrivingController(maxSteerRate = 2.5f)
        c.step(road(0f), false, settings, 1f, 1000)
        val out = c.step(road(1f), false, settings, 1f, 1150) // 0.15 s later
        assertTrue("steer ${out.steer}", out.steer <= 2.5f * 0.15f + 0.001f)
        var last = out
        var t = 1150L
        repeat(20) { t += 150; last = c.step(road(1f), false, settings, 1f, t) }
        assertEquals(1f, last.steer, 0.001f)
    }

    @Test
    fun obstacleMeansFullBrakeAndNoThrottle() {
        val out = DrivingController().step(road(0.1f), true, settings, 1f, 1000)
        assertEquals(1f, out.brake, 0f)
        assertEquals(0f, out.throttle, 0f)
    }

    @Test
    fun aHeldRoadReadingSlowsDownAndKeepsTheWheelWhereItIs() {
        val c = DrivingController()
        c.step(road(0.5f), false, settings, 1f, 1000)
        val before = c.currentSteer
        val out = c.step(road(0.5f, quality = RoadQuality.DEGRADED, missing = 800), false, settings, 1f, 1150)
        assertEquals(0f, out.throttle, 0f)
        assertTrue(out.brake in 0.1f..0.9f)
        assertEquals(before, out.steer, 0f)
    }

    @Test
    fun aLostRoadMeansFullBrake() {
        val out = DrivingController().step(road(quality = RoadQuality.LOST, missing = 5000), false, settings, 1f, 1000)
        assertEquals(0f, out.throttle, 0f)
        assertEquals(1f, out.brake, 0f)
    }

    @Test
    fun throttleFollowsSpeedSettingBendsAndTheCap() {
        val straight = DrivingController().step(road(0f, 0f), false, settings, 1f, 1000)
        assertEquals(0.6f, straight.throttle, 0.001f)
        val bend = DrivingController().step(road(0f, bend = 1f), false, settings, 1f, 1000)
        assertTrue(bend.throttle < straight.throttle)
        val capped = DrivingController().step(road(0f, 0f), false, settings, 0.3f, 1000)
        assertEquals(0.3f, capped.throttle, 0.001f)
        val off = DrivingController().step(road(0.8f, 0f), false, settings, 1f, 1000)
        assertTrue(off.throttle < straight.throttle)
        val ending = DrivingController().step(road(0f, 0f, ending = true), false, settings, 1f, 1000)
        assertEquals(0.36f, ending.throttle, 0.001f)
    }

    @Test
    fun theThrottleNeverExceedsTheCeilingEvenInABend() {
        val slow = AutomationSettings(speedLevel = 0.1f)
        val out = DrivingController().step(road(0f, bend = 1f), false, slow, 1f, 1000)
        assertTrue("throttle ${out.throttle}", out.throttle <= 0.1f + 0.0001f)
        assertTrue(out.throttle > 0f)
        val capped = DrivingController().step(road(0f, bend = 1f), false, settings, 0.12f, 1000)
        assertTrue(capped.throttle <= 0.12f + 0.0001f)
    }

    @Test
    fun sensitivityScalesSteering() {
        val lo = DrivingController().step(road(0.1f), false, settings.copy(sensitivity = 0.5f), 1f, 1000).steer
        val hi = DrivingController().step(road(0.1f), false, settings.copy(sensitivity = 2f), 1f, 1000).steer
        assertTrue("lo $lo hi $hi", hi > lo * 3.5f)
    }

    @Test
    fun resetClearsTheWheel() {
        val c = DrivingController()
        repeat(5) { c.step(road(1f), false, settings, 1f, 1000L + it * 150) }
        assertTrue(c.currentSteer > 0.3f)
        c.reset()
        assertEquals(0f, c.currentSteer, 0f)
    }
}

class NavigationDriveAgentTest {
    private val settings = AutomationSettings(speedLevel = 0.6f, sensitivity = 1f)

    private fun drive(d: Decision) = (d as Decision.Drive)

    @Test
    fun followsTheRouteAndReportsIt() {
        val agent = NavigationDriveAgent()
        val v = FakeVision().also { it.routeReading = reading(0.4f) }
        val d = drive(agent.decide(v, settings, 1f, 1000))
        assertEquals("Following the route", d.note)
        assertTrue(d.command.steer > 0f)
        assertTrue(d.command.throttle > 0f)
        assertEquals(RoadQuality.TRACKING, agent.road!!.quality)
    }

    @Test
    fun theApproachCapSlowsTheTruckAndSaysSo() {
        val agent = NavigationDriveAgent()
        val v = FakeVision().also { it.routeReading = reading(0f) }
        val d = drive(agent.decide(v, settings, 0.25f, 1000))
        assertEquals(0.25f, d.command.throttle, 0.001f)
        assertTrue(d.note.contains("Approaching"))
    }

    @Test
    fun slowsForBends() {
        val agent = NavigationDriveAgent()
        val v = FakeVision().also { it.routeReading = reading(0f, bend = 0.7f) }
        val d = drive(agent.decide(v, settings, 1f, 1000))
        assertTrue(d.command.throttle < 0.6f * 0.6f)
        assertTrue(d.note.contains("Bend"))
    }

    @Test
    fun anObstacleCueBrakesAndAsksForHelpWhenItStays() {
        val agent = NavigationDriveAgent()
        val v = FakeVision().also { it.routeReading = reading(0f) }
        v.put("obstacle_ahead", 0.5f, 0.5f)
        assertEquals(1f, drive(agent.decide(v, settings, 1f, 1000)).command.brake, 0f)
        assertEquals(1f, drive(agent.decide(v, settings, 1f, 15_000)).command.brake, 0f)
        assertTrue(agent.decide(v, settings, 1f, 22_000) is Decision.NeedHelp)
        // A cue that goes away restarts the timer.
        v.remove("obstacle_ahead")
        assertTrue(agent.decide(v, settings, 1f, 22_150) is Decision.Drive)
    }

    @Test
    fun aMissingRouteBrakesThenStopsAndAsksForHelp() {
        val agent = NavigationDriveAgent()
        val v = FakeVision()
        val first = drive(agent.decide(v, settings, 1f, 0))
        assertEquals(0f, first.command.throttle, 0f)
        assertEquals(1f, first.command.brake, 0f)
        assertTrue(agent.decide(v, settings, 1f, 5000) is Decision.Drive)
        val help = agent.decide(v, settings, 1f, 6500)
        assertTrue(help is Decision.NeedHelp)
        assertTrue(help.note.contains("Lost track of the road"))
        // Seeing the route again resets everything.
        v.routeReading = reading(0f)
        assertTrue(agent.decide(v, settings, 1f, 7000) is Decision.Drive)
    }

    @Test
    fun aRouteThatFlickersOutForAMomentOnlySlowsTheTruck() {
        val agent = NavigationDriveAgent()
        val v = FakeVision().also { it.routeReading = reading(0f) }
        agent.decide(v, settings, 1f, 1000)
        v.routeReading = null
        val d = drive(agent.decide(v, settings, 1f, 1500))
        assertEquals(0f, d.command.throttle, 0f)
        assertTrue(d.command.brake in 0.1f..0.9f)
        assertTrue(d.note.contains("unclear"))
        v.routeReading = reading(0f)
        val back = drive(agent.decide(v, settings, 1f, 1700))
        assertTrue(back.command.throttle > 0f)
    }

    @Test
    fun aWeakRouteReadingNeverSteers() {
        val agent = NavigationDriveAgent()
        val v = FakeVision().also { it.routeReading = reading(0f) }
        val before = drive(agent.decide(v, settings, 1f, 1000)).command.steer
        v.routeReading = reading(0.9f, confidence = 0.1f)
        val d = drive(agent.decide(v, settings, 1f, 1150))
        assertEquals(before, d.command.steer, 0f)
        assertEquals(0f, d.command.throttle, 0f)
    }
}
