package dev.toe3autopilot.core

import dev.toe3autopilot.core.vision.Roi
import java.io.File
import kotlin.system.exitProcess

/**
 * Command-line probe: runs Auto-Calibrate's detector on screenshots and writes what it proposes.
 *
 *     FixtureProbe [--out DIR] [--exclude x0,y0,x1,y1]... PICTURE.png...
 *
 * Several pictures are analysed together (like live collection); one picture uses the weaker single-picture path.
 * `--exclude` marks HaulPilot's own button or panels visible in the screenshot (fractions of the picture). For each run a
 * text report and an annotated, 3x enlarged picture are written to DIR (default: ./fixture-reports).
 * tools/probe-screenshot.sh compiles and runs this without Gradle; with Gradle, put the picture in
 * app/src/test/resources/fixtures/toe3 and run the RealScreenshotTest instead.
 */
fun main(args: Array<String>) {
    var out = File("fixture-reports")
    val exclusions = ArrayList<Roi>()
    val pictures = ArrayList<File>()
    var i = 0
    while (i < args.size) {
        when (args[i]) {
            "--out" -> out = File(args[++i])
            "--exclude" -> {
                val v = args[++i].split(",").map { it.trim().toFloat() }
                require(v.size == 4) { "--exclude needs x0,y0,x1,y1 as fractions of the picture" }
                exclusions += Roi(v[0], v[1], v[2], v[3])
            }
            else -> pictures += File(args[i])
        }
        i++
    }
    if (pictures.isEmpty()) {
        System.err.println("usage: FixtureProbe [--out DIR] [--exclude x0,y0,x1,y1]... PICTURE.png...")
        exitProcess(2)
    }
    val frames = pictures.mapIndexed { k, f -> RealScreenshots.load(f, k * 330L) }
    require(frames.all { it.width == frames[0].width && it.height == frames[0].height }) { "all pictures must have the same size" }
    val name = pictures.first().nameWithoutExtension + if (pictures.size > 1) "_x${pictures.size}" else ""
    val case = RealScreenshots.Case(name, pictures, null)
    val r = RealScreenshots.analyse(frames, exclusions)
    val spec = RealScreenshots.Spec("probe", emptyMap(), emptyMap(), emptySet(), exclusions.withIndex().associate { "exclude${it.index + 1}" to it.value }, emptyMap())
    val text = RealScreenshots.report(case, frames, r, null)
    print(text)
    out.mkdirs()
    File(out, "$name.txt").writeText(text)
    RealScreenshots.annotate(frames.last(), r, spec, File(out, "$name.png"))
    println("wrote ${File(out, "$name.png").path} and ${File(out, "$name.txt").path}")
}
