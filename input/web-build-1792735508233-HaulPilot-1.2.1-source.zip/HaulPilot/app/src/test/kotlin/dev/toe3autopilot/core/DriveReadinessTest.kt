package dev.toe3autopilot.core

import dev.toe3autopilot.core.session.SessionSnapshot
import dev.toe3autopilot.core.session.SessionStatus
import dev.toe3autopilot.core.status.DriveReadiness
import dev.toe3autopilot.core.status.PrereqAction
import dev.toe3autopilot.core.status.PrereqKey
import dev.toe3autopilot.core.status.ReadinessInputs
import dev.toe3autopilot.core.status.ReadinessTone
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DriveReadinessTest {
    private fun inputs(
        status: SessionStatus = SessionStatus.IDLE,
        profile: String? = "Truck",
        problems: List<String> = emptyList(),
        access: Boolean = true,
        assisted: Boolean = false,
        game: String = "com.example.game",
        capture: Boolean = true,
        busy: Boolean = false,
        armed: Boolean = false,
        count: Int = if (profile == null) 0 else 1,
        captureProblem: String? = null,
    ) = ReadinessInputs(SessionSnapshot(status = status), armed, count, profile, problems, access, assisted, game, capture, busy, captureProblem)

    @Test
    fun `a connected screen alone is never ready`() {
        val v = DriveReadiness.of(inputs(profile = null, problems = listOf("No calibration profile yet"), access = false, capture = true))
        assertFalse(v.canStart)
        assertNotEquals("Ready to drive", v.headline)
        assertFalse(v.headline.contains("Ready"))
        assertTrue(v.items.first { it.key == PrereqKey.CAPTURE }.ok)
        assertEquals(PrereqAction.OPEN_SETUP, v.items.first { it.key == PrereqKey.PROFILE }.action)
    }

    @Test
    fun `ready only when every prerequisite holds`() {
        val v = DriveReadiness.of(inputs())
        assertTrue(v.canStart)
        assertEquals("Ready to drive", v.headline)
        assertEquals(ReadinessTone.GOOD, v.tone)
        assertTrue(v.unmet.isEmpty())
    }

    @Test
    fun `each single missing prerequisite blocks start`() {
        val cases = listOf(
            inputs(profile = null, count = 2) to PrereqKey.PROFILE,
            inputs(problems = listOf("The minimap is not set up")) to PrereqKey.SETUP_COMPLETE,
            inputs(access = false) to PrereqKey.TOUCH,
            inputs(game = "") to PrereqKey.GAME,
            inputs(capture = false) to PrereqKey.CAPTURE,
            inputs(busy = true) to PrereqKey.SETUP_IDLE,
        )
        for ((i, key) in cases) {
            val v = DriveReadiness.of(i)
            assertFalse("$key should block", v.canStart)
            assertTrue("$key should be listed as unmet", v.unmet.any { it.key == key })
            assertNotEquals("Ready to drive", v.headline)
        }
    }

    @Test
    fun `assisted mode replaces the accessibility requirement`() {
        val v = DriveReadiness.of(inputs(access = false, assisted = true))
        assertTrue(v.canStart)
    }

    @Test
    fun `profile with problems names them and points to setup`() {
        val v = DriveReadiness.of(inputs(problems = listOf("a", "b", "c", "d")))
        val p = v.items.first { it.key == PrereqKey.SETUP_COMPLETE }
        assertFalse(p.ok)
        assertTrue(p.detail.contains("a; b"))
        assertTrue(p.detail.contains("2 more"))
        assertEquals(PrereqAction.OPEN_SETUP, p.action)
    }

    @Test
    fun `live drive never offers start and resume needs prerequisites`() {
        val running = DriveReadiness.of(inputs(status = SessionStatus.RUNNING))
        assertTrue(running.live)
        assertFalse(running.canStart)
        assertEquals("Driving", running.headline)

        val paused = DriveReadiness.of(inputs(status = SessionStatus.PAUSED))
        assertTrue(paused.live)
        assertTrue(paused.canResume)

        val pausedNoCapture = DriveReadiness.of(inputs(status = SessionStatus.PAUSED, capture = false))
        assertFalse(pausedNoCapture.canResume)

        val armed = DriveReadiness.of(inputs(armed = true))
        assertTrue(armed.live)
        assertFalse(armed.canStart)
        assertEquals("Starting", armed.headline)
    }

    @Test
    fun `a connected screen that delivers black pictures is not ready, and the reason is shown`() {
        val ok = DriveReadiness.of(inputs(profile = "P"))
        assertTrue(ok.canStart)
        val bad = DriveReadiness.of(inputs(profile = "P", captureProblem = "The game arrives black. The game may block screen capture."))
        assertFalse(bad.canStart)
        assertFalse(bad.headline.contains("Ready"))
        val cap = bad.items.first { it.key == PrereqKey.CAPTURE }
        assertFalse(cap.ok)
        assertTrue(cap.detail, cap.detail.contains("black"))
        assertEquals(PrereqAction.CONNECT_CAPTURE, cap.action)
    }
}
