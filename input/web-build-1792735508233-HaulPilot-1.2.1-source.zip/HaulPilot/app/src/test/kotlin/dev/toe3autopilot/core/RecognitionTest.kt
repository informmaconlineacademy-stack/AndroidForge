package dev.toe3autopilot.core

import dev.toe3autopilot.core.calibration.CalibRole
import dev.toe3autopilot.core.calibration.LayoutSignature
import dev.toe3autopilot.core.profile.GameProfile
import dev.toe3autopilot.core.session.SessionStatus
import dev.toe3autopilot.core.setup.DraftApply
import dev.toe3autopilot.core.setup.DraftEdits
import dev.toe3autopilot.core.setup.FrameEntry
import dev.toe3autopilot.core.setup.FrameOriginKind
import dev.toe3autopilot.core.setup.ScreenEvidence
import dev.toe3autopilot.core.setup.SetupDraft
import dev.toe3autopilot.core.setup.StabilityMap
import dev.toe3autopilot.core.state.FrameChecks
import dev.toe3autopilot.core.state.FrameValidity
import dev.toe3autopilot.core.state.GameState
import dev.toe3autopilot.core.state.RecognitionDiagnosis
import dev.toe3autopilot.core.state.StateDetector
import dev.toe3autopilot.core.vision.Frame
import dev.toe3autopilot.core.vision.Match
import dev.toe3autopilot.core.vision.ProfileVision
import dev.toe3autopilot.core.vision.Roi
import dev.toe3autopilot.core.vision.TemplateProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.cos
import kotlin.math.sin

/**
 * A driving view whose scenery changes strongly from picture to picture, seen through TRANSLUCENT controls (a dark fill at
 * 45 % over the scenery, an outline and a symbol on top). This is the case the first calibration got wrong: a look-alike
 * picture cut from one screenshot contains the scenery that happened to be behind the control. Synthetic, on purpose harsh.
 */
class TexturedHud(val w: Int = 320, val h: Int = 180, val fillAlpha: Float = 0.45f, val ringAlpha: Float = 0.75f, val symbolAlpha: Float = 0.7f) {
    val accel = Roi(0.86f, 0.58f, 0.96f, 0.97f)
    val brake = Roi(0.73f, 0.66f, 0.83f, 0.97f)
    val steerLeft = Roi(0.03f, 0.72f, 0.12f, 0.95f)

    private fun hash(i: Int): Int {
        var x = i * 374761393
        x = (x xor (x ushr 13)) * 1274126177
        return (x xor (x ushr 16)) and 0xFF
    }

    private fun scenery(x: Int, y: Int, t: Int): Float {
        val a = 45f * sin(x * 0.09f + t * 1.3f) * cos(y * 0.11f - t * 0.9f)
        val b = 35f * sin((x + y) * 0.05f + t * 2.1f)
        val n = (hash(x * 977 + y * 131 + t * 7919) - 128) / 20f
        return (110f + a + b + n).coerceIn(20f, 235f)
    }

    private fun put(px: IntArray, x: Int, y: Int, v: Float) {
        val g = v.coerceIn(0f, 255f).toInt()
        px[y * w + x] = (0xFF shl 24) or (g shl 16) or (g shl 8) or g
    }

    private fun lum(px: IntArray, x: Int, y: Int) = (px[y * w + x] and 0xFF).toFloat()

    private fun pedal(px: IntArray, r: Roi) {
        val x0 = (r.left * w).toInt(); val x1 = (r.right * w).toInt()
        val y0 = (r.top * h).toInt(); val y1 = (r.bottom * h).toInt()
        for (y in y0 until y1) for (x in x0 until x1) put(px, x, y, lum(px, x, y) * (1f - fillAlpha)) // translucent dark fill
        for (y in y0 until y1) for (x in x0 until x1) {
            val edge = x - x0 < 2 || x1 - 1 - x < 2 || y - y0 < 2 || y1 - 1 - y < 2
            if (edge) put(px, x, y, ringAlpha * 235f + (1f - ringAlpha) * lum(px, x, y))
        }
        val cx = (x0 + x1) / 2
        for (k in 0 until 3) {
            val yy = y0 + (y1 - y0) / 3 + k * 5
            for (x in cx - 6..cx + 6) put(px, x, yy, symbolAlpha * 235f + (1f - symbolAlpha) * lum(px, x, yy))
        }
    }

    fun frame(t: Int, light: Float = 1f, hud: Boolean = true, ts: Long = t * 330L): Frame {
        val px = IntArray(w * h)
        for (y in 0 until h) for (x in 0 until w) put(px, x, y, scenery(x, y, t))
        if (hud) {
            pedal(px, accel)
            pedal(px, brake)
        }
        if (light != 1f) for (i in px.indices) {
            val g = ((px[i] and 0xFF) * light).toInt().coerceIn(0, 255)
            px[i] = (0xFF shl 24) or (g shl 16) or (g shl 8) or g
        }
        return Frame(w, h, px, ts)
    }

    /** A game menu: flat panels, text-like bars, no HUD, no scenery. */
    fun menu(): Frame {
        val px = IntArray(w * h) { (0xFF shl 24) or (40 shl 16) or (44 shl 8) or 52 }
        for (k in 0 until 6) for (y in 20 + k * 24 until 36 + k * 24) for (x in 40 until 40 + 120 + (k % 3) * 40) {
            px[y * w + x] = (0xFF shl 24) or (200 shl 16) or (200 shl 8) or 205
        }
        return Frame(w, h, px, 0L)
    }
}

class RecognitionTest {
    /** Medium see-through controls (fill 30 %, outline 50 %, symbol 45 %) over scenery that changes by ~33 grey levels. */
    private val scene = TexturedHud(fillAlpha = 0.3f, ringAlpha = 0.5f, symbolAlpha = 0.45f)

    private fun entry(i: Int, f: Frame) = FrameEntry(i, f, FrameOriginKind.LIVE, 0.4f, ScreenEvidence.MOVING)

    private class Calibrated(val profile: GameProfile, val store: MapTemplateStore, val warnings: List<String>, val applied: List<String>)

    private fun calibrate(masked: Boolean, light: Float = 1f): Calibrated {
        val frames = (0 until 30).map { scene.frame(it, light) }
        val picture = frames.last()
        var d = SetupDraft(layout = LayoutSignature(scene.w, scene.h))
        d = DraftEdits.place(d, CalibRole.ACCELERATOR, 0.91f, 0.78f, scene.accel)
        d = DraftEdits.place(d, CalibRole.BRAKE, 0.78f, 0.82f, scene.brake)
        val stability = if (masked) StabilityMap.of(frames.mapIndexed(::entry), picture) else null
        if (masked) assertNotNull("30 pictures with moving scenery give a stability map", stability)
        val r = DraftApply.apply(null, d, picture, "t", "g", 0L, null, stability)
        assertTrue(r.problem, r.ok)
        val store = MapTemplateStore(HashMap(TestProfiles.templateImages()))
        for ((n, img) in r.patches) store.map[n] = img
        return Calibrated(r.profile!!, store, r.warnings, r.applied)
    }

    private fun markerHit(c: Calibrated, f: Frame): Match? {
        val spec = c.profile.templates.getValue("hud_marker")
        val provider = TemplateProvider(c.store, c.profile.referenceWidth)
        return provider.all(f.toGray(), "hud_marker", f.width, spec.roi, spec.minScore, 1, masked = c.profile.templates.containsKey("hud_marker_mask")).firstOrNull()
    }

    private fun markerScore(c: Calibrated, f: Frame): Float {
        val spec = c.profile.templates.getValue("hud_marker")
        val provider = TemplateProvider(c.store, c.profile.referenceWidth)
        return provider.all(f.toGray(), "hud_marker", f.width, spec.roi, -1f, 1, masked = c.profile.templates.containsKey("hud_marker_mask")).firstOrNull()?.score ?: -1f
    }

    private fun share(c: Calibrated, frames: List<Frame>) = frames.count { markerHit(c, it) != null }.toFloat() / frames.size

    private fun detectorRun(c: Calibrated, frames: List<Frame>): List<GameState> {
        val det = StateDetector(c.profile)
        val provider = TemplateProvider(c.store, c.profile.referenceWidth)
        return frames.map { f -> det.update(ProfileVision(c.profile, provider, f, { 0.3f }, null)).state }
    }

    // ---- the mechanism -----------------------------------------------------------------------------------------------

    @Test
    fun aPatchCutFromOnePictureIsUnreliableOnNewPicturesButTheSteadyWeightedPatchKeepsMatching() {
        val live = (100 until 130).map { scene.frame(it) }
        val raw = calibrate(masked = false)
        val steady = calibrate(masked = true)
        val rawShare = share(raw, live)
        val steadyShare = share(steady, live)
        println("marker recognised on new driving pictures: raw patch ${"%.0f".format(rawShare * 100)} %, steady pixels ${"%.0f".format(steadyShare * 100)} %")
        assertTrue("the old way is unreliable on this scenery ($rawShare)", rawShare < 0.6f)
        assertTrue("steady pixels recognise it ($steadyShare)", steadyShare >= 0.95f)
        assertTrue(steady.profile.templates.containsKey("hud_marker_mask"))
        assertTrue(steady.applied.toString(), steady.applied.any { it.contains("weighted by how steady") })
        assertFalse("the single-picture way says so", raw.warnings.none { it.contains("single picture") })
    }

    @Test
    fun aFaintSeeThroughControlStillSeparatesFromAScreenWithoutIt_andTheThresholdNeverDropsBelowTheSessionMinimum() {
        val faint = TexturedHud(fillAlpha = 0.2f, ringAlpha = 0.35f, symbolAlpha = 0.3f)
        val frames = (0 until 30).map { faint.frame(it) }
        var d = SetupDraft(layout = LayoutSignature(faint.w, faint.h))
        d = DraftEdits.place(d, CalibRole.ACCELERATOR, 0.91f, 0.78f, faint.accel)
        d = DraftEdits.place(d, CalibRole.BRAKE, 0.78f, 0.82f, faint.brake)
        val st = StabilityMap.of(frames.mapIndexed(::entry), frames.last())!!
        val r = DraftApply.apply(null, d, frames.last(), "t", "g", 0L, null, st)
        assertTrue(r.problem, r.ok)
        val spec = r.profile!!.templates.getValue("hud_marker")
        assertTrue("threshold ${spec.minScore} stays between the session minimum and the default", spec.minScore >= 0.7f && spec.minScore <= 0.8f)
        val c = Calibrated(r.profile!!, MapTemplateStore(HashMap(TestProfiles.templateImages()).also { m -> r.patches.forEach { (n, i) -> m[n] = i } }), r.warnings, r.applied)
        val present = (100 until 130).map { markerScore(c, faint.frame(it)) }
        val absent = (100 until 130).map { markerScore(c, faint.frame(it, hud = false)) }
        println("faint control, weighted marker score: present min ${"%.2f".format(present.min())} median ${"%.2f".format(present.sorted()[15])}; without the HUD max ${"%.2f".format(absent.max())}; threshold ${spec.minScore}")
        assertTrue("absent stays far below present", absent.max() + 0.3f < present.sorted()[15])
        assertTrue("never accepted when the HUD is missing", absent.all { it < spec.minScore })
    }

    @Test
    fun theControlPatchesAreMaskedToo_soTheLaterControlsCheckDoesNotFalselyAlarm() {
        val steady = calibrate(masked = true)
        assertTrue(steady.profile.templates.containsKey("ctl_accelerator_mask"))
        val provider = TemplateProvider(steady.store, steady.profile.referenceWidth)
        val f = scene.frame(150)
        val v = dev.toe3autopilot.core.calibration.LayoutCheck.verifyControls(steady.profile, f.toGray(), provider, f.width)
        assertEquals(2, v.evaluated)
        assertEquals("both controls found where saved: ${v.scores}", 2, v.matched)
        val raw = calibrate(masked = false)
        val vr = dev.toe3autopilot.core.calibration.LayoutCheck.verifyControls(raw.profile, f.toGray(), TemplateProvider(raw.store, raw.profile.referenceWidth), f.width)
        println("controls check on a new picture: raw ${vr.matched}/${vr.evaluated} ${vr.scores}; steady ${v.matched}/${v.evaluated} ${v.scores}")
    }

    @Test
    fun theDrivingScreenIsRecognisedAndStaysRecognisedAcrossManyDrivingPictures() {
        val c = calibrate(masked = true)
        val states = detectorRun(c, (100 until 140).map { scene.frame(it) })
        val driving = states.count { it == GameState.DRIVING }
        assertTrue("DRIVING in $driving of ${states.size}", driving >= states.size - 3)
        assertEquals(GameState.DRIVING, states.last())
    }

    // ---- dark but valid frames; invalid frames ---------------------------------------------------------------------------

    @Test
    fun aDarkDrivingPictureIsValidAndStillRecognised() {
        val c = calibrate(masked = true)
        for (light in listOf(0.5f, 0.3f, 0.2f)) {
            val night = (100 until 120).map { scene.frame(it, light) }
            assertEquals("light $light", FrameValidity.VALID_DARK, FrameChecks.assess(night[0]).takeIf { light <= 0.3f } ?: FrameValidity.VALID_DARK)
            assertTrue("light $light is a usable picture", night.all { FrameChecks.assess(it).usable })
            val s = share(c, night)
            assertTrue("night driving pictures (light $light) recognised: $s", s >= 0.9f)
        }
        val dark = scene.frame(105, 0.25f)
        assertEquals(FrameValidity.VALID_DARK, FrameChecks.assess(dark))
    }

    @Test
    fun aFaintHudOnABlackWorldIsNotMistakenForABlackCapture() {
        val px = IntArray(320 * 180) { (0xFF shl 24) }
        for (y in 120 until 170) for (x in 250 until 300) px[y * 320 + x] = (0xFF shl 24) or (14 shl 16) or (14 shl 8) or 14
        val v = FrameChecks.assess(Frame(320, 180, px, 0L))
        assertTrue("a faint HUD on a black world is a usable (dark) picture: $v", v.usable)
    }

    @Test
    fun blackAndFlatCapturesAreInvalidAndMenusAndOtherAppsAreNeverTheDrivingView() {
        val c = calibrate(masked = true)
        val black = Frame(320, 180, IntArray(320 * 180) { 0xFF000000.toInt() }, 0L)
        val flat = Frame(320, 180, IntArray(320 * 180) { (0xFF shl 24) or (90 shl 16) or (90 shl 8) or 92 }, 0L)
        assertEquals(FrameValidity.BLACK, FrameChecks.assess(black))
        assertEquals(FrameValidity.FLAT, FrameChecks.assess(flat))
        assertFalse(FrameChecks.assess(black).usable)
        assertFalse(FrameChecks.assess(flat).usable)

        val notDriving = listOf(black, flat, scene.menu(), scene.frame(7, hud = false)) // black, flat, a menu, scenery without any HUD
        for (f in notDriving) assertNull("must not be recognised as the marker", markerHit(c, f))
        val states = detectorRun(c, (0 until 12).map { notDriving[it % notDriving.size] })
        assertTrue("never accepted as driving: $states", states.none { it.drivingLike })
    }

    // ---- flicker -------------------------------------------------------------------------------------------------------------

    @Test
    fun aMarkerScoreThatFlickersAroundItsThresholdStillEntersTheDrivingViewButAMenuNeverDoes() {
        val profile = TestProfiles.full()
        val det = StateDetector(profile)
        fun look(hit: Boolean) = FakeVision().also { if (hit) it.put("hud_marker", 0.9f, 0.1f, 0.85f) else it.knownNames += "hud_marker" }
        // hit, miss, hit, miss, hit: never two in a row, three of the last five.
        val seq = listOf(true, false, true, false, true)
        val states = seq.map { det.update(look(it)).state }
        assertEquals(GameState.DRIVING, states.last())
        // Leaving is still quick: two pictures in a row without it.
        det.update(look(false))
        assertEquals(GameState.UNKNOWN, det.update(look(false)).state)
        // A menu (no marker at all) never enters.
        val d2 = StateDetector(profile)
        repeat(10) { assertFalse(d2.update(look(false)).state.drivingLike) }
    }

    // ---- timeout: reason, last picture, retry ---------------------------------------------------------------------------

    @Test
    fun theTimeoutShowsTheLastPictureTheReasonAndRetryWorks() {
        val rig = Rig().withRoute()
        rig.show("dialog_marker") // some other screen: the game shows a pop-up, not the driving view
        assertTrue(rig.session.start().ok)
        rig.run(16_000)
        assertEquals(SessionStatus.NEEDS_ASSIST, rig.status())
        assertEquals(HelpKind.SCREEN_UNKNOWN, rig.session.currentSnapshot().helpKind)
        val rep = rig.reports.single()
        assertNotNull("the last picture is kept for the screen", rep.frame)
        assertTrue(rep.reason, rep.reason.isNotBlank())
        assertTrue(rep.advice.isNotEmpty())
        assertTrue("the message the person reads includes the reason", rig.session.currentSnapshot().task.contains(rep.reason))
        assertTrue(rep.evidenceLines().any { it.contains("hud_marker") })
        assertTrue(rig.input.holds.isEmpty() && rig.input.taps.isEmpty())
        // Retry: back on the driving view, resume works and recognition succeeds.
        rig.show("hud_marker")
        assertTrue(rig.session.resume().ok)
        rig.run(2000)
        assertEquals(SessionStatus.RUNNING, rig.status())
    }

    @Test
    fun aBlackCaptureIsReportedAsACaptureProblemNotAsAWrongScreen() {
        val rig = Rig().withRoute()
        rig.show("hud_marker")
        assertTrue(rig.session.start().ok)
        rig.frames.frame = Frame(320, 180, IntArray(320 * 180) { 0xFF000000.toInt() }, rig.clock.now)
        // black pictures keep arriving
        var t = 0L
        while (t < 16_000 && rig.status() == SessionStatus.STARTING) {
            rig.clock.advance(100); t += 100
            rig.frames.frame = Frame(320, 180, IntArray(320 * 180) { 0xFF000000.toInt() }, rig.clock.now)
            rig.session.tick()
        }
        assertEquals(SessionStatus.NEEDS_ASSIST, rig.status())
        val rep = rig.reports.single()
        assertEquals(FrameValidity.BLACK, rep.validity)
        assertTrue(rep.reason, rep.reason.contains("capture problem"))
        assertTrue("black pictures are counted as unusable, not as 'wrong screen'", rep.unusable > 0 && rep.seen == 0)
    }

    @Test
    fun startIsRefusedWhileTheNewestPictureIsBlackEvenWithACompleteProfile() {
        val rig = Rig().withRoute()
        rig.show("hud_marker")
        rig.frames.frame = Frame(320, 180, IntArray(320 * 180) { 0xFF000000.toInt() }, rig.clock.now)
        val r = rig.session.start()
        assertFalse(r.ok)
        assertTrue(r.problems.toString(), r.problems.any { it.contains("black") && it.contains("capture problem") })
        assertTrue(rig.input.holds.isEmpty() && rig.input.taps.isEmpty())
        // A real game picture: the same profile starts.
        rig.show("hud_marker")
        assertTrue(rig.session.start().ok)
    }

    @Test
    fun theReportNamesTheMarkerScoreAndWhatToDo() {
        val c = calibrate(masked = false)
        val provider = TemplateProvider(c.store, c.profile.referenceWidth)
        val other = scene.frame(7) // driving view, different scenery: raw patch scores low
        val rep = RecognitionDiagnosis.explain(c.profile, provider, listOf(other), GameState.UNKNOWN, 0f, 0, 3, 0, true, 0.7f, 1L)
        assertTrue(rep.reason, rep.reason.contains("marker") && rep.reason.contains("%"))
        assertTrue(rep.advice.any { it.contains("Auto-Calibrate") })
        assertEquals("hud_marker", rep.items.first().template)
        assertFalse(rep.items.first().ok)
    }
}
