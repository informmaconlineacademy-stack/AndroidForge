package dev.toe3autopilot.core

import dev.toe3autopilot.core.calibration.CalibRole
import dev.toe3autopilot.core.calibration.ControlDetection
import dev.toe3autopilot.core.calibration.DetectionSource
import dev.toe3autopilot.core.calibration.DetectionStatus
import dev.toe3autopilot.core.calibration.VideoCalibrationAnalyzer
import dev.toe3autopilot.core.calibration.VideoInfo
import dev.toe3autopilot.core.calibration.VideoSamplePlan
import dev.toe3autopilot.core.calibration.VideoValidator
import dev.toe3autopilot.core.profile.GameProfile
import dev.toe3autopilot.core.vision.Frame
import dev.toe3autopilot.core.vision.Roi
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.math.abs

private val INFO = VideoInfo(durationMs = 10_000, width = 320, height = 180)

/** 40 pictures, 250 ms apart: idle, then accelerator held while the scenery moves, then idle again. */
private fun clip(scene: SynthHud = SynthHud(), pressAccel: Boolean = true, moveScenery: Boolean = true): List<Frame> =
    (0 until 40).map { k ->
        val going = k in 10..29
        scene.frame(k, k * 250L, moving = going && moveScenery, pressed = if (going && pressAccel) setOf("accel") else emptySet(), speed = k * 7)
    }

class VideoSamplePlanTest {
    @Test
    fun tenSecondClipGivesFortyOrderedSamplesInsideTheClip() {
        val t = VideoSamplePlan.timestampsMs(10_000)
        assertEquals(40, t.size)
        assertTrue(t.zipWithNext().all { (a, b) -> b > a })
        assertTrue(t.first() >= 0 && t.last() < 10_000)
    }

    @Test
    fun shortClipsAreSampledNoCloserThanTheMinimumSpacing() {
        val t = VideoSamplePlan.timestampsMs(3_000)
        assertEquals(25, t.size)
        assertTrue(t.zipWithNext().all { (a, b) -> b - a >= VideoSamplePlan.MIN_SPACING_MS - 1 })
    }

    @Test
    fun longClipsUseTheirMiddleAndNeverMoreThanTheCap() {
        val t = VideoSamplePlan.timestampsMs(100_000)
        assertTrue(t.size <= VideoSamplePlan.MAX_FRAMES)
        assertTrue(t.first() >= 35_000 - 1 && t.last() <= 65_000)
    }

    @Test
    fun nonsenseDurationsGiveNothing() {
        assertTrue(VideoSamplePlan.timestampsMs(0).isEmpty())
        assertTrue(VideoSamplePlan.timestampsMs(-5).isEmpty())
    }
}

class VideoValidatorTest {
    @Test
    fun goodInfoIsAccepted() {
        val r = VideoValidator.checkInfo(INFO)
        assertTrue(r.usable)
        assertTrue(r.problems.isEmpty())
    }

    @Test
    fun invalidFilesAreRejectedWithReasons() {
        assertFalse(VideoValidator.checkInfo(VideoInfo(10_000, 320, 180, hasVideoTrack = false)).usable)
        assertTrue(VideoValidator.checkInfo(VideoInfo(1_000, 320, 180)).problems.first().contains("long"))
        assertFalse(VideoValidator.checkInfo(VideoInfo(10_000, 0, 0)).usable)
        assertFalse(VideoValidator.checkInfo(VideoInfo(11 * 60_000L, 320, 180)).usable)
    }

    @Test
    fun longClipOnlyWarns() {
        val r = VideoValidator.checkInfo(VideoInfo(90_000, 320, 180))
        assertTrue(r.usable)
        assertTrue(r.warnings.any { it.contains("middle") })
    }

    @Test
    fun tooFewDecodedPicturesIsUnusableAndSaysSo() {
        val r = VideoValidator.checkFrames(INFO, 40, clip().take(4))
        assertFalse(r.usable)
        assertTrue(r.problems.first().contains("4 of 40"))
        assertTrue(r.advice().isNotEmpty())
    }

    @Test
    fun aMostlyBlackVideoIsUnusable() {
        val frames = (0 until 30).map { if (it < 20) Frame.solid(320, 180, 0, it * 250L) else clip()[it] }
        val r = VideoValidator.checkFrames(INFO, 30, frames)
        assertFalse(r.usable)
        assertTrue(r.problems.any { it.contains("black") })
    }

    @Test
    fun aFewBlackPicturesAreIgnoredWithAWarning() {
        val frames = clip().toMutableList().also { it[3] = Frame.solid(320, 180, 0) }
        val r = VideoValidator.checkFrames(INFO, 40, frames)
        assertTrue(r.usable)
        assertEquals(1, r.blackFrames)
        assertEquals(39, VideoValidator.usableFrames(frames).size)
    }

    @Test
    fun mixedSizesAreRefused() {
        val frames = clip().toMutableList().also { it[5] = SynthHud(w = 200, h = 100).frame(5, 0, true) }
        assertFalse(VideoValidator.checkFrames(INFO, 40, frames).usable)
    }
}

class VideoCalibrationAnalyzerTest {
    @Test
    fun findsTheAcceleratorFromItsPressedStateAndTheScenerySpeedingUp() {
        val scene = SynthHud()
        val res = VideoCalibrationAnalyzer.analyse(INFO, 40, clip(scene))
        assertTrue(res.report.problems.joinToString(), res.report.usable)
        val d = res.detections[CalibRole.ACCELERATOR]!!
        val (x, y) = scene.center("accel")
        assertEquals(DetectionStatus.NEEDS_CONFIRMATION, d.status)
        assertEquals(DetectionSource.VIDEO, d.source)
        assertTrue("accelerator at (${d.x},${d.y}) expected near ($x,$y)", abs(d.x - x) < 0.05f && abs(d.y - y) < 0.07f)
        assertTrue("confidence ${d.confidence}", d.confidence <= ControlDetection.VIDEO_MAX_CONFIDENCE && d.confidence > 0.3f)
        assertNotNull(d.box)
    }

    @Test
    fun nothingFromAClipIsEverUsableByItself() {
        val res = VideoCalibrationAnalyzer.analyse(INFO, 40, clip())
        assertTrue(res.detections.isNotEmpty())
        assertTrue(res.detections.values.none { it.status.usable })
        assertTrue(res.detections.values.none { it.status == DetectionStatus.AUTO_CONFIRMED })
        assertTrue(res.detections.values.all { it.confidence <= ControlDetection.VIDEO_MAX_CONFIDENCE })
    }

    @Test
    fun steeringAndReverseAreNeverGuessedFromPosition() {
        val res = VideoCalibrationAnalyzer.analyse(INFO, 40, clip())
        for (role in listOf(CalibRole.STEER_LEFT, CalibRole.STEER_RIGHT)) {
            val d = res.detections[role]!!
            assertEquals(DetectionStatus.NONE, d.status)
            assertTrue(d.source != DetectionSource.PRIOR)
        }
        assertTrue(res.detections.values.none { it.source == DetectionSource.PRIOR })
        assertEquals(DetectionStatus.NONE, res.detections[CalibRole.GEAR_REVERSE]!!.status)
    }

    @Test
    fun theBrakeIsNotInventedWhenItNeverMoves() {
        val res = VideoCalibrationAnalyzer.analyse(INFO, 40, clip())
        assertEquals(DetectionStatus.NONE, res.detections[CalibRole.BRAKE]!!.status)
        assertTrue(res.missing.any { it.contains("brake", ignoreCase = true) })
    }

    @Test
    fun aFlickeringSpeedReadoutIsNotMistakenForAButton() {
        val res = VideoCalibrationAnalyzer.analyse(INFO, 40, clip())
        val d = res.detections[CalibRole.ACCELERATOR]!!
        // the read-out sits at the top centre; the accelerator must come from the lower right
        assertTrue(d.y > 0.5f)
    }

    @Test
    fun aPressedLookWithoutAnyScenerySpeedUpIsOnlyAWeakCandidate() {
        val res = VideoCalibrationAnalyzer.analyse(INFO, 40, clip(pressAccel = true, moveScenery = false))
        // the scenery never moves, so the HUD cannot even be separated
        assertFalse(res.report.usable)
        assertTrue(res.missing.isNotEmpty())
    }

    @Test
    fun staticClipExplainsWhatIsMissing() {
        val scene = SynthHud()
        val frames = (0 until 40).map { scene.frame(it, it * 250L, moving = false) }
        val res = VideoCalibrationAnalyzer.analyse(INFO, 40, frames)
        assertFalse(res.report.usable)
        assertTrue(res.missing.any { it.contains("scenery") || it.contains("barely") || it.contains("moving") })
        assertTrue(res.detections.values.all { it.status == DetectionStatus.NONE })
    }

    @Test
    fun clipWithoutAnyHudFindsNothing() {
        val scene = SynthHud()
        val frames = (0 until 40).map { scene.frame(it, it * 250L, moving = true, drawHud = false) }
        val res = VideoCalibrationAnalyzer.analyse(INFO, 40, frames)
        assertFalse(res.report.usable)
        assertTrue(res.detections.values.all { it.status == DetectionStatus.NONE })
    }

    @Test
    fun unusableClipGivesAdviceInsteadOfGuesses() {
        val res = VideoCalibrationAnalyzer.analyse(INFO, 40, (0 until 30).map { Frame.solid(320, 180, 0, it * 250L) })
        assertFalse(res.report.usable)
        assertNull(res.hud)
        assertTrue(res.detections.isEmpty())
        assertTrue(res.missing.any { it.contains("10 seconds") })
    }

    @Test
    fun theMinimapIsNotGuessedFromACornerPosition() {
        // The corner-element guess of 0.9.0 is gone; the minimap comes from ControlCandidateDetector's evidence instead.
        val res = VideoCalibrationAnalyzer.analyse(INFO, 40, clip())
        assertNull(res.minimap)
    }
}



