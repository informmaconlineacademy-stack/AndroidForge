package dev.toe3autopilot.core

import dev.toe3autopilot.core.session.InputController
import dev.toe3autopilot.core.session.InputKind
import dev.toe3autopilot.core.vision.Frame
import java.util.Random
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/**
 * A tiny scripted "game" used to exercise the WHOLE pipeline (real pixel rendering -> real template matching ->
 * real route estimation -> real state detection -> real agents -> real control mapping -> input -> world) in a closed loop.
 *
 * IMPORTANT: this proves the control logic's wiring, timing and safety behaviour against a model I wrote. It says
 * nothing about how the real Truckers of Europe 3 looks or handles; that needs a device and a calibrated profile.
 *
 * Model: a throttle pedal that is smoothed into a speed (so duty-cycled presses give a steady slower speed), brakes that
 * bite hard, steering that only has an effect while moving, a wiggling road that disturbs the heading, a destination marker
 * that appears at [nearAt], and (optionally) a parking view in which the parking zone slides on screen as the truck
 * reverses and steers. Rules are enforced and counted as violations (gear change while rolling, leaving the road, ...).
 */
class SimulatedGame(
    private val clock: FakeClock,
    private val startZoneX: Float = 0.64f,
    startRouteOffset: Float = 0.05f,
) {
    enum class Screen { DRIVING, PARKING, DELIVERY }

    private val images = TestProfiles.templateImages()
    private val rnd = Random(7)
    private val w = TestProfiles.FW
    private val h = TestProfiles.FH
    private val controls = TestProfiles.CONTROLS

    var screen = Screen.DRIVING
        private set
    var holds: Map<Control, Point> = emptyMap()
    var speed = 0f
        private set
    var gear = Gear.FORWARD
        private set

    // ---- scenario switches (set before or during a run) ------------------------------------------------
    /** The distance at which the destination-near marker appears. */
    var nearAt = 3f

    /** The distance at which the game switches to its parking view; null = it never does (the user must park). */
    var parkViewAt: Float? = 4.5f

    /** The distance at which the route stops being drawn (destination reached / map ended); null = never. */
    var routeEndsAt: Float? = null

    /** A pop-up appears at this distance and stays until a tap on CLOSE_DIALOG-like area (which the app must never do). */
    var dialogAt: Float? = null

    /** The minimap loses the route (tunnel, glitch) while true. */
    var routeHidden = false

    // ---- statistics / rule violations ------------------------------------------------------------------
    var gearChangeWhileRolling = 0
        private set
    var offRoad = 0
        private set
    var strayTaps = 0
        private set
    var tapsAfterDelivery = 0
        private set
    var maxSpeedInApproach = 0f
        private set
    var accelerationAfter = 0L // time of the first accelerator hold after `emergencyAt` was set
    var emergencyAt: Long? = null
    val violations: Int get() = gearChangeWhileRolling + offRoad + strayTaps + tapsAfterDelivery

    // ---- world state -----------------------------------------------------------------------------------
    private var lastStep = clock.now
    private var dirty = true
    private var cached: Frame? = null
    private var pedalAvg = 0f
    var driven = 0f
        private set
    private var routeOffset = startRouteOffset
    private var onRoad = true
    private var zoneX = startZoneX
    private var depth = 0f
    private var parkedAt: Long? = null

    val parkedPose: Boolean get() = depth >= 1f && abs(zoneX - 0.5f) <= 0.05f

    private fun steerValue(): Float {
        val p = holds[Control.STEER_CENTER] ?: return 0f
        return ((p.x - controls[Control.STEER_CENTER]!!.x) / 0.12f).coerceIn(-1f, 1f)
    }

    private val dialogShown: Boolean get() = dialogAt?.let { driven >= it } == true

    /** Integrate physics from the previous step to now using the controls that were held in between. */
    fun step() {
        val now = clock.now
        val dt = ((now - lastStep) / 1000f).coerceIn(0f, 1f)
        lastStep = now
        val acc = holds.containsKey(Control.ACCELERATOR)
        val brk = holds.containsKey(Control.BRAKE)
        if (acc) {
            val e = emergencyAt
            if (e != null && accelerationAfter == 0L && now > e + 300) accelerationAfter = now
        }
        val pedal = if (acc && !brk) 1f else 0f
        pedalAvg += (pedal - pedalAvg) * minOf(1f, dt / 0.3f)
        val before = speed
        speed = if (brk) speed - 3f * dt else speed + (pedalAvg - speed) * minOf(1f, dt * 1.5f)
        speed = speed.coerceIn(0f, 1f)
        if (speed != before) dirty = true
        val steer = steerValue()

        when (screen) {
            Screen.DRIVING -> {
                val bend = 0.25f * sin(driven * 0.5f)
                routeOffset += (bend * 0.8f - steer * 1.5f) * speed * dt
                routeOffset = routeOffset.coerceIn(-1f, 1f)
                driven += speed * dt
                if (driven >= nearAt) maxSpeedInApproach = maxOf(maxSpeedInApproach, speed)
                if (abs(routeOffset) >= 0.98f) {
                    if (onRoad) offRoad++
                    onRoad = false
                } else if (abs(routeOffset) < 0.9f) {
                    onRoad = true
                }
                dirty = true
                val pv = parkViewAt
                if (pv != null && driven >= pv) {
                    screen = Screen.PARKING
                    zoneX = startZoneX
                    depth = 0f
                    parkedAt = null
                }
            }
            Screen.PARKING -> {
                if (gear == Gear.REVERSE) {
                    depth = (depth + speed * 0.25f * dt).coerceAtMost(1f)
                    zoneX -= steer * speed * 1.5f * dt
                }
                dirty = true
                if (parkedPose && speed < 0.01f) {
                    val t = parkedAt ?: now.also { parkedAt = it }
                    if (now - t >= 1000) {
                        screen = Screen.DELIVERY
                        parkedAt = null
                    }
                } else {
                    parkedAt = null
                }
            }
            Screen.DELIVERY -> {}
        }
    }

    private fun near(p: Point, c: Point, tx: Float = 0.04f, ty: Float = 0.07f) = abs(p.x - c.x) <= tx && abs(p.y - c.y) <= ty

    fun onTap(p: Point) {
        dirty = true
        if (screen == Screen.DELIVERY) {
            tapsAfterDelivery++
            return
        }
        when {
            screen == Screen.PARKING && near(p, controls[Control.GEAR_REVERSE]!!) -> changeGear(Gear.REVERSE)
            screen == Screen.PARKING && near(p, controls[Control.GEAR_DRIVE]!!) -> changeGear(Gear.FORWARD)
            else -> strayTaps++
        }
    }

    private fun changeGear(g: Gear) {
        if (speed > 0.001f) gearChangeWhileRolling++ else gear = g
    }

    /** Draw the current screen. The delivery screen is static and returns the identical frame object, like a real capture that only delivers changes. */
    fun render(): Frame {
        cached?.let { if (!dirty && screen == Screen.DELIVERY) return it }
        dirty = false
        val px = Synth.blankPixels(w, h)
        fun mark(name: String) {
            val v = TestProfiles.FIXED[name]!!
            put(px, name, v[0].toFloat(), v[1].toFloat())
        }
        // Motion noise first so markers drawn on top stay exact.
        if (speed > 0.003f) {
            val amp = (speed * 150f).toInt().coerceAtLeast(2)
            val x0 = (0.2f * w).toInt()
            val x1 = (0.8f * w).toInt()
            val y0 = (0.25f * h).toInt()
            val y1 = (0.7f * h).toInt()
            for (y in y0 until y1) for (x in x0 until x1) {
                val g = 0x30 + rnd.nextInt(amp)
                px[y * w + x] = (0xFF shl 24) or (g shl 16) or (g shl 8) or g
            }
        }
        // A heartbeat pixel outside every region of interest: the live game's HUD is always animated.
        px[0] = (0xFF shl 24) or (if ((clock.now / 100) % 2L == 0L) 0x40 else 0x50)

        when (screen) {
            Screen.DRIVING -> {
                mark("hud_marker")
                if (driven >= nearAt) mark("destination_near")
                val end = routeEndsAt
                if (!routeHidden && (end == null || driven < end)) drawRoute(px, farToo = end == null || driven < end - 0.6f)
                if (dialogShown) mark("dialog_marker")
            }
            Screen.PARKING -> {
                mark("parking_hud")
                val zy = (0.35f + 0.5f * depth)
                Synth.drawRect(
                    px, w, h, ((zoneX - 0.05f) * w).toInt(), ((zy - 0.06f) * h).toInt(),
                    ((zoneX + 0.05f) * w).toInt(), ((zy + 0.06f) * h).toInt(), 0x00C800,
                )
                if (parkedPose) mark("parked_ok")
            }
            Screen.DELIVERY -> mark("delivery_header")
        }
        val f = Frame(w, h, px, clock.now)
        cached = f
        return f
    }

    private fun put(px: IntArray, name: String, cx: Float, cy: Float) {
        val img = images[name]!!
        Synth.drawPatch(px, w, h, img, (cx * w).toInt() - img.width / 2, (cy * h).toInt() - img.height / 2)
    }

    private fun drawRoute(px: IntArray, farToo: Boolean) {
        val half = 0.15f
        val nearX = ((0.15f + routeOffset * half) * w).toInt()
        val farX = ((0.15f + (routeOffset + 0.08f * cos(driven * 0.5f)) * half) * w).toInt()
        Synth.drawRect(px, w, h, nearX - 2, (0.76f * h).toInt(), nearX + 2, (0.94f * h).toInt(), 0xFFD700)
        if (farToo) Synth.drawRect(px, w, h, farX - 2, (0.56f * h).toInt(), farX + 2, (0.74f * h).toInt(), 0xFFD700)
    }
}

/** Input channel that feeds the simulated game and records everything for assertions. */
class SimInput(private val game: SimulatedGame, private val clock: FakeClock) : InputController {
    override val kind = InputKind.INJECTED
    override val isReady = true
    override val isHealthy = true

    data class HoldEvent(val at: Long, val holds: Map<Control, Point>)

    val holdEvents = ArrayList<HoldEvent>()
    val tapEvents = ArrayList<Pair<Long, Point>>()
    var releaseAllCalls = 0

    override fun setHolds(holds: Map<Control, Point>) {
        game.holds = HashMap(holds)
        holdEvents.add(HoldEvent(clock.now, HashMap(holds)))
    }

    override fun tapAt(point: Point) {
        tapEvents.add(clock.now to point)
        game.onTap(point)
    }

    override fun releaseAll() {
        releaseAllCalls++
        game.holds = emptyMap()
        holdEvents.add(HoldEvent(clock.now, emptyMap()))
    }
}
