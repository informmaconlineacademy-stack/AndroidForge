package dev.toe3autopilot.core

import dev.toe3autopilot.core.capture.ForegroundTracker
import dev.toe3autopilot.core.capture.FrameGate
import dev.toe3autopilot.core.capture.FrameOrigin
import dev.toe3autopilot.core.capture.GameTarget
import dev.toe3autopilot.core.capture.TouchGate
import dev.toe3autopilot.core.session.SessionStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Regression tests for the package-switching failure on the user's phone (22:36:52: the floating button changed the selected
 * game to com.google.android.gms; the session then paused because "the game" was no longer in front; the profile test said
 * "A live picture of the game is available = no"). Synthetic: no phone, no game.
 */
class GameIdentityTest {
    private val own = "dev.toe3autopilot.debug"
    private val game = "com.WandaSoftware.TruckersofEurope3"
    private val gms = "com.google.android.gms"

    private fun tracker(clock: FakeClock) = ForegroundTracker(clock, own)

    @Test
    fun googlePlayServicesAndOtherHelpersCanNeverBeChosenAsTheGame() {
        assertNotNull(GameTarget.problemWith(gms, own))
        assertNotNull(GameTarget.problemWith("com.google.android.gms.persistent", own))
        assertNotNull(GameTarget.problemWith("com.android.vending", own))
        assertNotNull(GameTarget.problemWith(own, own))
        assertNotNull(GameTarget.problemWith("com.android.systemui", own))
        assertNotNull(GameTarget.problemWith("com.google.android.apps.nexuslauncher", own))
        assertNotNull(GameTarget.problemWith("", own))
        assertNull(GameTarget.problemWith(game, own))
        assertNull(GameTarget.problemWith("com.some.other.truckgame", own))
    }

    @Test
    fun aSavedPlayServicesGameIsRepairedAndAGoodOneIsKept() {
        val bad = GameTarget.repair(gms, own, game)
        assertEquals(game, bad.value)
        assertNotNull(bad.message)
        assertTrue(bad.message!!.contains(gms))
        val good = GameTarget.repair(game, own, "x.y.z")
        assertEquals(game, good.value)
        assertNull(good.message)
    }

    @Test
    fun theSelectedGameIsSeparateFromTheAppInFront() {
        val clock = FakeClock()
        val t = tracker(clock)
        t.setLive(true)
        t.onWindowChanged(game)
        var v = t.view(game)
        assertEquals(true, v.gameInFront)
        assertTrue(v.touchSafe)
        assertEquals(FrameOrigin.GAME, FrameGate.classify(false, v))

        // A real switch to another app: both facts are reported, the selected game does not change.
        t.onWindowChanged("com.example.browser")
        v = t.view(game)
        assertEquals(game, v.selected)
        assertEquals("com.example.browser", v.app)
        assertEquals(false, v.gameInFront)
        assertFalse(v.touchSafe)
        assertFalse(TouchGate.allowed(v))
        assertEquals(FrameOrigin.OTHER_APP, FrameGate.classify(false, v))
        val how = v.howToReturn()!!
        assertTrue(how, how.contains(game) && how.contains("com.example.browser"))
        assertTrue(v.describe().contains(game) && v.describe().contains("com.example.browser"))
    }

    @Test
    fun aPlayServicesWindowOverTheGameNeitherReplacesTheGameNorCountsAsIt() {
        val clock = FakeClock()
        val t = tracker(clock)
        t.setLive(true)
        t.onWindowChanged(game)
        val change = t.onWindowChanged(gms)
        assertEquals(ForegroundTracker.Change.Kind.HELPER, change!!.kind)
        val v = t.view(game)
        assertEquals("the app in front is still the game", game, v.app)
        assertEquals(gms, v.helper)
        assertEquals("the selected game is untouched", game, v.selected)
        assertTrue(v.helperFresh)
        assertFalse("no touch while the pop-up may cover the game", v.touchSafe)
        assertEquals("pictures under the pop-up are not game pictures", FrameOrigin.OTHER_APP, FrameGate.classify(false, v))
        assertTrue(v.howToReturn()!!.contains(gms))

        clock.advance(ForegroundTracker.HELPER_HOLD_MS + 1)
        val later = t.view(game)
        assertFalse(later.helperFresh)
        assertTrue("no event arrives when the pop-up closes: after the hold time the game is usable again", later.touchSafe)
        assertEquals(FrameOrigin.GAME, FrameGate.classify(false, later))
    }

    @Test
    fun theFloatingButtonAndTheKeyboardAreNotTheForegroundApp() {
        val clock = FakeClock()
        val t = tracker(clock)
        t.setLive(true)
        t.onWindowChanged(game)
        assertNull(t.onWindowChanged(own))
        assertNull(t.onWindowChanged("com.android.systemui"))
        assertNull(t.onWindowChanged("com.google.android.inputmethod.latin"))
        assertEquals(game, t.view(game).app)
    }

    @Test
    fun withoutTheAccessibilityServiceNothingIsClaimedAboutTheForeground() {
        val clock = FakeClock()
        val t = tracker(clock)
        t.onWindowChanged(game)
        val v = t.view(game)
        assertNull(v.gameInFront)
        assertFalse(v.touchSafe)
        assertEquals(FrameOrigin.UNKNOWN, FrameGate.classify(false, v))
        assertNotNull(v.howToReturn())
    }

    @Test
    fun theOwnAppInFrontIsNeverTheGame() {
        val clock = FakeClock()
        val t = tracker(clock)
        t.setLive(true)
        t.onWindowChanged(game)
        assertEquals(FrameOrigin.OWN_APP, FrameGate.classify(true, t.view(game)))
    }

    // ---- the session: pause on foreground loss, resume only when the game is confirmed in front ----

    @Test
    fun foregroundLossPausesAndTheMessageNamesBothPackages() {
        val rig = Rig().withRoute().startRunning("hud_marker")
        rig.monitor.note = "com.example.browser is in front, not $game. Open $game, then resume."
        rig.monitor.foreground = false
        rig.run(6000)
        assertEquals(SessionStatus.PAUSED, rig.status())
        // Only the safe brake may be requested (and the Android layer's touch gate withholds even that while the game is not in front).
        assertTrue(rig.input.holds.keys.all { it == Control.BRAKE })
        val msg = rig.session.currentSnapshot().task
        assertTrue(msg, msg.contains(game) && msg.contains("com.example.browser"))
    }

    @Test
    fun resumeIsRefusedUntilTheGameIsConfirmedInFrontAndNothingIsSentMeanwhile() {
        val rig = Rig().withRoute().startRunning("hud_marker")
        rig.monitor.foreground = false
        rig.monitor.note = "Open $game."
        rig.run(6000)
        assertEquals(SessionStatus.PAUSED, rig.status())
        val tapsBefore = rig.input.taps.size
        val r = rig.session.resume()
        assertFalse(r.ok)
        assertTrue(r.problems.toString(), r.problems.any { it.contains("foreground") && it.contains(game) })
        assertEquals(SessionStatus.PAUSED, rig.status())
        rig.run(2000)
        assertTrue(rig.input.holds.isEmpty())
        assertEquals(tapsBefore, rig.input.taps.size)
        // Unknown (accessibility service gone) is not "confirmed" either.
        rig.monitor.foreground = null
        assertFalse(rig.session.resume().ok)
        // Confirmed in front: resume is accepted.
        rig.monitor.foreground = true
        assertTrue(rig.session.resume().ok)
    }
}
