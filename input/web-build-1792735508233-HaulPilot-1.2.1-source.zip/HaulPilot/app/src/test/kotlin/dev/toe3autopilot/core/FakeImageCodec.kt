package dev.toe3autopilot.core

import dev.toe3autopilot.core.profile.ImageCodec
import dev.toe3autopilot.core.vision.GrayImage
import java.nio.ByteBuffer

/** Stores a GrayImage as raw ints with a small header; rejects anything else (stands in for PNG on the JVM). */
class FakeImageCodec : ImageCodec {
    override fun encode(img: GrayImage): ByteArray {
        val b = ByteBuffer.allocate(12 + img.px.size * 4)
        b.putInt(MAGIC).putInt(img.width).putInt(img.height)
        img.px.forEach { b.putInt(it) }
        return b.array()
    }

    override fun decode(bytes: ByteArray): GrayImage? {
        if (bytes.size < 12) return null
        val b = ByteBuffer.wrap(bytes)
        if (b.int != MAGIC) return null
        val w = b.int
        val h = b.int
        if (w <= 0 || h <= 0 || bytes.size != 12 + w * h * 4) return null
        return GrayImage(w, h, IntArray(w * h) { b.int })
    }

    companion object {
        const val MAGIC = 0x48504731
    }
}
