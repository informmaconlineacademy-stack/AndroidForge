package dev.toe3autopilot.core

import dev.toe3autopilot.core.vision.Frame
import dev.toe3autopilot.core.vision.Roi
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * A HARDER synthetic driving screen modelled on the user's Truckers of Europe 3 screenshots (chase camera, arrow steering).
 * It reproduces calibration failures that the simple [Toe3Scene] hides. It is still synthetic: it is NOT the real game and
 * cannot prove the detector works on real gameplay (the real screenshots are in `fixtures/toe3`, see `RealScreenshotTest`).
 *
 * The HUD follows what the screenshots show:
 *  - steering ARROWS bottom-left: two dark translucent discs side by side with a light chevron each, two small round
 *    buttons above them (or, with [wheel], a translucent steering wheel there instead);
 *  - PEDALS bottom-right: a wider brake and a taller accelerator, dark translucent rounded rectangles with a light grip-dot
 *    pattern, reaching the bottom edge;
 *  - two opaque round GAUGES with red rims at the bottom, cut off by the screen edge; a column of small light gear / camera
 *    icons at the right edge; a translucent pause button top-right; optionally a minimap (not visible in the screenshots);
 *  - HaulPilot's own floating button over the game at the right edge ([haulPilotButton]).
 *
 * What makes it hard, on purpose: the trailer is fixed on screen too (chase camera) and reaches the bottom edge, its rear
 * shows two doors with vertical bars (rectangles side by side with aligned bottoms, like pedals) and it sways a little; round
 * road signs and buildings with windows pass by; optional black cut-out band, status-bar strip and dusk light; pixel noise;
 * any frame size (the layout scales with the game area).
 */
class Toe3RealScene(
    val w: Int = 480,
    val h: Int = 216,
    /** Black band on the left where the game does not draw (display cut-out), in pixels. */
    val cutoutPx: Int = 0,
) {
    var wheel = false
    var showPedals = true
    var showBrake = true
    var showMinimap = false
    var showHud = true
    var showGauge = true
    var showTrailer = true
    /** Opacity of the dark fill of the translucent controls (the screenshots suggest roughly 0.4..0.5). */
    var hudAlpha = 0.45f

    /** HaulPilot's floating button drawn over the game (it is in every captured picture). */
    var haulPilotButton = false
    var statusBar = false

    /** Brightness factor of the world (dusk < 1). The HUD keeps its own colours. */
    var light = 1f

    private val gx0 = cutoutPx
    private val gw = w - cutoutPx

    // Layout. Like the game's HUD, controls are anchored to the screen edges and scale with one HUD unit [u]: the height
    // on a 20:9 screen, kept at that size on taller screens (16:9, 4:3) so nothing collides. Measured on the user's 480x217
    // screenshot (e.g. the arrows' centres are 0.136 and 0.320 units from the left edge, 0.14 units above the bottom).
    // Ground truth is reported in whole-frame NDS (what the detector must return).
    private val u: Float get() = min(h.toFloat(), gw / 2.22f)
    private fun fromLeft(k: Float) = gx0 + k * u
    private fun fromRight(k: Float) = w - k * u
    private fun fromBottom(k: Float) = h - k * u
    private fun fromTop(k: Float) = k * u
    private fun pxBox(x0: Float, y0: Float, x1: Float, y1: Float) =
        Roi((x0 / w).coerceIn(0f, 1f), (y0 / h).coerceIn(0f, 1f), (x1 / w).coerceIn(0f, 1f), (y1 / h).coerceIn(0f, 1f))

    val brake: Roi get() = pxBox(fromRight(0.415f), fromBottom(0.258f), fromRight(0.221f), fromBottom(0.015f))
    val accelerator: Roi get() = pxBox(fromRight(0.194f), fromBottom(0.360f), fromRight(0.028f), fromBottom(0.015f))
    private val wheelCxPx get() = fromLeft(0.290f)
    private val wheelCyPx get() = fromBottom(0.260f)
    private val wheelR get() = 0.200f * u
    val wheelBox: Roi
        get() {
            val cx = wheelCxPx
            val cy = wheelCyPx
            val r = wheelR
            return pxBox(cx - r, cy - r, cx + r, cy + r)
        }
    private val arrowR get() = 0.081f * u
    private fun discBox(cx: Float, cy: Float, r: Float) = pxBox(cx - r, cy - r, cx + r, cy + r)
    val left: Roi get() = discBox(fromLeft(0.136f), fromBottom(0.140f), arrowR)
    val right: Roi get() = discBox(fromLeft(0.320f), fromBottom(0.140f), arrowR)
    val minimap: Roi get() = pxBox(fromRight(0.62f), fromTop(0.05f), fromRight(0.20f), fromTop(0.40f))
    private fun box(l: Float, t: Float, r: Float, b: Float) = Roi((gx0 + l * gw) / w, t, (gx0 + r * gw) / w, b)
    val trailer = box(0.360f, 0.300f, 0.640f, 1.000f)
    private val gaugeR get() = 0.13f * u
    private fun gaugeCx(left: Boolean) = gx0 + gw / 2f + (if (left) -0.53f else 0.53f) * u
    val gauge: Roi get() = pxBox(gaugeCx(true) - gaugeR, fromBottom(0.11f), gaugeCx(true) + gaugeR, h.toFloat())

    /** Where HaulPilot's own button sits (NDS), as the app would report it. */
    val haulPilotButtonBox: Roi
        get() {
            val r = 0.065f * u
            val cx = fromRight(0.098f)
            val cy = fromTop(0.33f)
            return Roi((cx - r - 1) / w, (cy - r - 1) / h, (cx + r + 1) / w, (cy + r + 1) / h)
        }

    fun frame(t: Int, moving: Boolean = true, ts: Long = t * 330L): Frame {
        val px = IntArray(w * h)
        val tt = if (moving) t else 0
        val horizon = (0.40f * h).toInt()
        for (y in 0 until h) for (x in 0 until w) {
            if (x < gx0) {
                px[y * w + x] = rgb(0, 0, 0)
                continue
            }
            px[y * w + x] = if (y < horizon) sky(x, y, tt, horizon) else ground(x, y, horizon, tt)
        }
        roadside(px, horizon, tt)
        if (showTrailer) truck(px, if (moving) (2.2 * sin(t / 6.0)).roundToInt() else 0, if (moving) (t % 5 == 0).compareTo(false) else 0)
        if (light != 1f) for (i in px.indices) if (i % w >= gx0) px[i] = scale(px[i], light)
        noise(px, t)
        if (showHud) hud(px, t, moving)
        if (statusBar) statusBarStrip(px)
        if (haulPilotButton) floatingButton(px, t)
        return Frame(w, h, px, ts)
    }

    // ---- world -------------------------------------------------------------------------------------------------

    private fun sky(x: Int, y: Int, t: Int, horizon: Int): Int {
        val f = y.toFloat() / horizon
        var r = (120 + 80 * f).toInt()
        var g = (160 + 60 * f).toInt()
        var b = (225 + 20 * f).toInt()
        // soft clouds drifting slowly
        val cx = ((x - gx0) + t) % 160 - 80
        val cy = y - (0.12f * h).toInt()
        val d = hypot(cx.toFloat() * 0.6f, cy.toFloat() * 1.6f)
        if (d < 26) {
            val k = (1f - d / 26f) * 0.6f
            r = (r + (255 - r) * k).toInt(); g = (g + (255 - g) * k).toInt(); b = (b + (255 - b) * k).toInt()
        }
        // distant hills (move very slowly)
        val hill = horizon - (6 + 5 * sin(((x - gx0) + t * 0.3) / 23.0) + 3 * sin(((x - gx0) + t * 0.3) / 9.0)).toInt()
        if (y >= hill) return rgb(70, 105, 75)
        return rgb(r, g, b)
    }

    private fun ground(x: Int, y: Int, horizon: Int, t: Int): Int {
        val depth = (y - horizon + 1).toFloat() / (h - horizon)
        val roadHalf = 0.05f + 0.47f * depth
        val nxp = (x - gx0).toFloat() / gw - 0.5f
        val travel = t * 7f
        val row = ((y * 4 + travel * (0.4f + depth * 2.2f)).toInt() / 7)
        val n = hash(row * 7919 + ((x - gx0) / 6)) % 40
        return when {
            abs(nxp) < roadHalf -> {
                val edge = abs(abs(nxp) - (roadHalf - 0.012f * (1 + depth))) < 0.004f + 0.006f * depth
                val dash = abs(nxp) < 0.004f + 0.008f * depth && (row / 4) % 2 == 0
                if (edge || dash) rgb(225, 225, 210) else rgb(72 + n / 3, 72 + n / 3, 76 + n / 3)
            }
            else -> rgb(80 + n, 120 + n, 55 + n / 2)
        }
    }

    /** Buildings with windows and round road signs that move outwards as the truck drives. */
    private fun roadside(px: IntArray, horizon: Int, t: Int) {
        for (k in 0 until 3) {
            val phase = ((t * 3 + k * 53) % 160) / 160f // 0 = far, 1 = passing
            val scale = 0.25f + phase * 1.6f
            val side = if (k % 2 == 0) -1 else 1
            val cxN = 0.5f + side * (0.08f + phase * 0.55f)
            val cx = gx0 + (cxN * gw).toInt()
            val base = horizon + (phase * phase * (h - horizon) * 0.55f).toInt()
            if (k == 1) {
                // round road sign: red ring, white face, on a grey pole
                val r = (0.05f * h * scale).toInt().coerceAtLeast(2)
                val cy = base - (0.12f * h * scale).toInt() - r
                fillRect(px, cx - 1, cy + r, cx + 1, base, rgb(140, 140, 140), 1f)
                disc(px, cx.toFloat(), cy.toFloat(), r.toFloat(), rgb(210, 30, 30), 1f)
                disc(px, cx.toFloat(), cy.toFloat(), r * 0.72f, rgb(245, 245, 245), 1f)
            } else {
                // a building with a grid of windows
                val bw = (0.12f * gw * scale).toInt().coerceAtLeast(3)
                val bh = (0.22f * h * scale).toInt().coerceAtLeast(3)
                val x0 = cx - bw / 2
                val y0 = base - bh
                fillRect(px, x0, y0, x0 + bw, base, rgb(170, 150, 130), 1f)
                val step = max(3, bw / 5)
                var wy = y0 + step / 2
                while (wy < base - step) {
                    var wx = x0 + step / 2
                    while (wx < x0 + bw - step / 2) {
                        fillRect(px, wx, wy, wx + step / 2, wy + step / 2, rgb(60, 80, 110), 1f)
                        wx += step
                    }
                    wy += step
                }
            }
        }
    }

    /** Chase-camera truck: trailer rear with two doors (a pedal-pair look-alike), taillights, wheels. */
    private fun truck(px: IntArray, dx: Int, dy: Int) {
        val r = trailer
        val x0 = (r.left * w).toInt() + dx
        val x1 = (r.right * w).toInt() + dx
        val y0 = (r.top * h).toInt() + dy
        val y1 = (r.bottom * h).toInt() + dy
        fillRect(px, x0, y0, x1, y1, rgb(205, 205, 210), 1f)
        val mid = (x0 + x1) / 2
        // two doors with frames and two vertical lock bars each (as on the container in the screenshots)
        for ((a, b) in listOf(x0 + 3 to mid - 1, mid + 1 to x1 - 3)) {
            outline(px, a, y0 + 4, b, y1 - 10, 2, rgb(120, 120, 128), 1f)
            for (q in listOf(a + (b - a) / 3, a + 2 * (b - a) / 3)) fillRect(px, q - 1, y0 + 8, q + 1, y1 - 14, rgb(90, 90, 96), 1f)
            fillRect(px, a + 4, y0 + (y1 - y0) / 2, a + 10, y0 + (y1 - y0) / 2 + 6, rgb(230, 200, 40), 1f) // warning label
        }
        fillRect(px, x0, y1 - 10, x1, y1 - 6, rgb(40, 40, 44), 1f) // bumper
        fillRect(px, x0 + 2, y1 - 16, x0 + 10, y1 - 12, rgb(220, 30, 30), 1f) // taillights
        fillRect(px, x1 - 10, y1 - 16, x1 - 2, y1 - 12, rgb(220, 30, 30), 1f)
        fillRect(px, x0 + 6, y1 - 6, x0 + 22, y1 + 4, rgb(25, 25, 25), 1f) // wheels
        fillRect(px, x1 - 22, y1 - 6, x1 - 6, y1 + 4, rgb(25, 25, 25), 1f)
    }

    // ---- HUD ---------------------------------------------------------------------------------------------------------

    private fun hud(px: IntArray, t: Int, moving: Boolean) {
        val a = hudAlpha
        if (showPedals) {
            if (showBrake) pedal(px, brake, a)
            pedal(px, accelerator, a)
        }
        if (wheel) {
            steeringWheel(px, if (moving) (t * 11) % 70 - 35 else 0, a)
        } else {
            arrowButton(px, left, true, a)
            arrowButton(px, right, false, a)
            smallButton(px, fromLeft(0.226f), fromBottom(0.295f), 0.046f * u, a)
            smallButton(px, fromLeft(0.401f), fromBottom(0.249f), 0.032f * u, a)
        }
        if (showGauge) {
            gaugeAt(px, true, if (moving) (t * 7) % 180 else 30)
            gaugeAt(px, false, if (moving) (t * 5 + 40) % 180 else 60)
        }
        // gear / camera icons at the right edge and a translucent pause button top-right
        val ix = fromRight(0.10f)
        outline(px, (ix - 0.04f * u).toInt(), fromTop(0.43f).toInt(), (ix + 0.04f * u).toInt(), fromTop(0.50f).toInt(), 2, rgb(235, 235, 235), 0.85f)
        fillRect(px, (ix - 0.01f * u).toInt(), fromTop(0.55f).toInt(), (ix + 0.01f * u).toInt(), fromTop(0.59f).toInt(), rgb(235, 235, 235), 0.8f)
        outline(px, (ix - 0.027f * u).toInt(), fromTop(0.63f).toInt(), (ix + 0.027f * u).toInt(), fromTop(0.67f).toInt(), 1, rgb(220, 220, 220), 0.7f)
        val pcx = fromRight(0.10f)
        val pcy = fromTop(0.075f)
        disc(px, pcx, pcy, 0.05f * u, rgb(38, 40, 44), a)
        fillRect(px, (pcx - 3).toInt(), (pcy - 4).toInt(), (pcx - 1).toInt(), (pcy + 4).toInt(), rgb(235, 235, 235), 0.8f)
        fillRect(px, (pcx + 1).toInt(), (pcy - 4).toInt(), (pcx + 3).toInt(), (pcy + 4).toInt(), rgb(235, 235, 235), 0.8f)
        if (showMinimap) minimapAt(px, if (moving) t else 0)
    }

    /** Dark translucent rounded rectangle with a light bar near the top and a grid of light grip dots. */
    private fun pedal(px: IntArray, r: Roi, a: Float) {
        val x0 = (r.left * w).roundToInt()
        val y0 = (r.top * h).roundToInt()
        val x1 = (r.right * w).roundToInt()
        val y1 = (r.bottom * h).roundToInt()
        val rad = max(2, min(x1 - x0, y1 - y0) / 5)
        roundedFill(px, x0, y0, x1, y1, rad, rgb(36, 37, 41), a)
        val bw = x1 - x0
        val bh = y1 - y0
        fillRect(px, x0 + bw / 4, y0 + bh / 6, x1 - bw / 4, y0 + bh / 6 + 2, rgb(225, 225, 225), 0.45f)
        val step = max(4, bw / 5)
        var y = y0 + bh / 3
        while (y < y1 - step / 2) {
            var x = x0 + step
            while (x < x1 - step / 2) {
                disc(px, x.toFloat(), y.toFloat(), 1.2f, rgb(215, 215, 215), 0.5f)
                x += step
            }
            y += step
        }
    }

    /** Translucent steering wheel: light rim, three spokes that turn with the steering, dark hub. */
    private fun steeringWheel(px: IntArray, angleDeg: Int, a: Float) {
        val cx = wheelCxPx
        val cy = wheelCyPx
        val r = wheelR
        ring(px, cx, cy, r, max(3f, r * 0.13f), rgb(235, 235, 235), a + 0.1f)
        for (k in 0 until 3) {
            val ang = (angleDeg + k * 120 + 90) * PI / 180.0
            val steps = (r * 0.85f).toInt()
            for (s in (r * 0.28f).toInt() until steps) {
                val x = (cx + cos(ang) * s).roundToInt()
                val y = (cy + sin(ang) * s).roundToInt()
                for (o in -1..1) blend(px, x + o, y, rgb(235, 235, 235), a)
            }
        }
        disc(px, cx, cy, r * 0.26f, rgb(36, 37, 41), a + 0.1f)
    }

    /** Opaque gauge with a red rim, white ticks and a moving needle; centred below the bottom edge (cut off). */
    private fun gaugeAt(px: IntArray, leftOne: Boolean, needleDeg: Int) {
        val cx = gaugeCx(leftOne)
        val cy = fromBottom(-0.02f)
        val r = gaugeR
        disc(px, cx, cy, r, rgb(22, 23, 27), 0.92f)
        ring(px, cx, cy, r, 2.5f, rgb(190, 28, 28), 1f)
        for (k in 0 until 9) {
            val ang = (180 + k * 22.5) * PI / 180.0
            blend(px, (cx + cos(ang) * (r - 5)).roundToInt(), (cy + sin(ang) * (r - 5)).roundToInt(), rgb(240, 240, 240), 1f)
        }
        val ang = (needleDeg + 180) * PI / 180.0
        for (s in 0 until (r * 0.8f).toInt()) blend(px, (cx + cos(ang) * s).roundToInt(), (cy + sin(ang) * s).roundToInt(), rgb(230, 40, 30), 0.95f)
    }

    /** Dark translucent disc with a light chevron pointing left or right. */
    private fun arrowButton(px: IntArray, r: Roi, pointsLeft: Boolean, a: Float) {
        val cx = (r.left + r.right) / 2f * w
        val cy = (r.top + r.bottom) / 2f * h
        val rad = arrowR
        disc(px, cx, cy, rad, rgb(36, 37, 41), a)
        val dir = if (pointsLeft) -1f else 1f
        val len = rad * 0.45f
        for (i in 0..(len * 2).toInt()) {
            val f = i / (len * 2)
            val x = cx + dir * (len * 0.5f - f * len)
            for (sgn in listOf(-1f, 1f)) {
                val y = cy + sgn * f * len
                for (o in -1..1) blend(px, (x + o).roundToInt(), y.roundToInt(), rgb(230, 230, 230), 0.55f)
            }
        }
    }

    private fun smallButton(px: IntArray, cx: Float, cy: Float, rad: Float, a: Float) {
        disc(px, cx, cy, rad, rgb(36, 37, 41), a)
        fillRect(px, (cx - rad * 0.4f).toInt(), (cy - 1).toInt(), (cx + rad * 0.4f).toInt(), (cy + 1).toInt(), rgb(230, 230, 230), 0.5f)
    }

    private fun minimapAt(px: IntArray, t: Int) {
        val x0 = (minimap.left * w).toInt()
        val y0 = (minimap.top * h).toInt()
        val x1 = (minimap.right * w).toInt()
        val y1 = (minimap.bottom * h).toInt()
        for (y in y0 until y1) for (x in x0 until x1) {
            val n = hash(((y + t * 3) / 4) * 131 + x / 4) % 26
            px[y * w + x] = rgb(205 + n / 2, 200 + n / 2, 185 + n / 2) // light map background
            if (((x + 3 * y + t * 9) / 9) % 11 == 0) px[y * w + x] = rgb(245, 245, 245) // streets
        }
        val cx = (x0 + x1) / 2
        for (y in y0 + 3 until y1 - 8) {
            val bend = ((y1 - y) * (t % 24 - 12)) / 70
            for (dx in -1..1) {
                val x = cx + bend + dx
                if (x in x0 until x1) px[y * w + x] = rgb(60, 120, 255) // blue route line
            }
        }
        fillRect(px, cx - 2, y1 - 10, cx + 3, y1 - 5, rgb(255, 120, 0), 1f)
        roundedOutline(px, x0, y0, x1, y1, 3, 2, rgb(40, 40, 40), 0.9f)
    }

    private fun floatingButton(px: IntArray, t: Int) {
        val b = haulPilotButtonBox
        val cx = (b.left + b.right) / 2f * w
        val cy = (b.top + b.bottom) / 2f * h
        val r = 0.065f * u
        disc(px, cx, cy, r, rgb(18, 24, 33), 0.97f)
        // white "A" and an amber chevron, as in the app icon
        for (s in 0 until (r * 1.2f).toInt()) {
            val f = s / (r * 1.2f)
            blend(px, (cx - r * 0.45f + f * r * 0.45f).roundToInt(), (cy + r * 0.55f - f * r * 1.1f).roundToInt(), rgb(255, 255, 255), 1f)
            blend(px, (cx + r * 0.45f - f * r * 0.45f).roundToInt(), (cy + r * 0.55f - f * r * 1.1f).roundToInt(), rgb(255, 255, 255), 1f)
        }
        for (s in -4..4) blend(px, (cx + s).roundToInt(), (cy + abs(s) * 0.6f).roundToInt(), rgb(255, 154, 31), 1f)
        // progress ring segment grows while collecting
        val end = (t * 8) % 360
        for (deg in 0 until end step 3) {
            val ang = (deg - 90) * PI / 180.0
            blend(px, (cx + cos(ang) * (r + 1)).roundToInt(), (cy + sin(ang) * (r + 1)).roundToInt(), rgb(70, 194, 216), 1f)
        }
        disc(px, cx + r * 0.7f, cy - r * 0.7f, r * 0.18f, rgb(150, 155, 165), 1f)
    }

    private fun statusBarStrip(px: IntArray) {
        val sh = (0.045f * h).toInt()
        fillRect(px, 0, 0, w, sh, rgb(0, 0, 0), 0.6f)
        for (i in 0 until 4) fillRect(px, w - 30 - i * 9, 2, w - 25 - i * 9, sh - 2, rgb(255, 255, 255), 1f)
        fillRect(px, 8, 2, 26, sh - 2, rgb(255, 255, 255), 1f)
    }

    // ---- primitives ------------------------------------------------------------------------------------------------

    private fun noise(px: IntArray, t: Int) {
        for (i in px.indices) {
            if (i % w < gx0) continue
            val n = hash(i * 31 + t * 1_000_003) % 7 - 3
            val c = px[i]
            px[i] = rgb((((c shr 16) and 0xFF) + n).coerceIn(0, 255), (((c shr 8) and 0xFF) + n).coerceIn(0, 255), ((c and 0xFF) + n).coerceIn(0, 255))
        }
    }

    private fun hash(i: Int): Int {
        var z = i.toLong() * -7046029254386353131L
        z = (z xor (z ushr 30)) * -4658895280553007687L
        z = z xor (z ushr 31)
        return ((z ushr 33) and 0x7FFFFFFF).toInt()
    }

    private fun rgb(r: Int, g: Int, b: Int) = (0xFF shl 24) or (r.coerceIn(0, 255) shl 16) or (g.coerceIn(0, 255) shl 8) or b.coerceIn(0, 255)

    private fun scale(c: Int, f: Float) = rgb((((c shr 16) and 0xFF) * f).toInt(), (((c shr 8) and 0xFF) * f).toInt(), ((c and 0xFF) * f).toInt())

    private fun blend(px: IntArray, x: Int, y: Int, c: Int, a: Float) {
        if (x < gx0 || x >= w || y < 0 || y >= h) return
        val i = y * w + x
        val o = px[i]
        val aa = a.coerceIn(0f, 1f)
        fun ch(s: Int) = ((((c shr s) and 0xFF) * aa) + (((o shr s) and 0xFF) * (1 - aa))).roundToInt()
        px[i] = rgb(ch(16), ch(8), ch(0))
    }

    private fun fillRect(px: IntArray, x0: Int, y0: Int, x1: Int, y1: Int, c: Int, a: Float) {
        for (y in max(0, y0) until min(h, y1)) for (x in max(gx0, x0) until min(w, x1)) blend(px, x, y, c, a)
    }

    private fun outline(px: IntArray, x0: Int, y0: Int, x1: Int, y1: Int, t: Int, c: Int, a: Float) {
        fillRect(px, x0, y0, x1, y0 + t, c, a)
        fillRect(px, x0, y1 - t, x1, y1, c, a)
        fillRect(px, x0, y0 + t, x0 + t, y1 - t, c, a)
        fillRect(px, x1 - t, y0 + t, x1, y1 - t, c, a)
    }

    private fun inRounded(x: Int, y: Int, x0: Int, y0: Int, x1: Int, y1: Int, r: Int): Boolean {
        if (x < x0 || x >= x1 || y < y0 || y >= y1) return false
        val cx = when {
            x < x0 + r -> x0 + r
            x >= x1 - r -> x1 - r - 1
            else -> return true
        }
        val cy = when {
            y < y0 + r -> y0 + r
            y >= y1 - r -> y1 - r - 1
            else -> return true
        }
        return hypot((x - cx).toFloat(), (y - cy).toFloat()) <= r
    }

    private fun roundedFill(px: IntArray, x0: Int, y0: Int, x1: Int, y1: Int, r: Int, c: Int, a: Float) {
        for (y in y0 until y1) for (x in x0 until x1) if (inRounded(x, y, x0, y0, x1, y1, r)) blend(px, x, y, c, a)
    }

    private fun roundedOutline(px: IntArray, x0: Int, y0: Int, x1: Int, y1: Int, r: Int, t: Int, c: Int, a: Float) {
        for (y in y0 until y1) for (x in x0 until x1) {
            if (inRounded(x, y, x0, y0, x1, y1, r) && !inRounded(x, y, x0 + t, y0 + t, x1 - t, y1 - t, max(0, r - t))) blend(px, x, y, c, a)
        }
    }

    private fun disc(px: IntArray, cx: Float, cy: Float, r: Float, c: Int, a: Float) {
        for (y in (cy - r - 1).toInt()..(cy + r + 1).toInt()) for (x in (cx - r - 1).toInt()..(cx + r + 1).toInt()) {
            if (hypot(x - cx, y - cy) <= r) blend(px, x, y, c, a)
        }
    }

    private fun ring(px: IntArray, cx: Float, cy: Float, r: Float, thick: Float, c: Int, a: Float) {
        for (y in (cy - r - 2).toInt()..(cy + r + 2).toInt()) for (x in (cx - r - 2).toInt()..(cx + r + 2).toInt()) {
            val d = hypot(x - cx, y - cy)
            if (d <= r && d >= r - thick) blend(px, x, y, c, a)
        }
    }
}
