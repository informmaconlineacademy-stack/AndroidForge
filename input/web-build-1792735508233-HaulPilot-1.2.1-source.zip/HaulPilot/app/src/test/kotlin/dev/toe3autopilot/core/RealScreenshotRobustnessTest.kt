package dev.toe3autopilot.core

import dev.toe3autopilot.core.vision.Frame
import dev.toe3autopilot.core.vision.Roi
import org.junit.Assert.assertEquals
import org.junit.Assume.assumeTrue
import org.junit.Test
import kotlin.random.Random

/**
 * The detector was developed while looking at the user's two screenshots, so passing on them alone could be luck. Here
 * each real picture is changed the way real captures differ (brightness, sensor-like noise, softness, a black display
 * cut-out band, a cropped status bar, another capture size) and the result must stay right:
 *
 *  - NEVER a wrong proposal (a marker on something that is not that control), in every variant;
 *  - the controls are found in every variant except where noted (heavy blur on the faint pedals over grass: there the
 *    honest result is "not found", and the person taps them).
 */
class RealScreenshotRobustnessTest {
    private class Variant(val name: String, val frame: Frame, val spec: RealScreenshots.Spec)

    private fun variants(f0: Frame, spec: RealScreenshots.Spec): List<Variant> {
        val rnd = Random(7)
        val pad = 14
        val crop = 6
        return listOf(
            Variant("original", f0, spec),
            Variant("darker x0.8", map(f0) { v -> (v * 0.8f).toInt() }, spec),
            Variant("brighter x1.15", map(f0) { v -> (v * 1.15f).toInt() }, spec),
            Variant("noise +-8", map(f0) { v -> v + rnd.nextInt(-8, 9) }, spec),
            Variant("blur 3x3", blur(f0), spec),
            Variant("black cut-out $pad px left", padLeft(f0, pad), shift(spec, { (it * f0.width + pad) / (f0.width + pad) }, { it })),
            Variant("top $crop px cropped", cropTop(f0, crop), shift(spec, { it }, { (it * f0.height - crop) / (f0.height - crop) })),
            Variant("400 px wide", resize(f0, 400, f0.height * 400 / f0.width), spec),
            Variant("560 px wide", resize(f0, 560, f0.height * 560 / f0.width), spec),
        )
    }

    private fun run(name: String, mayMiss: Set<String>) {
        val dir = RealScreenshots.dir()
        assumeTrue("fixtures folder not found", dir != null)
        val c = RealScreenshots.cases(dir!!).firstOrNull { it.name == name }
        assumeTrue("fixture $name missing", c?.spec != null)
        val spec = c!!.spec!!
        val f0 = RealScreenshots.load(c.files.first())
        val wrong = ArrayList<String>()
        val missed = ArrayList<String>()
        for (v in variants(f0, spec)) {
            val r = RealScreenshots.analyse(listOf(v.frame), v.spec.exclusions.values.toList())
            val verdict = RealScreenshots.verdict(r, v.spec)
            println("$name [${v.name}] ${v.frame.width}x${v.frame.height}: " + if (verdict.all.isEmpty()) "OK" else verdict.all.joinToString(" | "))
            verdict.wrong.forEach { wrong += "[${v.name}] $it" }
            if (v.name !in mayMiss) verdict.missed.forEach { missed += "[${v.name}] $it" }
        }
        assertEquals("wrong proposals", emptyList<String>(), wrong)
        assertEquals("missed controls", emptyList<String>(), missed)
    }

    @Test
    fun pedalsOnTheUsersScreenshotSurviveRealisticChanges() = run("toe3_v09_review", mayMiss = setOf("blur 3x3"))

    @Test
    fun arrowsOnTheUsersScreenshotSurviveRealisticChanges() = run("toe3_v1_editor", mayMiss = emptySet())

    // ---- picture changes ------------------------------------------------------------------------------------------

    private fun map(f: Frame, fn: (Int) -> Int): Frame = Frame(f.width, f.height, IntArray(f.argb.size) { i ->
        val c = f.argb[i]
        val r = fn((c shr 16) and 255).coerceIn(0, 255)
        val g = fn((c shr 8) and 255).coerceIn(0, 255)
        val b = fn(c and 255).coerceIn(0, 255)
        (0xFF shl 24) or (r shl 16) or (g shl 8) or b
    })

    private fun blur(f: Frame): Frame {
        val w = f.width
        val h = f.height
        val o = IntArray(w * h)
        for (y in 0 until h) for (x in 0 until w) {
            var r = 0
            var g = 0
            var b = 0
            for (dy in -1..1) for (dx in -1..1) {
                val c = f.argb[(y + dy).coerceIn(0, h - 1) * w + (x + dx).coerceIn(0, w - 1)]
                r += (c shr 16) and 255
                g += (c shr 8) and 255
                b += c and 255
            }
            o[y * w + x] = (0xFF shl 24) or ((r / 9) shl 16) or ((g / 9) shl 8) or (b / 9)
        }
        return Frame(w, h, o)
    }

    private fun padLeft(f: Frame, pad: Int): Frame {
        val w = f.width + pad
        val o = IntArray(w * f.height) { 0xFF000000.toInt() }
        for (y in 0 until f.height) System.arraycopy(f.argb, y * f.width, o, y * w + pad, f.width)
        return Frame(w, f.height, o)
    }

    private fun cropTop(f: Frame, c: Int): Frame = Frame(f.width, f.height - c, f.argb.copyOfRange(c * f.width, f.argb.size))

    private fun resize(f: Frame, w: Int, h: Int): Frame =
        Frame(w, h, IntArray(w * h) { i -> f.argb[(i / w * f.height / h) * f.width + (i % w) * f.width / w] })

    private fun shift(s: RealScreenshots.Spec, fx: (Float) -> Float, fy: (Float) -> Float): RealScreenshots.Spec {
        fun m(r: Roi) = Roi(fx(r.left).coerceIn(0f, 1f), fy(r.top).coerceIn(0f, 1f), fx(r.right).coerceIn(0f, 1f), fy(r.bottom).coerceIn(0f, 1f))
        return s.copy(
            required = s.required.mapValues { m(it.value) }, optional = s.optional.mapValues { m(it.value) },
            exclusions = s.exclusions.mapValues { m(it.value) }, distractors = s.distractors.mapValues { m(it.value) },
        )
    }
}
