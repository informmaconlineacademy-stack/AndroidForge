package dev.toe3autopilot.core

import dev.toe3autopilot.core.vision.Frame
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Synthetic "screenshots" of a driving game HUD: round buttons with a pressed state, a steering wheel variant,
 * a speed read-out whose digits change, and a minimap frame, drawn over a block-noise world that changes every
 * frame while the truck "moves". This is NOT the real game; it only proves the analysis does what it claims on
 * pictures with this structure.
 */
class SynthHud(val w: Int = 320, val h: Int = 180) {
    data class Ring(val name: String, val x: Float, val y: Float, val r: Int)

    val rings = mutableListOf(
        Ring("accel", 0.90f, 0.80f, 16),
        Ring("brake", 0.78f, 0.80f, 16),
        Ring("left", 0.10f, 0.80f, 14),
        Ring("right", 0.22f, 0.80f, 14),
        Ring("reverse", 0.50f, 0.92f, 9),
    )

    /** When set, left/right buttons are replaced by one steering wheel whose spoke rotates. */
    var wheelInsteadOfButtons = false
    val wheelRing = Ring("wheel", 0.15f, 0.76f, 22)

    fun center(name: String): Pair<Float, Float> {
        val r = if (name == "wheel") wheelRing else rings.first { it.name == name }
        return r.x to r.y
    }

    fun frame(
        tick: Int,
        ts: Long,
        moving: Boolean,
        pressed: Set<String> = emptySet(),
        speed: Int = 0,
        wheelAngleDeg: Int = 0,
        drawHud: Boolean = true,
    ): Frame {
        val px = IntArray(w * h)
        // world
        // A proper integer hash per block: java.util.Random with related seeds yields correlated values across frames.
        val seed = if (moving) tick.toLong() + 17L else 1L
        val bs = 6
        val bw = (w + bs - 1) / bs
        val bh = (h + bs - 1) / bs
        val blocks = IntArray(bw * bh) { 30 + ((mix(seed * 1_000_003L + it) ushr 33) % 160L).toInt() }
        for (y in 0 until h) for (x in 0 until w) {
            val g = blocks[(y / bs) * bw + (x / bs)]
            px[y * w + x] = rgb(g, g, g)
        }
        if (drawHud) {
            drawMinimap(px)
            drawSpeed(px, speed)
            for (r in rings) {
                if (wheelInsteadOfButtons && (r.name == "left" || r.name == "right")) continue
                drawRing(px, r, r.name in pressed)
            }
            if (wheelInsteadOfButtons) drawWheel(px, wheelAngleDeg)
        }
        return Frame(w, h, px, ts)
    }

    private fun mix(z0: Long): Long {
        var z = z0 + -7046029254386353131L
        z = (z xor (z ushr 30)) * -4658895280553007687L
        z = (z xor (z ushr 27)) * -7723592293110705685L
        return z xor (z ushr 31)
    }

    private fun rgb(r: Int, g: Int, b: Int) = (0xFF shl 24) or (r shl 16) or (g shl 8) or b

    private fun drawRing(px: IntArray, ring: Ring, pressed: Boolean) {
        val cx = ring.x * w
        val cy = ring.y * h
        for (y in (cy - ring.r - 2).toInt()..(cy + ring.r + 2).toInt()) for (x in (cx - ring.r - 2).toInt()..(cx + ring.r + 2).toInt()) {
            if (x !in 0 until w || y !in 0 until h) continue
            val d = hypot(x - cx, y - cy)
            when {
                d <= ring.r - 2f -> px[y * w + x] = if (pressed) rgb(175, 175, 175) else rgb(50, 50, 50)
                d <= ring.r.toFloat() -> px[y * w + x] = rgb(240, 240, 240)
            }
        }
    }

    private fun drawWheel(px: IntArray, angleDeg: Int) {
        drawRing(px, wheelRing, false)
        val cx = wheelRing.x * w
        val cy = wheelRing.y * h
        val a = (angleDeg - 90) * PI / 180.0
        for (s in 0..16) {
            val x = (cx + cos(a) * s).roundToInt()
            val y = (cy + sin(a) * s).roundToInt()
            for (dx in -1..1) for (dy in -1..1) {
                val xx = x + dx
                val yy = y + dy
                if (xx in 0 until w && yy in 0 until h) px[yy * w + xx] = rgb(240, 240, 240)
            }
        }
    }

    private fun drawSpeed(px: IntArray, speed: Int) {
        val x0 = (0.5f * w - 22).toInt()
        val y0 = (0.06f * h).toInt()
        fill(px, x0, y0, x0 + 44, y0 + 16, rgb(240, 240, 240))
        fill(px, x0 + 2, y0 + 2, x0 + 42, y0 + 14, rgb(40, 40, 40))
        // three "digits" as bars whose heights depend on the speed value
        for (i in 0 until 3) {
            val hh = 2 + ((speed / (i + 1)) % 9)
            fill(px, x0 + 6 + i * 12, y0 + 14 - hh, x0 + 12 + i * 12, y0 + 14, rgb(230, 230, 230))
        }
    }

    private fun drawMinimap(px: IntArray) {
        val x0 = (0.04f * w).toInt()
        val y0 = (0.20f * h).toInt()
        fill(px, x0, y0, x0 + 56, y0 + 52, rgb(240, 240, 240))
        fill(px, x0 + 2, y0 + 2, x0 + 54, y0 + 50, rgb(30, 60, 30))
        fill(px, x0 + 26, y0 + 8, x0 + 30, y0 + 46, rgb(255, 215, 0)) // route line
    }

    private fun fill(px: IntArray, x0: Int, y0: Int, x1: Int, y1: Int, c: Int) {
        for (y in maxOf(0, y0) until minOf(h, y1)) for (x in maxOf(0, x0) until minOf(w, x1)) px[y * w + x] = c
    }
}
