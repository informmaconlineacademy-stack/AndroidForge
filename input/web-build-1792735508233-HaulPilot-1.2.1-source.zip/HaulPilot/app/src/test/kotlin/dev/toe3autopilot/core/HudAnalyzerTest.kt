package dev.toe3autopilot.core

import dev.toe3autopilot.core.calibration.CalibRole
import dev.toe3autopilot.core.calibration.ControlDetection
import dev.toe3autopilot.core.calibration.DetectionSource
import dev.toe3autopilot.core.calibration.DetectionStatus
import dev.toe3autopilot.core.calibration.HudAnalyzer
import dev.toe3autopilot.core.vision.Roi
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import kotlin.math.abs

class HudAnalyzerTest {
    private fun framesMoving(scene: SynthHud, n: Int) = (0 until n).map { scene.frame(it, it * 250L, moving = true, speed = 10 + it) }

    private fun near(el: List<dev.toe3autopilot.core.calibration.HudElement>, x: Float, y: Float, tol: Float = 0.03f) =
        el.any { abs(it.cx - x) <= tol && abs(it.cy - y) <= tol }

    @Test
    fun findsFixedButtonsOverMovingScenery() {
        val scene = SynthHud()
        val a = HudAnalyzer.analyse(framesMoving(scene, 16))
        assertTrue(a.problem ?: "", a.ok)
        for (name in listOf("accel", "brake", "left", "right", "reverse")) {
            val (x, y) = scene.center(name)
            assertTrue("button '$name' was not found; elements=${a.elements.map { it.cx to it.cy }}", near(a.elements, x, y))
        }
        // The scenery itself must not show up as elements.
        assertTrue("too many elements: ${a.elements.size}", a.elements.size <= 8)
    }

    @Test
    fun staticSceneGivesNoResultAndSaysWhy() {
        val scene = SynthHud()
        val frames = (0 until 14).map { scene.frame(it, it * 250L, moving = false) }
        val a = HudAnalyzer.analyse(frames)
        assertFalse(a.ok)
        assertTrue(a.problem!!.contains("barely changes"))
        assertTrue(a.elements.isEmpty())
    }

    @Test
    fun tooFewFramesIsRefused() {
        val scene = SynthHud()
        val a = HudAnalyzer.analyse(framesMoving(scene, 5))
        assertFalse(a.ok)
        assertTrue(a.problem!!.contains("at least"))
    }

    @Test
    fun sceneWithoutAnyHudFindsNothing() {
        val scene = SynthHud()
        val a = HudAnalyzer.analyse((0 until 16).map { scene.frame(it, it * 250L, moving = true, drawHud = false) })
        assertFalse(a.ok)
        assertTrue(a.elements.isEmpty())
    }
}

