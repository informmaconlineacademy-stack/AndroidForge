package dev.toe3autopilot.core

import dev.toe3autopilot.core.profile.GameProfile
import dev.toe3autopilot.core.profile.ProfileCodec
import dev.toe3autopilot.core.profile.ProfileEditing
import dev.toe3autopilot.core.profile.SteeringMode
import dev.toe3autopilot.core.state.GameState
import dev.toe3autopilot.core.vision.ColorTarget
import dev.toe3autopilot.core.vision.Frame
import dev.toe3autopilot.core.vision.Roi
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ProfileEditingTest {
    private val empty = GameProfile.EMPTY.copy(name = "t", gamePackage = "x.y")

    @Test
    fun dragIsNormalisedSortedAndClamped() {
        val r = ProfileEditing.roiFromDrag(300f, 200f, 100f, 50f, 400f, 300f)!!
        assertEquals(0.25f, r.left, 1e-4f)
        assertEquals(0.75f, r.right, 1e-4f)
        assertEquals(50f / 300f, r.top, 1e-4f)
        assertEquals(200f / 300f, r.bottom, 1e-4f)
        val clamped = ProfileEditing.roiFromDrag(-20f, -20f, 500f, 400f, 400f, 300f)!!
        assertEquals(Roi(0f, 0f, 1f, 1f), clamped)
    }

    @Test
    fun tinyOrDegenerateDragIsRejected() {
        assertNull(ProfileEditing.roiFromDrag(10f, 10f, 11f, 11f, 400f, 300f))
        assertNull(ProfileEditing.roiFromDrag(0f, 0f, 100f, 100f, 0f, 0f))
    }

    @Test
    fun searchAreaGrowsAndStaysInBounds() {
        val s = ProfileEditing.searchRoi(Roi(0.02f, 0.5f, 0.2f, 0.98f), 0.08f)
        assertEquals(0f, s.left, 1e-6f)
        assertEquals(0.42f, s.top, 1e-4f)
        assertEquals(1f, s.bottom, 1e-6f)
    }

    @Test
    fun averageColorOfSolidRegion() {
        val f = Frame.solid(20, 10, 0x336699)
        val c = ProfileEditing.averageColor(f, Roi(0.1f, 0.1f, 0.9f, 0.9f), 30)
        assertEquals(ColorTarget(0x33, 0x66, 0x99, 30), c)
    }

    @Test
    fun templateEditsRoundTripThroughTheCodec() {
        var p = ProfileEditing.withTemplate(empty, "hud_marker", Roi(0f, 0f, 0.5f, 0.2f), 480)
        p = ProfileEditing.withTemplate(p, "parking_hud", Roi(0.4f, 0.4f, 0.6f, 0.6f), 480)
        val (p2, err) = ProfileEditing.withStateRule(p, GameState.DRIVING, "hud_marker, !parking_hud")
        assertNull(err)
        val p3 = ProfileEditing.withControl(p2, Control.ACCELERATOR, Point(0.5f, 1.4f))
        assertEquals(1f, p3.controls[Control.ACCELERATOR]!!.y, 0f)
        val again = ProfileCodec.parse(ProfileCodec.format(p3))
        assertEquals(480, again.referenceWidth)
        assertEquals(listOf("hud_marker", "!parking_hud"), again.stateRules[GameState.DRIVING])
    }

    @Test
    fun ruleWithUnknownTemplateIsReportedAndNotApplied() {
        val (p, err) = ProfileEditing.withStateRule(empty, GameState.DRIVING, "nope")
        assertNotNull(err)
        assertTrue(p.stateRules.isEmpty())
    }

    @Test
    fun removingATemplateKeepsTheProfileParsable() {
        var p = ProfileEditing.withTemplate(empty, "a_marker", Roi(0f, 0f, 0.2f, 0.2f), 480)
        p = ProfileEditing.withTemplate(p, "b_marker", Roi(0.5f, 0.5f, 0.7f, 0.7f), 480)
        p = ProfileEditing.withStateRule(p, GameState.DRIVING, "a_marker,!b_marker").first
        val removed = ProfileEditing.withoutTemplate(p, "b_marker")
        assertEquals(listOf("a_marker"), removed.stateRules[GameState.DRIVING])
        ProfileCodec.parse(ProfileCodec.format(removed)) // must not throw
        val gone = ProfileEditing.withoutTemplate(removed, "a_marker")
        assertTrue(gone.stateRules.isEmpty())
        ProfileCodec.parse(ProfileCodec.format(gone))
    }

    @Test
    fun navEditsNeedTheMinimapFirst() {
        assertNull(ProfileEditing.withRouteColor(empty, ColorTarget(1, 2, 3)))
        assertNull(ProfileEditing.withTruckMarker(empty, Point(0.1f, 0.1f)))
        var p = ProfileEditing.withNavMinimap(empty, Roi(0.02f, 0.55f, 0.25f, 0.98f))
        p = ProfileEditing.withRouteColor(p, ColorTarget(250, 200, 0, 40))!!
        p = ProfileEditing.withTruckMarker(p, Point(0.13f, 0.9f))!!
        val parsed = ProfileCodec.parse(ProfileCodec.format(p))
        assertEquals(0.13f, parsed.nav!!.truckX, 1e-3f)
        assertEquals(250, parsed.nav!!.routeColor.r)
        // Re-marking the minimap keeps the colour and truck position the user already chose.
        val again = ProfileEditing.withNavMinimap(p, Roi(0.0f, 0.5f, 0.3f, 1.0f))
        assertEquals(250, again.nav!!.routeColor.r)
        assertEquals(0.13f, again.nav!!.truckX, 1e-6f)
    }

    @Test
    fun widthMismatchIsDetectedOnlyWhenTemplatesExist() {
        assertNull(ProfileEditing.widthProblem(empty, 480))
        val p = ProfileEditing.withTemplate(empty, "a_marker", Roi(0f, 0f, 0.2f, 0.2f), 480)
        assertNull(ProfileEditing.widthProblem(p, 480))
        assertNotNull(ProfileEditing.widthProblem(p, 270))
    }

    @Test
    fun nameValidationAndSteeringClamp() {
        assertNull(ProfileEditing.validateName("hud_marker_2"))
        assertNotNull(ProfileEditing.validateName("Hud Marker"))
        assertEquals(0.4f, ProfileEditing.withSteering(empty, SteeringMode.SLIDER, 9f).steerRadius, 0f)
    }
}
