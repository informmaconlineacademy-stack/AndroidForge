package dev.toe3autopilot.core

import dev.toe3autopilot.core.calibration.CalibRole
import dev.toe3autopilot.core.calibration.ControlCandidateDetector
import dev.toe3autopilot.core.calibration.DetectionStatus
import dev.toe3autopilot.core.calibration.HudAnalyzer
import dev.toe3autopilot.core.profile.SteeringMode
import dev.toe3autopilot.core.setup.AutoReview
import dev.toe3autopilot.core.setup.DraftEdits
import dev.toe3autopilot.core.setup.SetupDraft
import dev.toe3autopilot.core.vision.Frame
import dev.toe3autopilot.core.vision.Roi
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * The phone's report was: 46 pictures, "15 fixed elements", ONE pedal-shaped element, no steering control, no minimap.
 * These tests pin the behaviour the detector and the review must have in exactly that situation. Synthetic scenes
 * (Toe3Scene); the real-screenshot checks are in RealScreenshotTest.
 */
class ControlDetectionRegressionTest {
    private fun detect(scene: Toe3Scene): ControlCandidateDetector.Result {
        val f: List<Frame> = (0 until 45).map { scene.frame(it, true) }
        return ControlCandidateDetector.detect(HudAnalyzer.analyse(f), f)
    }

    @Test
    fun theMinimapIsFoundEvenWhenNoPedalAndNoSteeringControlIsRecognised() {
        val s = Toe3Scene().also { it.showPedals = false; it.showBrake = false }
        val r = detect(s)
        assertEquals(DetectionStatus.NONE, r.detections[CalibRole.ACCELERATOR]!!.status)
        assertEquals(DetectionStatus.NONE, r.detections[CalibRole.BRAKE]!!.status)
        val mm = r.minimap
        assertTrue("the minimap does not depend on the pedals: ${r.notes}", mm != null && iouOf(mm.box, s.minimap) > 0.6f)
    }

    @Test
    fun aSinglePedalShapedElementIsNotAssignedButIsListedAsFoundAndCanBeUsedByTap() {
        val s = Toe3Scene().also { it.showBrake = false }
        val r = detect(s)
        // Not invented: no role is given to it.
        assertEquals(DetectionStatus.NONE, r.detections[CalibRole.ACCELERATOR]!!.status)
        assertEquals(DetectionStatus.NONE, r.detections[CalibRole.BRAKE]!!.status)
        // But the element itself is among the measured outlines, so the review can draw it and a tap snaps to it.
        assertTrue("outlines: ${r.outlines.size}", r.outlines.any { iouOf(it, s.accelerator) > 0.4f })
        val shown = AutoReview.unassigned(SetupDraft(), r.outlines)
        assertTrue(shown.any { iouOf(it, s.accelerator) > 0.4f })
    }

    @Test
    fun placedControlsTheMinimapAndTheMarkerAreNotListedAsUnassigned() {
        val a = Roi(0.80f, 0.60f, 0.90f, 0.90f)
        val b = Roi(0.10f, 0.20f, 0.20f, 0.40f)
        var d = SetupDraft()
        d = DraftEdits.place(d, CalibRole.ACCELERATOR, 0.85f, 0.75f, a)
        val out = AutoReview.unassigned(d, listOf(a, Roi(0.805f, 0.61f, 0.895f, 0.89f), b))
        assertEquals(listOf(b), out)
    }

    @Test
    fun reverseIsOptionalAndTheMinimapIsNeverRequiredByTheReview() {
        for (mode in listOf(SteeringMode.BUTTONS, SteeringMode.SLIDER, null)) {
            assertFalse(CalibRole.GEAR_REVERSE in AutoReview.required(mode))
            assertTrue(CalibRole.GEAR_REVERSE in AutoReview.roles(mode))
        }
        // Everything the review requires, without reverse: nothing is left to place.
        var d = SetupDraft()
        d = DraftEdits.place(d, CalibRole.ACCELERATOR, 0.85f, 0.75f)
        d = DraftEdits.place(d, CalibRole.BRAKE, 0.70f, 0.75f)
        d = DraftEdits.place(d, CalibRole.STEER_WHEEL, 0.15f, 0.75f)
        assertTrue(AutoReview.stillToPlace(d, AutoReview.steering(d)).isEmpty())
    }
}
