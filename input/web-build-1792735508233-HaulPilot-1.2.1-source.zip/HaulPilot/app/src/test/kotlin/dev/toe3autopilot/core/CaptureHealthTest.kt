package dev.toe3autopilot.core

import dev.toe3autopilot.core.calibration.HudAnalyzer
import dev.toe3autopilot.core.capture.AnalyzerDiagnosis
import dev.toe3autopilot.core.capture.AnalyzerRejection
import dev.toe3autopilot.core.capture.CaptureFault
import dev.toe3autopilot.core.capture.CaptureHealthMonitor
import dev.toe3autopilot.core.capture.DiagnosisKind
import dev.toe3autopilot.core.capture.FrameClass
import dev.toe3autopilot.core.capture.FrameContext
import dev.toe3autopilot.core.capture.FrameStats
import dev.toe3autopilot.core.vision.Frame
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

private fun noisy(w: Int, h: Int, base: Int, amp: Int, seed: Int = 1): Frame {
    val px = IntArray(w * h)
    var s = seed * 7919
    for (i in px.indices) {
        s = s * 1103515245 + 12345
        val v = (base + ((s ushr 16) % (amp + 1))).coerceIn(0, 255)
        px[i] = (0xFF shl 24) or (v shl 16) or (v shl 8) or v
    }
    return Frame(w, h, px, 0)
}

private fun scene(seed: Int = 1) = noisy(160, 90, 60, 150, seed)

/** Left [fraction] of the picture exactly black, the rest detailed. */
private fun partlyBlack(fraction: Float): Frame {
    val f = scene()
    val px = f.argb.copyOf()
    for (y in 0 until f.height) for (x in 0 until (f.width * fraction).toInt()) px[y * f.width + x] = 0xFF000000.toInt()
    return Frame(f.width, f.height, px, 0)
}

class FrameStatsTest {
    @Test
    fun blackFrameIsAllBlack() {
        assertEquals(FrameClass.ALL_BLACK, FrameStats.of(Frame.solid(160, 90, 0x000000)).classify())
    }

    @Test
    fun nearBlackNoiseStillCountsAsBlackButADarkSceneDoesNot() {
        assertEquals(FrameClass.ALL_BLACK, FrameStats.of(noisy(160, 90, 0, 3)).classify())
        assertEquals(FrameClass.DARK_SCENE, FrameStats.of(noisy(160, 90, 8, 40)).classify())
    }

    @Test
    fun aPictureWithNoRedIsNotBlack() {
        // Regression: the old check compared the packed ARGB integer with 0x050505, which called any pixel with a tiny
        // red channel "black" whatever its green and blue values.
        assertEquals(FrameClass.SOLID_COLOUR, FrameStats.of(Frame.solid(160, 90, 0x00C8C8)).classify())
        val cyanScene = Frame(160, 90, IntArray(160 * 90) { i -> (0xFF shl 24) or (((i * 37) % 200 + 40) shl 8) or (((i * 91) % 200) + 40) }, 0)
        val c = FrameStats.of(cyanScene).classify()
        assertTrue("was $c", c == FrameClass.OK || c == FrameClass.DARK_SCENE)
    }

    @Test
    fun solidNonBlackColourIsReportedAsFlat() {
        assertEquals(FrameClass.SOLID_COLOUR, FrameStats.of(Frame.solid(160, 90, 0x808080)).classify())
    }

    @Test
    fun largeBlackAreaWithDetailElsewhereIsPartlyBlack() {
        assertEquals(FrameClass.PARTLY_BLACK, FrameStats.of(partlyBlack(0.7f)).classify())
        assertEquals(FrameClass.OK, FrameStats.of(partlyBlack(0.1f)).classify())
    }

    @Test
    fun normalSceneIsOk() {
        assertEquals(FrameClass.OK, FrameStats.of(scene()).classify())
    }

    @Test
    fun tinyFramesDoNotCrash() {
        FrameStats.of(Frame.solid(2, 2, 0x303030))
        FrameStats.of(Frame.solid(1, 1, 0))
    }
}

class CaptureHealthMonitorTest {
    private val clock = FakeClock()
    private val m = CaptureHealthMonitor(clock)
    private val own = FrameContext(ownAppInFront = true, gameInFront = false)
    private val game = FrameContext(ownAppInFront = false, gameInFront = true)

    private fun black() = Frame.solid(160, 90, 0)

    @Test
    fun notConnectedBeforeStart() {
        val d = m.diagnose()
        assertEquals(DiagnosisKind.NOT_CONNECTED, d.kind)
        assertFalse(d.isProblem)
    }

    @Test
    fun waitingThenNoFramesAfterTheLimit() {
        m.onCaptureStarted()
        assertEquals(DiagnosisKind.WAITING_FOR_FRAMES, m.diagnose().kind)
        clock.advance(7_000)
        val d = m.diagnose()
        assertEquals(DiagnosisKind.NO_FRAMES, d.kind)
        assertTrue(d.offerVideoCalibration)
        assertTrue(d.detail.contains("pipeline"))
    }

    @Test
    fun faultsAreDistinguishedAndPermissionDenialOnlyAsksToRetry() {
        m.onFault(CaptureFault.PERMISSION_DENIED)
        var d = m.diagnose()
        assertEquals(DiagnosisKind.FAULT, d.kind)
        assertEquals(CaptureFault.PERMISSION_DENIED.title, d.title)
        assertFalse(d.offerVideoCalibration)

        for (f in listOf(CaptureFault.PROJECTION_STOPPED, CaptureFault.VIRTUAL_DISPLAY_FAILED, CaptureFault.IMAGE_READER_FAILED, CaptureFault.TOKEN_INVALID)) {
            m.onFault(f, "x")
            d = m.diagnose()
            assertEquals(f.title, d.title)
            assertTrue(d.offerVideoCalibration)
        }
        // every fault has its own wording
        assertEquals(CaptureFault.entries.size, CaptureFault.entries.map { it.title }.toSet().size)
    }

    @Test
    fun aNewCaptureClearsAnOldFault() {
        m.onFault(CaptureFault.PROJECTION_STOPPED)
        m.onCaptureStarted()
        assertEquals(DiagnosisKind.WAITING_FOR_FRAMES, m.diagnose().kind)
    }

    @Test
    fun healthyWhenPicturesHaveDetail() {
        m.onCaptureStarted()
        m.onFrame(scene(), own)
        assertEquals(DiagnosisKind.HEALTHY, m.diagnose().kind)
        assertTrue(m.diagnose().healthy)
    }

    @Test
    fun darkSceneIsNotBlocked() {
        m.onCaptureStarted()
        m.onFrame(noisy(160, 90, 8, 40), own)
        for (i in 0 until 30) {
            clock.advance(1000)
            m.onFrame(noisy(160, 90, 8, 40, i + 2), game)
        }
        val d = m.diagnose()
        assertEquals(DiagnosisKind.DARK_BUT_FINE, d.kind)
        assertFalse(d.isProblem)
    }

    @Test
    fun blackGameWhileOwnScreenArrivesFineIsOnlySuspectedAfterTenSeconds() {
        m.onCaptureStarted()
        m.onFrame(scene(), own)
        m.onFrame(black(), game)
        clock.advance(5_000)
        assertFalse("too early", m.diagnose().kind == DiagnosisKind.GAME_BLACK_SUSPECTED_PROTECTION)
        clock.advance(6_000)
        val d = m.diagnose()
        assertEquals(DiagnosisKind.GAME_BLACK_SUSPECTED_PROTECTION, d.kind)
        assertTrue(d.offerVideoCalibration)
        // honest wording: not certain, no bypass, other recorders are not the same mechanism
        assertTrue(d.detail.contains("may be withholding"))
        assertTrue(d.detail.contains("will not try to get around"))
        assertTrue(d.detail.contains("not guaranteed to receive the same frames"))
    }

    @Test
    fun aLoadingScreenThatEndsIsNotReportedAsProtection() {
        m.onCaptureStarted()
        m.onFrame(scene(), own)
        m.onFrame(black(), game)
        clock.advance(8_000)
        m.onFrame(scene(2), game)
        clock.advance(20_000)
        assertEquals(DiagnosisKind.HEALTHY, m.diagnose().kind)
    }

    @Test
    fun partlyBlackGameIsReportedAsPartial() {
        m.onCaptureStarted()
        m.onFrame(scene(), own)
        m.onFrame(partlyBlack(0.8f), game)
        clock.advance(11_000)
        assertEquals(DiagnosisKind.GAME_PARTLY_BLACK_SUSPECTED_PROTECTION, m.diagnose().kind)
    }

    @Test
    fun blackEverywhereIsAPipelineProblemNotTheGame() {
        m.onCaptureStarted()
        repeat(4) { m.onFrame(black(), own) }
        val d = m.diagnose()
        assertEquals(DiagnosisKind.PIPELINE_BLACK, d.kind)
        assertTrue(d.detail.contains("not the game"))
    }

    @Test
    fun blackGameWithoutAnyOwnScreenSampleIsUndetermined() {
        m.onCaptureStarted()
        m.onFrame(black(), game)
        clock.advance(12_000)
        val d = m.diagnose()
        assertEquals(DiagnosisKind.GAME_BLACK_UNDETERMINED, d.kind)
        assertTrue(d.detail.contains("cannot be told apart"))
    }

    @Test
    fun blackFramesWhileSomethingElseIsInFrontAreNotBlamedOnTheGame() {
        m.onCaptureStarted()
        m.onFrame(scene(), own)
        m.onFrame(black(), FrameContext(ownAppInFront = false, gameInFront = false))
        clock.advance(30_000)
        assertFalse(m.diagnose().isProblem)
    }

    @Test
    fun historyIsBoundedAndPictureFree() {
        m.onCaptureStarted()
        repeat(200) { i -> m.onFrame(if (i % 2 == 0) scene() else black(), own); clock.advance(10) }
        assertTrue(m.history().size <= 40)
        assertTrue(m.history().all { it.length < 200 })
    }

    @Test
    fun theCaptureEndedStateReturnsToNotConnected() {
        m.onCaptureStarted()
        m.onFrame(scene(), own)
        m.onCaptureEnded()
        assertEquals(DiagnosisKind.NOT_CONNECTED, m.diagnose().kind)
    }
}

class AnalyzerDiagnosisTest {
    @Test
    fun staticFramesAreAnalyzerRejectionNotACaptureProblem() {
        val scene = SynthHud()
        val a = HudAnalyzer.analyse((0 until 14).map { scene.frame(it, it * 250L, moving = false) })
        val r = AnalyzerDiagnosis.classify(a.problem)
        assertEquals(AnalyzerRejection.STATIC_SCENE, r)
        assertTrue(AnalyzerDiagnosis.explain(r!!).contains("capture is working"))
    }

    @Test
    fun tooFewFramesAndNoElementsAreClassified() {
        val scene = SynthHud()
        val few = HudAnalyzer.analyse((0 until 4).map { scene.frame(it, it * 250L, moving = true) })
        assertEquals(AnalyzerRejection.TOO_FEW_FRAMES, AnalyzerDiagnosis.classify(few.problem))
        val none = HudAnalyzer.analyse((0 until 16).map { scene.frame(it, it * 250L, moving = true, drawHud = false) })
        assertEquals(AnalyzerRejection.NO_ELEMENTS, AnalyzerDiagnosis.classify(none.problem))
    }

    @Test
    fun noProblemMeansNoRejection() {
        assertNull(AnalyzerDiagnosis.classify(null))
        assertNotNull(AnalyzerDiagnosis.classify("something else"))
    }
}
