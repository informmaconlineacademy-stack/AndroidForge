package dev.toe3autopilot.core

import dev.toe3autopilot.core.calibration.CalibRole
import dev.toe3autopilot.core.calibration.ControlCandidateDetector
import dev.toe3autopilot.core.calibration.ControlDetection
import dev.toe3autopilot.core.calibration.DetectionStatus
import dev.toe3autopilot.core.calibration.PictureEvidence
import dev.toe3autopilot.core.setup.AnalysisProgress
import dev.toe3autopilot.core.setup.FrameEntry
import dev.toe3autopilot.core.setup.FrameOriginKind
import dev.toe3autopilot.core.setup.ScreenEvidence
import dev.toe3autopilot.core.setup.SetupAnalysis
import dev.toe3autopilot.core.vision.Roi
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * The many-picture path (what live Auto-Calibrate uses) on [Toe3RealScene]: a synthetic driving screen modelled on the
 * user's screenshots, with the hard parts on purpose (fixed trailer with door "pairs", gauges, round signs, HaulPilot's own
 * button, cut-out band, status bar, dusk, other screen shapes). Synthetic: it shows the method, not real gameplay.
 */
class Toe3RealSceneTest {
    private fun detect(s: Toe3RealScene, n: Int = 45, moving: Boolean = true, exclude: Boolean = true): ControlCandidateDetector.Result {
        val frames = (0 until n).map { s.frame(it, moving) }
        val ev = PictureEvidence.build(frames, frames.last(), if (exclude) listOf(s.haulPilotButtonBox) else emptyList())
        return ControlCandidateDetector.detect(ev)!!
    }

    private fun assertAt(d: ControlDetection?, truth: Roi) {
        assertNotNull(d)
        assertEquals("${d!!.role} status (${d.evidence.firstOrNull()})", DetectionStatus.NEEDS_CONFIRMATION, d.status)
        assertTrue("${d.role} at (${d.x}, ${d.y}) must lie on ${truth.format()}", d.x in truth.left..truth.right && d.y in truth.top..truth.bottom)
        assertTrue("${d.role} confidence stays capped", d.confidence <= ControlDetection.SHAPE_MAX_CONFIDENCE)
        assertTrue("${d.role} explains its evidence", d.evidence.size >= 3)
    }

    private fun assertNone(r: ControlCandidateDetector.Result, vararg roles: CalibRole) {
        for (role in roles) assertEquals("$role", DetectionStatus.NONE, r.detections.getValue(role).status)
    }

    private fun overlaps(a: Roi, b: Roi) = a.left < b.right && b.left < a.right && a.top < b.bottom && b.top < a.bottom

    private fun assertOwnButtonUnused(r: ControlCandidateDetector.Result, s: Toe3RealScene) {
        val own = s.haulPilotButtonBox
        for (d in r.detections.values) if (d.status != DetectionStatus.NONE) assertTrue("${d.role} on HaulPilot's button", !overlaps(d.box!!, own))
        r.marker?.let { assertTrue("driving-screen marker on HaulPilot's button", !overlaps(it, own)) }
    }

    private fun arrowsAndPedals(s: Toe3RealScene, r: ControlCandidateDetector.Result) {
        assertAt(r.detections[CalibRole.BRAKE], s.brake)
        assertAt(r.detections[CalibRole.ACCELERATOR], s.accelerator)
        assertAt(r.detections[CalibRole.STEER_LEFT], s.left)
        assertAt(r.detections[CalibRole.STEER_RIGHT], s.right)
        assertNone(r, CalibRole.STEER_WHEEL, CalibRole.GEAR_REVERSE)
        assertTrue(r.multiFrame)
    }

    @Test
    fun arrowLayoutLikeTheUsersScreen() {
        val s = Toe3RealScene().also { it.haulPilotButton = true }
        val r = detect(s)
        arrowsAndPedals(s, r)
        assertOwnButtonUnused(r, s)
        assertNotNull("a steady dashboard part is proposed for recognising the driving screen", r.marker)
    }

    @Test
    fun wheelLayout() {
        val s = Toe3RealScene().also { it.haulPilotButton = true; it.wheel = true }
        val r = detect(s)
        assertAt(r.detections[CalibRole.STEER_WHEEL], s.wheelBox)
        assertAt(r.detections[CalibRole.BRAKE], s.brake)
        assertAt(r.detections[CalibRole.ACCELERATOR], s.accelerator)
        assertNone(r, CalibRole.STEER_LEFT, CalibRole.STEER_RIGHT)
        assertOwnButtonUnused(r, s)
    }

    @Test
    fun cutoutBandStatusBarAndDusk() {
        val s = Toe3RealScene(480, 222, 14).also { it.haulPilotButton = true; it.statusBar = true; it.light = 0.6f }
        val r = detect(s)
        arrowsAndPedals(s, r)
        assertNotNull("the black cut-out band is reported", r.viewport)
        assertOwnButtonUnused(r, s)
    }

    @Test
    fun otherScreenShapes() {
        for ((w, h) in listOf(480 to 270, 480 to 360)) {
            val s = Toe3RealScene(w, h).also { it.haulPilotButton = true }
            arrowsAndPedals(s, detect(s))
        }
    }

    @Test
    fun faintControls() {
        val s = Toe3RealScene().also { it.haulPilotButton = true; it.hudAlpha = 0.3f }
        arrowsAndPedals(s, detect(s))
    }

    @Test
    fun withoutBeingToldWhereHaulPilotsButtonIsItIsStillNotAControl() {
        val s = Toe3RealScene().also { it.haulPilotButton = true }
        val r = detect(s, exclude = false)
        arrowsAndPedals(s, r)
        for (d in r.detections.values) if (d.status != DetectionStatus.NONE) assertTrue(!overlaps(d.box!!, s.haulPilotButtonBox))
    }

    @Test
    fun theTrailerAndTheGaugesAreNeverControls() {
        val s = Toe3RealScene().also { it.haulPilotButton = true }
        val r = detect(s)
        for (d in r.detections.values) {
            if (d.status == DetectionStatus.NONE) continue
            assertTrue("${d.role} on the trailer", !(d.x in s.trailer.left..s.trailer.right && d.y in s.trailer.top..s.trailer.bottom))
            assertTrue("${d.role} on the gauge", !(d.x in s.gauge.left..s.gauge.right && d.y in s.gauge.top..s.gauge.bottom))
        }
    }

    @Test
    fun noHudMeansNothingIsProposed() {
        val s = Toe3RealScene().also { it.haulPilotButton = true; it.showHud = false }
        val r = detect(s)
        for (d in r.detections.values) assertEquals("${d.role}", DetectionStatus.NONE, d.status)
        assertNull(r.minimap)
    }

    @Test
    fun aParkedTruckGivesWeakSinglePictureEvidenceAndSaysSo() {
        val s = Toe3RealScene().also { it.haulPilotButton = true }
        val r = detect(s, moving = false)
        assertTrue(!r.multiFrame)
        assertTrue(r.notes.any { it.contains("single picture") })
        for (d in r.detections.values) {
            if (d.status == DetectionStatus.NONE) continue
            assertTrue(d.confidence <= ControlDetection.SHAPE_MAX_CONFIDENCE.coerceAtMost(ControlCandidateDetector.SINGLE_PICTURE_MAX_CONFIDENCE))
        }
    }

    @Test
    fun theWholeAnalysisLeavesHaulPilotsButtonOutAndReportsRealProgress() {
        val s = Toe3RealScene().also { it.haulPilotButton = true }
        val frames = (0 until 45).map { i -> FrameEntry(i + 1, s.frame(i, true), FrameOriginKind.LIVE, 0.1f, ScreenEvidence.MOVING, exclusions = listOf(s.haulPilotButtonBox)) }
        val steps = ArrayList<AnalysisProgress>()
        val r = SetupAnalysis.run(frames, frames.last().id, progress = { steps += it })!!
        assertTrue(r.multiFrame)
        assertEquals(DetectionStatus.NEEDS_CONFIRMATION, r.detections.getValue(CalibRole.BRAKE).status)
        // Progress only moves forward and ends at 100 %.
        assertTrue(steps.zipWithNext().all { (a, b) -> b.fraction >= a.fraction })
        assertEquals(1f, steps.last().fraction, 1e-6f)
        r.marker?.let { assertTrue("marker on HaulPilot's button", !overlaps(it, s.haulPilotButtonBox)) }
        assertTrue(r.hud.elements.none { overlaps(it.box, s.haulPilotButtonBox) })
    }

    @Test
    fun theAnalysisStopsWhenCancelled() {
        val s = Toe3RealScene()
        val frames = (0 until 20).map { i -> FrameEntry(i + 1, s.frame(i, true), FrameOriginKind.LIVE, 0.1f, ScreenEvidence.MOVING) }
        var calls = 0
        val r = SetupAnalysis.run(frames, null) { calls++ >= 1 }
        assertNull(r)
    }
}
