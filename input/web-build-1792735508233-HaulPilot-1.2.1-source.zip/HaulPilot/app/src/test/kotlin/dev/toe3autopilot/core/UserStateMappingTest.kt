package dev.toe3autopilot.core

import dev.toe3autopilot.core.session.DrivePhase
import dev.toe3autopilot.core.session.SessionSnapshot
import dev.toe3autopilot.core.session.SessionStatus
import dev.toe3autopilot.core.session.UserState
import dev.toe3autopilot.core.session.userState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** The ten states the person sees, and what each internal session status/phase turns into. */
class UserStateMappingTest {
    private fun snap(status: SessionStatus, phase: DrivePhase? = null) = SessionSnapshot(status = status, phase = phase)

    @Test
    fun idleIsReadyOrCalibratingAndCalibrationNeverOverridesALiveSession() {
        assertEquals(UserState.READY, snap(SessionStatus.IDLE).userState(calibrating = false))
        assertEquals(UserState.CALIBRATING, snap(SessionStatus.IDLE).userState(calibrating = true))
        // A running drive is never shown as "calibrating" even if the calibration engine is busy.
        assertEquals(UserState.DRIVING, snap(SessionStatus.RUNNING, DrivePhase.DRIVING).userState(calibrating = true))
    }

    @Test
    fun runningPhasesMapToTheDrivingStates() {
        assertEquals(UserState.DRIVING, snap(SessionStatus.RUNNING, DrivePhase.DRIVING).userState(false))
        assertEquals(UserState.APPROACHING_TURN, snap(SessionStatus.RUNNING, DrivePhase.APPROACHING_TURN).userState(false))
        assertEquals(UserState.APPROACHING_DELIVERY, snap(SessionStatus.RUNNING, DrivePhase.APPROACHING).userState(false))
        assertEquals(UserState.PARKING, snap(SessionStatus.RUNNING, DrivePhase.PARKING).userState(false))
        assertEquals(UserState.PARKED, snap(SessionStatus.RUNNING, DrivePhase.PARKED).userState(false))
    }

    @Test
    fun haltsAreNeverShownAsDriving() {
        assertEquals(UserState.PAUSED, snap(SessionStatus.PAUSED, DrivePhase.DRIVING).userState(false))
        assertEquals(UserState.NEEDS_ASSISTANCE, snap(SessionStatus.NEEDS_ASSIST, DrivePhase.DRIVING).userState(false))
        assertEquals(UserState.NEEDS_ASSISTANCE, snap(SessionStatus.ERROR).userState(false))
        assertEquals(UserState.EMERGENCY_STOP, snap(SessionStatus.EMERGENCY_STOPPED, DrivePhase.PARKING).userState(false))
        assertEquals(UserState.PARKED, snap(SessionStatus.FINISHED, DrivePhase.PARKED).userState(false))
    }

    @Test
    fun everyRequiredStateExistsWithAReadableLabel() {
        val required = listOf(
            "READY", "CALIBRATING", "DRIVING", "APPROACHING_TURN", "APPROACHING_DELIVERY",
            "PARKING", "PARKED", "PAUSED", "NEEDS_ASSISTANCE", "EMERGENCY_STOP",
        )
        val names = UserState.entries.map { it.name }
        required.forEach { assertTrue("missing state $it", it in names) }
        UserState.entries.forEach { assertTrue(it.label.isNotBlank()) }
    }

    @Test
    fun onlyRunningAndStartingCountAsAnActiveLoop() {
        SessionStatus.entries.forEach { s ->
            assertEquals(s == SessionStatus.STARTING || s == SessionStatus.RUNNING, s.isActiveLoop)
        }
    }
}
