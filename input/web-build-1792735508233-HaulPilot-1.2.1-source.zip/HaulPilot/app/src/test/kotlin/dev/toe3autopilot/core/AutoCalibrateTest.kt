package dev.toe3autopilot.core

import dev.toe3autopilot.core.calibration.Alternative
import dev.toe3autopilot.core.calibration.CalibRole
import dev.toe3autopilot.core.calibration.ControlDetection
import dev.toe3autopilot.core.calibration.DetectionSource
import dev.toe3autopilot.core.calibration.DetectionStatus
import dev.toe3autopilot.core.calibration.LayoutSignature
import dev.toe3autopilot.core.capture.FrameOrigin
import dev.toe3autopilot.core.overlay.OverlayInputs
import dev.toe3autopilot.core.overlay.OverlayModel
import dev.toe3autopilot.core.overlay.OverlayUi
import dev.toe3autopilot.core.overlay.OwnUiRegions
import dev.toe3autopilot.core.profile.SteeringMode
import dev.toe3autopilot.core.session.SessionSnapshot
import dev.toe3autopilot.core.session.SessionStatus
import dev.toe3autopilot.core.setup.AnalysisProgress
import dev.toe3autopilot.core.setup.AutoReview
import dev.toe3autopilot.core.setup.AutoStage
import dev.toe3autopilot.core.setup.DraftApply
import dev.toe3autopilot.core.setup.DraftCodec
import dev.toe3autopilot.core.setup.DraftEdits
import dev.toe3autopilot.core.setup.DraftValidator
import dev.toe3autopilot.core.setup.IssueSeverity
import dev.toe3autopilot.core.setup.SetupAnalysis
import dev.toe3autopilot.core.setup.SetupDraft
import dev.toe3autopilot.core.setup.SetupPhase
import dev.toe3autopilot.core.setup.SetupSession
import dev.toe3autopilot.core.setup.SetupState
import dev.toe3autopilot.core.vision.Frame
import dev.toe3autopilot.core.vision.Roi
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * The one-action Auto-Calibrate flow: motion-aware collection, the automatic analysis, the review (markers, next
 * candidate, steering style, duplicates), confirm -> validate -> save, persistence, cancel / retry, HaulPilot's own UI
 * left out, and what the floating button shows.
 */
class AutoCalibrateTest {
    private val clock = FakeClock()

    private fun session(target: Int = 45) = SetupSession(clock, target = target)

    private val scene = Toe3RealScene().also { it.haulPilotButton = true }

    /** Feeds [n] live pictures 400 ms apart, each with HaulPilot's button as an exclusion (as the app does). */
    private fun feed(s: SetupSession, n: Int, moving: Boolean = true, from: Int = 0, sc: Toe3RealScene = scene) {
        repeat(n) { i ->
            clock.advance(400)
            s.onLink(true, null, FrameOrigin.GAME)
            s.offer(sc.frame(from + i, moving, clock.now), FrameOrigin.GAME, listOf(sc.haulPilotButtonBox))
        }
    }

    private fun runAnalysis(s: SetupSession): SetupState {
        val job = s.beginAnalysis()!!
        assertTrue(job.auto)
        val r = SetupAnalysis.run(job.frames, job.selectedId, progress = { s.reportProgress(job, it) })!!
        assertTrue(s.completeAnalysis(job, r))
        return s.state()
    }

    // ---- collection -------------------------------------------------------------------------------------------------

    @Test
    fun onlyPicturesWithMovingSceneryCountAndTheAnalysisIsRequestedByItself() {
        val s = session(target = 20)
        assertNull(s.startAuto())
        assertTrue(s.state().auto)
        // The first picture has nothing to compare with, so it is not a "moving" one: 20 moving pictures need 21.
        feed(s, 20)
        assertEquals(SetupPhase.CAPTURING, s.state().phase)
        assertEquals(19, s.state().runMoving)
        feed(s, 1, from = 20)
        val st = s.state()
        assertEquals(SetupPhase.REVIEW_REQUIRED, st.phase)
        assertTrue("the host is asked to analyse now", st.autoAnalyze)
        assertEquals(20, st.runMoving)
        assertTrue(st.frames.all { it.exclusions == listOf(scene.haulPilotButtonBox) })
        assertNotNull("a driving picture is suggested", st.selectedFrame)
        assertFalse("but not confirmed", st.draft.drivingConfirmed)
    }

    @Test
    fun aStandingTruckKeepsOnlyAFewPicturesAndAsksToDrive() {
        val s = session(target = 20)
        s.startAuto()
        feed(s, 12, moving = false)
        val st = s.state()
        assertEquals(SetupPhase.CAPTURING, st.phase)
        assertEquals(0, st.runMoving)
        assertTrue(st.frames.size <= SetupSession.MAX_STILL_AUTO + 1)
        assertTrue(st.stillSkipped > 0)
        assertTrue(st.message, st.message.contains("Drive forward"))
    }

    @Test
    fun theTimeLimitAnalysesWhatWasCollectedAndSaysTheEvidenceIsWeak() {
        val s = session(target = 45)
        s.startAuto()
        feed(s, 3, moving = false)
        clock.advance(SetupSession.AUTO_MAX_MS)
        s.onLink(true, null, FrameOrigin.GAME)
        val st = s.state()
        assertEquals(SetupPhase.REVIEW_REQUIRED, st.phase)
        assertTrue(st.autoAnalyze)
        assertTrue(st.message, st.message.contains("weaker evidence"))
    }

    @Test
    fun blackAndFrozenPicturesAreNotUsed() {
        val s = session(target = 10)
        s.startAuto()
        repeat(5) {
            clock.advance(400)
            s.offer(Frame.solid(480, 216, 0x000000, clock.now), FrameOrigin.GAME)
        }
        assertEquals(5, s.state().rejectedFrames)
        assertEquals(0, s.state().frames.size)
        // The same picture again and again (a frozen game) counts as still: a few are kept, none count.
        val frozen = scene.frame(3, false)
        repeat(10) {
            clock.advance(400)
            s.offer(Frame(frozen.width, frozen.height, frozen.argb.copyOf(), clock.now), FrameOrigin.GAME)
        }
        assertEquals(0, s.state().runMoving)
        assertTrue(s.state().frames.size <= SetupSession.MAX_STILL_AUTO)
        assertEquals(SetupPhase.CAPTURING, s.state().phase)
    }

    @Test
    fun picturesOfOtherAppsOrHaulPilotItselfAreIgnored() {
        val s = session(target = 10)
        s.startAuto()
        repeat(5) {
            clock.advance(400)
            s.offer(scene.frame(it, true, clock.now), FrameOrigin.OWN_APP)
            s.offer(scene.frame(it, true, clock.now), FrameOrigin.OTHER_APP)
        }
        assertEquals(0, s.state().frames.size)
    }

    @Test
    fun cancelKeepsThePicturesAndARetryStartsClean() {
        val s = session(target = 30)
        s.startAuto()
        feed(s, 8)
        s.cancel()
        assertEquals(SetupPhase.CANCELLED, s.state().phase)
        assertFalse(s.state().autoAnalyze)
        assertEquals(AutoStage.READY, AutoReview.stage(s.state(), captureOn = true))
        val token = s.state().token
        assertNull(s.startAuto())
        assertTrue(s.state().token > token)
        assertEquals("a new run starts from no pictures", 0, s.state().frames.size)
        feed(s, 31)
        assertTrue(s.state().autoAnalyze)
    }

    @Test
    fun stopEarlyAnalysesWhatWasCollected() {
        val s = session(target = 45)
        s.startAuto()
        feed(s, 12)
        s.stopCapture()
        assertTrue(s.state().autoAnalyze)
        assertEquals(AutoStage.ANALYSING, AutoReview.stage(s.state(), true))
    }

    // ---- the whole flow ---------------------------------------------------------------------------------------------

    @Test
    fun collectAnalyseReviewConfirmValidateSaveAndRestore() {
        val s = session(target = 45)
        s.startAuto()
        feed(s, 46)
        assertEquals(AutoStage.ANALYSING, AutoReview.stage(s.state(), true))
        val st = runAnalysis(s)
        assertEquals(AutoStage.REVIEW, AutoReview.stage(st, true))
        assertNull("progress is cleared when done", st.progress)
        assertTrue(st.analysisMultiFrame)
        assertTrue(st.message, st.message.startsWith("Found"))
        val d = st.draft
        // The arrows were found, so the review shows buttons (no wheel question), and nothing is confirmed yet.
        assertEquals(SteeringMode.BUTTONS, AutoReview.steering(d))
        assertEquals(listOf(CalibRole.ACCELERATOR, CalibRole.BRAKE, CalibRole.STEER_LEFT, CalibRole.STEER_RIGHT, CalibRole.GEAR_REVERSE), AutoReview.roles(AutoReview.steering(d)))
        assertTrue(AutoReview.stillToPlace(d, SteeringMode.BUTTONS).isEmpty())
        assertEquals(0, d.confirmedCount)
        assertNull("the driving-screen marker is never HaulPilot's own button", d.marker?.takeIf { overlaps(it, scene.haulPilotButtonBox) })

        // The person checks the markers and confirms: one undo step.
        val roles = AutoReview.roles(SteeringMode.BUTTONS)
        assertTrue(s.edit { DraftEdits.confirmReviewed(it, s.state().selectedFrame, emptyMap(), roles) })
        val after = s.state().draft
        assertEquals(4, after.confirmedCount)
        assertEquals(DetectionStatus.NONE, after.controls[CalibRole.GEAR_REVERSE]?.status ?: DetectionStatus.NONE)
        assertTrue(after.drivingConfirmed)
        assertEquals(SteeringMode.BUTTONS, after.steering)
        assertTrue(after.missingRequired.isEmpty())
        assertTrue(s.validate().none { it.severity == IssueSeverity.ERROR })
        assertTrue(s.state().canSave)

        val sel = s.state().selectedFrame!!
        val r = DraftApply.apply(null, after, sel.frame, "TOE3 Auto-Calibrate", "pkg", clock.now)
        assertTrue(r.problem, r.ok)
        assertNotNull(r.profile!!.control(Control.ACCELERATOR))
        assertNotNull(r.profile!!.control(Control.STEER_LEFT))
        assertEquals(SteeringMode.BUTTONS, r.profile!!.steeringMode)
        s.markSaved("TOE3 Auto-Calibrate")
        assertEquals(SetupPhase.CONFIRMED, s.state().phase)

        // Undo goes back to the unconfirmed candidates in one step.
        assertTrue(s.undo())
        assertEquals(0, s.state().draft.confirmedCount)
        assertTrue(s.redo())

        // The confirmed setup survives the app being closed.
        val parsed = DraftCodec.parse(DraftCodec.format(s.state().draft, "TOE3 Auto-Calibrate", false))
        assertTrue(parsed.warnings.toString(), parsed.warnings.isEmpty())
        assertEquals(SteeringMode.BUTTONS, parsed.draft.steering)
        for (role in roles.filter { it != CalibRole.GEAR_REVERSE }) {
            assertEquals(role.name, DetectionStatus.CONFIRMED, parsed.draft.controls[role]!!.status)
            assertEquals(after.controls[role]!!.x, parsed.draft.controls[role]!!.x, 1e-4f)
        }
    }

    @Test
    fun aMovedMarkerIsPlacedByThePersonAndTheRestStayCandidates() {
        val s = session()
        s.startAuto()
        feed(s, 46)
        runAnalysis(s)
        val brake = s.state().draft.controls[CalibRole.BRAKE]!!
        val p = AutoReview.regionFor(brake, s.state().hudBoxes, brake.x + 0.005f, brake.y, 480f / 216f)
        assertEquals("a small correction keeps the control's own outline", brake.box, p)
        s.edit { DraftEdits.place(it, CalibRole.BRAKE, brake.x + 0.005f, brake.y, p) }
        val d = s.state().draft
        assertEquals(DetectionSource.USER, d.controls[CalibRole.BRAKE]!!.source)
        assertEquals(DetectionStatus.CONFIRMED, d.controls[CalibRole.BRAKE]!!.status)
        assertEquals(DetectionStatus.NEEDS_CONFIRMATION, d.controls[CalibRole.ACCELERATOR]!!.status)
        // The next control to look at after the brake: the first one after it that still needs the person.
        assertEquals(CalibRole.STEER_LEFT, AutoReview.nextUnresolved(d, SteeringMode.BUTTONS, CalibRole.BRAKE))
        assertEquals(CalibRole.ACCELERATOR, AutoReview.nextUnresolved(d, SteeringMode.BUTTONS, CalibRole.STEER_RIGHT))
    }

    @Test
    fun aMarkerDraggedOntoAnotherControlCannotBeSaved() {
        val s = session()
        s.startAuto()
        feed(s, 46)
        runAnalysis(s)
        val acc = s.state().draft.controls[CalibRole.ACCELERATOR]!!
        s.edit { DraftEdits.place(it, CalibRole.BRAKE, acc.x + 0.005f, acc.y + 0.005f) }
        s.edit { DraftEdits.confirmReviewed(it, s.state().selectedFrame, emptyMap(), AutoReview.roles(SteeringMode.BUTTONS)) }
        val issues = s.validate()
        assertTrue(issues.toString(), issues.any { it.severity == IssueSeverity.ERROR && it.message.contains("same spot") })
        assertFalse(s.state().canSave)
    }

    @Test
    fun aStillTruckGivesTheSinglePictureResultAndSaysItIsWeaker() {
        val s = session(target = 45)
        s.startAuto()
        feed(s, 3, moving = false)
        clock.advance(SetupSession.AUTO_MAX_MS)
        s.onLink(true, null, FrameOrigin.GAME)
        val st = runAnalysis(s)
        assertFalse(st.analysisMultiFrame)
        assertTrue(st.analysisNotes.any { it.contains("single picture") })
    }

    @Test
    fun anAnalysisOfADifferentlyShapedScreenStartsFromAnEmptySetupAndUndoRestoresTheOldOne() {
        val s = session(target = 20)
        // An earlier setup made on a 20:9 screen.
        s.startAuto()
        feed(s, 21)
        runAnalysis(s)
        s.edit { DraftEdits.confirmReviewed(it, s.state().selectedFrame, emptyMap(), AutoReview.roles(SteeringMode.BUTTONS)) }
        val old = s.state().draft
        assertEquals(LayoutSignature(480, 216), old.layout)
        // Now the phone is used in another shape (4:3 window).
        val tall = Toe3RealScene(480, 360).also { it.haulPilotButton = true }
        s.startAuto()
        feed(s, 21, sc = tall)
        val st = runAnalysis(s)
        assertEquals("no position from the old shape is kept", 0, st.draft.confirmedCount)
        assertTrue(st.analysisNotes.any { it.contains("different screen shape") })
        assertTrue(s.undo())
        assertEquals(old.confirmedCount, s.state().draft.confirmedCount)
    }

    @Test
    fun progressFromAnOldJobIsIgnored() {
        val s = session(target = 20)
        s.startAuto()
        feed(s, 21)
        val job = s.beginAnalysis()!!
        s.reportProgress(job, AnalysisProgress(0.5f, "Finding the driving controls"))
        assertEquals(0.5f, s.state().progress!!.fraction, 1e-6f)
        s.cancel()
        s.reportProgress(job, AnalysisProgress(0.9f, "late"))
        assertNull(s.state().progress)
    }

    // ---- review helpers ---------------------------------------------------------------------------------------------

    private fun candidate(role: CalibRole, x: Float, y: Float, alts: List<Alternative> = emptyList()) = ControlDetection(
        role, x, y, Roi(x - 0.03f, y - 0.05f, x + 0.03f, y + 0.05f), 0.5f, DetectionStatus.NEEDS_CONFIRMATION, DetectionSource.SHAPE,
        listOf("found"), alts,
    )

    @Test
    fun steeringIsTakenFromWhatWasFoundOrAskedNeverAssumed() {
        val none = SetupDraft()
        assertNull(AutoReview.steering(none))
        assertEquals(listOf(CalibRole.ACCELERATOR, CalibRole.BRAKE, CalibRole.GEAR_REVERSE), AutoReview.roles(null))
        val buttons = none.copy(controls = mapOf(CalibRole.STEER_LEFT to candidate(CalibRole.STEER_LEFT, 0.06f, 0.85f)))
        assertEquals(SteeringMode.BUTTONS, AutoReview.steering(buttons))
        val wheel = none.copy(controls = mapOf(CalibRole.STEER_WHEEL to candidate(CalibRole.STEER_WHEEL, 0.15f, 0.7f)))
        assertEquals(SteeringMode.SLIDER, AutoReview.steering(wheel))
        // The person's choice wins.
        assertEquals(SteeringMode.SLIDER, AutoReview.steering(buttons.copy(steering = SteeringMode.SLIDER)))
        assertEquals(listOf(CalibRole.ACCELERATOR, CalibRole.BRAKE, CalibRole.STEER_WHEEL), AutoReview.required(SteeringMode.SLIDER))
    }

    @Test
    fun aTouchGrabsTheNearestMarkerWithinReachOnly() {
        val d = SetupDraft(
            controls = mapOf(
                CalibRole.BRAKE to candidate(CalibRole.BRAKE, 0.85f, 0.86f),
                CalibRole.ACCELERATOR to candidate(CalibRole.ACCELERATOR, 0.95f, 0.83f),
                CalibRole.STEER_LEFT to candidate(CalibRole.STEER_LEFT, 0.06f, 0.85f).copy(status = DetectionStatus.REJECTED),
            ),
        )
        val roles = AutoReview.roles(SteeringMode.BUTTONS)
        assertEquals(CalibRole.BRAKE, AutoReview.hit(d, roles, 0.86f, 0.86f, 0.03f, 0.06f))
        assertEquals(CalibRole.ACCELERATOR, AutoReview.hit(d, roles, 0.93f, 0.84f, 0.03f, 0.06f))
        assertNull("out of reach", AutoReview.hit(d, roles, 0.5f, 0.5f, 0.03f, 0.06f))
        assertNull("a rejected marker is not shown, so it cannot be grabbed", AutoReview.hit(d, roles, 0.06f, 0.85f, 0.03f, 0.06f))
        assertEquals(listOf(CalibRole.STEER_LEFT, CalibRole.STEER_RIGHT), AutoReview.stillToPlace(d, SteeringMode.BUTTONS))
        assertEquals(CalibRole.STEER_LEFT, AutoReview.firstUnresolved(d, SteeringMode.BUTTONS))
    }

    @Test
    fun theNextCandidateCyclesThroughWhatWasConsideredWithoutConfirmingAnything() {
        val a1 = Alternative(0.5f, 0.5f, Roi(0.48f, 0.45f, 0.52f, 0.55f), 0.4f, "another pair", listOf("alt evidence"))
        val a2 = Alternative(0.3f, 0.6f, null, 0.3f, "a third pair")
        var d = SetupDraft(controls = mapOf(CalibRole.BRAKE to candidate(CalibRole.BRAKE, 0.85f, 0.86f, listOf(a1, a2))))
        d = DraftEdits.nextAlternative(d, CalibRole.BRAKE)
        var c = d.controls.getValue(CalibRole.BRAKE)
        assertEquals(0.5f, c.x, 1e-6f)
        assertEquals(DetectionStatus.NEEDS_CONFIRMATION, c.status)
        assertEquals(0.4f, c.confidence, 1e-6f)
        assertEquals(listOf("alt evidence"), c.evidence)
        d = DraftEdits.nextAlternative(DraftEdits.nextAlternative(d, CalibRole.BRAKE), CalibRole.BRAKE)
        c = d.controls.getValue(CalibRole.BRAKE)
        assertEquals("back to the first proposal", 0.85f, c.x, 1e-6f)
        assertEquals(listOf("found"), c.evidence)
        assertEquals(0.5f, c.confidence, 1e-6f)
        // A confirmed control is not changed by it.
        val confirmed = DraftEdits.confirm(d, CalibRole.BRAKE)
        assertEquals(confirmed, DraftEdits.nextAlternative(confirmed, CalibRole.BRAKE))
    }

    @Test
    fun confirmingTheReviewConfirmsOnlyTheShownCandidates() {
        val d = SetupDraft(
            controls = mapOf(
                CalibRole.BRAKE to candidate(CalibRole.BRAKE, 0.85f, 0.86f),
                CalibRole.STEER_WHEEL to candidate(CalibRole.STEER_WHEEL, 0.15f, 0.7f),
                CalibRole.ACCELERATOR to candidate(CalibRole.ACCELERATOR, 0.95f, 0.83f).copy(status = DetectionStatus.REJECTED),
            ),
            steering = SteeringMode.BUTTONS,
        )
        val out = DraftEdits.confirmReviewed(d, null, emptyMap(), AutoReview.roles(SteeringMode.BUTTONS))
        assertEquals(DetectionStatus.CONFIRMED, out.controls[CalibRole.BRAKE]!!.status)
        assertEquals("not shown (buttons chosen), so not confirmed", DetectionStatus.NEEDS_CONFIRMATION, out.controls[CalibRole.STEER_WHEEL]!!.status)
        assertEquals("rejected stays rejected", DetectionStatus.REJECTED, out.controls[CalibRole.ACCELERATOR]!!.status)
        assertTrue(DraftValidator.validate(out).none { it.message.contains("same spot") })
    }

    @Test
    fun stagesFollowTheSetupState() {
        assertEquals(AutoStage.CONNECT, AutoReview.stage(SetupState(), captureOn = false))
        assertEquals(AutoStage.READY, AutoReview.stage(SetupState(), captureOn = true))
        assertEquals(AutoStage.COLLECTING, AutoReview.stage(SetupState(phase = SetupPhase.CAPTURING, auto = true), true))
        assertEquals(AutoStage.ANALYSING, AutoReview.stage(SetupState(phase = SetupPhase.ANALYZING), true))
        assertEquals(AutoStage.FAILED, AutoReview.stage(SetupState(phase = SetupPhase.FAILED, problem = "x"), true))
    }

    // ---- HaulPilot's own UI ----------------------------------------------------------------------------------------

    @Test
    fun ownWindowsBecomeRegionsOfTheCapturedPicture() {
        // A 52 dp button at 2.75 px/dp on a 2400 x 1080 landscape screen, at the right edge 30 % down.
        val regions = OwnUiRegions.of(listOf(OwnUiRegions.Window(2235, 310, 143, 143)), 2400, 1080, marginPx = 11)
        val r = regions.single()
        assertEquals((2235 - 11) / 2400f, r.left, 1e-4f)
        assertEquals((310 - 11) / 1080f, r.top, 1e-4f)
        assertEquals((2235 + 143 + 11) / 2400f, r.right, 1e-4f)
        assertEquals((310 + 143 + 11) / 1080f, r.bottom, 1e-4f)
        assertTrue("off-screen windows are dropped", OwnUiRegions.of(listOf(OwnUiRegions.Window(3000, 10, 50, 50)), 2400, 1080).isEmpty())
        assertTrue(OwnUiRegions.of(listOf(OwnUiRegions.Window(0, 0, 0, 10)), 2400, 1080).isEmpty())
        assertTrue(OwnUiRegions.of(listOf(OwnUiRegions.Window(0, 0, 10, 10)), 0, 0).isEmpty())
    }

    // ---- floating button -------------------------------------------------------------------------------------------

    private fun overlay(setup: SetupState) = OverlayModel.build(
        OverlayInputs(SessionSnapshot(status = SessionStatus.IDLE, task = "t"), captureOn = true, armedMessage = null, setup = setup, note = null, recordingSnapshots = false, showWhileCaptureOn = true, readyToDrive = false),
    )

    @Test
    fun theFloatingButtonShowsHonestAutoCalibrateProgressAndOffersTheReview() {
        val idle = overlay(SetupState())
        assertEquals(OverlayUi.AUTO_CALIBRATE, idle.calibrateLabel)
        assertTrue(idle.canStartCalibration)
        assertFalse(idle.canOpenReview)

        val collecting = overlay(SetupState(phase = SetupPhase.CAPTURING, auto = true, target = 40, runMoving = 10, runCollected = 14))
        assertEquals("only the moving pictures count", 25, collecting.calibration!!.percent)
        assertEquals("Stop and analyse now", collecting.cancelLabel)
        assertTrue(collecting.calibration!!.stageTitle.contains("drive forward"))
        assertNotNull(collecting.ring)

        val analysing = overlay(SetupState(phase = SetupPhase.ANALYZING, auto = true, progress = AnalysisProgress(0.4f, "Finding the driving controls")))
        assertEquals(40, analysing.calibration!!.percent)
        assertEquals("Cancel the analysis", analysing.cancelLabel)
        assertFalse(analysing.canStartCalibration)

        val waiting = overlay(
            SetupState(
                phase = SetupPhase.REVIEW_REQUIRED, auto = true,
                draft = SetupDraft(analysed = true, controls = mapOf(CalibRole.BRAKE to candidate(CalibRole.BRAKE, 0.85f, 0.86f))),
            ),
        )
        assertTrue(waiting.canOpenReview)
        assertEquals("Auto-Calibrate again", waiting.calibrateLabel)
        assertTrue(waiting.status, waiting.status.contains("found 1 control"))
        assertTrue("nothing is used before it is confirmed", waiting.status.contains("nothing is used"))

        val manual = overlay(SetupState(phase = SetupPhase.CAPTURING, auto = false, target = 45, runCollected = 9))
        assertEquals(20, manual.calibration!!.percent)
        assertEquals("Stop collecting", manual.cancelLabel)
    }

    private fun overlaps(a: Roi, b: Roi) = a.left < b.right && b.left < a.right && a.top < b.bottom && b.top < a.bottom
}
