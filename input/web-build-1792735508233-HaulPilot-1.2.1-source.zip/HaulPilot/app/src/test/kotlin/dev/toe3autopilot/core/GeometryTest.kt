package dev.toe3autopilot.core

import dev.toe3autopilot.core.geometry.Affine
import dev.toe3autopilot.core.geometry.CaptureGeometry
import dev.toe3autopilot.core.geometry.DisplaySpace
import dev.toe3autopilot.core.geometry.EditorTransform
import dev.toe3autopilot.core.geometry.FitTransform
import dev.toe3autopilot.core.geometry.FrameSpace
import dev.toe3autopilot.core.geometry.RectF
import dev.toe3autopilot.core.geometry.Vec2
import dev.toe3autopilot.core.geometry.ZoomPan
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import kotlin.random.Random

class GeometryTest {
    private val eps = 1e-3f

    private fun assertVec(expected: Vec2, actual: Vec2, tol: Float = eps, msg: String = "") {
        assertEquals("$msg x", expected.x, actual.x, tol)
        assertEquals("$msg y", expected.y, actual.y, tol)
    }

    private val corners = listOf(Vec2(0f, 0f), Vec2(1f, 0f), Vec2(0f, 1f), Vec2(1f, 1f), Vec2(0.5f, 0.5f))

    // ---- Affine -------------------------------------------------------------------------------------------------

    @Test
    fun affineInverseRoundTripsRandomTransforms() {
        val rnd = Random(7)
        repeat(200) {
            val t = Affine.scale(rnd.nextFloat() * 5 + 0.1f, rnd.nextFloat() * 5 + 0.1f)
                .then(Affine.rotateUnitSquare(rnd.nextInt(4)))
                .then(Affine.translate(rnd.nextFloat() * 400 - 200, rnd.nextFloat() * 400 - 200))
            val p = Vec2(rnd.nextFloat() * 1000, rnd.nextFloat() * 1000)
            assertVec(p, t.inverse().map(t.map(p)), 1e-2f)
        }
    }

    @Test
    fun thenAppliesLeftTransformFirst() {
        val t = Affine.translate(10f, 0f).then(Affine.scale(2f))
        assertVec(Vec2(22f, 4f), t.map(1f, 2f)) // (1+10)*2, 2*2
        val u = Affine.scale(2f).then(Affine.translate(10f, 0f))
        assertVec(Vec2(12f, 4f), u.map(1f, 2f))
    }

    @Test
    fun rotationOfTheUnitSquareMapsCornersOntoCorners() {
        val r1 = Affine.rotateUnitSquare(1)
        assertVec(Vec2(1f, 0f), r1.map(0f, 0f)) // top-left -> top-right (clockwise)
        assertVec(Vec2(1f, 1f), r1.map(1f, 0f))
        assertVec(Vec2(0f, 1f), r1.map(1f, 1f))
        assertVec(Vec2(0f, 0f), r1.map(0f, 1f))
        assertVec(Vec2(0.5f, 0.5f), r1.map(0.5f, 0.5f))
        for (q in 0..3) {
            val back = Affine.rotateUnitSquare(q).then(Affine.rotateUnitSquare(4 - q))
            for (c in corners) assertVec(c, back.map(c), msg = "q=$q")
            for (c in corners) assertVec(c, Affine.rotateUnitSquare(q).inverse().map(Affine.rotateUnitSquare(q).map(c)))
        }
        assertEquals(Affine.rotateUnitSquare(1), Affine.rotateUnitSquare(5))
        assertEquals(Affine.rotateUnitSquare(3), Affine.rotateUnitSquare(-1))
    }

    @Test(expected = IllegalStateException::class)
    fun singularTransformCannotBeInverted() {
        Affine.scale(0f, 1f).inverse()
    }

    // ---- Display / frame ----------------------------------------------------------------------------------------

    @Test
    fun displaySpaceCornersAndCentre() {
        val d = DisplaySpace(2400, 1080)
        assertVec(Vec2(0f, 0f), d.toPixels.map(0f, 0f))
        assertVec(Vec2(2400f, 1080f), d.toPixels.map(1f, 1f))
        assertVec(Vec2(1200f, 540f), d.toPixels.map(0.5f, 0.5f))
        for (c in corners) assertVec(c, d.toNormalized.map(d.toPixels.map(c)))
        // A touch at the very edge stays on the screen.
        assertVec(Vec2(2399f, 1079f), d.touchPoint(1f, 1f))
        assertVec(Vec2(0f, 0f), d.touchPoint(-0.2f, -1f))
    }

    @Test
    fun frameSpacePixelLookupIsClampedAndRoundTrips() {
        val f = FrameSpace(480, 216)
        assertEquals(0 to 0, f.pixelAt(0f, 0f))
        assertEquals(479 to 215, f.pixelAt(1f, 1f))
        assertEquals(240 to 108, f.pixelAt(0.5f, 0.5f))
        for (c in corners) assertVec(c, f.toNormalized.map(f.toPixels.map(c)))
    }

    // ---- Capture surface (letterbox / crop) ---------------------------------------------------------------------

    @Test
    fun surfaceSizeKeepsTheDisplayAspect() {
        assertEquals(480 to 216, CaptureGeometry.chooseSurfaceSize(2400, 1080, 480))
        assertEquals(480 to 222, CaptureGeometry.chooseSurfaceSize(2340, 1080, 480)) // 221.5 rounds to 222
        assertEquals(216 to 480, CaptureGeometry.chooseSurfaceSize(1080, 2400, 480))
        assertEquals(480 to 300, CaptureGeometry.chooseSurfaceSize(2560, 1600, 480)) // tablet 16:10
        assertEquals(320 to 200, CaptureGeometry.chooseSurfaceSize(320, 200, 480)) // never upscaled
        for ((w, h) in listOf(2400 to 1080, 2340 to 1080, 3200 to 1440, 1920 to 1200, 2208 to 1768)) {
            val (sw, sh) = CaptureGeometry.chooseSurfaceSize(w, h, 480)
            val err = kotlin.math.abs(sw.toFloat() / sh - w.toFloat() / h) / (w.toFloat() / h)
            assertTrue("aspect error $err for ${w}x$h", err < 0.005f)
        }
    }

    @Test
    fun matchingAspectHasNoBoxesAndMapsCornersExactly() {
        val g = CaptureGeometry(2400, 1080, 480, 216)
        assertEquals(RectF(0f, 0f, 480f, 216f), g.contentRect)
        assertVec(Vec2(0f, 0f), g.surfaceToNormalized.map(0f, 0f))
        assertVec(Vec2(1f, 1f), g.surfaceToNormalized.map(480f, 216f))
        assertVec(Vec2(0.5f, 0.5f), g.surfaceToNormalized.map(240f, 108f))
        for (c in corners) assertVec(c, g.surfaceToNormalized.map(g.normalizedToSurface.map(c)))
    }

    @Test
    fun aspectMismatchIsPillarBoxedAndCropped() {
        // The old capture code rounded 2340x1080 to a 480x220 surface. The mirrored display is fitted inside it.
        val g = CaptureGeometry(2340, 1080, 480, 220)
        val r = g.contentRect
        assertEquals(220f, r.height, eps)
        assertEquals(2340f * 220f / 1080f, r.width, eps) // 476.67: pillar-boxed
        assertEquals((480f - r.width) / 2f, r.left, eps)
        // Content corners are NDS corners; surface corners are slightly outside the display.
        assertVec(Vec2(0f, 0f), g.surfaceToNormalized.map(r.left, r.top))
        assertVec(Vec2(1f, 1f), g.surfaceToNormalized.map(r.right, r.bottom))
        assertTrue(g.surfaceToNormalized.map(0f, 0f).x < 0f)
        // Without the correction a control at NDS x=0.95 would be read at a different place.
        val naive = g.normalizedToSurface.map(0.95f, 0.5f).x / 480f
        assertTrue("naive x $naive should differ from 0.95", kotlin.math.abs(naive - 0.95f) > 0.002f)
        val crop = g.cropRect
        assertEquals(2, crop.x0)
        assertEquals(478, crop.x1)
        assertEquals(0, crop.y0)
        assertEquals(220, crop.y1)
    }

    @Test
    fun letterBoxedPortraitSurface() {
        val g = CaptureGeometry(1080, 2400, 216, 500)
        val r = g.contentRect
        assertEquals(216f, r.width, eps)
        assertEquals(480f, r.height, eps)
        assertEquals(10f, r.top, eps)
        for (c in corners) assertVec(c, g.surfaceToNormalized.map(g.normalizedToSurface.map(c)))
        assertEquals(10, g.cropRect.y0)
        assertEquals(490, g.cropRect.y1)
    }

    // ---- Fit / zoom / pan ---------------------------------------------------------------------------------------

    @Test
    fun fitLetterBoxesALandscapePictureInAPortraitView() {
        val fit = FitTransform(480f, 216f, 1080f, 1600f)
        assertEquals(2.25f, fit.scale, eps)
        val r = fit.imageRect
        assertEquals(0f, r.left, eps)
        assertEquals(1080f, r.right, eps)
        assertEquals((1600f - 486f) / 2f, r.top, eps)
        assertVec(Vec2(r.left, r.top), fit.imageToView.map(0f, 0f))
        assertVec(Vec2(r.right, r.bottom), fit.imageToView.map(480f, 216f))
        assertVec(Vec2(540f, 800f), fit.imageToView.map(240f, 108f))
        for (c in corners) {
            val p = Vec2(c.x * 480f, c.y * 216f)
            assertVec(p, fit.viewToImage.map(fit.imageToView.map(p)))
        }
    }

    @Test
    fun fitPillarBoxesInAWideView() {
        val fit = FitTransform(400f, 300f, 2000f, 600f)
        assertEquals(2f, fit.scale, eps)
        assertEquals(600f, fit.imageRect.left, eps)
        assertEquals(1400f, fit.imageRect.right, eps)
    }

    @Test
    fun zoomKeepsTheFocusPointFixed() {
        val z = ZoomPan.NONE.transformed(3f, 300f, 200f, 0f, 0f)
        assertVec(Vec2(300f, 200f), z.forward.map(300f, 200f))
        assertEquals(3f, z.scale, eps)
        val z2 = z.transformed(0.5f, 50f, 70f, 0f, 0f)
        val before = z.backward.map(50f, 70f)
        assertVec(Vec2(50f, 70f), z2.forward.map(before))
    }

    @Test
    fun zoomIsLimited() {
        assertEquals(ZoomPan.MAX_SCALE, ZoomPan.NONE.transformed(100f, 0f, 0f, 0f, 0f).scale, eps)
        assertEquals(1f, ZoomPan.NONE.transformed(0.01f, 0f, 0f, 0f, 0f).scale, eps)
    }

    @Test
    fun panIsClampedSoThePictureCannotDriftAway() {
        val view = 1000f to 600f
        val content = RectF(0f, 75f, 1000f, 525f) // fitted 1000x450 picture
        val z = ZoomPan(2f, 0f, 0f).transformed(1f, 0f, 0f, 5000f, 5000f).clampedTo(view.first, view.second, content)
        // Zoomed content: x 0..2000, y 150..1050 before translation. Left edge may not move right of 0, top not below 0.
        assertEquals(0f, z.tx, eps)
        assertEquals(-150f, z.ty, eps)
        val far = ZoomPan(2f, -99999f, -99999f).clampedTo(view.first, view.second, content)
        assertEquals(1000f - 2000f, far.tx, eps)
        assertEquals(600f - 1050f, far.ty, eps)
        // Un-zoomed content smaller than the view is centred.
        val small = ZoomPan(1f, 300f, 300f).clampedTo(view.first, view.second, content)
        assertEquals(0f, small.tx, eps)
        assertEquals(0f, small.ty, eps)
    }

    // ---- Editor chain -------------------------------------------------------------------------------------------

    @Test
    fun editorRoundTripsAllCornersAtManyZoomLevels() {
        val rnd = Random(3)
        for ((iw, ih, vw, vh) in listOf(
            listOf(480f, 216f, 1080f, 1600f), listOf(480f, 216f, 2200f, 900f), listOf(300f, 480f, 1080f, 1500f), listOf(480f, 300f, 800f, 800f),
        )) {
            val fit = FitTransform(iw, ih, vw, vh)
            repeat(20) {
                val zoom = ZoomPan.NONE
                    .transformed(1f + rnd.nextFloat() * 6f, rnd.nextFloat() * vw, rnd.nextFloat() * vh, rnd.nextFloat() * 200 - 100, rnd.nextFloat() * 200 - 100)
                    .clampedTo(vw, vh, fit.imageRect)
                val ed = EditorTransform(fit, zoom)
                for (c in corners) {
                    val s = ed.toScreen(c.x, c.y)
                    val back = ed.backward.map(s)
                    assertVec(c, back, 1e-3f, "corner $c zoom ${zoom.scale}")
                }
            }
        }
    }

    @Test
    fun touchesOutsideThePictureAreIgnored() {
        val fit = FitTransform(480f, 216f, 1080f, 1600f)
        val ed = EditorTransform(fit, ZoomPan.NONE)
        assertNull(ed.toNormalized(540f, 10f)) // in the letter-box above the picture
        assertNotNull(ed.toNormalized(540f, 800f))
        assertVec(Vec2(0.5f, 0.5f), ed.toNormalized(540f, 800f)!!)
        assertVec(Vec2(0.5f, 0f), ed.toNormalizedClamped(540f, 10f))
    }

    @Test
    fun aTapLandsOnTheSameNdsPointAfterZoomingAndPanning() {
        // A pedal at NDS (0.9, 0.8). Whatever the zoom, tapping where its marker is drawn returns the same point.
        val fit = FitTransform(480f, 216f, 1080f, 1600f)
        var zoom = ZoomPan.NONE
        val target = Vec2(0.9f, 0.8f)
        repeat(10) { i ->
            zoom = zoom.transformed(1.3f, 900f, 900f, -15f * i, 7f * i).clampedTo(1080f, 1600f, fit.imageRect)
            val ed = EditorTransform(fit, zoom)
            val onScreen = ed.toScreen(target.x, target.y)
            assertVec(target, ed.toNormalized(onScreen.x, onScreen.y)!!, 1e-3f)
        }
    }

    @Test
    fun normalisedSizeOfScreenPixelsShrinksWithZoom() {
        val fit = FitTransform(480f, 216f, 1080f, 1600f)
        val a = EditorTransform(fit, ZoomPan.NONE).normalizedSizeOf(10f)
        val b = EditorTransform(fit, ZoomPan(4f)).normalizedSizeOf(10f)
        assertEquals(a.x / 4f, b.x, 1e-5f)
        assertEquals(10f / 1080f, a.x, 1e-5f)
    }

    @Test
    fun captureToEditorToTouchChainIsConsistent() {
        // Display -> capture surface -> cropped frame -> editor -> back to display pixels for the gesture.
        val display = DisplaySpace(2340, 1080)
        val (sw, sh) = CaptureGeometry.chooseSurfaceSize(2340, 1080, 480)
        val cap = CaptureGeometry(2340, 1080, sw, sh)
        val crop = cap.cropRect
        val frame = FrameSpace(crop.width, crop.height)
        // A control drawn by the game at display pixel (2200, 950):
        val nds = display.toNormalized.map(2200f, 950f)
        val inSurface = cap.normalizedToSurface.map(nds)
        val inFrame = Vec2(inSurface.x - crop.x0, inSurface.y - crop.y0)
        val ndsFromFrame = frame.toNormalized.map(inFrame)
        assertVec(nds, ndsFromFrame, 0.003f)
        val ed = EditorTransform(FitTransform(frame.width.toFloat(), frame.height.toFloat(), 1080f, 1700f), ZoomPan(3f, -1800f, -900f))
        val screen = ed.toScreen(ndsFromFrame.x, ndsFromFrame.y)
        val picked = ed.backward.map(screen)
        val touch = display.touchPoint(picked.x, picked.y)
        assertEquals(2200f, touch.x, 2340f * 0.003f)
        assertEquals(950f, touch.y, 1080f * 0.003f)
    }
}
