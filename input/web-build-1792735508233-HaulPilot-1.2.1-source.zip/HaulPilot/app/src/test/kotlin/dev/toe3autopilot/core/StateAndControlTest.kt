package dev.toe3autopilot.core

import dev.toe3autopilot.core.profile.SteeringMode
import dev.toe3autopilot.core.session.ControlMapper
import dev.toe3autopilot.core.state.GameState
import dev.toe3autopilot.core.state.StateDetector
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class StateDetectorTest {
    private val profile = TestProfiles.full()

    private fun vision(vararg names: String) = FakeVision().also { v -> names.forEach { v.put(it, 0.5f, 0.5f, 0.9f) } }

    @Test
    fun stateChangesOnlyAfterTwoAgreeingFrames() {
        val d = StateDetector(profile)
        val first = d.update(vision("hud_marker"))
        assertEquals(GameState.UNKNOWN, first.state)
        assertEquals(GameState.DRIVING, first.candidate)
        val second = d.update(vision("hud_marker"))
        assertEquals(GameState.DRIVING, second.state)
        assertEquals(0.9f, second.confidence, 0.001f)
    }

    @Test
    fun anUnchangedScreenCountsAsPersistenceOfTheLastCandidate() {
        // A live capture delivers no new frame while the screen is static; the session then calls repeat().
        val d = StateDetector(profile)
        assertEquals(GameState.UNKNOWN, d.update(vision("hud_marker")).state)
        val again = d.repeat()
        assertEquals(GameState.DRIVING, again.state)
        assertEquals(0.9f, again.confidence, 0.001f)
        assertEquals(GameState.DRIVING, d.repeat().state)
    }

    @Test
    fun singleFrameFlickerIsIgnored() {
        val d = StateDetector(profile)
        repeat(3) { d.update(vision("hud_marker")) }
        assertEquals(GameState.DRIVING, d.update(vision()).state) // one blank frame
        assertEquals(GameState.DRIVING, d.update(vision("hud_marker")).state)
        assertEquals(GameState.DRIVING, d.update(vision()).state)
        assertEquals(GameState.UNKNOWN, d.update(vision()).state) // two in a row: now it changes
    }

    @Test
    fun interruptingDialogBeatsTheHudBeneathIt() {
        val d = StateDetector(profile)
        repeat(2) { d.update(vision("hud_marker", "dialog_marker")) }
        assertEquals(GameState.UNEXPECTED_DIALOG, d.update(vision("hud_marker", "dialog_marker")).state)
    }

    @Test
    fun crashScreenBeatsTheHudBeneathIt() {
        val d = StateDetector(profile)
        repeat(2) { d.update(vision("hud_marker", "crash_marker")) }
        assertEquals(GameState.CRASH_OR_PENALTY, d.update(vision("hud_marker", "crash_marker")).state)
    }

    @Test
    fun negatedTemplatesSeparateTheDrivingViewFromTheParkingView() {
        val a = StateDetector(profile)
        repeat(2) { a.update(vision("hud_marker")) }
        assertEquals(GameState.DRIVING, a.update(vision("hud_marker")).state)
        val b = StateDetector(profile)
        repeat(3) { b.update(vision("hud_marker", "parking_hud")) }
        assertEquals(GameState.PARKING, b.update(vision("hud_marker", "parking_hud")).state)
    }

    @Test
    fun theDeliveryScreenIsRecognised() {
        val d = StateDetector(profile)
        repeat(2) { d.update(vision("delivery_header")) }
        assertEquals(GameState.DELIVERY_COMPLETE, d.update(vision("delivery_header")).state)
    }

    @Test
    fun nothingMatchingIsUnknownWithZeroConfidence() {
        val d = StateDetector(profile)
        val e = d.update(vision())
        assertEquals(GameState.UNKNOWN, e.candidate)
        assertEquals(0f, e.confidence, 0f)
    }
}

class ControlMapperTest {
    private val c = TestProfiles.CONTROLS

    @Test
    fun fullThrottleIsAlwaysPressedAndBrakeCancelsIt() {
        val m = ControlMapper(TestProfiles.full())
        val go = m.map(DriveCommand(throttle = 1f), 123, 0.1f, null)
        assertTrue(go.holds.containsKey(Control.ACCELERATOR))
        val stop = m.map(DriveCommand(throttle = 1f, brake = 1f), 123, 0.1f, null)
        assertTrue(stop.holds.containsKey(Control.BRAKE))
        assertFalse(stop.holds.containsKey(Control.ACCELERATOR))
    }

    @Test
    fun partialThrottleIsDutyCycled() {
        val m = ControlMapper(TestProfiles.full(), pwmPeriodMs = 1000)
        val on = m.map(DriveCommand(throttle = 0.5f), 200, 0.1f, null).holds.containsKey(Control.ACCELERATOR)
        val off = m.map(DriveCommand(throttle = 0.5f), 700, 0.1f, null).holds.containsKey(Control.ACCELERATOR)
        assertTrue(on)
        assertFalse(off)
        var pressed = 0
        for (t in 0 until 1000 step 10) if (m.map(DriveCommand(throttle = 0.3f), t.toLong(), 0.1f, null).holds.containsKey(Control.ACCELERATOR)) pressed++
        assertEquals(30.0, pressed.toDouble(), 2.0)
        assertFalse(m.map(DriveCommand(throttle = 0.02f), 1L, 0.1f, null).holds.containsKey(Control.ACCELERATOR))
    }

    @Test
    fun sliderSteeringMovesTheTouchPointHorizontally() {
        val centre = c[Control.STEER_CENTER]!!
        val right = ControlMapper(TestProfiles.full()).map(DriveCommand(steer = 1f), 0, 0.1f, null).holds[Control.STEER_CENTER]!!
        assertEquals(centre.x + 0.12f, right.x, 0.0001f)
        assertEquals(centre.y, right.y, 0f)
        val straight = ControlMapper(TestProfiles.full()).map(DriveCommand(steer = 0f), 0, 0.1f, null).holds[Control.STEER_CENTER]!!
        assertEquals(centre.x, straight.x, 0.0001f)
        val clamped = ControlMapper(TestProfiles.full()).map(DriveCommand(steer = 5f), 0, 0.1f, null).holds[Control.STEER_CENTER]!!
        assertEquals(centre.x + 0.12f, clamped.x, 0.0001f)
    }

    @Test
    fun steeringRateIsLimitedWhateverTheAgentAsks() {
        val m = ControlMapper(TestProfiles.full(), maxSteerRatePerSec = 2.0f)
        val centre = c[Control.STEER_CENTER]!!
        fun steerOf(now: Long, demand: Float): Float =
            (m.map(DriveCommand(steer = demand), now, 0.1f, null).holds[Control.STEER_CENTER]!!.x - centre.x) / 0.12f
        assertEquals(0f, steerOf(0, 0f), 0.001f)
        assertEquals(0.3f, steerOf(150, 1f), 0.01f) // 2.0/s * 0.15 s
        assertEquals(0.6f, steerOf(300, 1f), 0.01f)
        var s = 0f
        var t = 300L
        repeat(10) { t += 150; s = steerOf(t, 1f) }
        assertEquals(1f, s, 0.001f)
        assertEquals(0.7f, steerOf(t + 150, -1f), 0.01f) // and it unwinds just as gradually
    }

    @Test
    fun buttonSteeringUsesADeadbandAndTheRightButton() {
        val base = TestProfiles.full(SteeringMode.BUTTONS)
        val profile = base.copy(controls = base.controls + mapOf(Control.STEER_LEFT to Point(0.1f, 0.8f), Control.STEER_RIGHT to Point(0.2f, 0.8f)))
        assertTrue(ControlMapper(profile).map(DriveCommand(steer = 0.05f), 0, 0.1f, null).holds.keys.none { it == Control.STEER_LEFT || it == Control.STEER_RIGHT })
        assertTrue(ControlMapper(profile).map(DriveCommand(steer = 1f), 0, 0.1f, null).holds.containsKey(Control.STEER_RIGHT))
        assertTrue(ControlMapper(profile).map(DriveCommand(steer = -1f), 0, 0.1f, null).holds.containsKey(Control.STEER_LEFT))
    }

    @Test
    fun gearChangeWaitsUntilTheTruckHasStopped() {
        val m = ControlMapper(TestProfiles.full())
        val moving = m.map(DriveCommand(throttle = 0.5f, gear = Gear.REVERSE), 0, 0.05f, null)
        assertTrue(moving.taps.isEmpty())
        assertTrue(moving.holds.containsKey(Control.BRAKE))
        assertFalse(moving.holds.containsKey(Control.ACCELERATOR))

        val stopped = m.map(DriveCommand(throttle = 0.5f, gear = Gear.REVERSE), 0, 0.0f, null)
        assertEquals(listOf(Control.GEAR_REVERSE), stopped.taps)
        assertFalse(stopped.holds.containsKey(Control.ACCELERATOR))

        // Now believed to be in reverse: no second tap, throttle allowed.
        val after = m.map(DriveCommand(throttle = 1f, gear = Gear.REVERSE), 0, 0.0f, null)
        assertTrue(after.taps.isEmpty())
        assertTrue(after.holds.containsKey(Control.ACCELERATOR))
    }

    @Test
    fun observedGearOverridesTheBelief() {
        val m = ControlMapper(TestProfiles.full())
        m.map(DriveCommand(gear = Gear.REVERSE), 0, 0f, null) // tap, now believes reverse
        val again = m.map(DriveCommand(gear = Gear.REVERSE), 0, 0f, observedReverse = false) // HUD says it is not
        assertEquals(listOf(Control.GEAR_REVERSE), again.taps)
    }

    @Test
    fun missingControlsAreReportedNotIgnored() {
        val base = TestProfiles.full()
        val noReverse = base.copy(controls = base.controls - Control.GEAR_REVERSE)
        val out = ControlMapper(noReverse).map(DriveCommand(gear = Gear.REVERSE), 0, 0f, null)
        assertTrue(out.error!!.contains("GEAR_REVERSE"))
    }
}
