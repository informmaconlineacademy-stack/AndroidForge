package dev.toe3autopilot.core

import dev.toe3autopilot.core.overlay.DockPosition
import dev.toe3autopilot.core.overlay.OverlayInputs
import dev.toe3autopilot.core.overlay.OverlayModel
import dev.toe3autopilot.core.overlay.OverlayPlacement
import dev.toe3autopilot.core.overlay.OverlayUi
import dev.toe3autopilot.core.overlay.OverlayTone
import dev.toe3autopilot.core.overlay.TapGuard
import dev.toe3autopilot.core.session.DrivePhase
import dev.toe3autopilot.core.session.SessionSnapshot
import dev.toe3autopilot.core.session.SessionStatus
import dev.toe3autopilot.core.session.UserState
import dev.toe3autopilot.core.setup.SetupPhase
import dev.toe3autopilot.core.setup.SetupSession
import dev.toe3autopilot.core.setup.SetupState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** The floating controls are a pure function of the app state: these tests pin that mapping down. */
class OverlayModelTest {
    private fun inputs(
        status: SessionStatus = SessionStatus.IDLE,
        phase: DrivePhase? = null,
        capture: Boolean = true,
        armed: String? = null,
        setup: SetupState = SetupState(),
        note: String? = null,
        show: Boolean = true,
        ready: Boolean = true,
    ) = OverlayInputs(
        snapshot = SessionSnapshot(status = status, phase = phase, task = "task text"),
        captureOn = capture,
        armedMessage = armed,
        setup = setup,
        note = note,
        recordingSnapshots = false,
        showWhileCaptureOn = show,
        readyToDrive = ready,
        notReadyReason = if (ready) null else "Control BRAKE is not calibrated",
    )

    @Test
    fun hiddenWhenNothingIsHappeningAndCaptureIsOff() {
        val ui = OverlayModel.build(inputs(capture = false))
        assertFalse(ui.visible)
        assertFalse(ui.canStartDrive)
    }

    @Test
    fun readyWithCaptureOnOffersStartAndCalibrationButNotPause() {
        val ui = OverlayModel.build(inputs())
        assertTrue(ui.visible)
        assertEquals(UserState.READY, ui.state)
        assertTrue(ui.canStartDrive)
        assertTrue(ui.canStartCalibration)
        assertFalse(ui.canPause)
        assertFalse(ui.canResume)
        assertFalse(ui.canEnd)
        assertTrue(ui.canEmergency)
    }

    @Test
    fun theSettingCanHideTheIdleButtonButNeverDuringADrive() {
        assertFalse(OverlayModel.build(inputs(show = false)).visible)
        assertTrue(OverlayModel.build(inputs(status = SessionStatus.RUNNING, phase = DrivePhase.DRIVING, show = false)).visible)
    }

    @Test
    fun drivingAllowsPauseAndEndButNotAnotherStartOrCalibration() {
        val ui = OverlayModel.build(inputs(status = SessionStatus.RUNNING, phase = DrivePhase.APPROACHING))
        assertEquals(UserState.APPROACHING_DELIVERY, ui.state)
        assertEquals(OverlayTone.ACTIVE, ui.tone)
        assertTrue(ui.canPause)
        assertTrue(ui.canEnd)
        assertFalse(ui.canResume)
        assertFalse(ui.canStartDrive)
        assertFalse(ui.canStartCalibration)
        assertNull("no calibration block while driving", ui.calibration)
    }

    @Test
    fun pausedAndNeedsAssistanceOfferResumeAndDrawAttentionOnlyWhenHelpIsNeeded() {
        val paused = OverlayModel.build(inputs(status = SessionStatus.PAUSED, phase = DrivePhase.DRIVING))
        assertTrue(paused.canResume)
        assertFalse(paused.canPause)
        assertFalse(paused.attention)
        val help = OverlayModel.build(inputs(status = SessionStatus.NEEDS_ASSIST, phase = DrivePhase.DRIVING))
        assertEquals(UserState.NEEDS_ASSISTANCE, help.state)
        assertEquals(OverlayTone.DANGER, help.tone)
        assertTrue(help.canResume)
        assertTrue(help.attention)
    }

    @Test
    fun afterEmergencyStopNothingResumesButANewStartIsPossible() {
        val ui = OverlayModel.build(inputs(status = SessionStatus.EMERGENCY_STOPPED))
        assertEquals(UserState.EMERGENCY_STOP, ui.state)
        assertFalse(ui.canResume)
        assertFalse(ui.canPause)
        assertTrue(ui.attention)
        assertTrue(ui.canStartDrive)
    }

    @Test
    fun armingShowsTheCountdownAndCanBeCancelled() {
        val ui = OverlayModel.build(inputs(armed = "Starting in 2…"))
        assertEquals(UserState.STARTING, ui.state)
        assertEquals("Starting in 2…", ui.status)
        assertTrue(ui.canEnd)
        assertEquals("Cancel start", ui.endLabel)
        assertFalse(ui.canStartDrive)
    }

    @Test
    fun notReadyHidesStartAndSaysWhyInsteadOfShowingReady() {
        val ui = OverlayModel.build(inputs(ready = false))
        assertFalse(ui.canStartDrive)
        assertTrue(ui.status, ui.status.startsWith("Not ready to drive: Control BRAKE"))
        assertTrue("collecting pictures is still possible", ui.canStartCalibration)
    }

    @Test
    fun collectingPicturesShowsRealProgressAndARing() {
        val clock = FakeClock()
        val s = SetupSession(clock, target = 45)
        s.startCapture()
        val scene = Toe3Scene()
        repeat(9) { k ->
            clock.advance(400)
            s.offer(scene.frame(k), dev.toe3autopilot.core.capture.FrameOrigin.GAME)
        }
        val ui = OverlayModel.build(inputs(setup = s.state()))
        assertEquals(UserState.CALIBRATING, ui.state)
        assertTrue(ui.status, ui.status.startsWith("9 of 45"))
        assertEquals(20, ui.calibration!!.percent)
        assertEquals(0.2f, ui.ring!!, 1e-6f)
        assertTrue(ui.canCancelCalibration)
        assertFalse("a drive must not start during setup", ui.canStartDrive)
        assertFalse(ui.canStartCalibration)
    }

    @Test
    fun aStoppedSetupIsShownWithItsProblem() {
        val ui = OverlayModel.build(inputs(setup = SetupState(phase = SetupPhase.FAILED, problem = "No pictures of the game arrived", recovery = dev.toe3autopilot.core.setup.SetupRecovery.OPEN_GAME)))
        assertEquals("No pictures of the game arrived", ui.calibration!!.blocker)
        assertNull(ui.ring)
    }

    @Test
    fun aNoteFromTheLastButtonPressIsShownFirst() {
        assertEquals("Cannot start: no profile", OverlayModel.build(inputs(note = "Cannot start: no profile")).status)
    }

    @Test
    fun dockPositionSnapsToTheNearerEdgeAndSurvivesRotation() {
        val size = 150
        val m = 20
        val left = OverlayPlacement.snap(100, 500, size, 1080, 2400, m)
        assertFalse(left.rightSide)
        val right = OverlayPlacement.snap(800, 500, size, 1080, 2400, m)
        assertTrue(right.rightSide)
        // Same stored position on a landscape screen stays on screen and on the same side.
        val (x, y) = OverlayPlacement.place(right, size, 2400, 1080, m)
        assertEquals(2400 - size - m, x)
        assertTrue(y in 0..(1080 - size))
        // Extreme fractions are clamped onto the screen.
        val (_, yBottom) = OverlayPlacement.place(DockPosition(true, 5f), size, 1080, 2400, m)
        assertTrue(yBottom <= 2400 - size)
    }

    @Test
    fun panelOpensBesideTheButtonAndStaysOnScreen() {
        val (px, py) = OverlayPlacement.panelAnchor(bx = 910, by = 2300, size = 150, panelW = 700, panelH = 900, screenW = 1080, screenH = 2400, gap = 16)
        assertTrue("panel to the left of a right-edge button", px + 700 <= 910)
        assertTrue(py + 900 <= 2400)
        val (lx, _) = OverlayPlacement.panelAnchor(bx = 20, by = 100, size = 150, panelW = 700, panelH = 900, screenW = 1080, screenH = 2400, gap = 16)
        assertEquals(20 + 150 + 16, lx)
    }

    @Test
    fun tapGuardSeparatesDragsAndIgnoresPressesRightAfterOpening() {
        val g = TapGuard(slopPx = 24f)
        assertTrue(g.isTap(100f, 100f, 110f, 95f))
        assertFalse(g.isTap(100f, 100f, 180f, 100f))
        g.panelOpened(1_000)
        assertFalse(g.accepts(1_100))
        assertTrue(g.accepts(1_000 + TapGuard.ARM_DELAY_MS))
    }

    @Test
    fun theFloatingButtonHasNoWayToChangeTheGame_andAnotherAppInFrontIsNotLive() {
        val other = dev.toe3autopilot.core.capture.LinkStatus(
            dev.toe3autopilot.core.capture.LinkState.CONNECTED, "other", false, dev.toe3autopilot.core.capture.LinkAction.OPEN_GAME, "Open the game",
        )
        assertFalse("another app in front is never 'live'", OverlayModel.build(inputs().copy(link = other)).linkOk)
        assertFalse(OverlayModel.build(inputs()).linkOk)
        // The model has no field that could re-target the game (the old "This app is the game" button is gone).
        assertTrue(OverlayUi::class.java.declaredFields.none { it.name.contains("adopt", ignoreCase = true) })
    }
}
