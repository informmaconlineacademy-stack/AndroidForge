package dev.toe3autopilot.core

import dev.toe3autopilot.core.profile.GameProfile
import dev.toe3autopilot.core.profile.ProfileCodec
import dev.toe3autopilot.core.profile.ProfileReadiness
import dev.toe3autopilot.core.profile.SteeringMode
import dev.toe3autopilot.core.state.GameState
import dev.toe3autopilot.core.Control
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ProfileTest {
    private fun expectFailure(text: String, mustMention: String) {
        try {
            ProfileCodec.parse(text)
            error("expected a parse failure for: $text")
        } catch (e: IllegalArgumentException) {
            assertTrue("message '${e.message}' should mention '$mustMention'", e.message!!.contains(mustMention))
        }
    }

    @Test
    fun roundTripPreservesEverything() {
        val original = TestProfiles.full(SteeringMode.BUTTONS, mapOf("parking.direction" to "REVERSE", "motion.stopped" to "0.006"))
        val text = ProfileCodec.format(original)
        val copy = ProfileCodec.parse(text)
        assertEquals(original.name, copy.name)
        assertEquals(original.referenceWidth, copy.referenceWidth)
        assertEquals(original.steeringMode, copy.steeringMode)
        assertEquals(original.controls.keys, copy.controls.keys)
        for ((c, p) in original.controls) {
            assertEquals(p.x, copy.controls[c]!!.x, 0.0001f)
            assertEquals(p.y, copy.controls[c]!!.y, 0.0001f)
        }
        assertEquals(original.templates.keys, copy.templates.keys)
        for ((n, t) in original.templates) {
            assertEquals(t.roi.left, copy.templates[n]!!.roi.left, 0.0001f)
            assertEquals(t.minScore, copy.templates[n]!!.minScore, 0.0001f)
        }
        assertEquals(original.stateRules, copy.stateRules)
        assertEquals(original.colors.keys, copy.colors.keys)
        assertEquals(original.nav!!.routeColor, copy.nav!!.routeColor)
        assertEquals(original.extras, copy.extras)
        // Formatting is stable.
        assertEquals(text, ProfileCodec.format(copy))
    }

    @Test
    fun parsingIsStrict() {
        expectFailure("bogus.key=1", "unknown key")
        expectFailure("control.FLY=0.5,0.5", "FLY")
        expectFailure("control.BRAKE=1.5,0.5", "0..1")
        expectFailure("template.Bad-Name.roi=0,0,1,1", "[a-z0-9_]+")
        expectFailure("template.a.roi=0,0,1", "4 comma-separated")
        expectFailure("template.a.min=0.9", "no roi")
        expectFailure("state.DRIVING=missing_tpl", "unknown template")
        expectFailure("nav.minimap.roi=0,0,1,1", "must all be set together")
        expectFailure("steering.mode=TELEPORT", "TELEPORT")
        expectFailure("color.zone.roi=0,0,1,1", "no target")
        expectFailure("reference.width=wide", "integer")
    }

    @Test
    fun emptyAndMinimalProfilesParse() {
        val p = ProfileCodec.parse("")
        assertEquals("unnamed", p.name)
        assertTrue(p.templates.isEmpty())
        assertNull(p.nav)
        val q = ProfileCodec.parse("template.a.roi=0,0,0.5,0.5\nstate.DRIVING=a\n")
        assertEquals(0.80f, q.templates["a"]!!.minScore, 0f)
        assertNotNull(q.stateRules[GameState.DRIVING])
    }

    @Test
    fun legacyProfilesFromTheJobAutomationVersionStillLoad() {
        val legacy = """
            name=old
            template.hud.roi=0,0,0.2,0.2
            template.coupled.roi=0.5,0,0.7,0.2
            template.menu_logo.roi=0.1,0.1,0.3,0.3
            state.MAIN_MENU=menu_logo
            state.JOB_LIST=menu_logo
            state.DRIVING_UNCOUPLED=hud,!coupled
            state.DRIVING_COUPLED=hud,coupled
            control.ACCELERATOR=0.9,0.8
            control.OPEN_JOBS=0.1,0.9
            control.COUPLE=0.5,0.8
        """.trimIndent()
        val p = ProfileCodec.parse(legacy)
        assertEquals(setOf(GameState.DRIVING), p.stateRules.keys)
        assertEquals(listOf("hud", "coupled"), p.stateRules[GameState.DRIVING])
        assertEquals(setOf(Control.ACCELERATOR), p.controls.keys)
        // And what is written back is valid for the new version.
        assertEquals(p.stateRules, ProfileCodec.parse(ProfileCodec.format(p)).stateRules)
    }

    @Test
    fun completeProfileIsReadyToDrive() {
        val store = MapTemplateStore(TestProfiles.templateImages())
        val problems = ProfileReadiness.problems(TestProfiles.full(), AutomationSettings(), store)
        assertTrue("unexpected problems: $problems", problems.isEmpty())
        assertTrue("unexpected advice: ${ProfileReadiness.advice(TestProfiles.full(), AutomationSettings())}", ProfileReadiness.advice(TestProfiles.full(), AutomationSettings()).none { it.contains("obstacle") || it.contains("delivery-area") })
    }

    @Test
    fun theMinimalProfileCanDriveButTheAdviceExplainsTheLimits() {
        val store = MapTemplateStore(TestProfiles.templateImages())
        val p = TestProfiles.minimal()
        assertTrue(ProfileReadiness.problems(p, AutomationSettings(), store).isEmpty())
        val advice = ProfileReadiness.advice(p, AutomationSettings()).joinToString("\n")
        assertTrue(advice, advice.contains("cannot tell when it has arrived"))
        assertTrue(advice, advice.contains("park"))
        assertTrue(advice, advice.contains("obstacle"))
    }

    @Test
    fun noParkingAdviceWhenParkingIsSwitchedOff() {
        val advice = ProfileReadiness.advice(TestProfiles.minimal(), AutomationSettings(tryParking = false)).joinToString("\n")
        assertTrue(advice, !advice.contains("parking area") && !advice.contains("Reverse gear") && !advice.contains("parked"))
    }

    @Test
    fun readinessReportsEverythingThatBlocksDriving() {
        val images = TestProfiles.templateImages()
        images.remove("hud_marker")
        val problems = ProfileReadiness.problems(TestProfiles.full(), AutomationSettings(), MapTemplateStore(images))
        assertTrue(problems.toString(), problems.any { it.contains("hud_marker") })

        val empty = ProfileReadiness.problems(GameProfile.EMPTY, AutomationSettings(), MapTemplateStore())
        assertTrue(empty.toString(), empty.any { it.contains("driving screen") })
        assertTrue(empty.any { it.contains("ACCELERATOR") })
        assertTrue(empty.any { it.contains("BRAKE") })
        assertTrue(empty.any { it.contains("minimap") })
    }

    @Test
    fun aDefinedButBrokenStateRuleBlocksStart() {
        val images = TestProfiles.templateImages()
        images.remove("dialog_marker")
        val problems = ProfileReadiness.problems(TestProfiles.full(), AutomationSettings(), MapTemplateStore(images))
        assertTrue(problems.toString(), problems.any { it.contains("dialog_marker") })
    }

    @Test
    fun buttonSteeringNeedsLeftAndRight() {
        val base = TestProfiles.full(SteeringMode.BUTTONS)
        val store = MapTemplateStore(TestProfiles.templateImages())
        val problems = ProfileReadiness.problems(base, AutomationSettings(), store)
        assertTrue(problems.any { it.contains("STEER_LEFT") })
        assertTrue(problems.any { it.contains("STEER_RIGHT") })
    }

    @Test
    fun aButtonTemplateCanStandInForACoordinate() {
        val p = TestProfiles.full()
        val noBrakePoint = p.copy(
            controls = p.controls - Control.BRAKE,
            templates = p.templates + ("btn_brake" to dev.toe3autopilot.core.profile.TemplateSpec("btn_brake", dev.toe3autopilot.core.vision.Roi(0.7f, 0.7f, 0.9f, 0.9f))),
        )
        val problems = ProfileReadiness.problems(noBrakePoint, AutomationSettings(), MapTemplateStore(TestProfiles.templateImages()))
        assertTrue(problems.toString(), problems.none { it.contains("BRAKE") })
    }

    @Test
    fun settingsAreSanitised() {
        val s = AutomationSettings(speedLevel = 7f, approachSpeed = 0.9f, sensitivity = 0f).sanitized()
        assertEquals(1.0f, s.speedLevel, 0f)
        assertEquals(0.5f, s.approachSpeed, 0f)
        assertEquals(0.5f, s.sensitivity, 0f)
        val low = AutomationSettings(speedLevel = 0f, approachSpeed = 0f).sanitized()
        assertEquals(0.1f, low.speedLevel, 0f)
        assertEquals(0.1f, low.approachSpeed, 0f)
    }
}

class CalibrationChecklistTest {
    private val store = MapTemplateStore(TestProfiles.templateImages())

    @Test
    fun anEmptyProfileHasEveryRequiredItemOpen() {
        val items = dev.toe3autopilot.core.profile.CalibrationChecklist.items(null, store)
        assertTrue(items.filter { it.required }.none { it.done })
        assertEquals(5, items.count { it.required })
    }

    @Test
    fun theRequiredItemsMatchWhatBlocksStart() {
        for (profile in listOf(TestProfiles.full(), TestProfiles.minimal(), GameProfile.EMPTY, TestProfiles.full(SteeringMode.BUTTONS))) {
            val items = dev.toe3autopilot.core.profile.CalibrationChecklist.items(profile, store)
            val blocking = ProfileReadiness.problems(profile, AutomationSettings(), store)
            assertEquals(
                "profile ${profile.name}: items=${items.filter { it.required && !it.done }.map { it.title }} problems=$blocking",
                blocking.isEmpty(), items.filter { it.required }.all { it.done },
            )
        }
    }

    @Test
    fun optionalItemsFollowTheCuesThatExist() {
        val full = dev.toe3autopilot.core.profile.CalibrationChecklist.items(TestProfiles.full(), store)
        assertTrue(full.all { it.done })
        val min = dev.toe3autopilot.core.profile.CalibrationChecklist.items(TestProfiles.minimal(), store).filter { !it.required }
        assertTrue(min.none { it.done })
    }
}
