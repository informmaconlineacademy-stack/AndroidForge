package dev.toe3autopilot.core.calibration

import dev.toe3autopilot.core.geometry.IntRect
import dev.toe3autopilot.core.vision.Frame
import dev.toe3autopilot.core.vision.Roi
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * The part of a captured picture the game really draws in. Columns or rows at the picture's edges that stay black in every
 * picture (a display cut-out the game leaves empty, letterboxing) are left out of the search, so nothing at their border is
 * mistaken for an on-screen element. Positions stay in whole-display coordinates (NDS); only the searched area shrinks.
 */
object GameViewport {
    /** Grey level below which a pixel counts as black. */
    const val DARK = 24

    /** A column / row is black when at most this share of its pixels (over all pictures) is brighter than [DARK]. */
    const val BRIGHT_SHARE = 0.02f

    fun detect(frames: List<Frame>): IntRect {
        if (frames.isEmpty()) return IntRect(0, 0, 1, 1)
        val w = frames.first().width
        val h = frames.first().height
        val colBright = IntArray(w)
        val rowBright = IntArray(h)
        var n = 0
        for (f in frames) {
            if (f.width != w || f.height != h) continue
            n++
            val p = f.argb
            for (y in 0 until h) {
                val row = y * w
                for (x in 0 until w) {
                    if (PictureEvidence.lum(p[row + x]) > DARK) {
                        colBright[x]++
                        rowBright[y]++
                    }
                }
            }
        }
        if (n == 0) return IntRect(0, 0, w, h)
        val colLimit = BRIGHT_SHARE * h * n
        val rowLimit = BRIGHT_SHARE * w * n
        var x0 = 0
        while (x0 < w && colBright[x0] <= colLimit) x0++
        var x1 = w
        while (x1 > x0 && colBright[x1 - 1] <= colLimit) x1--
        var y0 = 0
        while (y0 < h && rowBright[y0] <= rowLimit) y0++
        var y1 = h
        while (y1 > y0 && rowBright[y1 - 1] <= rowLimit) y1--
        // A mostly black picture is not a viewport question; analyse everything and let the other checks report it.
        if (x1 - x0 < w / 2 || y1 - y0 < h / 2) return IntRect(0, 0, w, h)
        return IntRect(x0, y0, x1, y1)
    }

    /** Plain words for the analysis report. */
    fun describe(vp: IntRect, w: Int, h: Int): String =
        if (vp.x0 == 0 && vp.y0 == 0 && vp.x1 == w && vp.y1 == h) {
            "The game fills the whole picture (${w}x$h)."
        } else {
            val parts = ArrayList<String>()
            if (vp.x0 > 0) parts += "${vp.x0} px on the left"
            if (vp.x1 < w) parts += "${w - vp.x1} px on the right"
            if (vp.y0 > 0) parts += "${vp.y0} px at the top"
            if (vp.y1 < h) parts += "${h - vp.y1} px at the bottom"
            "The game draws in ${vp.width}x${vp.height} of the ${w}x$h picture; black bands (${parts.joinToString(", ")}) are ignored."
        }
}

/**
 * What the control search looks at, built either from MANY pictures taken while driving (the scenery moves, on-screen
 * controls do not) or from ONE picture (a screenshot, or a parked truck where nothing moves).
 *
 *  - Many pictures: the search runs on the time-AVERAGED picture of the pictures in which the scenery moved. Moving scenery
 *    blurs away in it, while fixed overlays (translucent ones too) stay sharp. The individual pictures are kept to check that
 *    a shape is really fixed (it must show in each of them), and the per-pixel change over time tells see-through controls
 *    (the scenery keeps changing behind them) from solid objects such as the truck in a chase camera.
 *  - One picture: the search runs on that picture. Much weaker evidence; reported as such.
 *
 * HaulPilot's own on-screen parts ([exclusions], e.g. its floating button, which is in every captured picture) and
 * everything outside the [GameViewport] are marked [blocked]: no shape touching them can become a control.
 */
class PictureEvidence private constructor(
    val width: Int,
    val height: Int,
    val viewport: IntRect,
    /** The picture the shapes are searched on (grey 0..255): the time average, or the single picture. */
    val ref: FloatArray,
    /** Up to [KEEP_FRAMES] of the moving pictures (grey), evenly spread, for the "is it fixed" check. Empty with one picture. */
    val frames: List<FloatArray>,
    /** Per-pixel change over time (grey levels, standard deviation) over the moving pictures; null with one picture. */
    val temporalStd: FloatArray?,
    /** The colour picture used for colour checks (the chosen driving picture). */
    val colour: Frame,
    /** True where nothing may be found: HaulPilot's own parts (dilated) and everything outside the viewport. */
    val blocked: BooleanArray,
    /** True only where HaulPilot's own parts are (dilated). */
    val ownUi: BooleanArray,
    val exclusions: List<Roi>,
    /** Pictures of this size that were available, and how many of them showed moving scenery. */
    val pictures: Int,
    val moving: Int,
) {
    val multiFrame: Boolean get() = moving >= MIN_MOVING

    /**
     * Grey-level step that counts as contrast across an outline on [ref]. The time average of many pictures has little
     * noise, so faint translucent controls (dusk, dark asphalt) still show; a single picture needs a larger step.
     */
    val step: Float get() = if (multiFrame) 3f else 6f

    /** Same, for one of the individual [frames] (the "is it fixed" check). */
    val frameStep: Float get() = 4f

    /** Short words for reports: what the evidence is based on. */
    val basis: String
        get() = when {
            multiFrame -> "$moving pictures in which the scenery moved"
            pictures > 1 -> "a single picture ($pictures pictures, but the scenery moved in only $moving of them)"
            else -> "a single picture"
        }

    fun at(img: FloatArray, x: Int, y: Int): Float = img[y * width + x]

    fun inViewport(x: Int, y: Int): Boolean = x >= viewport.x0 && x < viewport.x1 && y >= viewport.y0 && y < viewport.y1

    /** True when any pixel of [x0,x1) x [y0,y1), widened by [margin], is HaulPilot's own UI. */
    fun touchesOwnUi(x0: Int, y0: Int, x1: Int, y1: Int, margin: Int = 1): Boolean {
        for (y in max(0, y0 - margin) until min(height, y1 + margin)) {
            val row = y * width
            for (x in max(0, x0 - margin) until min(width, x1 + margin)) if (ownUi[row + x]) return true
        }
        return false
    }

    /** Median of the temporal change inside [x0,x1) x [y0,y1); 0 with one picture. */
    fun medianStd(x0: Int, y0: Int, x1: Int, y1: Int): Float {
        val s = temporalStd ?: return 0f
        val v = ArrayList<Float>()
        for (y in max(0, y0) until min(height, y1)) for (x in max(0, x0) until min(width, x1)) {
            if (!blocked[y * width + x]) v += s[y * width + x]
        }
        if (v.isEmpty()) return 0f
        v.sort()
        return v[v.size / 2]
    }

    companion object {
        /** Moving pictures needed before the many-picture evidence is used. */
        const val MIN_MOVING = 6

        /** A picture counts as "moving" when at least this share of its pixels changed since the previous picture. */
        const val MOVING_CHANGE = 0.02f

        /** Moving pictures kept for the "is it fixed" check. */
        const val KEEP_FRAMES = 12

        /** HaulPilot's own parts are widened by this many pixels (anti-aliasing, shadows, a moved button). */
        const val OWN_UI_MARGIN = 3

        fun lum(c: Int): Int = (77 * ((c shr 16) and 0xFF) + 150 * ((c shr 8) and 0xFF) + 29 * (c and 0xFF)) shr 8

        fun gray(f: Frame): FloatArray = FloatArray(f.width * f.height) { i -> lum(f.argb[i]).toFloat() }

        /**
         * @param frames the collected pictures; only those with [preferred]'s size are used
         * @param preferred the chosen driving picture (used alone when the scenery did not move); defaults to the last one
         * @param exclusions regions (NDS) that HaulPilot itself drew over the game; never searched
         */
        fun build(frames: List<Frame>, preferred: Frame? = null, exclusions: List<Roi> = emptyList()): PictureEvidence? {
            val refFrame = preferred ?: frames.lastOrNull() ?: return null
            val w = refFrame.width
            val h = refFrame.height
            val same = frames.filter { it.width == w && it.height == h }.ifEmpty { listOf(refFrame) }
            val viewport = GameViewport.detect(same)

            val ownUi = BooleanArray(w * h)
            for (r in exclusions) {
                val p = r.toRect(w, h)
                for (y in max(0, p.y0 - OWN_UI_MARGIN) until min(h, p.y1 + OWN_UI_MARGIN)) {
                    for (x in max(0, p.x0 - OWN_UI_MARGIN) until min(w, p.x1 + OWN_UI_MARGIN)) ownUi[y * w + x] = true
                }
            }
            val blocked = BooleanArray(w * h) { i ->
                val x = i % w
                val y = i / w
                ownUi[i] || x < viewport.x0 || x >= viewport.x1 || y < viewport.y0 || y >= viewport.y1
            }

            // Which pictures show moving scenery (HaulPilot's own parts excluded: its progress ring changes every picture).
            val movingIdx = ArrayList<Int>()
            var prev: FloatArray? = null
            val greys = arrayOfNulls<FloatArray>(same.size)
            for ((k, f) in same.withIndex()) {
                val g = gray(f)
                val p = prev
                if (p != null) {
                    var changed = 0
                    var n = 0
                    var y = viewport.y0
                    while (y < viewport.y1) {
                        var x = viewport.x0
                        while (x < viewport.x1) {
                            val i = y * w + x
                            if (!ownUi[i]) {
                                if (abs(p[i] - g[i]) > 10f) changed++
                                n++
                            }
                            x += 2
                        }
                        y += 2
                    }
                    if (n > 0 && changed.toFloat() / n >= MOVING_CHANGE) movingIdx += k
                }
                greys[k] = g
                prev = g
            }

            val ref: FloatArray
            var std: FloatArray? = null
            val keep = ArrayList<FloatArray>()
            if (movingIdx.size >= MIN_MOVING) {
                ref = FloatArray(w * h)
                val sq = FloatArray(w * h)
                for (k in movingIdx) {
                    val g = greys[k]!!
                    for (i in g.indices) {
                        ref[i] += g[i]
                        sq[i] += g[i] * g[i]
                    }
                }
                val n = movingIdx.size.toFloat()
                std = FloatArray(w * h)
                for (i in ref.indices) {
                    ref[i] /= n
                    std[i] = sqrt(max(0f, sq[i] / n - ref[i] * ref[i]))
                }
                val step = max(1f, movingIdx.size.toFloat() / KEEP_FRAMES)
                var t = 0f
                while (t < movingIdx.size && keep.size < KEEP_FRAMES) {
                    keep += greys[movingIdx[t.toInt()]]!!
                    t += step
                }
            } else {
                val idx = same.indexOf(refFrame)
                ref = if (idx >= 0) greys[idx]!! else gray(refFrame)
            }
            return PictureEvidence(w, h, viewport, ref, keep, std, refFrame, blocked, ownUi, exclusions, same.size, movingIdx.size)
        }
    }
}
