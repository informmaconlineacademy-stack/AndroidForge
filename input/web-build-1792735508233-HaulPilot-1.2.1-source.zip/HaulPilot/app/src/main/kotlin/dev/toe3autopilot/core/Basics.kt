package dev.toe3autopilot.core

/*
 * Everything under dev.toe3autopilot.core is plain Kotlin with NO Android imports, so that
 * all decision logic can be unit-tested on a normal JVM.
 */

fun interface Clock {
    fun nowMs(): Long
}

object WallClock : Clock {
    override fun nowMs(): Long = System.currentTimeMillis()
}

/** A point in normalised screen coordinates: (0,0) top-left, (1,1) bottom-right. */
data class Point(val x: Float, val y: Float)

/** Logical on-screen controls. Their screen positions come from the calibrated [dev.toe3autopilot.core.profile.GameProfile]. */
enum class Control {
    ACCELERATOR, BRAKE,
    STEER_CENTER, STEER_LEFT, STEER_RIGHT,
    GEAR_DRIVE, GEAR_REVERSE;

    /** Name of the optional button template that lets us find this control by vision instead of by coordinates. */
    val buttonTemplate: String get() = "btn_" + name.lowercase()
}

enum class Gear { FORWARD, REVERSE }

fun clampF(v: Float, lo: Float, hi: Float): Float = if (v < lo) lo else if (v > hi) hi else v

/** Allows an action at most once per [intervalMs]. */
class Cooldown(private val intervalMs: Long) {
    private var last: Long? = null
    fun ready(now: Long): Boolean = last.let { it == null || now - it >= intervalMs }
    fun mark(now: Long) {
        last = now
    }

    fun reset() {
        last = null
    }
}

/** A hard cap on how many times something may be tried. */
class AttemptBudget(val max: Int) {
    var used: Int = 0
        private set
    val exhausted: Boolean get() = used >= max

    fun tryUse(): Boolean {
        if (used >= max) return false
        used++
        return true
    }

    fun reset() {
        used = 0
    }
}
