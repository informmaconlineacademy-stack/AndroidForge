package dev.toe3autopilot.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.Stroke
import dev.toe3autopilot.core.state.RecognitionReport

/**
 * Shown when the driving screen was not recognised within the timeout: the newest picture HaulPilot looked at, the saved area it
 * was looking for drawn on it (green = found well enough, red = not), why it failed, what each check scored, and real actions.
 */
@Composable
fun RecognitionReportCard(env: UiEnv, report: RecognitionReport) {
    HpCard(accent = Hp.Warning) {
        SectionHeader("Why the driving screen was not recognised")
        BodyText(report.reason, color = Hp.Text)
        report.frame?.let { frame ->
            Box(Modifier.fillMaxWidth()) {
                FramePicture(frame, description = "The last picture HaulPilot looked at, with the area it searched for the saved driving-screen marker outlined")
                Canvas(Modifier.matchParentSize()) {
                    for (item in report.items.filter { !it.negated }) {
                        val roi = item.roi ?: continue
                        val color = if (item.ok) Hp.Success else Hp.Danger
                        drawRect(
                            color, Offset(roi.left * size.width, roi.top * size.height),
                            Size((roi.right - roi.left) * size.width, (roi.bottom - roi.top) * size.height), style = Stroke(3f),
                        )
                    }
                }
            }
            SmallText("The last picture it looked at. ${if (report.items.any { !it.negated }) "The outlined area is where it looked for the saved marker (red = not found there)." else ""}")
        } ?: SmallText("No picture arrived while it waited.")
        report.evidenceLines().forEach { SmallText(it) }
        report.advice.forEachIndexed { i, a -> BodyText("${i + 1}. $a") }
        Row(horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
            HpButton("Try again", { env.startDrive(resume = true) }, kind = BtnKind.PRIMARY)
            HpButton("Open the game", { env.openGame() }, kind = BtnKind.SECONDARY)
        }
        HpButton("Auto-Calibrate again", { env.nav.openAutoCalibrate() }, Modifier.fillMaxWidth(), kind = BtnKind.GHOST, glyph = Glyph.TARGET)
    }
}
