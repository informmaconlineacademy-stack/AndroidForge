package dev.toe3autopilot.core.agents

import dev.toe3autopilot.core.HelpKind
import dev.toe3autopilot.core.AutomationSettings
import dev.toe3autopilot.core.Decision
import dev.toe3autopilot.core.DriveCommand
import dev.toe3autopilot.core.clampF
import dev.toe3autopilot.core.vision.RoadQuality
import dev.toe3autopilot.core.vision.RoadTracker
import dev.toe3autopilot.core.vision.TrackedRoad
import dev.toe3autopilot.core.vision.Vision
import kotlin.math.abs

/**
 * PD steering with bend feed-forward + speed governor for following the navigation route.
 *
 *  - steer    = sensitivity * (Kp * offset + Kd * d(offset)/dt + Kff * bend), then slew-rate limited so the wheel
 *               can never be thrown from lock to lock in one tick;
 *  - throttle = the lower of the speed setting and [speedCap], reduced for bends and for large lateral error, and capped
 *               when the route is about to end;
 *  - brake    = full when an obstacle is flagged or the road is lost, gentle while the road reading is only held.
 *
 * It never steers on a guess: with a held (DEGRADED) reading the wheel stays where it is and the truck slows; with a LOST
 * road it stops.
 */
class DrivingController(
    private val kp: Float = 1.6f,
    private val kd: Float = 0.25f,
    private val kff: Float = 0.4f,
    /** Max steering change per second (full lock is 1.0). */
    private val maxSteerRate: Float = 2.5f,
) {
    private var lastOffset: Float? = null
    private var lastSteer = 0f
    private var lastTimeMs: Long? = null

    val currentSteer: Float get() = lastSteer

    fun reset() {
        lastOffset = null
        lastSteer = 0f
        lastTimeMs = null
    }

    fun step(
        road: TrackedRoad,
        obstacle: Boolean,
        settings: AutomationSettings,
        speedCap: Float,
        now: Long,
    ): DriveCommand {
        val dt = lastTimeMs?.let { clampF((now - it) / 1000f, 0.02f, 0.5f) } ?: 0.15f
        lastTimeMs = now

        if (obstacle) {
            lastSteer = slew(lastSteer, 0f, dt)
            return DriveCommand(steer = lastSteer, throttle = 0f, brake = 1f)
        }
        when (road.quality) {
            RoadQuality.LOST -> {
                lastOffset = null
                return DriveCommand(steer = lastSteer, throttle = 0f, brake = 1f)
            }
            RoadQuality.DEGRADED -> {
                lastOffset = null
                // Do not steer on guesses: hold the wheel where it is, coast and brake lightly.
                return DriveCommand(steer = lastSteer, throttle = 0f, brake = 0.4f)
            }
            RoadQuality.TRACKING -> {}
        }

        // No derivative on the first sample (it would be a spurious kick from an assumed zero offset).
        val derivative = lastOffset?.let { (road.offset - it) / dt } ?: 0f
        lastOffset = road.offset
        val demand = settings.sensitivity * (kp * road.offset + kd * derivative + kff * road.bend)
        lastSteer = slew(lastSteer, clampF(demand, -1f, 1f), dt)

        val ceiling = minOf(settings.speedLevel, speedCap)
        var throttle = ceiling * (1f - 0.75f * road.curvature)
        if (abs(road.offset) > 0.6f) throttle *= 0.5f
        if (road.routeEnding) throttle = minOf(throttle, ceiling * 0.6f)
        // Do not let a bend stall the truck completely; it still never exceeds the ceiling.
        throttle = maxOf(throttle, minOf(ceiling, MIN_THROTTLE))
        return DriveCommand(steer = lastSteer, throttle = clampF(throttle, 0f, 1f), brake = 0f)
    }

    private fun slew(current: Float, target: Float, dt: Float): Float {
        val maxDelta = maxSteerRate * dt
        return current + clampF(target - current, -maxDelta, maxDelta)
    }

    companion object {
        const val MIN_THROTTLE = 0.15f
    }
}

/**
 * Follows the navigation route line on the minimap.
 *
 * Optional template: "obstacle_ahead" (a warning / vehicle-ahead cue you calibrate). Without it the app cannot see
 * obstacles at all, and this is stated in the calibration advice.
 *
 * Stops and asks for help when the route is lost for [stopAfterLostMs] after the truck has already been braked, or when an
 * obstacle cue stays on for [obstacleHelpMs].
 */
class NavigationDriveAgent(
    private val controller: DrivingController = DrivingController(),
    private val tracker: RoadTracker = RoadTracker(),
    private val stopAfterLostMs: Long = 3000L,
    private val obstacleHelpMs: Long = 20_000L,
) {
    private var obstacleSince: Long? = null

    /** The latest road estimate, for the status display. */
    var road: TrackedRoad? = null
        private set

    fun reset() {
        controller.reset()
        tracker.reset()
        obstacleSince = null
        road = null
    }

    fun decide(vision: Vision, settings: AutomationSettings, speedCap: Float, now: Long): Decision {
        val r = tracker.update(vision.route(), now)
        road = r
        val obstacle = vision.has("obstacle_ahead")
        if (obstacle) {
            val since = obstacleSince ?: now.also { obstacleSince = it }
            if (now - since > obstacleHelpMs) return Decision.NeedHelp("An obstacle has been in the way for ${(now - since) / 1000}s")
        } else {
            obstacleSince = null
        }
        if (r.quality == RoadQuality.LOST && r.missingForMs > tracker.lostAfterMs() + stopAfterLostMs) {
            return Decision.NeedHelp("Lost track of the road (route not visible for ${r.missingForMs / 1000}s). Stopped.", HelpKind.ROAD_LOST)
        }
        val cmd = controller.step(r, obstacle, settings, speedCap, now)
        val note = when {
            obstacle -> "Obstacle ahead: braking"
            r.quality == RoadQuality.LOST -> "Road lost: stopped, waiting for the route"
            r.quality == RoadQuality.DEGRADED -> "Route unclear: slowing down"
            speedCap < 1f -> "Approaching the delivery area slowly"
            r.routeEnding -> "Route ends ahead: slowing"
            r.curvature > 0.35f -> "Bend ahead: slowing"
            else -> "Following the route"
        }
        return Decision.Drive(cmd, note)
    }
}
