package dev.toe3autopilot.core.profile

import dev.toe3autopilot.core.Control
import dev.toe3autopilot.core.state.GameState

/** One thing the person has to (or may) calibrate, and whether it is done. */
data class ChecklistItem(val title: String, val done: Boolean, val required: Boolean, val hint: String)

/**
 * The calibration to-do list shown for each profile. [required] items are exactly the ones whose absence blocks
 * START AUTO DRIVE (see [ProfileReadiness.problems]); the optional ones each switch on one capability and the hint says which.
 */
object CalibrationChecklist {
    fun items(profile: GameProfile?, store: TemplateStore): List<ChecklistItem> {
        val p = profile ?: GameProfile.EMPTY
        fun hasControl(c: Control) = p.control(c) != null || p.templates.containsKey(c.buttonTemplate)
        fun templateUsable(n: String) = p.templates.containsKey(n) && store.gray(n) != null

        val drivingRule = p.stateRules[GameState.DRIVING]
        val drivingDone = !drivingRule.isNullOrEmpty() && drivingRule.all { templateUsable(it.removePrefix("!")) }
        val steeringDone = when (p.steeringMode) {
            SteeringMode.SLIDER -> hasControl(Control.STEER_CENTER)
            SteeringMode.BUTTONS -> hasControl(Control.STEER_LEFT) && hasControl(Control.STEER_RIGHT)
        }
        val hasZone = p.templates.containsKey("parking_zone") || p.colors.containsKey("parking_zone")
        val reverseOk = hasControl(Control.GEAR_REVERSE) || p.extra("parking.direction", "REVERSE").uppercase() == "FORWARD"

        return listOf(
            ChecklistItem(
                "Driving screen marker", drivingDone, true,
                "Smart Setup → step 3 (choose the driving screen); the analysis in step 4 or step 7 sets the screen marker.",
            ),
            ChecklistItem(
                "Minimap, route colour and truck marker", p.nav != null, true,
                "Smart Setup → step 7: mark the minimap, then tap the route line and your truck on it. The minimap must be heading-up (truck always points up).",
            ),
            ChecklistItem("Accelerator", hasControl(Control.ACCELERATOR), true, "Smart Setup → steps 5–6: confirm the detected accelerator or place it on the picture."),
            ChecklistItem("Brake", hasControl(Control.BRAKE), true, "Smart Setup → steps 5–6: confirm the detected brake or place it on the picture."),
            ChecklistItem("Steering", steeringDone, true, "Smart Setup → steps 5–6: choose wheel or buttons, then confirm or place them on the picture."),
            ChecklistItem(
                "Delivery-area cue", p.templates.containsKey("destination_near") || p.colors.containsKey("destination_marker") || hasZone, false,
                "Without it the truck cannot tell it has arrived. Smart Setup → step 7: pick the destination marker on the minimap (optional).",
            ),
            ChecklistItem("Parking area colour", hasZone, false, "Without it the truck stops near the delivery area and you park. Not set up by this version of Smart Setup."),
            ChecklistItem("Reverse gear", reverseOk, false, "Needed for parking by reversing. Smart Setup → step 6: place the reverse control on the picture."),
            ChecklistItem(
                "Parked cue", p.templates.containsKey("parked_ok") || !p.stateRules[GameState.DELIVERY_COMPLETE].isNullOrEmpty(), false,
                "Without it the app cannot tell that parking worked. Not set up by this version of Smart Setup.",
            ),
            ChecklistItem("Obstacle cue", p.templates.containsKey("obstacle_ahead"), false, "Without it the app cannot see vehicles or obstacles ahead. Not set up by this version of Smart Setup."),
            ChecklistItem("Pop-up marker", !p.stateRules[GameState.UNEXPECTED_DIALOG].isNullOrEmpty(), false, "So the truck stops when a pop-up appears. Not set up by this version of Smart Setup; pop-ups are noticed because the driving screen disappears."),
        )
    }
}
