package dev.toe3autopilot.app.ui

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import dev.toe3autopilot.app.Brand

/**
 * Design tokens. One dark "cab at night" look: charcoal-navy surfaces in three steps, amber-orange for the one primary
 * action on a screen, a restrained cyan for selection and the step in progress, and status colours that only carry
 * meaning (green = good, yellow = needs you, red = stop / problem, blue = information).
 */
object Hp {
    val Bg = Color(Brand.BG)
    val Surface = Color(Brand.SURFACE)
    val Raised = Color(Brand.RAISED)
    val RaisedHigh = Color(Brand.RAISED_HIGH)
    val Border = Color(Brand.BORDER)
    val BorderSubtle = Color(Brand.BORDER_SUBTLE)

    val Text = Color(Brand.TEXT_PRIMARY)
    val TextSecondary = Color(Brand.TEXT_SECONDARY)
    val TextMuted = Color(Brand.TEXT_MUTED)

    val Primary = Color(Brand.PRIMARY)
    val OnPrimary = Color(Brand.ON_PRIMARY)
    val Accent = Color(Brand.ACCENT)
    val OnAccent = Color(Brand.ON_ACCENT)

    val Success = Color(Brand.SUCCESS)
    val Warning = Color(Brand.WARNING)
    val Danger = Color(Brand.DANGER)
    val DangerFill = Color(Brand.DANGER_FILL)
    val Info = Color(Brand.INFO)
}

/** Spacing (4-point grid), radii and touch sizes. */
object Sp {
    val xxs = 2.dp
    val xs = 4.dp
    val s = 8.dp
    val m = 12.dp
    val l = 16.dp
    val xl = 20.dp
    val xxl = 24.dp
    val xxxl = 32.dp

    /** Horizontal gutter of every screen. */
    val gutter = 16.dp

    /** Minimum touch target. */
    val touch = 48.dp

    val radiusS = 8.dp
    val radiusM = 12.dp
    val radiusL = 16.dp
    val radiusXL = 20.dp
}

/** What a status colour means. */
enum class Tone { NEUTRAL, GOOD, ATTENTION, BAD, INFO, ACTIVE }

fun toneColor(t: Tone): Color = when (t) {
    Tone.NEUTRAL -> Hp.TextMuted
    Tone.GOOD -> Hp.Success
    Tone.ATTENTION -> Hp.Warning
    Tone.BAD -> Hp.Danger
    Tone.INFO -> Hp.Info
    Tone.ACTIVE -> Hp.Accent
}

private val HpTypography = Typography(
    displaySmall = TextStyle(fontSize = 30.sp, lineHeight = 36.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.sp),
    headlineMedium = TextStyle(fontSize = 26.sp, lineHeight = 32.sp, fontWeight = FontWeight.Bold),
    headlineSmall = TextStyle(fontSize = 22.sp, lineHeight = 28.sp, fontWeight = FontWeight.SemiBold),
    titleLarge = TextStyle(fontSize = 19.sp, lineHeight = 25.sp, fontWeight = FontWeight.SemiBold),
    titleMedium = TextStyle(fontSize = 16.sp, lineHeight = 22.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.1.sp),
    titleSmall = TextStyle(fontSize = 14.sp, lineHeight = 20.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.1.sp),
    bodyLarge = TextStyle(fontSize = 16.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontSize = 12.sp, lineHeight = 17.sp, letterSpacing = 0.1.sp),
    labelLarge = TextStyle(fontSize = 14.sp, lineHeight = 20.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.2.sp),
    labelMedium = TextStyle(fontSize = 12.sp, lineHeight = 16.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.4.sp),
    labelSmall = TextStyle(fontSize = 11.sp, lineHeight = 14.sp, fontWeight = FontWeight.Medium, letterSpacing = 0.5.sp),
)

private val HpShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(Sp.radiusS),
    medium = RoundedCornerShape(Sp.radiusM),
    large = RoundedCornerShape(Sp.radiusL),
    extraLarge = RoundedCornerShape(Sp.radiusXL),
)

/** Always dark: the app is used next to a game at any time of day, and one carefully tuned theme reads better than two. */
@Composable
fun HpTheme(content: @Composable () -> Unit) {
    val scheme = darkColorScheme(
        primary = Hp.Primary,
        onPrimary = Hp.OnPrimary,
        primaryContainer = Hp.RaisedHigh,
        onPrimaryContainer = Hp.Text,
        secondary = Hp.Accent,
        onSecondary = Hp.OnAccent,
        secondaryContainer = Hp.RaisedHigh,
        onSecondaryContainer = Hp.Text,
        tertiary = Hp.Info,
        background = Hp.Bg,
        onBackground = Hp.Text,
        surface = Hp.Surface,
        onSurface = Hp.Text,
        surfaceVariant = Hp.Raised,
        onSurfaceVariant = Hp.TextSecondary,
        surfaceContainer = Hp.Surface,
        surfaceContainerHigh = Hp.Raised,
        surfaceContainerHighest = Hp.RaisedHigh,
        surfaceContainerLow = Hp.Surface,
        surfaceContainerLowest = Hp.Bg,
        inverseSurface = Hp.Text,
        inverseOnSurface = Hp.Bg,
        error = Hp.Danger,
        onError = Hp.Bg,
        outline = Hp.Border,
        outlineVariant = Hp.BorderSubtle,
    )
    MaterialTheme(colorScheme = scheme, typography = HpTypography, shapes = HpShapes, content = content)
}
