package dev.toe3autopilot.core.calibration

import dev.toe3autopilot.core.Point
import dev.toe3autopilot.core.profile.GameProfile
import dev.toe3autopilot.core.vision.GrayImage
import dev.toe3autopilot.core.vision.Roi
import dev.toe3autopilot.core.vision.TemplateMatcher
import dev.toe3autopilot.core.vision.TemplateProvider
import kotlin.math.abs
import kotlin.math.hypot

/**
 * Detects that the screen no longer matches the calibration, and proposes where moved controls went.
 *
 * Two independent signals:
 *  1. **Frame geometry**: the live frame's aspect ratio differs from the one the profile was made for (rotation,
 *     different screen, split-screen, changed capture size). Reliable and cheap.
 *  2. **Control look-alikes**: every confirmed control stores a small picture ("patch") of how it looks unpressed.
 *     If, while nothing is pressing them, most patches are no longer found where they should be, the interface
 *     probably changed. This needs the HUD to be visible, so callers must only use it on driving screens.
 */
object LayoutCheck {
    const val HEIGHT_KEY = "reference.height"
    const val PATCH_PREFIX = "ctl_"
    const val ASPECT_TOLERANCE = 0.03f
    private const val MATCH_MIN = 0.6f
    private const val POSITION_TOLERANCE = 0.05f
    private const val RELOCATE_MIN = 0.7f
    private const val AMBIGUITY_MARGIN = 0.1f

    fun patchName(role: CalibRole) = PATCH_PREFIX + role.name.lowercase()

    fun roleOfPatch(name: String): CalibRole? =
        if (name.startsWith(PATCH_PREFIX)) CalibRole.entries.firstOrNull { patchName(it) == name } else null

    fun referenceSize(p: GameProfile): LayoutSignature? {
        val h = p.extras[HEIGHT_KEY]?.toIntOrNull() ?: return null
        if (p.referenceWidth <= 0 || h <= 0) return null
        return LayoutSignature(p.referenceWidth, h)
    }

    /** Null when the frame fits the calibration, or when the profile does not record its size (older profiles). */
    fun layoutProblem(p: GameProfile, frameWidth: Int, frameHeight: Int): String? {
        val ref = referenceSize(p) ?: return null
        if (frameWidth <= 0 || frameHeight <= 0) return null
        val live = frameWidth.toFloat() / frameHeight
        val rel = abs(live - ref.aspect) / ref.aspect
        return if (rel > ASPECT_TOLERANCE) {
            "The screen layout changed since calibration (calibrated ${ref.width}x${ref.height}, now ${frameWidth}x$frameHeight). Recalibrate."
        } else {
            null
        }
    }

    /** Where the profile says [role] is, if known. */
    fun locationOf(p: GameProfile, role: CalibRole): Point? {
        role.control?.let { c -> p.controls[c]?.let { return it } }
        val v = p.extras["calib." + role.name.lowercase()] ?: return null
        val parts = v.split(",").map { it.trim().toFloatOrNull() }
        return if (parts.size == 2 && parts[0] != null && parts[1] != null) Point(parts[0]!!, parts[1]!!) else null
    }

    data class Verification(val evaluated: Int, val matched: Int, val scores: Map<CalibRole, Float>) {
        /** Only a verdict when at least two controls could be checked and fewer than half were found. */
        val stale: Boolean get() = evaluated >= 2 && matched.toFloat() / evaluated < 0.5f
    }

    /**
     * @param skip roles that must not be judged now (for example controls that are currently being pressed by the automation).
     */
    fun verifyControls(p: GameProfile, gray: GrayImage, templates: TemplateProvider, frameWidth: Int, skip: Set<CalibRole> = emptySet()): Verification {
        var evaluated = 0
        var matched = 0
        val scores = LinkedHashMap<CalibRole, Float>()
        for ((name, spec) in p.templates) {
            val role = roleOfPatch(name) ?: continue
            if (role in skip) continue
            val loc = locationOf(p, role) ?: continue
            if (templates.get(name, frameWidth) == null) continue
            val best = templates.best(gray, name, frameWidth, spec.roi, masked = p.templates.containsKey(name + TemplateProvider.MASK_SUFFIX))
            evaluated++
            val ok = best != null && best.score >= MATCH_MIN && hypot(best.x - loc.x, best.y - loc.y) <= POSITION_TOLERANCE
            if (ok) matched++
            scores[role] = best?.score ?: 0f
        }
        return Verification(evaluated, matched, scores)
    }

    /** [ambiguous]: another equally good look-alike exists (for example two identical buttons), so the match may be the wrong one. */
    data class Relocation(val role: CalibRole, val x: Float, val y: Float, val score: Float, val movedBy: Float, val ambiguous: Boolean)

    /** Searches the whole frame for each stored patch. Results are proposals that still need confirmation. */
    fun relocate(p: GameProfile, gray: GrayImage, templates: TemplateProvider, frameWidth: Int): List<Relocation> {
        val out = ArrayList<Relocation>()
        for (name in p.templates.keys) {
            val role = roleOfPatch(name) ?: continue
            val tpl = templates.get(name, frameWidth) ?: continue
            val hits = TemplateMatcher.all(gray, tpl, Roi.FULL, RELOCATE_MIN, 4)
            if (hits.isEmpty()) continue
            val old = locationOf(p, role)
            // Among good matches prefer the one closest to where the control used to be.
            val chosen = if (old == null) hits.first() else hits.maxByOrNull { it.score - 0.5f * hypot(it.x - old.x, it.y - old.y) }!!
            val ambiguous = hits.count { it.score >= chosen.score - AMBIGUITY_MARGIN } > 1
            val moved = if (old == null) 0f else hypot(chosen.x - old.x, chosen.y - old.y)
            out += Relocation(role, chosen.x, chosen.y, chosen.score, moved, ambiguous)
        }
        return out
    }
}
