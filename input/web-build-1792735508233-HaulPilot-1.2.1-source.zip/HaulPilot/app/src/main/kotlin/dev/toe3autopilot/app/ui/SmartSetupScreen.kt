package dev.toe3autopilot.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.toe3autopilot.app.AutopilotRuntime
import dev.toe3autopilot.core.capture.LinkState
import dev.toe3autopilot.core.setup.FrameEntry
import dev.toe3autopilot.core.setup.FrameOriginKind
import dev.toe3autopilot.core.setup.ScreenEvidence
import dev.toe3autopilot.core.setup.SetupPhase
import dev.toe3autopilot.core.setup.SetupRecovery
import dev.toe3autopilot.core.setup.SetupSession
import dev.toe3autopilot.core.setup.SetupState
import dev.toe3autopilot.core.setup.SetupStep
import dev.toe3autopilot.core.setup.SetupSteps
import dev.toe3autopilot.core.setup.StepState
import dev.toe3autopilot.core.setup.StepStatus
import kotlin.math.abs

/**
 * Smart Setup: ten steps, every one of them observing the one [SetupState] owned by the SetupController. The screen
 * never keeps its own copy of a status, so what it shows is what the setup job is really doing.
 */
@Composable
fun SmartSetupScreen(env: UiEnv) {
    val state by AutopilotRuntime.setup.state.collectAsStateWithLifecycle()
    val link by AutopilotRuntime.link.collectAsStateWithLifecycle()
    val steps = remember(state, link.receivingGame) { SetupSteps.of(state, link.receivingGame) }
    val current = env.nav.setupStep.coerceIn(0, steps.size - 1)
    val scroll = rememberScrollState()
    LaunchedEffect(current) { scroll.scrollTo(0) }

    Column(Modifier.fillMaxSize()) {
        SetupHeader(env, state, steps, current)
        Column(
            Modifier.weight(1f).fillMaxWidth().verticalScroll(scroll).padding(horizontal = Sp.gutter, vertical = Sp.m),
            verticalArrangement = Arrangement.spacedBy(Sp.m),
        ) {
            val step = steps[current]
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Overline("Step ${step.step.number} of ${steps.size}", Modifier.padding(top = 0.dp))
                Text(step.step.title, Modifier.semantics { heading() }, style = MaterialTheme.typography.headlineSmall, color = Hp.Text)
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(Sp.s), modifier = Modifier.padding(top = Sp.xs)) {
                    StatusPill(statusWord(step.status), statusTone(step.status))
                    SmallText(step.detail, Modifier.weight(1f), color = Hp.TextSecondary, maxLines = 3)
                }
            }
            ProblemBanner(env, state)
            if (state.phase == SetupPhase.ANALYZING && step.step != SetupStep.ANALYZE) {
                Banner(Tone.ACTIVE, "The analysis is running", "Changes are paused until it finishes or you cancel it in step 4.", "Go to step 4", { env.nav.setupStep = SETUP_STEP_ANALYZE })
            }
            when (step.step) {
                SetupStep.CONNECT -> StepConnect(env, state)
                SetupStep.CAPTURE -> StepCapture(env, state)
                SetupStep.SELECT_SCREEN -> StepScreen(env, state)
                SetupStep.ANALYZE -> StepAnalyze(env, state)
                SetupStep.REVIEW -> StepReview(env, state)
                SetupStep.PLACE -> StepPlace(env, state)
                SetupStep.MINIMAP -> StepMinimap(env, state)
                SetupStep.VALIDATE -> StepValidate(env, state)
                SetupStep.SAVE -> StepSave(env, state)
                SetupStep.TEST -> StepTest(env, state)
            }
            Spacer(Modifier.height(Sp.l))
        }
        SetupFooter(env, current, steps.size)
    }
}

fun statusWord(s: StepStatus): String = when (s) {
    StepStatus.TODO -> "To do"
    StepStatus.DONE -> "Done"
    StepStatus.SKIPPED -> "Skipped"
    StepStatus.ATTENTION -> "Needs attention"
    StepStatus.BLOCKED -> "Waiting for an earlier step"
}

fun statusTone(s: StepStatus): Tone = when (s) {
    StepStatus.TODO -> Tone.ACTIVE
    StepStatus.DONE -> Tone.GOOD
    StepStatus.SKIPPED -> Tone.NEUTRAL
    StepStatus.ATTENTION -> Tone.ATTENTION
    StepStatus.BLOCKED -> Tone.NEUTRAL
}

fun phaseTone(p: SetupPhase): Tone = when (p) {
    SetupPhase.NOT_STARTED -> Tone.NEUTRAL
    SetupPhase.CAPTURING, SetupPhase.ANALYZING -> Tone.ACTIVE
    SetupPhase.REVIEW_REQUIRED -> Tone.ATTENTION
    SetupPhase.VALIDATING -> Tone.INFO
    SetupPhase.CONFIRMED -> Tone.GOOD
    SetupPhase.FAILED -> Tone.BAD
    SetupPhase.CANCELLED -> Tone.NEUTRAL
}

@Composable
private fun SetupHeader(env: UiEnv, state: SetupState, steps: List<StepState>, current: Int) {
    var menu by remember { mutableStateOf(false) }
    var confirmReset by rememberSaveable { mutableStateOf(false) }
    BarSurface {
        Column(Modifier.padding(vertical = Sp.s)) {
            Row(Modifier.padding(start = Sp.gutter, end = Sp.xs), verticalAlignment = Alignment.CenterVertically) {
                StatusPill(state.phase.label, phaseTone(state.phase))
                if (state.dirty && state.phase != SetupPhase.CONFIRMED) {
                    Spacer(Modifier.width(Sp.s))
                    StatusPill("Unsaved changes", Tone.INFO)
                }
                Spacer(Modifier.weight(1f))
                IconAction(Glyph.UNDO, "Undo the last setup change", { if (!AutopilotRuntime.setup.undo()) env.toast("Nothing to undo right now.") }, enabled = state.canUndo)
                IconAction(Glyph.REDO, "Redo", { AutopilotRuntime.setup.redo() }, enabled = state.canRedo)
                Box {
                    IconAction(Glyph.MORE, "More setup actions", { menu = true })
                    DropdownMenu(menu, { menu = false }, containerColor = Hp.RaisedHigh) {
                        DropdownMenuItem(
                            text = { Text("Start over…") },
                            onClick = {
                                menu = false
                                confirmReset = true
                            },
                        )
                    }
                }
            }
            AutoCalibrateEntry(env, state)
            StepRail(steps, current) { env.nav.setupStep = it }
        }
    }
    if (confirmReset) {
        ConfirmDialog(
            "Start Smart Setup over?",
            "All collected pictures and everything placed or confirmed in this setup are cleared. Saved profiles are NOT changed or deleted.",
            "Start over", { confirmReset = false }, danger = true,
        ) {
            confirmReset = false
            AutopilotRuntime.setup.resetAll()
            env.nav.setupStep = SETUP_STEP_CONNECT
            env.toast("Smart Setup cleared. Saved profiles were not changed.")
        }
    }
}

/**
 * The one prominent action of Smart Setup: Auto-Calibrate (connect, drive, review, save, test on one screen). The ten
 * steps below stay as the manual way and show the same state.
 */
@Composable
private fun AutoCalibrateEntry(env: UiEnv, state: SetupState) {
    val label = when {
        state.phase == SetupPhase.CAPTURING && state.auto -> "Auto-Calibrate: ${state.runMoving} of ${state.target} · Open"
        state.phase == SetupPhase.ANALYZING || state.autoAnalyze -> "Auto-Calibrate: analysing · Open"
        state.auto && state.draft.analysed && state.draft.pendingCandidates.isNotEmpty() -> "Auto-Calibrate: review ${state.draft.pendingCandidates.size} found control(s)"
        else -> "Auto-Calibrate"
    }
    Column(Modifier.padding(horizontal = Sp.gutter, vertical = Sp.xs), verticalArrangement = Arrangement.spacedBy(2.dp)) {
        HpButton(label, { env.nav.openAutoCalibrate() }, Modifier.fillMaxWidth(), glyph = Glyph.TARGET)
        SmallText("Finds the controls while you drive, then you check them on the picture. Or follow the steps below by hand.", maxLines = 2)
    }
}

@Composable
private fun StepRail(steps: List<StepState>, current: Int, onSelect: (Int) -> Unit) {
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = Sp.m, vertical = Sp.xs),
        horizontalArrangement = Arrangement.spacedBy(Sp.xxs),
    ) {
        steps.forEachIndexed { i, s ->
            val sel = i == current
            val c = when (s.status) {
                StepStatus.DONE -> Hp.Success
                StepStatus.ATTENTION -> Hp.Warning
                StepStatus.TODO -> Hp.Text
                StepStatus.SKIPPED, StepStatus.BLOCKED -> Hp.TextMuted
            }
            Column(
                Modifier
                    .clip(RoundedCornerShape(Sp.radiusS))
                    .clickable(role = Role.Tab) { onSelect(i) }
                    .width(58.dp)
                    .heightIn(min = Sp.touch)
                    .padding(vertical = Sp.xs)
                    .semantics(mergeDescendants = true) {
                        selected = sel
                        contentDescription = "Step ${s.step.number}, ${s.step.short}, ${statusWord(s.status)}"
                    },
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(3.dp),
            ) {
                Box(
                    Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(if (sel) Hp.Accent else c.copy(alpha = 0.14f))
                        .border(if (sel) 0.dp else 1.dp, if (sel) Hp.Accent else c.copy(alpha = 0.45f), CircleShape),
                    contentAlignment = Alignment.Center,
                ) {
                    if (s.status == StepStatus.DONE && !sel) {
                        HpIcon(Glyph.CHECK, tint = Hp.Success, size = 15.dp)
                    } else {
                        Text("${s.step.number}", style = MaterialTheme.typography.labelMedium, color = if (sel) Hp.OnAccent else c)
                    }
                }
                Text(
                    s.step.short, style = MaterialTheme.typography.labelSmall, color = if (sel) Hp.Text else Hp.TextMuted,
                    maxLines = 1, textAlign = TextAlign.Center,
                )
            }
        }
    }
}

@Composable
private fun SetupFooter(env: UiEnv, current: Int, count: Int) {
    BarSurface {
        Row(Modifier.padding(horizontal = Sp.gutter, vertical = Sp.s), horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
            HpButton("Back", { env.nav.setupStep = current - 1 }, Modifier.weight(1f), kind = BtnKind.SECONDARY, enabled = current > 0, glyph = Glyph.BACK)
            HpButton(
                if (current < count - 1) "Next step" else "Dashboard",
                { if (current < count - 1) env.nav.setupStep = current + 1 else env.nav.open(Tab.DASHBOARD) },
                Modifier.weight(1f), kind = BtnKind.SECONDARY,
            )
        }
    }
}

/** The setup's problem (capture or analysis stopped, an import failed) with the matching recovery action. */
@Composable
private fun ProblemBanner(env: UiEnv, state: SetupState) {
    val problem = state.problem ?: return
    val rec = state.recovery
    Banner(
        if (state.phase == SetupPhase.FAILED) Tone.BAD else Tone.ATTENTION, problem, state.message.takeIf { it != problem },
        rec?.label, rec?.let { r -> { env.runRecovery(r) } },
    )
}

fun UiEnv.runRecovery(r: SetupRecovery) {
    when (r) {
        SetupRecovery.CONNECT_SCREEN -> actions.connectCapture()
        SetupRecovery.OPEN_GAME -> openGame()
        SetupRecovery.CHOOSE_GAME -> nav.open(Tab.SETTINGS, SettingsPage.CAPTURE)
        SetupRecovery.DRIVE_AND_RETRY -> startCollecting(this)
        SetupRecovery.IMPORT_PICTURES -> nav.setupStep = SETUP_STEP_CAPTURE
        SetupRecovery.RETRY -> {
            val s = AutopilotRuntime.setup.state.value
            if (s.frames.isNotEmpty()) {
                nav.setupStep = SETUP_STEP_ANALYZE
                AutopilotRuntime.setup.analyze()
            } else {
                startCollecting(this)
            }
        }
    }
}

/** Starts a live collection and brings the game to the front. */
fun startCollecting(env: UiEnv, keepPictures: Boolean = false) {
    if (!AutopilotRuntime.captureActive.value) {
        env.toast("Connect the screen first (step 1).")
        env.nav.setupStep = SETUP_STEP_CONNECT
        return
    }
    val err = if (keepPictures) AutopilotRuntime.setup.startCapture(true) else AutopilotRuntime.startSetupCapture(fromOverlay = false)
    if (err != null && AutopilotRuntime.setup.state.value.phase != SetupPhase.CAPTURING) {
        env.toast(err)
        return
    }
    env.nav.setupStep = SETUP_STEP_CAPTURE
    env.openGame()
}

// ---- step 1 ---------------------------------------------------------------------------------------------------------

@Composable
private fun StepConnect(env: UiEnv, state: SetupState) {
    val link by AutopilotRuntime.link.collectAsStateWithLifecycle()
    val captureOn by AutopilotRuntime.captureActive.collectAsStateWithLifecycle()
    val game by AutopilotRuntime.gamePackage.collectAsStateWithLifecycle()
    val access by AutopilotRuntime.accessibilityConnected.collectAsStateWithLifecycle()
    BodyText("HaulPilot learns the game's controls from pictures of the game while you drive normally. It needs to see the screen for that; nothing is sent anywhere.")
    HpCard {
        SectionHeader("Screen", trailing = {
            StatusPill(
                link.state.label,
                when (link.state) {
                    LinkState.CONNECTED -> if (link.receivingGame) Tone.GOOD else Tone.ACTIVE
                    LinkState.WAITING_FOR_PERMISSION -> Tone.ATTENTION
                    LinkState.FAILED -> Tone.BAD
                    LinkState.NOT_CONNECTED -> Tone.NEUTRAL
                },
            )
        })
        BodyText(link.detail)
        if (!captureOn) {
            SmallText("Android shows its own screen-sharing dialog. Choose \"Entire screen\" (sharing a single app hides the game's controls). A notification stays visible while sharing is on.")
            HpButton("Connect screen", { env.actions.connectCapture() }, Modifier.fillMaxWidth(), glyph = Glyph.LINK)
        } else {
            Row(horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
                link.actionLabel?.let { label -> HpButton(label, { env.runLink(link.action) }, kind = BtnKind.SECONDARY) }
                HpButton("Disconnect", { if (state.phase == SetupPhase.CAPTURING) env.toast("Stop collecting first (step 2).") else env.actions.disconnectCapture() }, kind = BtnKind.GHOST)
            }
        }
    }
    HpCard {
        SectionHeader("Game", subtitle = game.ifBlank { "Not chosen" })
        BodyText("Only pictures taken while this game is in front are used.")
        Row(horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
            HpButton("Open the game", { env.openGame() }, kind = BtnKind.SECONDARY, enabled = game.isNotBlank(), glyph = Glyph.PLAY)
            HpButton("Change", { env.nav.open(Tab.SETTINGS, SettingsPage.CAPTURE) }, kind = BtnKind.GHOST)
        }
        if (!access) {
            SmallText("Without the accessibility service HaulPilot cannot tell which app is in front, so every picture taken while HaulPilot is not in front is treated as the game. Turning it on (Settings → Permissions) avoids collecting pictures of other apps.")
        }
    }
    HpCard {
        SectionHeader("No live capture?")
        BodyText("Some phones or game versions block screen sharing (the pictures are black). Screenshots or a screen recording of yourself driving work instead: go to step 2.")
        HpButton("Use screenshots or a clip", { env.nav.setupStep = SETUP_STEP_CAPTURE }, kind = BtnKind.GHOST)
    }
}

// ---- step 2 ---------------------------------------------------------------------------------------------------------

@Composable
private fun StepCapture(env: UiEnv, state: SetupState) {
    val captureOn by AutopilotRuntime.captureActive.collectAsStateWithLifecycle()
    val import by AutopilotRuntime.setup.importProgress.collectAsStateWithLifecycle()
    val snapshots by AutopilotRuntime.recorder.items.collectAsStateWithLifecycle()
    val capturing = state.phase == SetupPhase.CAPTURING
    val analysing = state.phase == SetupPhase.ANALYZING
    var keep by rememberSaveable { mutableStateOf(false) }

    HpCard(accent = if (capturing) Hp.Accent else null) {
        SectionHeader("Collect while you drive", subtitle = "About ${state.target} pictures, one every third of a second (about 15 seconds of driving)")
        if (capturing) {
            ProgressLine("${state.runCollected} of ${state.target} pictures", (state.runCollected.toFloat() / state.target).coerceIn(0f, 1f))
            BodyText(state.message, color = Hp.Text)
            SmallText("Drive normally in the game: accelerate, brake and steer so the scenery moves. The floating HaulPilot button shows the count and can stop the collection.")
            Row(horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
                HpButton("Open the game", { env.openGame() }, Modifier.weight(1f), glyph = Glyph.PLAY)
                HpButton("Stop and use these", { AutopilotRuntime.setup.stopCapture() }, Modifier.weight(1f), kind = BtnKind.SECONDARY)
            }
            HpButton("Cancel collecting", { AutopilotRuntime.setup.cancel() }, kind = BtnKind.GHOST, glyph = Glyph.CLOSE)
        } else {
            BodyText("Start, switch to the game and drive for about 15 seconds. Pictures of HaulPilot or other apps, and black or blank pictures, are never kept.")
            if (state.frames.isNotEmpty()) SwitchRow("Keep the ${state.frames.size} picture(s) already here", "Off: start a fresh collection (the chosen driving picture is always kept).", keep, { keep = it })
            HpButton(
                "Start collecting and open the game", { startCollecting(env, keep) }, Modifier.fillMaxWidth(),
                enabled = captureOn && !analysing && import == null, glyph = Glyph.CAMERA,
            )
            when {
                !captureOn -> SmallText("Connect the screen first (step 1).")
                analysing -> SmallText("Wait until the analysis has finished, or cancel it in step 4.")
            }
        }
        if (state.rejectedFrames > 0) SmallText("${state.rejectedFrames} black, blank or unreadable picture(s) were ignored.")
    }

    HpCard {
        SectionHeader("Or use saved pictures", subtitle = "Screenshots or a screen recording of the normal driving view")
        val im = import
        if (im != null) {
            ProgressLine(im.label, im.fraction)
            HpButton("Cancel import", { AutopilotRuntime.setup.cancel() }, kind = BtnKind.GHOST, glyph = Glyph.CLOSE)
        } else {
            val can = !state.phase.busy
            Row(horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
                HpButton("Screenshots", { env.actions.pickScreenshots() }, Modifier.weight(1f), kind = BtnKind.SECONDARY, enabled = can, glyph = Glyph.IMAGE)
                HpButton("Video clip", { env.actions.pickVideo() }, Modifier.weight(1f), kind = BtnKind.SECONDARY, enabled = can, glyph = Glyph.VIDEO)
            }
            HpButton("Find a video in files", { env.actions.browseVideo() }, kind = BtnKind.GHOST, enabled = can)
            if (snapshots.isNotEmpty()) {
                HpButton(
                    "Use ${snapshots.size} recorded snapshot(s)",
                    {
                        AutopilotRuntime.ioScope.launchSafely {
                            val frames = AutopilotRuntime.recorder.sampleForAnalysis(40)
                            val err = AutopilotRuntime.setup.importFrames(frames, FrameOriginKind.SCREENSHOT)
                            AutopilotRuntime.notice.value = err ?: "Added ${frames.size} recorded snapshot(s)."
                        }
                    },
                    kind = BtnKind.GHOST, enabled = can,
                )
            }
            if (!can) SmallText("Available when nothing is being collected or analysed.")
            SmallText("Several screenshots taken a moment apart while driving work best: the analysis compares them to find what stays in place. A single screenshot is searched for control shapes too, but that evidence is weaker.")
        }
    }
    if (state.frames.isNotEmpty() && !capturing) {
        Banner(Tone.GOOD, "${state.frames.size} picture(s) ready", "Next: choose the one that shows the normal driving view.", "Choose the driving screen", { env.nav.setupStep = SETUP_STEP_SCREEN })
    }
}

// ---- step 3 ---------------------------------------------------------------------------------------------------------

@Composable
private fun StepScreen(env: UiEnv, state: SetupState) {
    if (state.frames.isEmpty()) {
        EmptyState(Glyph.IMAGE, "No pictures yet", "Collect live pictures or import screenshots or a clip first.", "Go to step 2") { env.nav.setupStep = SETUP_STEP_CAPTURE }
        return
    }
    var pendingSwitch by remember { mutableStateOf<FrameEntry?>(null) }
    val sel = state.selectedFrame
    val busy = state.phase.busy

    fun choose(e: FrameEntry) {
        if (busy) {
            env.toast("Wait until ${state.phase.label.lowercase()} has finished.")
            return
        }
        val layout = state.draft.layout
        val reshape = layout != null && state.draft.confirmedCount > 0 &&
            abs(layout.aspect - e.frame.width.toFloat() / e.frame.height) / layout.aspect > 0.03f
        if (reshape) pendingSwitch = e else AutopilotRuntime.setup.selectFrame(e.id)?.let { env.toast(it) }
    }

    if (sel != null) {
        HpCard(accent = if (state.draft.drivingConfirmed) Hp.Success else Hp.Warning) {
            FramePicture(sel.frame, description = "Picture ${sel.id}: ${sel.evidence.label}")
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
                Column(Modifier.weight(1f)) {
                    Text("Picture #${sel.id} · ${sel.origin.label}", style = MaterialTheme.typography.titleSmall, color = Hp.Text)
                    SmallText(evidenceText(sel))
                }
                StatusPill(if (state.draft.drivingConfirmed) "Chosen" else "Suggested", if (state.draft.drivingConfirmed) Tone.GOOD else Tone.ATTENTION)
            }
            if (!state.draft.drivingConfirmed) {
                SmallText("Suggested because it is the latest picture with moving scenery. It is only used once you confirm it.")
                HpButton("This is the driving screen", { choose(sel) }, Modifier.fillMaxWidth(), enabled = !busy, glyph = Glyph.CHECK)
            }
            HpButton(
                "Remove this picture",
                {
                    if (busy) env.toast("Wait until ${state.phase.label.lowercase()} has finished.") else AutopilotRuntime.setup.removeFrame(sel.id)
                },
                kind = BtnKind.GHOST, glyph = Glyph.TRASH,
            )
        }
    }
    SectionHeader("All pictures (${state.frames.size})", subtitle = "Tap the one that shows the normal driving view: pedals, steering and minimap visible, no menu or pop-up.")
    state.frames.reversed().chunked(3).forEach { row ->
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
            row.forEach { e ->
                val isSel = e.id == sel?.id
                Column(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(Sp.radiusM))
                        .border(if (isSel) 2.dp else 1.dp, if (isSel) Hp.Accent else Hp.BorderSubtle, RoundedCornerShape(Sp.radiusM))
                        .clickable(role = Role.Button) { choose(e) }
                        .padding(Sp.xs)
                        .semantics(mergeDescendants = true) {
                            selected = isSel
                            contentDescription = "Picture ${e.id}, ${e.evidence.label}"
                        },
                    verticalArrangement = Arrangement.spacedBy(Sp.xs),
                ) {
                    FramePicture(e.frame, thumbnailWidth = 200)
                    Text(
                        "#${e.id} " + when (e.evidence) {
                            ScreenEvidence.DRIVING_LIKELY -> "driving"
                            ScreenEvidence.MOVING -> "moving"
                            ScreenEvidence.STILL -> "still"
                            ScreenEvidence.PARTLY_BLACK -> "dark"
                            ScreenEvidence.HUD_MISSING -> "no controls"
                            ScreenEvidence.SINGLE -> "single"
                        },
                        style = MaterialTheme.typography.labelSmall,
                        color = when (e.evidence) {
                            ScreenEvidence.DRIVING_LIKELY -> Hp.Success
                            ScreenEvidence.PARTLY_BLACK, ScreenEvidence.HUD_MISSING, ScreenEvidence.STILL -> Hp.Warning
                            else -> Hp.TextMuted
                        },
                        maxLines = 1,
                    )
                }
            }
            repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
        }
    }
    pendingSwitch?.let { e ->
        ConfirmDialog(
            "Use a picture of a different shape?",
            "This picture has a different screen shape (rotation or another device). Positions placed on the old picture would be wrong on it, so they are cleared. Undo brings them back.",
            "Use it and clear", { pendingSwitch = null }, danger = true,
        ) {
            pendingSwitch = null
            AutopilotRuntime.setup.selectFrame(e.id)?.let { env.toast(it) }
        }
    }
}

private fun evidenceText(e: FrameEntry): String {
    val parts = ArrayList<String>()
    parts += e.evidence.label
    e.motion?.let { parts += "${pct(it)} of the picture changed since the one before" }
    e.hudVisible?.let { parts += "${pct(it)} of the fixed controls visible" }
    parts += "${e.frame.width}×${e.frame.height}"
    return parts.joinToString(" · ")
}

// ---- step 4 ---------------------------------------------------------------------------------------------------------

@Composable
private fun StepAnalyze(env: UiEnv, state: SetupState) {
    val sel = state.selectedFrame
    if (sel == null) {
        EmptyState(Glyph.IMAGE, "Choose the driving screen first", "The analysis works on the pictures with the same size as the chosen one.", "Go to step 3") { env.nav.setupStep = SETUP_STEP_SCREEN }
        return
    }
    val sameSize = state.frames.count { it.frame.width == sel.frame.width && it.frame.height == sel.frame.height }
    // Any number of pictures can be analysed; with few (or still) pictures the evidence is weaker and said so.
    val strong = sameSize >= SetupSession.MIN_FOR_ANALYSIS
    val analysing = state.phase == SetupPhase.ANALYZING
    HpCard(accent = if (analysing) Hp.Accent else null) {
        SectionHeader("Find candidate controls", subtitle = "$sameSize picture(s) of this size")
        BodyText(
            "HaulPilot compares the pictures: the scenery moves, the controls stay put. It then proposes candidates from their shapes and arrangement " +
                "(two tall pedals side by side, a round wheel or a mirrored pair of arrows, a changing map area).",
        )
        SmallText("Candidates are never used until you confirm them, and their evidence score never goes above 60 %: a shape is a hint, not proof.")
        when {
            analysing -> {
                ProgressLine(state.message, null)
                HpButton("Cancel analysis", { AutopilotRuntime.setup.cancel() }, kind = BtnKind.GHOST, glyph = Glyph.CLOSE)
            }
            else -> {
                if (!strong) {
                    Banner(
                        Tone.ATTENTION, "Few pictures: weaker evidence",
                        "With fewer than ${SetupSession.MIN_FOR_ANALYSIS} pictures taken while driving, the fixed controls cannot be told apart from the scenery. " +
                            "The pictures are still searched for control shapes, but every candidate is weaker and must be checked. Collecting while driving gives much better results.",
                    )
                }
                HpButton(
                    if (state.draft.analysed) "Analyse again" else "Analyse $sameSize picture(s)", { AutopilotRuntime.setup.analyze() },
                    Modifier.fillMaxWidth(), kind = if (state.draft.analysed) BtnKind.SECONDARY else BtnKind.PRIMARY,
                    enabled = !state.phase.busy, glyph = Glyph.TARGET,
                )
                if (state.phase == SetupPhase.CAPTURING) SmallText("Stop collecting first (step 2).")
                SmallText("What you already confirmed or placed is never replaced by a new analysis.")
            }
        }
    }
    if (state.draft.analysed && state.analysisNotes.isNotEmpty() && !analysing) {
        HpCard {
            SectionHeader("What the analysis found")
            state.analysisNotes.forEach { n -> CheckLine(null, n) }
            HpButton("Review the candidates", { env.nav.setupStep = SETUP_STEP_REVIEW }, Modifier.fillMaxWidth())
        }
    }
    HpCard {
        SectionHeader("Prefer to do it yourself?")
        BodyText("Skip the analysis and place each control on the picture with the zoomable editor.")
        HpButton(
            "Skip and place by hand",
            {
                AutopilotRuntime.setup.skipAnalysis()
                env.nav.setupStep = SETUP_STEP_PLACE
            },
            kind = BtnKind.SECONDARY, enabled = !state.phase.busy,
        )
    }
}
