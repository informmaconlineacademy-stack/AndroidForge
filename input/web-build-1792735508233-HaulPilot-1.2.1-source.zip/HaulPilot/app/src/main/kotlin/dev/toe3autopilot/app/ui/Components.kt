package dev.toe3autopilot.app.ui

import android.graphics.Bitmap
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import dev.toe3autopilot.core.vision.Frame

// ---- surfaces ---------------------------------------------------------------------------------------------------------

/** The one card style: surface colour, hairline border, 16 dp corners. Clickable when [onClick] is given. */
@Composable
fun HpCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    accent: Color? = null,
    padding: PaddingValues = PaddingValues(Sp.l),
    content: @Composable ColumnScope.() -> Unit,
) {
    val shape = RoundedCornerShape(Sp.radiusL)
    val base = modifier
        .fillMaxWidth()
        .clip(shape)
        .background(Hp.Surface)
        .border(1.dp, accent?.copy(alpha = 0.55f) ?: Hp.BorderSubtle, shape)
    val m = if (onClick != null) base.clickable(role = Role.Button, onClick = onClick) else base
    Column(m.padding(padding), verticalArrangement = Arrangement.spacedBy(Sp.m), content = content)
}

/** Title row of a section, optionally with a trailing action. Marked as a heading for TalkBack. */
@Composable
fun SectionHeader(title: String, modifier: Modifier = Modifier, subtitle: String? = null, trailing: (@Composable RowScope.() -> Unit)? = null) {
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, Modifier.semantics { heading() }, style = MaterialTheme.typography.titleMedium, color = Hp.Text)
            if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = Hp.TextMuted)
        }
        if (trailing != null) Row(verticalAlignment = Alignment.CenterVertically, content = trailing)
    }
}

/** Small overline label above a group of cards. */
@Composable
fun Overline(text: String, modifier: Modifier = Modifier) {
    Text(text.uppercase(), modifier.padding(top = Sp.s, start = Sp.xs), style = MaterialTheme.typography.labelMedium, color = Hp.TextMuted)
}

@Composable
fun BodyText(text: String, modifier: Modifier = Modifier, color: Color = Hp.TextSecondary) {
    Text(text, modifier, style = MaterialTheme.typography.bodyMedium, color = color)
}

@Composable
fun SmallText(text: String, modifier: Modifier = Modifier, color: Color = Hp.TextMuted, maxLines: Int = Int.MAX_VALUE) {
    Text(text, modifier, style = MaterialTheme.typography.bodySmall, color = color, maxLines = maxLines, overflow = TextOverflow.Ellipsis)
}

// ---- buttons ----------------------------------------------------------------------------------------------------------

enum class BtnKind { PRIMARY, SECONDARY, GHOST, DANGER, ACCENT }

/**
 * The app's button. PRIMARY (amber) is used for the one main action of a screen. Disabled buttons keep their label
 * readable; the reason they are disabled is always shown next to them by the caller.
 */
@Composable
fun HpButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    kind: BtnKind = BtnKind.PRIMARY,
    enabled: Boolean = true,
    glyph: Glyph? = null,
    height: Dp = Sp.touch,
) {
    val shape = RoundedCornerShape(Sp.radiusM)
    val pad = PaddingValues(horizontal = Sp.l, vertical = Sp.s)
    val content: @Composable RowScope.() -> Unit = {
        if (glyph != null) {
            HpIcon(glyph, tint = buttonContent(kind, enabled), size = 18.dp)
            Spacer(Modifier.width(Sp.s))
        }
        Text(text, style = MaterialTheme.typography.labelLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
    val m = modifier.heightIn(min = height)
    when (kind) {
        BtnKind.PRIMARY, BtnKind.DANGER, BtnKind.ACCENT -> Button(
            onClick = onClick, modifier = m, enabled = enabled, shape = shape, contentPadding = pad,
            colors = ButtonDefaults.buttonColors(
                containerColor = when (kind) {
                    BtnKind.DANGER -> Hp.DangerFill
                    BtnKind.ACCENT -> Hp.Accent
                    else -> Hp.Primary
                },
                contentColor = buttonContent(kind, true),
                disabledContainerColor = Hp.Raised,
                disabledContentColor = Hp.TextMuted,
            ),
            content = content,
        )
        BtnKind.SECONDARY -> OutlinedButton(
            onClick = onClick, modifier = m, enabled = enabled, shape = shape, contentPadding = pad,
            border = BorderStroke(1.dp, if (enabled) Hp.Border else Hp.BorderSubtle),
            colors = ButtonDefaults.outlinedButtonColors(containerColor = Hp.Raised, contentColor = Hp.Text, disabledContentColor = Hp.TextMuted),
            content = content,
        )
        BtnKind.GHOST -> TextButton(
            onClick = onClick, modifier = m, enabled = enabled, shape = shape, contentPadding = pad,
            colors = ButtonDefaults.textButtonColors(contentColor = Hp.Accent, disabledContentColor = Hp.TextMuted),
            content = content,
        )
    }
}

private fun buttonContent(kind: BtnKind, enabled: Boolean): Color = when {
    !enabled -> Hp.TextMuted
    kind == BtnKind.PRIMARY -> Hp.OnPrimary
    kind == BtnKind.ACCENT -> Hp.OnAccent
    kind == BtnKind.DANGER -> Color.White
    kind == BtnKind.GHOST -> Hp.Accent
    else -> Hp.Text
}

/** A square icon button with a 48 dp touch target. */
@Composable
fun IconAction(glyph: Glyph, description: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true, tint: Color = Hp.TextSecondary) {
    Box(
        modifier
            .size(Sp.touch)
            .clip(RoundedCornerShape(Sp.radiusM))
            .clickable(enabled = enabled, role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { HpIcon(glyph, tint = if (enabled) tint else Hp.TextMuted.copy(alpha = 0.5f), size = 22.dp, description = description) }
}

// ---- status -----------------------------------------------------------------------------------------------------------

/** A compact status label: coloured dot + text on a tinted background. */
@Composable
fun StatusPill(text: String, tone: Tone, modifier: Modifier = Modifier) {
    val c = toneColor(tone)
    Row(
        modifier
            .clip(RoundedCornerShape(50))
            .background(c.copy(alpha = 0.13f))
            .padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Box(Modifier.size(7.dp).clip(CircleShape).background(c))
        Text(text, style = MaterialTheme.typography.labelMedium, color = c, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

/** One line of a checklist: state icon, title, explanation and an optional action. */
@Composable
fun CheckLine(ok: Boolean?, title: String, detail: String? = null, actionLabel: String? = null, onAction: (() -> Unit)? = null) {
    val (glyph, tint) = when (ok) {
        true -> Glyph.CHECK to Hp.Success
        false -> Glyph.WARNING to Hp.Warning
        null -> Glyph.DOT to Hp.TextMuted
    }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(Sp.m)) {
        Box(Modifier.size(28.dp).clip(CircleShape).background(tint.copy(alpha = 0.12f)), contentAlignment = Alignment.Center) {
            HpIcon(glyph, tint = tint, size = 16.dp)
        }
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall, color = Hp.Text)
            if (detail != null) Text(detail, style = MaterialTheme.typography.bodySmall, color = Hp.TextSecondary)
            if (actionLabel != null && onAction != null) {
                HpButton(actionLabel, onAction, kind = BtnKind.GHOST, height = 40.dp, modifier = Modifier.padding(top = 2.dp))
            }
        }
    }
}

/** A highlighted message with an optional action. */
@Composable
fun Banner(tone: Tone, title: String, text: String? = null, actionLabel: String? = null, onAction: (() -> Unit)? = null, modifier: Modifier = Modifier) {
    val c = toneColor(tone)
    val shape = RoundedCornerShape(Sp.radiusM)
    Row(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(c.copy(alpha = 0.10f))
            .border(1.dp, c.copy(alpha = 0.35f), shape)
            .padding(Sp.m),
        horizontalArrangement = Arrangement.spacedBy(Sp.m),
        verticalAlignment = Alignment.Top,
    ) {
        HpIcon(
            when (tone) {
                Tone.BAD, Tone.ATTENTION -> Glyph.WARNING
                Tone.GOOD -> Glyph.CHECK
                else -> Glyph.INFO
            },
            tint = c, size = 20.dp,
        )
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall, color = Hp.Text)
            if (text != null) Text(text, style = MaterialTheme.typography.bodySmall, color = Hp.TextSecondary)
            if (actionLabel != null && onAction != null) HpButton(actionLabel, onAction, kind = BtnKind.SECONDARY, height = 40.dp)
        }
    }
}

/** Nothing to show yet: what this place is for and how to fill it. */
@Composable
fun EmptyState(glyph: Glyph, title: String, text: String, actionLabel: String? = null, onAction: (() -> Unit)? = null) {
    Column(
        Modifier.fillMaxWidth().padding(vertical = Sp.xl, horizontal = Sp.l),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(Sp.s),
    ) {
        Box(Modifier.size(56.dp).clip(CircleShape).background(Hp.Raised), contentAlignment = Alignment.Center) {
            HpIcon(glyph, tint = Hp.TextSecondary, size = 28.dp)
        }
        Text(title, style = MaterialTheme.typography.titleMedium, color = Hp.Text)
        Text(text, style = MaterialTheme.typography.bodyMedium, color = Hp.TextSecondary)
        if (actionLabel != null && onAction != null) HpButton(actionLabel, onAction, kind = BtnKind.SECONDARY)
    }
}

/** Determinate (0..1) or indeterminate progress with a label. */
@Composable
fun ProgressLine(label: String, fraction: Float?, modifier: Modifier = Modifier, color: Color = Hp.Accent) {
    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(Modifier.fillMaxWidth()) {
            Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall, color = Hp.TextSecondary)
            if (fraction != null) Text("${(fraction * 100).toInt()}%", style = MaterialTheme.typography.labelMedium, color = color)
        }
        if (fraction != null) {
            LinearProgressIndicator(progress = { fraction.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(50)), color = color, trackColor = Hp.Raised)
        } else {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(50)), color = color, trackColor = Hp.Raised)
        }
    }
}

/** Horizontal confidence meter (0..1) with the number. */
@Composable
fun Meter(value: Float, color: Color, modifier: Modifier = Modifier) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
        Box(Modifier.weight(1f).heightIn(min = 6.dp).clip(RoundedCornerShape(50)).background(Hp.Raised)) {
            Box(Modifier.fillMaxWidth(value.coerceIn(0f, 1f)).heightIn(min = 6.dp).clip(RoundedCornerShape(50)).background(color))
        }
        Text("${(value * 100).toInt()}%", style = MaterialTheme.typography.labelMedium, color = Hp.TextSecondary)
    }
}

/** Label and value on one line. */
@Composable
fun InfoRow(label: String, value: String, valueColor: Color = Hp.Text) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = Arrangement.spacedBy(Sp.m)) {
        Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium, color = Hp.TextSecondary)
        Text(value, style = MaterialTheme.typography.bodyMedium, color = valueColor)
    }
}

// ---- settings rows -------------------------------------------------------------------------------------------------------

/** A tappable row that opens something, with an icon and a chevron. */
@Composable
fun NavRow(glyph: Glyph, title: String, subtitle: String?, onClick: () -> Unit, trailing: (@Composable () -> Unit)? = null) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(Sp.radiusM))
            .clickable(role = Role.Button, onClick = onClick)
            .heightIn(min = 60.dp)
            .padding(horizontal = Sp.m, vertical = Sp.s),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(Sp.m),
    ) {
        Box(Modifier.size(36.dp).clip(RoundedCornerShape(Sp.radiusS)).background(Hp.Raised), contentAlignment = Alignment.Center) {
            HpIcon(glyph, tint = Hp.Accent, size = 20.dp)
        }
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall, color = Hp.Text)
            if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = Hp.TextMuted, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        if (trailing != null) trailing()
        HpIcon(Glyph.CHEVRON, tint = Hp.TextMuted, size = 18.dp)
    }
}

@Composable
fun SwitchRow(title: String, subtitle: String?, checked: Boolean, onChange: (Boolean) -> Unit, enabled: Boolean = true) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(Sp.radiusM))
            .clickable(enabled = enabled, role = Role.Switch) { onChange(!checked) }
            .heightIn(min = 56.dp)
            .padding(vertical = Sp.xs),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(Sp.m),
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall, color = if (enabled) Hp.Text else Hp.TextMuted)
            if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = Hp.TextMuted)
        }
        Switch(
            checked = checked, onCheckedChange = null, enabled = enabled,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Hp.OnAccent, checkedTrackColor = Hp.Accent,
                uncheckedThumbColor = Hp.TextSecondary, uncheckedTrackColor = Hp.Raised, uncheckedBorderColor = Hp.Border,
            ),
        )
    }
}

@Composable
fun SliderRow(
    title: String,
    valueLabel: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    steps: Int = 0,
    subtitle: String? = null,
    enabled: Boolean = true,
    onChange: (Float) -> Unit,
) {
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(title, Modifier.weight(1f), style = MaterialTheme.typography.titleSmall, color = if (enabled) Hp.Text else Hp.TextMuted)
            Text(valueLabel, style = MaterialTheme.typography.labelLarge, color = if (enabled) Hp.Accent else Hp.TextMuted)
        }
        if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = Hp.TextMuted)
        Slider(
            value = value, onValueChange = onChange, valueRange = range, steps = steps, enabled = enabled,
            colors = SliderDefaults.colors(thumbColor = Hp.Accent, activeTrackColor = Hp.Accent, inactiveTrackColor = Hp.Raised),
        )
    }
}

// ---- dialogs ---------------------------------------------------------------------------------------------------------------

@Composable
fun ConfirmDialog(title: String, text: String, confirmLabel: String, onDismiss: () -> Unit, danger: Boolean = false, onConfirm: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Hp.Surface,
        title = { Text(title, color = Hp.Text) },
        text = { Text(text, color = Hp.TextSecondary) },
        confirmButton = { HpButton(confirmLabel, onConfirm, kind = if (danger) BtnKind.DANGER else BtnKind.PRIMARY) },
        dismissButton = { HpButton("Cancel", onDismiss, kind = BtnKind.GHOST) },
    )
}

/** Asks for a short name; [validate] returns an error to show, or null. */
@Composable
fun NameDialog(title: String, initial: String, confirmLabel: String, onDismiss: () -> Unit, validate: (String) -> String? = { null }, onConfirm: (String) -> Unit) {
    var name by rememberSaveable { mutableStateOf(initial) }
    val error = if (name.isBlank()) "Enter a name" else validate(name.trim())
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Hp.Surface,
        title = { Text(title, color = Hp.Text) },
        text = {
            OutlinedTextField(
                value = name, onValueChange = { name = it.take(60) }, singleLine = true,
                label = { Text("Name") }, isError = error != null && name.isNotEmpty(),
                supportingText = { if (error != null && name.isNotEmpty()) Text(error) },
            )
        },
        confirmButton = { HpButton(confirmLabel, { onConfirm(name.trim()) }, enabled = error == null) },
        dismissButton = { HpButton("Cancel", onDismiss, kind = BtnKind.GHOST) },
    )
}

// ---- pictures --------------------------------------------------------------------------------------------------------------

/** Converts a frame into a bitmap once per frame (and, with [maxWidth], scales it down for thumbnails). */
@Composable
fun rememberBitmap(frame: Frame, maxWidth: Int = 0): Bitmap = remember(frame, maxWidth) {
    val full = Bitmap.createBitmap(frame.argb, frame.width, frame.height, Bitmap.Config.ARGB_8888)
    if (maxWidth in 1 until frame.width) {
        val h = (frame.height.toFloat() * maxWidth / frame.width).toInt().coerceAtLeast(1)
        val small = Bitmap.createScaledBitmap(full, maxWidth, h, true)
        if (small !== full) full.recycle()
        small
    } else {
        full
    }
}

/** A captured picture at its own aspect ratio. */
@Composable
fun FramePicture(frame: Frame, modifier: Modifier = Modifier, description: String? = null, thumbnailWidth: Int = 0) {
    val bmp = rememberBitmap(frame, thumbnailWidth)
    Image(
        bmp.asImageBitmap(), contentDescription = description, contentScale = ContentScale.FillBounds,
        filterQuality = FilterQuality.Low,
        modifier = modifier.fillMaxWidth().aspectRatio(frame.width.toFloat() / frame.height).clip(RoundedCornerShape(Sp.radiusM)).background(Hp.Raised),
    )
}

/** A thin rule between groups. */
@Composable
fun Hairline(modifier: Modifier = Modifier) {
    Box(modifier.fillMaxWidth().heightIn(min = 1.dp, max = 1.dp).background(Hp.BorderSubtle))
}

/** A surface used for sticky bars (step footer, editor bars). */
@Composable
fun BarSurface(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Surface(modifier.fillMaxWidth(), color = Hp.Surface, contentColor = Hp.Text, border = BorderStroke(1.dp, Hp.BorderSubtle), content = content)
}
