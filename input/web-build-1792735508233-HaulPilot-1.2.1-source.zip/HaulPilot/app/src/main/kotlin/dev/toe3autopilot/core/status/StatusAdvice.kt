package dev.toe3autopilot.core.status

import dev.toe3autopilot.core.HelpKind
import dev.toe3autopilot.core.capture.AnalyzerDiagnosis
import dev.toe3autopilot.core.capture.CaptureDiagnosis
import dev.toe3autopilot.core.capture.CaptureFault
import dev.toe3autopilot.core.capture.DiagnosisKind
import dev.toe3autopilot.core.session.SessionSnapshot
import dev.toe3autopilot.core.session.SessionStatus
import dev.toe3autopilot.core.setup.SetupPhase
import dev.toe3autopilot.core.setup.SetupState

enum class AdviceSeverity { SUCCESS, INFO, PROGRESS, WARNING, ERROR }

/** What the app can do for the person from a piece of advice. The UI maps each to a real action. */
enum class AdviceAction {
    NONE, TURN_ON_CAPTURE, USE_RECORDED_CLIP, OPEN_CALIBRATION, REVIEW_CONTROLS, ENABLE_ACCESSIBILITY, RESUME, START_DRIVE,
}

/** Every real-world situation the screens explain. */
enum class AdviceKey {
    EMERGENCY_STOP, ROAD_LOST, LAYOUT_CHANGED, PARKING_NEEDS_YOU, INPUT_FAILED, SERVICE_STOPPED, NEEDS_ASSISTANCE,
    PAUSED, PARKED, PERMISSION_DENIED, CAPTURE_UNAVAILABLE, NO_USABLE_FRAMES, CAPTURE_OFF, CALIBRATING, CALIBRATION_FAILED,
    NEEDS_CONFIRMATION, NO_PROFILE, ACCESSIBILITY_OFF, NOT_READY, UNSAVED_SETUP,
}

data class Advice(
    val key: AdviceKey,
    val severity: AdviceSeverity,
    val title: String,
    /** What happened and what to do, in plain words. */
    val text: String,
    val action: AdviceAction,
    val actionLabel: String?,
)

data class StatusInputs(
    val snapshot: SessionSnapshot,
    val captureOn: Boolean,
    val diagnosis: CaptureDiagnosis,
    /** Why screen capture last ended, if it did. */
    val captureEndReason: String?,
    val accessibilityOn: Boolean,
    val assistedMode: Boolean,
    /** Smart Setup's state (the single source of truth for calibration). */
    val setup: SetupState,
    val hasProfile: Boolean,
    /** What prevents driving with the active profile (empty = ready). */
    val notReady: List<String> = emptyList(),
)

/**
 * Turns the app's real state into the short list of things the person should know right now, most important first. Each
 * item says what happened and offers one next step. Pure function, so every state is covered by unit tests.
 */
object StatusAdvice {
    fun all(i: StatusInputs): List<Advice> {
        val out = ArrayList<Advice>()
        val snap = i.snapshot
        val why = snap.lastError ?: snap.task

        // ---- the drive ----
        when (snap.status) {
            SessionStatus.EMERGENCY_STOPPED -> out += Advice(
                AdviceKey.EMERGENCY_STOP, AdviceSeverity.ERROR, "Emergency Stop activated",
                "All automated inputs were released and driving will not continue by itself. Check the game, then start again when it is safe.",
                AdviceAction.START_DRIVE, "Start Auto Drive again",
            )
            SessionStatus.NEEDS_ASSIST, SessionStatus.ERROR -> {
                val canResume = snap.status == SessionStatus.NEEDS_ASSIST
                out += when (snap.helpKind) {
                    HelpKind.ROAD_LOST -> Advice(
                        AdviceKey.ROAD_LOST, AdviceSeverity.WARNING, "Road tracking lost",
                        "$why The truck was stopped because the route line could not be seen. Make sure the minimap with the route is visible, " +
                            "drive back onto the route if needed, then resume.",
                        if (canResume) AdviceAction.RESUME else AdviceAction.START_DRIVE, if (canResume) "Resume" else "Start again",
                    )
                    HelpKind.LAYOUT_CHANGED -> Advice(
                        AdviceKey.LAYOUT_CHANGED, AdviceSeverity.WARNING, "The screen layout changed",
                        "$why The calibration no longer matches the screen, so driving stopped. Recalibrate for this layout.",
                        AdviceAction.OPEN_CALIBRATION, "Recalibrate",
                    )
                    HelpKind.PARKING_FAILED -> Advice(
                        AdviceKey.PARKING_NEEDS_YOU, AdviceSeverity.WARNING, "Please finish parking",
                        "$why The truck stopped near the delivery area instead of manoeuvring blindly.", AdviceAction.NONE, null,
                    )
                    HelpKind.INPUT -> Advice(
                        AdviceKey.INPUT_FAILED, AdviceSeverity.ERROR, "Touches could not be sent",
                        "$why Check that the HaulPilot accessibility service is on, or use Assisted mode.",
                        AdviceAction.ENABLE_ACCESSIBILITY, "Accessibility settings",
                    )
                    HelpKind.CAPTURE -> Advice(
                        AdviceKey.SERVICE_STOPPED, AdviceSeverity.ERROR, "Screen capture stopped",
                        "$why Driving stopped and will not restart by itself. Turn screen capture on again, then start.",
                        AdviceAction.TURN_ON_CAPTURE, "Turn on screen capture",
                    )
                    else -> Advice(
                        AdviceKey.NEEDS_ASSISTANCE, AdviceSeverity.WARNING, "Needs your help",
                        "$why The truck was stopped. Take over in the game; resume only when it is safe.",
                        if (canResume) AdviceAction.RESUME else AdviceAction.START_DRIVE, if (canResume) "Resume" else "Start again",
                    )
                }
            }
            SessionStatus.PAUSED -> out += Advice(
                AdviceKey.PAUSED, AdviceSeverity.INFO, "Driving paused",
                "${snap.task}. All inputs are released. Resume when the normal driving view is showing.", AdviceAction.RESUME, "Resume",
            )
            SessionStatus.FINISHED -> out += Advice(
                AdviceKey.PARKED, AdviceSeverity.SUCCESS, "Parked",
                "Driving has stopped. Unload, detach the trailer, collect payment and choose the next job yourself.", AdviceAction.NONE, null,
            )
            else -> {}
        }
        val live = snap.status.isActiveLoop

        // ---- screen capture ----
        val d = i.diagnosis
        when {
            d.fault == CaptureFault.PERMISSION_DENIED -> out += Advice(
                AdviceKey.PERMISSION_DENIED, AdviceSeverity.ERROR, "Screen-capture permission not granted",
                "Android's screen-sharing dialog was declined, so the app cannot see the game. Ask again and choose \"Entire screen\".",
                AdviceAction.TURN_ON_CAPTURE, "Ask again",
            )
            d.kind == DiagnosisKind.FAULT -> out += Advice(
                AdviceKey.CAPTURE_UNAVAILABLE, AdviceSeverity.ERROR, d.title, d.detail,
                if (d.offerVideoCalibration) AdviceAction.USE_RECORDED_CLIP else AdviceAction.TURN_ON_CAPTURE,
                if (d.offerVideoCalibration) "Calibrate from a recorded clip" else "Try again",
            )
            d.isProblem -> out += Advice(
                AdviceKey.NO_USABLE_FRAMES, AdviceSeverity.ERROR, d.title, d.detail,
                if (d.offerVideoCalibration) AdviceAction.USE_RECORDED_CLIP else AdviceAction.TURN_ON_CAPTURE,
                if (d.offerVideoCalibration) "Calibrate from a recorded clip" else "Try again",
            )
            !i.captureOn && !live && out.none { it.key == AdviceKey.SERVICE_STOPPED } && i.captureEndReason != null -> out += Advice(
                AdviceKey.CAPTURE_OFF, AdviceSeverity.INFO, "Screen capture is off",
                "It ended: ${i.captureEndReason}. Nothing restarts by itself; Start Auto Drive asks for it again.",
                AdviceAction.TURN_ON_CAPTURE, "Turn on screen capture",
            )
        }

        // ---- setup (only when no drive is running) ----
        if (!live) {
            val setup = i.setup
            val busy = setup.phase.busy
            val pending = setup.draft.pendingCandidates.size
            when {
                busy -> out += Advice(
                    AdviceKey.CALIBRATING, AdviceSeverity.PROGRESS, "Smart Setup: ${setup.phase.label.lowercase()}",
                    setup.message, AdviceAction.OPEN_CALIBRATION, "Open Smart Setup",
                )
                setup.phase == SetupPhase.FAILED -> {
                    val reason = setup.problem ?: "Setup stopped."
                    val explain = AnalyzerDiagnosis.classify(reason)?.let { AnalyzerDiagnosis.explain(it) }
                    out += Advice(
                        AdviceKey.CALIBRATION_FAILED, AdviceSeverity.WARNING, "Smart Setup stopped",
                        listOfNotNull(reason, explain).joinToString(" ") + " Retry, import screenshots or a clip, or place the controls by hand.",
                        AdviceAction.OPEN_CALIBRATION, "Open Smart Setup",
                    )
                }
                pending > 0 -> out += Advice(
                    AdviceKey.NEEDS_CONFIRMATION, AdviceSeverity.WARNING,
                    "$pending control(s) need your confirmation",
                    "Candidates are never used until you confirm them. Check each one on the picture and confirm, move or reject it.",
                    AdviceAction.REVIEW_CONTROLS, "Review controls",
                )
                setup.dirty && setup.draft.confirmedCount > 0 -> out += Advice(
                    AdviceKey.UNSAVED_SETUP, AdviceSeverity.INFO, "Setup changes not saved",
                    "Smart Setup has changes that are not in a profile yet. Validate and save them to use them.",
                    AdviceAction.OPEN_CALIBRATION, "Open Smart Setup",
                )
            }
            if (!i.hasProfile && !busy) {
                out += Advice(
                    AdviceKey.NO_PROFILE, AdviceSeverity.INFO, "No calibration profile yet",
                    "Set up the driving controls once in Smart Setup. Live play works best; screenshots or a recorded clip work when live capture does not.",
                    AdviceAction.OPEN_CALIBRATION, "Start Smart Setup",
                )
            } else if (i.notReady.isNotEmpty() && !busy) {
                out += Advice(
                    AdviceKey.NOT_READY, AdviceSeverity.WARNING, "Not ready to drive",
                    i.notReady.take(3).joinToString("; ") + if (i.notReady.size > 3) "; and ${i.notReady.size - 3} more." else ".",
                    AdviceAction.OPEN_CALIBRATION, "Finish Smart Setup",
                )
            }
        }

        // ---- touches ----
        if (!i.accessibilityOn && !i.assistedMode && out.none { it.key == AdviceKey.INPUT_FAILED }) out += Advice(
            AdviceKey.ACCESSIBILITY_OFF, AdviceSeverity.WARNING, "Touch control is off",
            "The accessibility service sends the touches and shows the floating button. Turn it on, or use Assisted mode, which only shows what it would do.",
            AdviceAction.ENABLE_ACCESSIBILITY, "Turn on",
        )
        return out
    }
}
