package dev.toe3autopilot.core.profile

import dev.toe3autopilot.core.AutomationSettings
import dev.toe3autopilot.core.Clock
import dev.toe3autopilot.core.Control
import dev.toe3autopilot.core.calibration.LayoutCheck
import dev.toe3autopilot.core.vision.GrayImage
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.nio.file.AtomicMoveNotSupportedException
import java.nio.file.Files
import java.nio.file.StandardCopyOption

/** PNG (or any) encoding of template pictures. Android implements it with Bitmap; tests use a raw codec. */
interface ImageCodec {
    fun encode(img: GrayImage): ByteArray

    /** Null when the bytes are not a readable picture. */
    fun decode(bytes: ByteArray): GrayImage?
}

/** One entry of the profile list. */
data class ProfileSummary(
    val id: String,
    val name: String,
    val active: Boolean,
    /** False when the stored file could not be read (shown as damaged; it can be deleted, not used). */
    val readable: Boolean,
    val error: String?,
    val updatedMs: Long?,
    /** "480x216" (the picture size the positions were made on), when known. */
    val layout: String?,
    val controls: Set<Control>,
    val steering: SteeringMode?,
    val hasMinimap: Boolean,
    val hasDrivingScreen: Boolean,
    /** What still prevents driving with this profile (empty = ready). */
    val notReady: List<String>,
    val gameVersion: String?,
    val canUndoLastChange: Boolean,
)

sealed class ProfileLoad {
    data class Ok(val profile: GameProfile) : ProfileLoad()
    data class Damaged(val reason: String) : ProfileLoad()
    object Missing : ProfileLoad()
}

data class SaveResult(val ok: Boolean, val error: String? = null)

/** Handle for undoing a delete. */
data class DeletedProfile(val id: String, val name: String, val wasActive: Boolean)

/**
 * Several calibration profiles on disk, crash-safe.
 *
 *     <root>/active                       id of the active profile
 *     <root>/<id>/profile.properties      the profile (ProfileCodec text)
 *     <root>/<id>/templates/<name>.png    its template pictures
 *     <root>/<id>/previous/...            the version before the last save (profile + pictures), for Undo
 *     <root>/.trash/<id>/...              a deleted profile, until it is purged (for Undo)
 *
 * Saving never edits a profile in place. A complete new version is written to `<id>.staging`, then swapped in with two
 * directory renames (`<id>` -> `<id>.old`, staging -> `<id>`). If the app dies in between, [recover] (run on start-up)
 * puts the old version back. So a save either fully happens or leaves the previous version untouched, and a working
 * profile is never replaced by a half-written one.
 *
 * Not thread-safe by itself beyond its own methods (all synchronized). Android-free so it is unit-tested on the JVM.
 */
class ProfileRepository(private val root: File, private val codec: ImageCodec, private val clock: Clock) : TemplateStore {
    private val lock = Any()
    private val trash = File(root, ".trash")
    private val activeFile = File(root, "active")
    private val cache = HashMap<String, Pair<Long, GrayImage?>>()

    init {
        root.mkdirs()
    }

    // ---- reading ----------------------------------------------------------------------------------------------

    fun ids(): List<String> = synchronized(lock) {
        root.listFiles { f -> f.isDirectory && ID.matches(f.name) }?.map { it.name }?.sorted().orEmpty()
    }

    fun activeId(): String? = synchronized(lock) {
        val id = if (activeFile.exists()) activeFile.readText().trim() else ""
        if (id.isNotEmpty() && File(root, id).isDirectory) id else null
    }

    fun load(id: String): ProfileLoad = synchronized(lock) {
        val f = profileFile(id)
        if (!f.exists()) return ProfileLoad.Missing
        return try {
            ProfileLoad.Ok(ProfileCodec.parse(f.readText()))
        } catch (e: IllegalArgumentException) {
            ProfileLoad.Damaged(e.message ?: "unreadable")
        } catch (e: IOException) {
            ProfileLoad.Damaged("the file could not be read (${e.javaClass.simpleName})")
        }
    }

    fun active(): GameProfile? = activeId()?.let { (load(it) as? ProfileLoad.Ok)?.profile }

    fun list(settings: AutomationSettings = AutomationSettings()): List<ProfileSummary> = synchronized(lock) {
        val act = activeId()
        ids().map { id -> summary(id, id == act, settings) }.sortedWith(compareByDescending<ProfileSummary> { it.active }.thenBy { it.name.lowercase() })
    }

    fun summary(id: String, active: Boolean, settings: AutomationSettings = AutomationSettings()): ProfileSummary = synchronized(lock) {
        val canUndo = profileFile(id, previous = true).exists()
        when (val l = load(id)) {
            is ProfileLoad.Ok -> {
                val p = l.profile
                val ref = LayoutCheck.referenceSize(p)
                val store = storeFor(id)
                ProfileSummary(
                    id, p.name, active, true, null,
                    p.extras["meta.updatedMs"]?.toLongOrNull() ?: profileFile(id).lastModified().takeIf { it > 0 },
                    ref?.let { "${it.width}x${it.height}" },
                    p.controls.keys, if (p.controls.isEmpty()) null else p.steeringMode, p.nav != null,
                    !p.stateRules[dev.toe3autopilot.core.state.GameState.DRIVING].isNullOrEmpty(),
                    ProfileReadiness.problems(p, settings, store), p.extras["meta.gameVersion"], canUndo,
                )
            }
            is ProfileLoad.Damaged -> ProfileSummary(id, id, active, false, l.reason, null, null, emptySet(), null, false, false, listOf("The profile file is damaged"), null, canUndo)
            ProfileLoad.Missing -> ProfileSummary(id, id, active, false, "missing", null, null, emptySet(), null, false, false, listOf("The profile file is missing"), null, canUndo)
        }
    }

    /** Template pictures of profile [id], read lazily. */
    fun storeFor(id: String): TemplateStore = object : TemplateStore {
        override fun gray(name: String): GrayImage? = readTemplate(id, name)
    }

    /** Templates of the ACTIVE profile (what the automation uses). */
    override fun gray(name: String): GrayImage? = activeId()?.let { readTemplate(it, name) }

    fun templateBytes(id: String, name: String): ByteArray? = synchronized(lock) {
        val f = templateFile(id, name)
        if (f.exists()) f.readBytes() else null
    }

    fun profileText(id: String): String? = synchronized(lock) { profileFile(id).takeIf { it.exists() }?.readText() }

    // ---- writing ----------------------------------------------------------------------------------------------

    /** Creates an empty profile and returns its id. It becomes active when there was none. */
    fun create(name: String, gamePackage: String): String = synchronized(lock) {
        val id = newId(name)
        val now = clock.nowMs()
        val p = GameProfile.EMPTY.copy(name = cleanName(name), gamePackage = gamePackage, extras = mapOf("meta.createdMs" to now.toString(), "meta.updatedMs" to now.toString()))
        val r = writeVersion(id, p, emptyMap(), keepPrevious = false, replaceTemplates = true)
        check(r.ok) { r.error ?: "could not create the profile" }
        if (activeId() == null) activate(id)
        id
    }

    /**
     * Saves a new version of profile [id] (created if needed) with these template pictures added or replaced.
     * With [replaceTemplates] the old pictures are dropped first (a fresh calibration). The previous version is kept for
     * [undoLastChange]. Nothing on disk changes when it fails.
     */
    fun save(id: String, profile: GameProfile, patches: Map<String, GrayImage>, replaceTemplates: Boolean = false): SaveResult = synchronized(lock) {
        require(ID.matches(id)) { "bad profile id" }
        val stamped = profile.copy(
            name = cleanName(profile.name),
            extras = profile.extras + ("meta.updatedMs" to clock.nowMs().toString()) +
                (if (profile.extras.containsKey("meta.createdMs")) emptyMap() else mapOf("meta.createdMs" to clock.nowMs().toString())),
        )
        writeVersion(id, stamped, patches, keepPrevious = true, replaceTemplates = replaceTemplates)
    }

    fun rename(id: String, newName: String): SaveResult = synchronized(lock) {
        val p = (load(id) as? ProfileLoad.Ok)?.profile ?: return SaveResult(false, "The profile cannot be read.")
        save(id, p.copy(name = newName), emptyMap())
    }

    /** Copies profile [id] (with its pictures) under a new name; returns the new id. */
    fun duplicate(id: String, newName: String): String? = synchronized(lock) {
        val p = (load(id) as? ProfileLoad.Ok)?.profile ?: return null
        val nid = newId(newName)
        val pics = HashMap<String, GrayImage>()
        for (n in p.templates.keys) readTemplate(id, n)?.let { pics[n] = it }
        val now = clock.nowMs().toString()
        val r = writeVersion(nid, p.copy(name = cleanName(newName), extras = p.extras + mapOf("meta.createdMs" to now, "meta.updatedMs" to now)), pics, keepPrevious = false, replaceTemplates = true)
        if (r.ok) nid else null
    }

    fun activate(id: String): Boolean = synchronized(lock) {
        if (!File(root, id).isDirectory) return false
        atomicWrite(activeFile, id.toByteArray())
        cache.clear()
        true
    }

    /** Moves the profile to the trash; [undoDelete] brings it back. */
    fun delete(id: String): DeletedProfile? = synchronized(lock) {
        val dir = File(root, id)
        if (!dir.isDirectory) return null
        val name = (load(id) as? ProfileLoad.Ok)?.profile?.name ?: id
        val wasActive = activeId() == id
        trash.mkdirs()
        val dest = File(trash, id)
        if (dest.exists()) dest.deleteRecursively()
        if (!dir.renameTo(dest)) return null
        if (wasActive) {
            activeFile.delete()
            ids().firstOrNull()?.let { activate(it) }
        }
        cache.clear()
        DeletedProfile(id, name, wasActive)
    }

    fun undoDelete(d: DeletedProfile): Boolean = synchronized(lock) {
        val src = File(trash, d.id)
        val dest = File(root, d.id)
        if (!src.isDirectory || dest.exists()) return false
        if (!src.renameTo(dest)) return false
        if (d.wasActive) activate(d.id)
        true
    }

    fun purgeTrash() = synchronized(lock) {
        trash.deleteRecursively()
    }

    fun canUndoLastChange(id: String): Boolean = synchronized(lock) { profileFile(id, previous = true).exists() }

    /** Puts back the version before the last save (profile and pictures). The undone version becomes the new "previous". */
    fun undoLastChange(id: String): SaveResult = synchronized(lock) {
        val prevDir = File(File(root, id), PREVIOUS)
        val text = File(prevDir, PROFILE).takeIf { it.exists() }?.readText() ?: return SaveResult(false, "There is no earlier version.")
        val p = try {
            ProfileCodec.parse(text)
        } catch (e: IllegalArgumentException) {
            return SaveResult(false, "The earlier version cannot be read: ${e.message}")
        }
        val pics = HashMap<String, GrayImage>()
        File(prevDir, TEMPLATES).listFiles { f -> f.name.endsWith(".png") }?.forEach { f ->
            codec.decode(f.readBytes())?.let { pics[f.name.removeSuffix(".png")] = it }
        }
        writeVersion(id, p, pics, keepPrevious = true, replaceTemplates = true)
    }

    /** Imports raw files (from an archive): the profile text must parse strictly. Returns the new id. */
    fun importProfile(text: String, templatesPng: Map<String, ByteArray>, nameOverride: String? = null): String = synchronized(lock) {
        val p = ProfileCodec.parse(text)
        val name = nameOverride ?: p.name
        val pics = HashMap<String, GrayImage>()
        for ((n, b) in templatesPng) {
            require(TEMPLATE.matches(n)) { "bad template name" }
            pics[n] = codec.decode(b) ?: throw IllegalArgumentException("Template picture '$n' is not readable")
        }
        val id = newId(name)
        val r = writeVersion(id, p.copy(name = cleanName(name)), pics, keepPrevious = false, replaceTemplates = true)
        if (!r.ok) throw IOException(r.error)
        id
    }

    /**
     * Brings back a consistent state after the app died during a save: a lone `<id>.old` is renamed back, leftovers of
     * unfinished saves are removed. Returns what was repaired.
     */
    fun recover(): List<String> = synchronized(lock) {
        val notes = ArrayList<String>()
        root.listFiles()?.forEach { f ->
            when {
                f.isDirectory && f.name.endsWith(OLD) -> {
                    val id = f.name.removeSuffix(OLD)
                    val cur = File(root, id)
                    if (!cur.exists()) {
                        if (f.renameTo(cur)) notes += "Restored profile '$id' after an interrupted save."
                    } else {
                        f.deleteRecursively()
                    }
                }
                f.isDirectory && f.name.endsWith(STAGING) -> {
                    f.deleteRecursively()
                    notes += "Removed an unfinished save of '${f.name.removeSuffix(STAGING)}'."
                }
                f.isFile && f.name.endsWith(".tmp") -> f.delete()
            }
        }
        notes
    }

    /**
     * One-time move of the old single-profile layout (`<legacyDir>/profile.properties` + `templates/`) into this
     * repository. The old files are left in place (a marker prevents a second import). A profile that does not parse is
     * still brought over, so it shows up as damaged instead of silently disappearing.
     */
    fun migrateLegacy(legacyDir: File): String? = synchronized(lock) {
        val marker = File(legacyDir, "migrated-to-profiles")
        val legacy = File(legacyDir, PROFILE)
        if (!legacy.exists() || marker.exists()) return null
        val text = legacy.readText()
        val name = try {
            ProfileCodec.parse(text).name
        } catch (e: IllegalArgumentException) {
            "Imported profile"
        }
        val id = newId(name)
        val dir = File(root, id)
        File(dir, TEMPLATES).mkdirs()
        atomicWrite(File(dir, PROFILE), text.toByteArray())
        File(legacyDir, TEMPLATES).listFiles { f -> f.name.endsWith(".png") && TEMPLATE.matches(f.name.removeSuffix(".png")) }?.forEach { f ->
            atomicWrite(File(File(dir, TEMPLATES), f.name), f.readBytes())
        }
        if (activeId() == null) activate(id)
        atomicWrite(marker, id.toByteArray())
        id
    }

    // ---- internals ----------------------------------------------------------------------------------------------

    private fun writeVersion(id: String, p: GameProfile, patches: Map<String, GrayImage>, keepPrevious: Boolean, replaceTemplates: Boolean): SaveResult {
        // 1. The text must survive the strict parser, or it is not written at all.
        val text = ProfileCodec.format(p)
        try {
            ProfileCodec.parse(text)
        } catch (e: IllegalArgumentException) {
            return SaveResult(false, "The profile is not valid: ${e.message}")
        }
        for (n in patches.keys) if (!TEMPLATE.matches(n)) return SaveResult(false, "Bad template name '$n'")
        val dir = File(root, id)
        val stage = File(root, id + STAGING)
        val old = File(root, id + OLD)
        try {
            if (stage.exists()) stage.deleteRecursively()
            File(stage, TEMPLATES).mkdirs()
            // 2. Build the complete new version next to the current one.
            if (dir.isDirectory) {
                if (!replaceTemplates) {
                    File(dir, TEMPLATES).listFiles { f -> f.name.endsWith(".png") }?.forEach { f -> f.copyTo(File(File(stage, TEMPLATES), f.name), overwrite = true) }
                }
                if (keepPrevious && File(dir, PROFILE).exists()) {
                    val prev = File(stage, PREVIOUS)
                    File(prev, TEMPLATES).mkdirs()
                    File(dir, PROFILE).copyTo(File(prev, PROFILE), overwrite = true)
                    File(dir, TEMPLATES).listFiles { f -> f.name.endsWith(".png") }?.forEach { f -> f.copyTo(File(File(prev, TEMPLATES), f.name), overwrite = true) }
                } else if (!keepPrevious && File(dir, PREVIOUS).isDirectory) {
                    File(dir, PREVIOUS).copyRecursively(File(stage, PREVIOUS), overwrite = true)
                }
            }
            for ((n, img) in patches) atomicWrite(File(File(stage, TEMPLATES), "$n.png"), codec.encode(img))
            // Templates the profile no longer uses are not carried as dead weight, but pictures of other templates stay.
            atomicWrite(File(stage, PROFILE), text.toByteArray())
            // 3. Swap. Between the two renames a crash leaves <id>.old, which recover() renames back.
            if (old.exists()) old.deleteRecursively()
            if (dir.exists() && !dir.renameTo(old)) throw IOException("could not move the current version aside")
            if (!stage.renameTo(dir)) {
                if (old.exists()) old.renameTo(dir)
                throw IOException("could not put the new version in place")
            }
            old.deleteRecursively()
            cache.clear()
            return SaveResult(true)
        } catch (e: Exception) {
            stage.deleteRecursively()
            if (!dir.exists() && old.exists()) old.renameTo(dir)
            return SaveResult(false, "Saving failed: ${e.message ?: e.javaClass.simpleName}. The previous version is unchanged.")
        }
    }

    private fun readTemplate(id: String, name: String): GrayImage? {
        if (!TEMPLATE.matches(name)) return null
        val f = templateFile(id, name)
        synchronized(lock) {
            if (!f.exists()) return null
            val key = "$id/$name"
            val hit = cache[key]
            if (hit != null && hit.first == f.lastModified()) return hit.second
            val img = try {
                codec.decode(f.readBytes())
            } catch (e: IOException) {
                null
            }
            cache[key] = f.lastModified() to img
            return img
        }
    }

    private fun profileFile(id: String, previous: Boolean = false): File =
        if (previous) File(File(File(root, id), PREVIOUS), PROFILE) else File(File(root, id), PROFILE)

    private fun templateFile(id: String, name: String) = File(File(File(root, id), TEMPLATES), "$name.png")

    private fun newId(name: String): String {
        val base = name.lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-').take(32).ifEmpty { "profile" }
        var id = base
        var n = 2
        while (File(root, id).exists() || File(trash, id).exists()) id = "$base-${n++}"
        return id
    }

    private fun cleanName(n: String): String =
        n.replace('\n', ' ').replace('\r', ' ').replace('\\', '/').trim().take(60).ifEmpty { "Profile" }

    companion object {
        private val ID = Regex("[a-z0-9][a-z0-9-]{0,40}")
        private val TEMPLATE = Regex("[a-z0-9_]{1,64}")
        private const val PROFILE = "profile.properties"
        private const val TEMPLATES = "templates"
        private const val PREVIOUS = "previous"
        private const val STAGING = ".staging"
        private const val OLD = ".old"

        /** Writes [bytes] to a temporary file, flushes it to the disk, then renames it over [target]. */
        fun atomicWrite(target: File, bytes: ByteArray) {
            target.parentFile?.mkdirs()
            val tmp = File(target.parentFile, target.name + ".tmp")
            FileOutputStream(tmp).use { out ->
                out.write(bytes)
                out.flush()
                out.fd.sync()
            }
            try {
                Files.move(tmp.toPath(), target.toPath(), StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING)
            } catch (e: AtomicMoveNotSupportedException) {
                if (!tmp.renameTo(target)) throw IOException("could not replace ${target.name}")
            }
        }
    }
}
