package dev.toe3autopilot.core.setup

import dev.toe3autopilot.core.Point
import dev.toe3autopilot.core.calibration.CalibRole
import dev.toe3autopilot.core.calibration.ControlDetection
import dev.toe3autopilot.core.calibration.DetectionSource
import dev.toe3autopilot.core.calibration.DetectionStatus
import dev.toe3autopilot.core.calibration.LayoutSignature
import dev.toe3autopilot.core.profile.SteeringMode
import dev.toe3autopilot.core.vision.ColorTarget
import dev.toe3autopilot.core.vision.Roi
import java.io.StringReader
import java.util.Locale
import java.util.Properties

/**
 * Text form of a [SetupDraft], saved after every change so the setup survives the app being closed or killed. Lenient on
 * read: a bad line is skipped and reported; an invariant that no longer holds (for example a candidate stored with a
 * confidence above its cap) is repaired downwards, never upwards.
 */
object DraftCodec {
    const val VERSION = 1

    data class Parsed(val draft: SetupDraft, val savedProfile: String?, val dirty: Boolean, val warnings: List<String>)

    fun format(d: SetupDraft, savedProfile: String?, dirty: Boolean): String {
        val sb = StringBuilder()
        fun put(k: String, v: String) = sb.append(k).append('=').append(v.replace("\\", "\\\\").replace("\n", " ")).append('\n')
        put("version", VERSION.toString())
        d.layout?.let { put("layout", "${it.width}x${it.height}") }
        put("driving.confirmed", d.drivingConfirmed.toString())
        d.steering?.let { put("steering", it.name) }
        d.steerRadius?.let { put("steer.radius", f(it)) }
        for ((role, c) in d.controls) {
            put(
                "control.${role.name}",
                listOf(c.status.name, f(c.confidence), f(c.x), f(c.y), c.source.name, c.box?.format() ?: "-", c.evidence.joinToString("~") { clean(it) }).joinToString("|"),
            )
        }
        val mm = d.minimap
        mm.box?.let { put("minimap.box", it.format()) }
        put("minimap.confirmed", mm.boxConfirmed.toString())
        mm.routeColor?.let { put("minimap.route", it.format()) }
        mm.truck?.let { put("minimap.truck", "${f(it.x)},${f(it.y)}") }
        mm.destinationColor?.let { put("minimap.destination", it.format()) }
        put("minimap.skipped", mm.skipped.toString())
        d.marker?.let { put("marker", it.format()) }
        d.markerSource?.let { put("marker.source", it.name) }
        put("analysed", d.analysed.toString())
        put("analysis.skipped", d.analysisSkipped.toString())
        savedProfile?.let { put("saved.profile", it) }
        put("dirty", dirty.toString())
        return sb.toString()
    }

    fun parse(text: String): Parsed {
        val warnings = ArrayList<String>()
        val p = Properties()
        try {
            p.load(StringReader(text))
        } catch (e: Exception) {
            return Parsed(SetupDraft.EMPTY, null, false, listOf("The saved setup could not be read and was ignored."))
        }
        fun bool(k: String) = p.getProperty(k)?.trim() == "true"
        fun <T> safe(k: String, block: (String) -> T): T? {
            val v = p.getProperty(k) ?: return null
            return try {
                block(v.trim())
            } catch (e: Exception) {
                warnings += "Skipped a bad line ($k)."
                null
            }
        }
        val layout = safe("layout") { v ->
            val (w, h) = v.split("x").map { it.toInt() }
            require(w > 0 && h > 0)
            LayoutSignature(w, h)
        }
        val controls = LinkedHashMap<CalibRole, ControlDetection>()
        for (key in p.stringPropertyNames().sorted()) {
            if (!key.startsWith("control.")) continue
            val role = CalibRole.entries.firstOrNull { it.name == key.removePrefix("control.") }
            if (role == null) {
                warnings += "Skipped an unknown control ($key)."
                continue
            }
            safe(key) { parseControl(role, it) }?.let { controls[role] = it }
        }
        val draft = SetupDraft(
            layout = layout,
            drivingConfirmed = bool("driving.confirmed"),
            steering = safe("steering") { SteeringMode.valueOf(it) },
            steerRadius = safe("steer.radius") { it.toFloat().coerceIn(0.02f, 0.4f) },
            controls = controls,
            minimap = MinimapDraft(
                box = safe("minimap.box") { Roi.parse(it) },
                boxConfirmed = bool("minimap.confirmed"),
                routeColor = safe("minimap.route") { ColorTarget.parse(it) },
                truck = safe("minimap.truck") { v -> v.split(",").map { it.trim().toFloat() }.let { Point(it[0].coerceIn(0f, 1f), it[1].coerceIn(0f, 1f)) } },
                skipped = bool("minimap.skipped"),
                destinationColor = safe("minimap.destination") { ColorTarget.parse(it) },
            ),
            marker = safe("marker") { Roi.parse(it) },
            markerSource = safe("marker.source") { DetectionSource.valueOf(it) },
            analysed = bool("analysed"),
            analysisSkipped = bool("analysis.skipped"),
        )
        // A box that is no longer confirmed cannot carry a confirmed flag without its box.
        val fixed = if (draft.minimap.box == null) draft.copy(minimap = draft.minimap.copy(boxConfirmed = false)) else draft
        return Parsed(fixed, p.getProperty("saved.profile"), bool("dirty"), warnings)
    }

    private fun parseControl(role: CalibRole, v: String): ControlDetection {
        val parts = v.split("|", limit = 7)
        require(parts.size == 7)
        var status = DetectionStatus.valueOf(parts[0])
        var conf = parts[1].toFloat().coerceIn(0f, 1f)
        val x = parts[2].toFloat().coerceIn(0f, 1f)
        val y = parts[3].toFloat().coerceIn(0f, 1f)
        val source = DetectionSource.valueOf(parts[4])
        val box = if (parts[5] == "-") null else Roi.parse(parts[5])
        val evidence = parts[6].split("~").filter { it.isNotBlank() }
        when (source) {
            DetectionSource.PRIOR -> conf = conf.coerceAtMost(ControlDetection.PRIOR_MAX_CONFIDENCE)
            DetectionSource.VIDEO -> conf = conf.coerceAtMost(ControlDetection.VIDEO_MAX_CONFIDENCE)
            DetectionSource.SHAPE -> conf = conf.coerceAtMost(ControlDetection.SHAPE_MAX_CONFIDENCE)
            else -> {}
        }
        if (status == DetectionStatus.AUTO_CONFIRMED && (source != DetectionSource.DEMONSTRATION || conf < ControlDetection.AUTO_CONFIRM_MIN)) {
            status = DetectionStatus.NEEDS_CONFIRMATION
        }
        return ControlDetection(role, x, y, box, conf, status, source, evidence)
    }

    private fun f(v: Float) = String.format(Locale.ROOT, "%.4f", v)

    private fun clean(s: String) = s.replace('|', '/').replace('~', '-').replace('\n', ' ').replace('\r', ' ')
}
