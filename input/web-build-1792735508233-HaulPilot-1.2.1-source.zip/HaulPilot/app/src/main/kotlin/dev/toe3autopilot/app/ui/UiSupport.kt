package dev.toe3autopilot.app.ui

import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarResult
import dev.toe3autopilot.app.AutopilotRuntime
import dev.toe3autopilot.core.capture.LinkAction
import dev.toe3autopilot.core.status.AdviceAction
import dev.toe3autopilot.core.status.AdviceSeverity
import dev.toe3autopilot.core.status.PrereqAction
import dev.toe3autopilot.core.status.ReadinessTone
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/*
 * Small glue shared by the screens: every advice / prerequisite / link action maps to ONE real action here, so a button
 * label can never promise something that is not wired.
 */

fun UiEnv.toast(message: String) {
    scope.launch { snackbar.showSnackbar(message, withDismissAction = true, duration = SnackbarDuration.Short) }
}

/** Shows [message] with an Undo action; [onUndo] runs only when the person presses it. */
fun UiEnv.toastWithUndo(message: String, onUndo: () -> Unit) {
    scope.launch {
        val r = snackbar.showSnackbar(message, actionLabel = "Undo", withDismissAction = true, duration = SnackbarDuration.Long)
        if (r == SnackbarResult.ActionPerformed) onUndo()
    }
}

/** Start Auto Drive from the app: problems (if any) are shown, never silently swallowed. */
fun UiEnv.startDrive(resume: Boolean = false) {
    val problems = AutopilotRuntime.startDriving(actions.launchGame, resume)
    if (problems.isNotEmpty()) toast((if (resume) "Cannot resume: " else "Cannot start: ") + problems.first())
}

fun UiEnv.connectOrExplain() {
    if (AutopilotRuntime.captureActive.value) toast("Screen capture is already connected.") else actions.connectCapture()
}

fun UiEnv.openGame() {
    if (!actions.launchGame()) toast("The game could not be opened. Choose it in Settings → Game & screen capture.")
}

fun UiEnv.runAdvice(a: AdviceAction) {
    when (a) {
        AdviceAction.NONE -> {}
        AdviceAction.TURN_ON_CAPTURE -> connectOrExplain()
        AdviceAction.USE_RECORDED_CLIP -> {
            nav.openSetup(SETUP_STEP_CAPTURE)
            actions.pickVideo()
        }
        AdviceAction.OPEN_CALIBRATION -> nav.openSetup(suggestedStep())
        AdviceAction.REVIEW_CONTROLS -> nav.openSetup(SETUP_STEP_REVIEW)
        AdviceAction.ENABLE_ACCESSIBILITY -> actions.openAccessibilitySettings()
        AdviceAction.RESUME -> startDrive(resume = true)
        AdviceAction.START_DRIVE -> startDrive()
    }
}

fun UiEnv.runPrereq(a: PrereqAction) {
    when (a) {
        PrereqAction.NONE -> {}
        PrereqAction.OPEN_PROFILES -> nav.open(Tab.PROFILES)
        PrereqAction.OPEN_SETUP -> nav.openSetup(suggestedStep())
        PrereqAction.ENABLE_ACCESSIBILITY -> actions.openAccessibilitySettings()
        PrereqAction.CHOOSE_GAME -> nav.open(Tab.SETTINGS, SettingsPage.CAPTURE)
        PrereqAction.CONNECT_CAPTURE -> connectOrExplain()
    }
}

fun UiEnv.runLink(a: LinkAction) {
    when (a) {
        LinkAction.CONNECT, LinkAction.RETRY -> actions.connectCapture()
        LinkAction.OPEN_GAME -> openGame()
        LinkAction.USE_GAME_IN_FRONT -> AutopilotRuntime.adoptForegroundAsGame()?.let { toast(it) } ?: toast("The app in front is now treated as the game.")
        LinkAction.CHOOSE_GAME -> nav.open(Tab.SETTINGS, SettingsPage.CAPTURE)
        LinkAction.USE_CLIP -> {
            nav.openSetup(SETUP_STEP_CAPTURE)
            actions.pickVideo()
        }
        LinkAction.NONE -> {}
    }
}

/** The first Smart Setup step that still needs the person (0-based), so "Open Smart Setup" lands where it matters. */
fun suggestedStep(): Int {
    val s = AutopilotRuntime.setup.state.value
    val steps = dev.toe3autopilot.core.setup.SetupSteps.of(s, AutopilotRuntime.link.value.receivingGame)
    val i = steps.indexOfFirst {
        it.status == dev.toe3autopilot.core.setup.StepStatus.TODO || it.status == dev.toe3autopilot.core.setup.StepStatus.ATTENTION
    }
    return if (i < 0) 0 else i
}

const val SETUP_STEP_CONNECT = 0
const val SETUP_STEP_CAPTURE = 1
const val SETUP_STEP_SCREEN = 2
const val SETUP_STEP_ANALYZE = 3
const val SETUP_STEP_REVIEW = 4
const val SETUP_STEP_PLACE = 5
const val SETUP_STEP_MINIMAP = 6
const val SETUP_STEP_VALIDATE = 7
const val SETUP_STEP_SAVE = 8
const val SETUP_STEP_TEST = 9

fun toneOf(t: ReadinessTone): Tone = when (t) {
    ReadinessTone.GOOD -> Tone.GOOD
    ReadinessTone.ATTENTION -> Tone.ATTENTION
    ReadinessTone.BAD -> Tone.BAD
    ReadinessTone.ACTIVE -> Tone.ACTIVE
    ReadinessTone.NEUTRAL -> Tone.NEUTRAL
}

fun toneOf(s: AdviceSeverity): Tone = when (s) {
    AdviceSeverity.SUCCESS -> Tone.GOOD
    AdviceSeverity.INFO -> Tone.INFO
    AdviceSeverity.PROGRESS -> Tone.ACTIVE
    AdviceSeverity.WARNING -> Tone.ATTENTION
    AdviceSeverity.ERROR -> Tone.BAD
}

private val dateTime = SimpleDateFormat("d MMM, HH:mm", Locale.getDefault())
private val clockTime = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

fun formatDateTime(ms: Long): String = synchronized(dateTime) { dateTime.format(Date(ms)) }

fun formatClock(ms: Long): String = synchronized(clockTime) { clockTime.format(Date(ms)) }

fun formatDuration(ms: Long): String {
    val s = ms / 1000
    return when {
        s < 60 -> "${s}s"
        s < 3600 -> "${s / 60}m ${s % 60}s"
        else -> "${s / 3600}h ${(s % 3600) / 60}m"
    }
}

fun formatBytes(b: Long): String = when {
    b < 1024 -> "$b B"
    b < 1024 * 1024 -> "${b / 1024} KB"
    else -> String.format(Locale.US, "%.1f MB", b / (1024.0 * 1024.0))
}

fun pct(v: Float): String = "${(v * 100).toInt()}%"

/** Background work started from a button: an exception becomes a notice for the person instead of a crash. */
fun CoroutineScope.launchSafely(block: suspend () -> Unit): Job = launch {
    try {
        block()
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        AutopilotRuntime.notice.value = "That did not work: ${e.message ?: e.javaClass.simpleName}"
    } catch (e: OutOfMemoryError) {
        AutopilotRuntime.notice.value = "That did not work: not enough memory."
    }
}
