package dev.toe3autopilot.core.session

/** One finished drive, as shown under "Recent sessions". States and reasons only; nothing from the screen. */
data class SessionRecord(
    val startedMs: Long,
    val endedMs: Long,
    val outcome: SessionStatus,
    val reason: String,
    val profile: String,
) {
    val durationMs: Long get() = (endedMs - startedMs).coerceAtLeast(0)
}

/**
 * Turns the stream of session snapshots into [SessionRecord]s. A drive starts when the session enters STARTING (a resume
 * after a pause continues the same drive); it ends when the session finishes, is stopped, emergency-stopped, fails or asks
 * for help. Pure.
 */
class SessionRecorder {
    private var startedAt: Long? = null
    private var profile: String = ""
    private var last: SessionStatus = SessionStatus.IDLE

    /** Returns a finished record when [snap] ends a drive, else null. */
    fun onSnapshot(snap: SessionSnapshot, nowMs: Long, profileName: String): SessionRecord? {
        val prev = last
        last = snap.status
        if (prev == snap.status) return null
        if (snap.status == SessionStatus.STARTING) {
            if (startedAt == null) {
                startedAt = nowMs
                profile = profileName
            }
            return null
        }
        val start = startedAt ?: return null
        if (snap.status !in ENDS) return null
        startedAt = null
        return SessionRecord(start, nowMs, snap.status, (snap.lastError ?: snap.task).take(200), profile)
    }

    private companion object {
        val ENDS = setOf(SessionStatus.FINISHED, SessionStatus.EMERGENCY_STOPPED, SessionStatus.ERROR, SessionStatus.NEEDS_ASSIST, SessionStatus.IDLE)
    }
}

/** Bounded list of records with a line-based text form. */
object SessionHistoryCodec {
    const val MAX = 30

    fun format(records: List<SessionRecord>): String = records.takeLast(MAX).joinToString("\n") { r ->
        listOf(r.startedMs, r.endedMs, r.outcome.name, clean(r.profile), clean(r.reason)).joinToString("\t")
    } + if (records.isEmpty()) "" else "\n"

    /** Unreadable lines are skipped. */
    fun parse(text: String): List<SessionRecord> = text.lineSequence().mapNotNull { line ->
        val p = line.split("\t")
        if (p.size != 5) return@mapNotNull null
        val s = p[0].toLongOrNull() ?: return@mapNotNull null
        val e = p[1].toLongOrNull() ?: return@mapNotNull null
        val st = SessionStatus.entries.firstOrNull { it.name == p[2] } ?: return@mapNotNull null
        SessionRecord(s, e, st, p[4], p[3])
    }.toList().takeLast(MAX)

    private fun clean(s: String) = s.replace('\t', ' ').replace('\n', ' ').replace('\r', ' ')
}
