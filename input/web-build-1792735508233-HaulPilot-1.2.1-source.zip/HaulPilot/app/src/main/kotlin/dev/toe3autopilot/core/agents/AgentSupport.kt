package dev.toe3autopilot.core.agents

enum class PulsePhase { MOVE, SETTLE }

/**
 * Alternates short MOVE bursts with SETTLE pauses. Parking uses it so that the truck is
 * stationary (and the picture steady) whenever a measurement is taken, and so that no single correction can run
 * away: Observe -> decide steering -> press the pedal for a short burst -> stop -> observe again.
 *
 * A burst is a FULL pedal press whose DURATION sets how far the truck moves. (Duty-cycling a partial throttle
 * over such a short window would produce only a tap or two and barely move the truck.)
 */
class PulseDriver {
    var phase: PulsePhase = PulsePhase.SETTLE
        private set
    var pulseCount: Int = 0
        private set

    /** True only on the tick on which a new MOVE phase begins. */
    var newPulse: Boolean = false
        private set

    private var phaseStart = 0L
    private var started = false

    fun reset() {
        phase = PulsePhase.SETTLE
        pulseCount = 0
        newPulse = false
        started = false
    }

    /** Forget how many pulses were used (assisted mode: pulses are suggestions, not our own attempts). */
    fun resetCount() {
        pulseCount = 0
    }

    /** @param wantMove whether another move should start once the settle time has elapsed. */
    fun tick(now: Long, wantMove: Boolean, moveMs: Long, settleMs: Long): PulsePhase {
        newPulse = false
        if (!started) {
            started = true
            phase = PulsePhase.SETTLE
            phaseStart = now
        }
        when (phase) {
            PulsePhase.SETTLE -> if (wantMove && now - phaseStart >= settleMs) {
                phase = PulsePhase.MOVE
                phaseStart = now
                pulseCount++
                newPulse = true
            }
            PulsePhase.MOVE -> if (now - phaseStart >= moveMs) {
                phase = PulsePhase.SETTLE
                phaseStart = now
            }
        }
        return phase
    }
}
