package dev.toe3autopilot.core.agents

import dev.toe3autopilot.core.HelpKind
import dev.toe3autopilot.core.AutomationSettings
import dev.toe3autopilot.core.Decision
import dev.toe3autopilot.core.DriveCommand
import dev.toe3autopilot.core.Gear
import dev.toe3autopilot.core.clampF
import dev.toe3autopilot.core.profile.GameProfile
import dev.toe3autopilot.core.vision.Vision
import kotlin.math.abs

/**
 * Low-speed positioning in the parking / reversing view, one short pulse at a time, re-measuring after each stop.
 *
 * It steers toward the "parking_zone" target (a template or a colour region). The session decides that parking is finished
 * (a "parked_ok" cue or the delivery screen); this agent only moves the truck. Bounded by [Config.maxPulses].
 * Profile extras: parking.direction=REVERSE|FORWARD (default REVERSE), parking.reverseSteerSign=1|-1,
 * parking.moveMs / parking.settleMs (burst and pause lengths; the burst is also scaled by the speed setting).
 */
class ParkingAgent(private val cfg: Config = Config()) {
    data class Config(
        val targetX: Float = 0.5f,
        val alignTol: Float = 0.05f,
        val moveMs: Long = 600,
        val settleMs: Long = 700,
        val maxPulses: Int = 60,
        val steerGain: Float = 3.5f,
        val searchTimeoutMs: Long = 15_000,
    )

    private val pulser = PulseDriver()
    private var lostSince: Long? = null
    private var pulseSteer = 0f

    val pulsesUsed: Int get() = pulser.pulseCount

    fun reset() {
        pulser.reset()
        lostSince = null
        pulseSteer = 0f
    }

    /** Assisted mode: suggestions are not our own attempts. */
    fun resetBudgets() {
        pulser.resetCount()
    }

    fun decide(vision: Vision, profile: GameProfile, settings: AutomationSettings, now: Long): Decision {
        val reverse = profile.extra("parking.direction", "REVERSE").uppercase() != "FORWARD"
        val gear = if (reverse) Gear.REVERSE else Gear.FORWARD
        val steerSign = if (reverse) profile.extraFloat("parking.reverseSteerSign", 1f) else 1f
        val hold = DriveCommand(brake = 1f, gear = gear)

        if (vision.has("parked_ok")) return Decision.Drive(hold, "Parked: waiting for the delivery to register")

        val zone = vision.locate("parking_zone")
        if (zone == null) {
            val since = lostSince ?: now.also { lostSince = it }
            if (now - since > cfg.searchTimeoutMs) return Decision.NeedHelp("The parking area is no longer visible. Stopped near the delivery area: please finish parking manually.", HelpKind.PARKING_FAILED)
            return Decision.Drive(hold, "Searching for the parking zone")
        }
        lostSince = null

        val ex = zone.x - cfg.targetX
        // Keep nudging even when "aligned": depth is only known from the game's own cues.
        val moveMs = (profile.extraFloat("parking.moveMs", cfg.moveMs.toFloat()) * clampF(settings.speedLevel / 0.5f, 0.5f, 2f)).toLong().coerceAtLeast(250L)
        val settleMs = profile.extraFloat("parking.settleMs", cfg.settleMs.toFloat()).toLong()
        when (pulser.tick(now, wantMove = true, moveMs = moveMs, settleMs = settleMs)) {
            PulsePhase.SETTLE -> return Decision.Drive(hold, "Stopped: measuring position")
            PulsePhase.MOVE -> {
                if (pulser.newPulse) {
                    if (pulser.pulseCount > cfg.maxPulses) {
                        return Decision.NeedHelp("Could not park within ${cfg.maxPulses} corrections. Stopped near the delivery area: please finish parking manually.", HelpKind.PARKING_FAILED)
                    }
                    pulseSteer = if (abs(ex) <= cfg.alignTol) 0f
                    else clampF(cfg.steerGain * ex * settings.sensitivity * steerSign, -1f, 1f)
                }
                val dir = if (reverse) "Reversing" else "Creeping"
                return Decision.Drive(
                    DriveCommand(steer = pulseSteer, throttle = 1f, gear = gear),
                    "$dir into the parking zone (offset ${"%.2f".format(ex)})",
                )
            }
        }
    }
}
