package dev.toe3autopilot.core.vision

import dev.toe3autopilot.core.clampF
import kotlin.math.abs

/** How trustworthy the road (route line) position currently is. */
enum class RoadQuality {
    /** A fresh, plausible reading. */
    TRACKING,

    /** The route was seen recently but not in the last readings: the last values are held and the truck should slow down. */
    DEGRADED,

    /** The route has not been seen for too long: the truck must stop. */
    LOST,
}

/**
 * Smoothed, validated road position.
 * @property offset   -1..+1: where the route line is relative to the truck marker (positive: to the right)
 * @property bend     -1..+1: how far the road veers sideways further ahead (positive: to the right)
 * @property curvature |bend|
 * @property routeEnding the far part of the route is not visible (a destination, an end of the route, or a very sharp turn)
 * @property missingForMs how long no valid reading has been available (0 while [quality] is TRACKING)
 */
data class TrackedRoad(
    val offset: Float,
    val bend: Float,
    val curvature: Float,
    val confidence: Float,
    val routeEnding: Boolean,
    val quality: RoadQuality,
    val missingForMs: Long,
)

/**
 * Turns raw per-frame [RouteReading]s into a stable road estimate and an explicit quality verdict.
 *
 *  - readings below [minConfidence] count as "not seen";
 *  - a sudden jump of the offset by more than [jumpLimit] from weak evidence is treated as an outlier unless it persists
 *    for [jumpConfirmFrames] readings in a row (a minimap glitch must not yank the steering);
 *  - while the route is not seen the last good values are held, quality is DEGRADED, and after [lostMs] it is LOST.
 *
 * It only knows what the minimap's route line shows. It does not see lane markings, other vehicles or the 3-D road.
 */
class RoadTracker(
    private val minConfidence: Float = 0.25f,
    private val lostMs: Long = 3000L,
    private val smoothing: Float = 0.6f,
    private val jumpLimit: Float = 0.7f,
    private val jumpConfirmFrames: Int = 3,
) {
    private var offset: Float? = null
    private var bend = 0f
    private var confidence = 0f
    private var ending = false
    private var lastGoodAt: Long? = null
    private var startedAt: Long? = null
    private var jumpCount = 0

    /** Time without a valid reading after which the road counts as lost. */
    fun lostAfterMs(): Long = lostMs

    fun reset() {
        offset = null
        bend = 0f
        confidence = 0f
        ending = false
        lastGoodAt = null
        startedAt = null
        jumpCount = 0
    }

    fun update(raw: RouteReading?, now: Long): TrackedRoad {
        if (startedAt == null) startedAt = now
        val good = raw != null && raw.confidence >= minConfidence
        if (raw != null && good) {
            val prev = offset
            val outlier = prev != null && abs(raw.offset - prev) > jumpLimit && raw.confidence < 0.6f
            if (outlier) {
                jumpCount++
            } else {
                jumpCount = 0
            }
            if (!outlier || jumpCount >= jumpConfirmFrames) {
                if (outlier) jumpCount = 0
                offset = if (prev == null) raw.offset else prev + smoothing * (raw.offset - prev)
                bend = if (prev == null) raw.bend else bend + smoothing * (raw.bend - bend)
                confidence = raw.confidence
                ending = !raw.farVisible
                lastGoodAt = now
                return TrackedRoad(offset ?: 0f, bend, abs(bend), confidence, ending, RoadQuality.TRACKING, 0L)
            }
        }
        val since = lastGoodAt ?: startedAt ?: now
        val missing = now - since
        val quality = if (lastGoodAt == null || missing > lostMs) RoadQuality.LOST else RoadQuality.DEGRADED
        return TrackedRoad(
            offset = clampF(offset ?: 0f, -1f, 1f), bend = bend, curvature = abs(bend), confidence = 0f,
            routeEnding = ending, quality = quality, missingForMs = missing,
        )
    }
}
