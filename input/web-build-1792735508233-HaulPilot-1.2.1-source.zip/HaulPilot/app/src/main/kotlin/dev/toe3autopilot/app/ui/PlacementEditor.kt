package dev.toe3autopilot.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.toe3autopilot.app.AutopilotRuntime
import dev.toe3autopilot.core.Point
import dev.toe3autopilot.core.calibration.CalibRole
import dev.toe3autopilot.core.calibration.DetectionStatus
import dev.toe3autopilot.core.calibration.GuidedSetup
import dev.toe3autopilot.core.calibration.TapSnap
import dev.toe3autopilot.core.geometry.BoxEditing
import dev.toe3autopilot.core.geometry.BoxHandle
import dev.toe3autopilot.core.geometry.EditorTransform
import dev.toe3autopilot.core.geometry.FitTransform
import dev.toe3autopilot.core.geometry.Vec2
import dev.toe3autopilot.core.geometry.ZoomPan
import dev.toe3autopilot.core.setup.DraftEdits
import dev.toe3autopilot.core.setup.DraftValidator
import dev.toe3autopilot.core.setup.SetupDraft
import dev.toe3autopilot.core.vision.Frame
import dev.toe3autopilot.core.vision.Roi
import kotlin.math.hypot

/**
 * Full-screen placement editor on the chosen driving picture.
 *
 *  - Tap: puts the crosshair there. One-finger drag: moves the crosshair relative to the finger (like a trackpad), so the
 *    finger never covers the spot; a loupe shows the real pixels under it. Arrow buttons move it one picture pixel.
 *  - Two fingers: zoom and move the picture (also the + / − / fit buttons, for people who cannot pinch).
 *  - Boxes (minimap, screen marker): drag a corner to resize, inside to move, elsewhere to draw a new box.
 *  - Nothing is written until Confirm; every confirmed change can be undone.
 *
 * The picture and all markers are drawn through one [EditorTransform] and touches are read back through its inverse,
 * so what you see is exactly what is stored.
 */
@Composable
fun PlacementEditor(req: EditorRequest, onClose: () -> Unit, onSwitch: (EditorRequest) -> Unit) {
    val state by AutopilotRuntime.setup.state.collectAsStateWithLifecycle()
    val frame = state.selectedFrame?.frame
    val draft = state.draft
    var message by remember(req) { mutableStateOf<String?>(null) }

    Box(
        Modifier
            .fillMaxSize()
            .background(Hp.Bg)
            // Swallows touches that no child handled, so nothing behind the editor reacts.
            .pointerInput(Unit) { awaitEachGesture { awaitFirstDown(requireUnconsumed = false) } },
    ) {
        Column(Modifier.fillMaxSize()) {
            EditorTopBar(req, state.canUndo, state.canRedo, onClose)
            EmergencyBar()
            if (frame == null) {
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    EmptyState(
                        Glyph.IMAGE, "No driving picture yet",
                        "Choose the picture that shows the normal driving view (Smart Setup, step 3) before placing anything.",
                        "Close", onClose,
                    )
                }
            } else {
                EditorBody(req, frame, draft, state.hudBoxes, message, { message = it }, onSwitch)
            }
        }
    }
}

@Composable
private fun EditorTopBar(req: EditorRequest, canUndo: Boolean, canRedo: Boolean, onClose: () -> Unit) {
    BarSurface {
        Row(
            Modifier.windowInsetsPadding(WindowInsets.statusBars).heightIn(min = 56.dp).padding(horizontal = Sp.xs),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconAction(Glyph.CLOSE, "Close the editor", onClose)
            Column(Modifier.weight(1f).padding(horizontal = Sp.xs)) {
                Text(editorTitle(req), style = MaterialTheme.typography.titleMedium, color = Hp.Text, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("Changes are saved to the setup when you confirm", style = MaterialTheme.typography.bodySmall, color = Hp.TextMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            IconAction(Glyph.UNDO, "Undo", { AutopilotRuntime.setup.undo() }, enabled = canUndo)
            IconAction(Glyph.REDO, "Redo", { AutopilotRuntime.setup.redo() }, enabled = canRedo)
        }
    }
}

private fun editorTitle(req: EditorRequest): String = when (req.mode) {
    EditorMode.CONTROL -> "Place: ${req.role?.label ?: "control"}"
    EditorMode.MINIMAP_BOX -> "Mark the minimap"
    EditorMode.ROUTE_COLOR -> "Pick the route colour"
    EditorMode.TRUCK -> "Mark your truck on the minimap"
    EditorMode.DESTINATION -> "Pick the destination marker"
    EditorMode.MARKER -> "Mark a steady dashboard part"
}

private val pointModes = setOf(EditorMode.CONTROL, EditorMode.ROUTE_COLOR, EditorMode.TRUCK, EditorMode.DESTINATION)

@Composable
private fun EditorBody(
    req: EditorRequest,
    frame: Frame,
    draft: SetupDraft,
    hudBoxes: List<Roi>,
    message: String?,
    setMessage: (String?) -> Unit,
    onSwitch: (EditorRequest) -> Unit,
) {
    val img = rememberImage(frame)
    val measurer = rememberTextMeasurer()
    val density = LocalDensity.current
    var viewSize by remember { mutableStateOf(IntSize.Zero) }
    var zoom by remember(frame) { mutableStateOf(ZoomPan.NONE) }
    var cross by remember(req, frame) { mutableStateOf<Vec2?>(null) }
    var moved by remember(req, frame) { mutableStateOf(false) }
    var box by remember(req, frame) { mutableStateOf<Roi?>(null) }
    var touching by remember { mutableStateOf(false) }

    // What is stored for this item right now; re-syncs after confirm, undo and redo.
    val stored: Any? = when (req.mode) {
        EditorMode.CONTROL -> draft.controls[req.role]
        EditorMode.TRUCK -> draft.minimap.truck
        EditorMode.ROUTE_COLOR -> draft.minimap.routeColor
        EditorMode.DESTINATION -> draft.minimap.destinationColor
        EditorMode.MINIMAP_BOX -> draft.minimap.box
        EditorMode.MARKER -> draft.marker
    }
    LaunchedEffect(req, frame, stored) {
        moved = false
        when (req.mode) {
            EditorMode.CONTROL -> {
                val c = draft.controls[req.role]
                cross = if (c != null && c.status != DetectionStatus.NONE && c.status != DetectionStatus.REJECTED) Vec2(c.x, c.y) else null
            }
            EditorMode.TRUCK -> cross = draft.minimap.truck?.let { Vec2(it.x, it.y) }
            EditorMode.ROUTE_COLOR, EditorMode.DESTINATION -> {}
            EditorMode.MINIMAP_BOX -> box = draft.minimap.box
            EditorMode.MARKER -> box = draft.marker
        }
    }

    fun transform(): EditorTransform? {
        if (viewSize.width <= 0 || viewSize.height <= 0) return null
        return EditorTransform(FitTransform(frame.width.toFloat(), frame.height.toFloat(), viewSize.width.toFloat(), viewSize.height.toFloat()), zoom)
    }

    fun zoomBy(factor: Float, focus: Offset? = null) {
        val t = transform() ?: return
        val f = focus ?: cross?.let { val p = t.toScreen(it.x, it.y); Offset(p.x, p.y) } ?: Offset(viewSize.width / 2f, viewSize.height / 2f)
        zoom = zoom.transformed(factor, f.x, f.y, 0f, 0f).clampedTo(viewSize.width.toFloat(), viewSize.height.toFloat(), t.fit.imageRect)
    }

    val latestMode = rememberUpdatedState(req.mode)
    val handleRadiusPx = with(density) { 28.dp.toPx() }

    Column(Modifier.fillMaxSize()) {
        Box(Modifier.weight(1f).fillMaxWidth()) {
            Canvas(
                Modifier
                    .fillMaxSize()
                    .clipToBounds()
                    .onSizeChanged { viewSize = it }
                    .semantics { contentDescription = canvasDescription(req, cross, box) }
                    .pointerInput(req, frame) {
                        awaitEachGesture {
                            val down = awaitFirstDown(requireUnconsumed = false)
                            touching = true
                            try {
                                var multi = false
                                var dragging = false
                                var travelled = 0f
                                var grab: BoxHandle? = null
                                var anchor: Vec2? = null
                                val mode = latestMode.value
                                while (true) {
                                    val ev = awaitPointerEvent()
                                    val pressed = ev.changes.filter { it.pressed }
                                    if (pressed.isEmpty()) break
                                    val t = transform() ?: continue
                                    if (pressed.size >= 2) {
                                        multi = true
                                        val c = ev.calculateCentroid(useCurrent = true)
                                        val pan = ev.calculatePan()
                                        zoom = zoom.transformed(ev.calculateZoom(), c.x, c.y, pan.x, pan.y)
                                            .clampedTo(viewSize.width.toFloat(), viewSize.height.toFloat(), t.fit.imageRect)
                                        ev.changes.forEach { it.consume() }
                                        continue
                                    }
                                    if (multi) continue // after a pinch, the remaining finger does nothing until all are lifted
                                    val ch = pressed[0]
                                    val d = ch.position - ch.previousPosition
                                    travelled += hypot(d.x, d.y)
                                    if (!dragging && travelled > viewConfiguration.touchSlop) {
                                        dragging = true
                                        if (mode !in pointModes) {
                                            grab = box?.let { BoxEditing.hitTest(t, it, down.position.x, down.position.y, handleRadiusPx) }
                                            if (grab == null) anchor = t.toNormalizedClamped(down.position.x, down.position.y)
                                        } else if (cross == null) {
                                            cross = t.toNormalizedClamped(down.position.x, down.position.y)
                                        }
                                    }
                                    if (!dragging) continue
                                    ch.consume()
                                    val unit = t.normalizedSizeOf(1f)
                                    if (mode in pointModes) {
                                        val c0 = cross ?: continue
                                        cross = Vec2((c0.x + d.x * unit.x).coerceIn(0f, 1f), (c0.y + d.y * unit.y).coerceIn(0f, 1f))
                                        moved = true
                                    } else {
                                        val p = t.toNormalizedClamped(ch.position.x, ch.position.y)
                                        val b = box
                                        box = when {
                                            grab == BoxHandle.MOVE && b != null -> BoxEditing.move(b, d.x * unit.x, d.y * unit.y)
                                            grab != null && b != null -> BoxEditing.resize(b, grab!!, p.x, p.y)
                                            else -> anchor?.let { BoxEditing.fromCorners(it.x, it.y, p.x, p.y) } ?: b
                                        }
                                        moved = true
                                    }
                                }
                                if (!multi && !dragging) {
                                    val t = transform()
                                    val p = t?.toNormalized(down.position.x, down.position.y)
                                    if (p != null) {
                                        if (mode in pointModes) {
                                            cross = p
                                            moved = true
                                        } else {
                                            val b = box
                                            box = if (b == null) defaultBox(mode, p, frame) else BoxEditing.move(b, p.x - (b.left + b.right) / 2f, p.y - (b.top + b.bottom) / 2f)
                                            moved = true
                                        }
                                    }
                                }
                            } finally {
                                touching = false
                            }
                        }
                    },
            ) {
                val t = transform() ?: return@Canvas
                drawPicture(img, frame.width, frame.height, t)
                val editingRole = if (req.mode == EditorMode.CONTROL) req.role else null
                drawDraft(
                    t, draft, measurer, highlight = null,
                    showMinimap = req.mode != EditorMode.MINIMAP_BOX,
                    showMarker = req.mode != EditorMode.MARKER,
                    skipRole = editingRole,
                )
                // The stored position of the control being edited, faint, so a move is visible against it.
                if (editingRole != null) draft.controls[editingRole]?.let { c ->
                    if (c.status != DetectionStatus.NONE && c.status != DetectionStatus.REJECTED) {
                        c.box?.let { drawRoi(t, it, Hp.Warning.copy(alpha = 0.6f), 1.5f * density.density, dashed = true) }
                        if (moved) {
                            val p = t.toScreen(c.x, c.y)
                            drawCircle(Hp.TextMuted, 6f * density.density, Offset(p.x, p.y), style = Stroke(1.5f * density.density))
                        }
                    }
                }
                if (req.mode in pointModes) cross?.let { drawCrosshair(t, it, measurer, crossLabel(req)) }
                if (req.mode !in pointModes) box?.let { drawEditableBox(t, it) }
            }
            // Loupe: the real pixels under the crosshair while a finger is down.
            val c = cross
            if (touching && c != null && req.mode in pointModes) {
                val t = transform()
                if (t != null) {
                    val onLeft = t.toScreen(c.x, c.y).x > viewSize.width / 2f
                    Loupe(img, frame, t, c, Modifier.align(if (onLeft) Alignment.TopStart else Alignment.TopEnd).padding(Sp.m))
                }
            }
            Column(Modifier.align(Alignment.BottomEnd).padding(Sp.s), verticalArrangement = Arrangement.spacedBy(Sp.xs)) {
                RoundTool(Glyph.PLUS, "Zoom in") { zoomBy(1.6f) }
                RoundTool(Glyph.DOT, "Zoom out") { zoomBy(1f / 1.6f) }
                RoundTool(Glyph.FIT, "Show the whole picture") { zoom = ZoomPan.NONE }
            }
        }
        EditorPanel(
            req, frame, draft, hudBoxes, cross, moved, box, message, setMessage, onSwitch,
            nudge = { dx, dy ->
                val cc = cross ?: Vec2(0.5f, 0.5f)
                cross = Vec2((cc.x + dx / frame.width).coerceIn(0f, 1f), (cc.y + dy / frame.height).coerceIn(0f, 1f))
                moved = true
            },
            resetLocal = {
                cross = null
                box = null
                moved = false
            },
        )
    }
}

private fun crossLabel(req: EditorRequest): String = when (req.mode) {
    EditorMode.CONTROL -> req.role?.let { roleShort(it) } ?: ""
    EditorMode.ROUTE_COLOR -> "Route colour"
    EditorMode.TRUCK -> "Your truck"
    EditorMode.DESTINATION -> "Destination"
    else -> ""
}

private fun canvasDescription(req: EditorRequest, cross: Vec2?, box: Roi?): String {
    val what = editorTitle(req)
    return when {
        req.mode in pointModes && cross != null -> "$what. Crosshair at ${pct(cross.x)} from the left, ${pct(cross.y)} from the top. Use the arrow buttons to move it."
        req.mode in pointModes -> "$what. Tap the picture to place the crosshair."
        box != null -> "$what. Box from ${pct(box.left)} to ${pct(box.right)} across and ${pct(box.top)} to ${pct(box.bottom)} down."
        else -> "$what. Drag on the picture to draw a box."
    }
}

private fun defaultBox(mode: EditorMode, p: Vec2, frame: Frame): Roi {
    val aspect = frame.width.toFloat() / frame.height
    // Roughly square on screen: height h in picture heights is h / aspect in picture widths.
    val h = if (mode == EditorMode.MINIMAP_BOX) 0.36f else 0.12f
    return BoxEditing.around(p.x, p.y, h / aspect, h)
}

private fun DrawScope.drawCrosshair(t: EditorTransform, c: Vec2, measurer: TextMeasurer, label: String) {
    val p = t.toScreen(c.x, c.y)
    val o = Offset(p.x, p.y)
    val dp = density
    val arm = 22f * dp
    val gap = 5f * dp
    val shadow = Color(0xCC0B0F15)
    for ((col, w) in listOf(shadow to 4.5f * dp, Hp.Accent to 2f * dp)) {
        drawLine(col, Offset(o.x - arm, o.y), Offset(o.x - gap, o.y), w)
        drawLine(col, Offset(o.x + gap, o.y), Offset(o.x + arm, o.y), w)
        drawLine(col, Offset(o.x, o.y - arm), Offset(o.x, o.y - gap), w)
        drawLine(col, Offset(o.x, o.y + gap), Offset(o.x, o.y + arm), w)
        drawCircle(col, arm * 0.62f, o, style = Stroke(w * 0.7f))
    }
    drawCircle(Hp.Accent, 1.6f * dp, o)
    if (label.isNotEmpty()) drawLabel(measurer, label, Offset(o.x, o.y - arm + 4f * dp), Hp.Accent)
}

private fun DrawScope.drawEditableBox(t: EditorTransform, b: Roi) {
    val dp = density
    val a = t.toScreen(b.left, b.top)
    val z = t.toScreen(b.right, b.bottom)
    // Dim everything outside the box so the area is obvious.
    val outside = Path().apply {
        fillType = androidx.compose.ui.graphics.PathFillType.EvenOdd
        addRect(androidx.compose.ui.geometry.Rect(0f, 0f, size.width, size.height))
        addRect(androidx.compose.ui.geometry.Rect(a.x, a.y, z.x, z.y))
    }
    drawPath(outside, Color(0x800B0F15))
    drawRect(Hp.Accent, Offset(a.x, a.y), Size(z.x - a.x, z.y - a.y), style = Stroke(2.2f * dp))
    for (p in listOf(Offset(a.x, a.y), Offset(z.x, a.y), Offset(a.x, z.y), Offset(z.x, z.y))) {
        drawCircle(Color(0xCC0B0F15), 10f * dp, p)
        drawCircle(Hp.Accent, 7f * dp, p)
    }
}

@Composable
private fun Loupe(img: ImageBitmap, frame: Frame, t: EditorTransform, c: Vec2, modifier: Modifier) {
    Canvas(
        modifier
            .size(136.dp)
            .clip(CircleShape)
            .background(Hp.Raised)
            .border(2.dp, Hp.Accent, CircleShape),
    ) {
        val circle = Path().apply { addOval(androidx.compose.ui.geometry.Rect(0f, 0f, size.width, size.height)) }
        clipPath(circle) {
            // About 4x the current on-screen size, and at least 6 screen pixels per picture pixel.
            val s = maxOf(t.fit.scale * t.zoom.scale * 4f, 6f * density)
            val cx = size.width / 2f
            val cy = size.height / 2f
            withPictureScale(img, frame, cx - c.x * frame.width * s, cy - c.y * frame.height * s, s)
            drawLine(Color(0xCC0B0F15), Offset(cx - 18f * density, cy), Offset(cx + 18f * density, cy), 4f * density)
            drawLine(Color(0xCC0B0F15), Offset(cx, cy - 18f * density), Offset(cx, cy + 18f * density), 4f * density)
            drawLine(Hp.Accent, Offset(cx - 18f * density, cy), Offset(cx + 18f * density, cy), 1.6f * density)
            drawLine(Hp.Accent, Offset(cx, cy - 18f * density), Offset(cx, cy + 18f * density), 1.6f * density)
        }
    }
}

private fun DrawScope.withPictureScale(img: ImageBitmap, frame: Frame, left: Float, top: Float, s: Float) {
    val fit = FitTransform(frame.width.toFloat(), frame.height.toFloat(), frame.width.toFloat(), frame.height.toFloat())
    // A transform whose NDS origin lands at (left, top) with s screen pixels per picture pixel.
    val zoom = ZoomPan(s, left, top)
    drawPicture(img, frame.width, frame.height, EditorTransform(fit, zoom))
}

@Composable
private fun RoundTool(glyph: Glyph, description: String, onClick: () -> Unit) {
    Box(
        Modifier
            .size(Sp.touch)
            .clip(CircleShape)
            .background(Hp.Surface.copy(alpha = 0.92f))
            .border(1.dp, Hp.Border, CircleShape)
            .clickable(role = Role.Button, onClick = onClick)
            .semantics { contentDescription = description },
        contentAlignment = Alignment.Center,
    ) {
        if (glyph == Glyph.DOT) {
            // "Zoom out": a minus sign drawn to match the plus glyph.
            Canvas(Modifier.size(20.dp)) { drawLine(Hp.Text, Offset(size.width * 0.18f, size.height / 2f), Offset(size.width * 0.82f, size.height / 2f), 1.6f * density) }
        } else {
            HpIcon(glyph, tint = Hp.Text, size = 20.dp)
        }
    }
}

/** Bottom panel: instructions, readout, nudge pad, control switcher and the confirm / reset actions. */
@Composable
private fun EditorPanel(
    req: EditorRequest,
    frame: Frame,
    draft: SetupDraft,
    hudBoxes: List<Roi>,
    cross: Vec2?,
    moved: Boolean,
    box: Roi?,
    message: String?,
    setMessage: (String?) -> Unit,
    onSwitch: (EditorRequest) -> Unit,
    nudge: (Float, Float) -> Unit,
    resetLocal: () -> Unit,
) {
    val setup = AutopilotRuntime.setup
    fun commit(done: String, edit: (SetupDraft) -> SetupDraft): Boolean {
        val ok = setup.edit(edit)
        setMessage(if (ok) done else "Not changed: wait until the analysis has finished.")
        return ok
    }
    BarSurface {
        Column(
            Modifier.windowInsetsPadding(WindowInsets.navigationBars).padding(horizontal = Sp.l, vertical = Sp.m),
            verticalArrangement = Arrangement.spacedBy(Sp.s),
        ) {
            if (req.mode == EditorMode.CONTROL) RoleSwitcher(draft, req.role, onSwitch)

            SmallText(instructions(req), color = Hp.TextSecondary)

            if (req.mode in pointModes) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(Sp.xs)) {
                    Column(Modifier.weight(1f)) {
                        if (cross != null) {
                            Text(
                                "x " + String.format(java.util.Locale.US, "%.3f", cross.x) + " · y " + String.format(java.util.Locale.US, "%.3f", cross.y),
                                style = MaterialTheme.typography.labelLarge, color = Hp.Text,
                            )
                            SmallText("Picture pixel ${(cross.x * frame.width).toInt()}, ${(cross.y * frame.height).toInt()} of ${frame.width}×${frame.height}")
                        } else {
                            SmallText("Nothing placed yet")
                        }
                    }
                    IconAction(Glyph.ARROW_LEFT, "Move left one pixel", { nudge(-1f, 0f) })
                    IconAction(Glyph.ARROW_UP, "Move up one pixel", { nudge(0f, -1f) })
                    IconAction(Glyph.ARROW_DOWN, "Move down one pixel", { nudge(0f, 1f) })
                    IconAction(Glyph.ARROW_RIGHT, "Move right one pixel", { nudge(1f, 0f) })
                }
            }

            when (req.mode) {
                EditorMode.CONTROL -> ControlActions(req.role ?: CalibRole.ACCELERATOR, frame, draft, hudBoxes, cross, moved, onSwitch, resetLocal, ::commit)
                EditorMode.ROUTE_COLOR -> RouteColorActions(frame, draft, cross, ::commit)
                EditorMode.TRUCK -> TruckActions(draft, cross, ::commit)
                EditorMode.DESTINATION -> DestinationActions(frame, draft, cross, ::commit)
                EditorMode.MINIMAP_BOX -> MinimapActions(draft, box, moved, resetLocal, ::commit)
                EditorMode.MARKER -> MarkerActions(draft, box, resetLocal, ::commit)
            }
            if (message != null) SmallText(message, color = Hp.Accent)
        }
    }
}

private fun instructions(req: EditorRequest): String = when (req.mode) {
    EditorMode.CONTROL -> "Tap the middle of the ${req.role?.label?.lowercase() ?: "control"}, then drag anywhere to fine-tune. Two fingers zoom and move the picture."
    EditorMode.ROUTE_COLOR -> "Zoom in on the minimap and put the crosshair exactly on the coloured route line."
    EditorMode.TRUCK -> "Put the crosshair on your truck's arrow on the minimap (it should be inside the minimap box)."
    EditorMode.DESTINATION -> "Optional. Zoom in and put the crosshair on the destination icon on the minimap. It must have a different colour from the route line."
    EditorMode.MINIMAP_BOX -> "Drag to draw a box around the whole minimap. Drag a corner to resize it, the inside to move it."
    EditorMode.MARKER -> "Box a small part of the dashboard that never changes while driving (not a pedal or button, and not the minimap)."
}

@Composable
private fun RoleSwitcher(draft: SetupDraft, current: CalibRole?, onSwitch: (EditorRequest) -> Unit) {
    val roles = editorRoles(draft)
    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
        roles.forEach { r ->
            val c = draft.controls[r]
            val (dot, word) = when {
                c == null || c.status == DetectionStatus.NONE -> Hp.TextMuted to "missing"
                c.status.usable -> Hp.Success to "confirmed"
                c.status == DetectionStatus.NEEDS_CONFIRMATION -> Hp.Warning to "candidate"
                else -> Hp.Danger to "rejected"
            }
            val selected = r == current
            Row(
                Modifier
                    .clip(RoundedCornerShape(50))
                    .background(if (selected) Hp.Accent.copy(alpha = 0.16f) else Hp.Raised)
                    .border(1.dp, if (selected) Hp.Accent else Hp.Border, RoundedCornerShape(50))
                    .clickable(role = Role.Tab) { onSwitch(EditorRequest(EditorMode.CONTROL, r)) }
                    .heightIn(min = 40.dp)
                    .padding(horizontal = Sp.m)
                    .semantics { contentDescription = "${r.label}, $word" + if (selected) ", selected" else "" },
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Box(Modifier.size(8.dp).clip(CircleShape).background(dot))
                Text(roleShort(r), style = MaterialTheme.typography.labelLarge, color = if (selected) Hp.Text else Hp.TextSecondary)
            }
        }
    }
}

/** Roles offered in the editor: before a steering style is chosen, both the wheel and the buttons are offered. */
fun editorRoles(d: SetupDraft): List<CalibRole> = if (d.steering == null) {
    listOf(CalibRole.ACCELERATOR, CalibRole.BRAKE, CalibRole.STEER_WHEEL, CalibRole.STEER_LEFT, CalibRole.STEER_RIGHT, CalibRole.GEAR_REVERSE)
} else {
    setupRoles(d.steering)
}

@Composable
private fun ControlActions(
    role: CalibRole,
    frame: Frame,
    draft: SetupDraft,
    hudBoxes: List<Roi>,
    cross: Vec2?,
    moved: Boolean,
    onSwitch: (EditorRequest) -> Unit,
    resetLocal: () -> Unit,
    commit: (String, (SetupDraft) -> SetupDraft) -> Boolean,
) {
    val c = draft.controls[role]
    val isCandidate = c?.status == DetectionStatus.NEEDS_CONFIRMATION
    // Same-spot check before confirming, with the same rule the validator uses.
    val clash = cross?.let { p ->
        draft.controls.values.firstOrNull { o ->
            o.role != role && o.status.usable && hypot(o.x - p.x, o.y - p.y) < DraftValidator.MIN_SEPARATION &&
                !(setOf(o.role, role).contains(CalibRole.STEER_WHEEL) && setOf(o.role, role).any { it == CalibRole.STEER_LEFT || it == CalibRole.STEER_RIGHT })
        }
    }
    if (isCandidate && !moved) {
        SmallText("Candidate (${pct(c!!.confidence)} evidence, from the picture's shapes): ${c.evidence.take(2).joinToString("; ")}", color = Hp.Warning, maxLines = 3)
    }
    if (clash != null) SmallText("This is on the same spot as ${clash.role.label}. Move one of them.", color = Hp.Danger)
    if (role == CalibRole.STEER_WHEEL && c != null && c.status.usable) {
        val r = draft.steerRadius ?: DraftEdits.DEFAULT_STEER_RADIUS
        SliderRow("Steering range", "± ${pct(r)} of the width", r, 0.03f..0.3f, subtitle = "How far HaulPilot drags sideways from the wheel's centre for full lock.") { v ->
            AutopilotRuntime.setup.edit { DraftEdits.setSteerRadius(it, v) }
        }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(Sp.s), verticalAlignment = Alignment.CenterVertically) {
        HpButton(
            if (c == null || c.status == DetectionStatus.NONE) "Clear" else "Reset",
            {
                if (c != null && c.status != DetectionStatus.NONE) commit("${role.label} reset to missing. Undo brings it back.") { DraftEdits.reset(it, role) }
                resetLocal()
            },
            kind = BtnKind.SECONDARY, glyph = Glyph.REFRESH,
        )
        if (isCandidate && !moved) {
            HpButton("Reject", { commit("${role.label} candidate rejected.") { DraftEdits.reject(it, role) } }, kind = BtnKind.GHOST)
        }
        HpButton(
            if (isCandidate && !moved) "Confirm candidate" else "Confirm position",
            {
                val p = cross ?: return@HpButton
                val ok = if (isCandidate && !moved) {
                    commit("${role.label} confirmed.") { DraftEdits.confirm(it, role) }
                } else {
                    val aspect = frame.width.toFloat() / frame.height
                    val snapped = TapSnap.boxFor(hudBoxes, p.x, p.y, aspect)
                    commit("${role.label} placed.") { DraftEdits.place(it, role, p.x, p.y, snapped) }
                }
                if (ok) {
                    // Next control that still needs the person, so a full placement is a quick run through the chips.
                    val after = AutopilotRuntime.setup.state.value.draft
                    val next = editorRoles(after).firstOrNull { r -> r != role && r != CalibRole.GEAR_REVERSE && after.controls[r]?.status?.usable != true }
                    if (next != null) onSwitch(EditorRequest(EditorMode.CONTROL, next))
                }
            },
            Modifier.weight(1f), enabled = cross != null && clash == null, glyph = Glyph.CHECK,
        )
    }
    if (cross == null) SmallText("Confirm is available once the crosshair is on the picture.")
}

@Composable
private fun RouteColorActions(frame: Frame, draft: SetupDraft, cross: Vec2?, commit: (String, (SetupDraft) -> SetupDraft) -> Boolean) {
    val sample = cross?.let { GuidedSetup.colorAt(frame, it.x, it.y) }
    val problem = sample?.let { GuidedSetup.colourProblem(it) }
    val box = draft.minimap.box
    val outside = cross != null && box != null && !(cross.x in box.left..box.right && cross.y in box.top..box.bottom)
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(Sp.m)) {
        Swatch(sample?.let { Color(it.r, it.g, it.b) }, "Colour under the crosshair")
        Column(Modifier.weight(1f)) {
            Text(if (sample == null) "No colour picked yet" else "R ${sample.r} · G ${sample.g} · B ${sample.b}", style = MaterialTheme.typography.labelLarge, color = Hp.Text)
            draft.minimap.routeColor?.let { SmallText("Saved: R ${it.r} · G ${it.g} · B ${it.b}") }
        }
        Swatch(draft.minimap.routeColor?.let { Color(it.r, it.g, it.b) }, "Saved route colour")
    }
    if (problem != null) SmallText(problem, color = Hp.Warning)
    if (outside) SmallText("The crosshair is outside the minimap box. The route line is inside the minimap.", color = Hp.Warning)
    HpButton(
        "Use this colour", { if (sample != null) commit("Route colour saved.") { DraftEdits.setRouteColor(it, sample) } },
        Modifier.fillMaxWidth(), enabled = sample != null && problem == null, glyph = Glyph.CHECK,
    )
}

@Composable
private fun DestinationActions(frame: Frame, draft: SetupDraft, cross: Vec2?, commit: (String, (SetupDraft) -> SetupDraft) -> Boolean) {
    val mm = draft.minimap
    val sample = cross?.let { GuidedSetup.colorAt(frame, it.x, it.y, 50) }
    val box = mm.box
    val outside = cross != null && box != null && !(cross.x in box.left..box.right && cross.y in box.top..box.bottom)
    val problem = sample?.let { s ->
        GuidedSetup.colourProblem(s)
            ?: mm.routeColor?.takeIf { DraftValidator.colourDistance(s, it) < DraftValidator.SAME_COLOUR }?.let { "That is the route line's colour. Put the crosshair on the destination icon itself." }
    }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(Sp.m)) {
        Swatch(sample?.let { Color(it.r, it.g, it.b) }, "Colour under the crosshair")
        Column(Modifier.weight(1f)) {
            Text(if (sample == null) "No colour picked yet" else "R ${sample.r} · G ${sample.g} · B ${sample.b}", style = MaterialTheme.typography.labelLarge, color = Hp.Text)
            mm.destinationColor?.let { SmallText("Saved: R ${it.r} · G ${it.g} · B ${it.b}") }
        }
        Swatch(mm.destinationColor?.let { Color(it.r, it.g, it.b) }, "Saved destination colour")
    }
    if (box == null) SmallText("Mark the minimap first; the destination marker is looked for inside it.", color = Hp.Warning)
    if (problem != null) SmallText(problem, color = Hp.Warning)
    if (outside) SmallText("The crosshair is outside the minimap box.", color = Hp.Danger)
    Row(horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
        if (mm.destinationColor != null) {
            HpButton("Remove", { commit("Destination marker removed.") { DraftEdits.setDestinationColor(it, null) } }, kind = BtnKind.SECONDARY, glyph = Glyph.TRASH)
        }
        HpButton(
            "Use this colour", { if (sample != null) commit("Destination marker colour saved.") { DraftEdits.setDestinationColor(it, sample) } },
            Modifier.weight(1f), enabled = sample != null && problem == null && box != null && !outside, glyph = Glyph.CHECK,
        )
    }
}

@Composable
private fun TruckActions(draft: SetupDraft, cross: Vec2?, commit: (String, (SetupDraft) -> SetupDraft) -> Boolean) {
    val box = draft.minimap.box
    val outside = cross != null && box != null && !(cross.x in box.left..box.right && cross.y in box.top..box.bottom)
    if (box == null) SmallText("Mark the minimap first; the truck must be inside it.", color = Hp.Warning)
    if (outside) SmallText("That is outside the minimap box.", color = Hp.Danger)
    HpButton(
        "Confirm truck position", { if (cross != null) commit("Truck position saved.") { DraftEdits.setTruck(it, Point(cross.x, cross.y)) } },
        Modifier.fillMaxWidth(), enabled = cross != null && box != null && !outside, glyph = Glyph.CHECK,
    )
}

@Composable
private fun MinimapActions(draft: SetupDraft, box: Roi?, moved: Boolean, resetLocal: () -> Unit, commit: (String, (SetupDraft) -> SetupDraft) -> Boolean) {
    val mm = draft.minimap
    val suggested = mm.box != null && !mm.boxConfirmed && BoxEditing.same(mm.box, box) && !moved
    if (suggested) SmallText("Suggested by the analysis: ${mm.note ?: "an area whose content keeps changing, with vivid colours"}. Check it covers the whole map.", color = Hp.Warning, maxLines = 3)
    box?.let { b ->
        val h = b.bottom - b.top
        val w = b.right - b.left
        if (h < 0.05f) SmallText("This box is too small to read the route.", color = Hp.Danger)
        if (h > 0.8f || w > 0.8f) SmallText("This box covers most of the screen; it should cover only the map.", color = Hp.Danger)
    }
    Row(horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
        HpButton("Clear", { resetLocal() }, kind = BtnKind.SECONDARY, glyph = Glyph.REFRESH, enabled = box != null)
        HpButton(
            if (suggested) "Confirm suggested box" else "Confirm minimap box",
            {
                val b = box ?: return@HpButton
                if (suggested) commit("Minimap box confirmed.") { DraftEdits.confirmMinimapBox(it) } else commit("Minimap box saved.") { DraftEdits.setMinimapBox(it, b) }
            },
            Modifier.weight(1f), enabled = box != null && (box.bottom - box.top) >= 0.05f && (box.bottom - box.top) <= 0.8f && (box.right - box.left) <= 0.8f, glyph = Glyph.CHECK,
        )
    }
}

@Composable
private fun MarkerActions(draft: SetupDraft, box: Roi?, resetLocal: () -> Unit, commit: (String, (SetupDraft) -> SetupDraft) -> Boolean) {
    val overControl = box?.let { b -> draft.controls.values.firstOrNull { it.status.usable && it.x in b.left..b.right && it.y in b.top..b.bottom } }
    val overMap = box != null && draft.minimap.box?.let { m -> box.left < m.right && m.left < box.right && box.top < m.bottom && m.top < box.bottom } == true
    if (overControl != null) SmallText("This includes ${overControl.role.label}. Controls can change their look when pressed; choose a part that never changes.", color = Hp.Warning)
    if (overMap) SmallText("This overlaps the minimap, whose content keeps changing.", color = Hp.Warning)
    Row(horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
        HpButton("Clear", { resetLocal() }, kind = BtnKind.SECONDARY, glyph = Glyph.REFRESH, enabled = box != null)
        HpButton(
            "Use as screen marker", { val b = box ?: return@HpButton; commit("Screen marker saved.") { DraftEdits.setMarker(it, b) } },
            Modifier.weight(1f), enabled = box != null, glyph = Glyph.CHECK,
        )
    }
}

@Composable
private fun Swatch(c: Color?, description: String) {
    Box(
        Modifier
            .size(36.dp)
            .clip(RoundedCornerShape(Sp.radiusS))
            .background(c ?: Hp.Raised)
            .border(1.dp, Hp.Border, RoundedCornerShape(Sp.radiusS))
            .semantics { contentDescription = description },
    )
}
