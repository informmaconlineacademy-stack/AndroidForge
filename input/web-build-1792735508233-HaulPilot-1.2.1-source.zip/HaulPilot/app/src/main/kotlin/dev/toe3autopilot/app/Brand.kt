package dev.toe3autopilot.app

/**
 * Product name, creator credit and the brand colours, in one place. Plain ARGB ints so both the Compose screens and the
 * View-based floating controls (which run in the accessibility service) use exactly the same values.
 *
 * The internal Kotlin package stays `dev.toe3autopilot` on purpose: renaming packages touches every file and the manifest for
 * no user-visible gain. Only user-facing text and the application id carry the product name (HaulPilot).
 *
 * Palette: deep charcoal-navy surfaces, warm amber-orange for primary actions only, a restrained cyan for selection and
 * secondary emphasis, and status colours that only ever carry meaning. Contrast ratios are against [BG] unless noted.
 */
object Brand {
    const val APP_NAME = "HaulPilot"
    const val TAGLINE = "Drive smarter. Deliver better."
    const val CREDIT = "Made by Praju (praju_12)"

    /** Support or documentation page shown on the About screen. Null until a real one exists; no link is invented. */
    val SUPPORT_URL: String? = null

    // Surfaces, darkest to lightest.
    const val BG = 0xFF0B0F15.toInt()
    const val SURFACE = 0xFF121821.toInt()
    const val RAISED = 0xFF19212C.toInt()
    const val RAISED_HIGH = 0xFF212B38.toInt()
    const val BORDER = 0xFF2A3544.toInt()
    const val BORDER_SUBTLE = 0xFF1F2834.toInt()

    // Text: primary ~16:1, secondary ~8.6:1, muted ~4.9:1.
    const val TEXT_PRIMARY = 0xFFEEF2F7.toInt()
    const val TEXT_SECONDARY = 0xFFA9B4C2.toInt()
    const val TEXT_MUTED = 0xFF7E8A99.toInt()

    /** Warm amber-orange: primary actions only (Start, Confirm, Save). Dark text on it (~9:1). */
    const val PRIMARY = 0xFFFF9A1F.toInt()
    const val ON_PRIMARY = 0xFF1C1000.toInt()

    /** Restrained cyan: selection, the active setup step, markers being edited. */
    const val ACCENT = 0xFF46C2D8.toInt()
    const val ON_ACCENT = 0xFF03161A.toInt()

    const val SUCCESS = 0xFF3FD68E.toInt()
    /** Yellow, kept clearly apart from the orange primary so "attention" never looks like an action. */
    const val WARNING = 0xFFF5C84C.toInt()
    const val DANGER = 0xFFFF5D5F.toInt()
    /** Emergency Stop fill; white text on it is ~5.3:1. */
    const val DANGER_FILL = 0xFFD12F35.toInt()
    const val INFO = 0xFF6FAEFF.toInt()
}
