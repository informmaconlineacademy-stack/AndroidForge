package dev.toe3autopilot.core.vision

import kotlin.math.abs

/** A colour to look for: each RGB channel may differ from the target by at most [tolerance]. */
data class ColorTarget(val r: Int, val g: Int, val b: Int, val tolerance: Int = 40) {
    fun matches(argb: Int): Boolean =
        abs(((argb shr 16) and 0xFF) - r) <= tolerance &&
            abs(((argb shr 8) and 0xFF) - g) <= tolerance &&
            abs((argb and 0xFF) - b) <= tolerance

    fun format(): String = "$r,$g,$b,$tolerance"

    companion object {
        fun parse(s: String): ColorTarget {
            val v = s.split(",").map { it.trim().toIntOrNull() ?: throw IllegalArgumentException("Not an integer in '$s'") }
            require(v.size == 4) { "Colour must be r,g,b,tolerance but got '$s'" }
            require(v.all { it in 0..255 }) { "Colour values must be 0..255 in '$s'" }
            return ColorTarget(v[0], v[1], v[2], v[3])
        }
    }
}

/** Result of a colour search. cx/cy are normalised frame coordinates of the centroid (only meaningful if [found]). */
data class Blob(val count: Int, val fraction: Float, val cx: Float, val cy: Float) {
    val found: Boolean get() = count > 0
}

object ColorMask {
    fun measure(frame: Frame, roi: Roi, target: ColorTarget, step: Int = 1): Blob {
        val rect = roi.toRect(frame.width, frame.height)
        val s = maxOf(1, step)
        var count = 0
        var total = 0
        var sx = 0L
        var sy = 0L
        var y = rect.y0
        while (y < rect.y1) {
            var x = rect.x0
            while (x < rect.x1) {
                total++
                if (target.matches(frame.argb[y * frame.width + x])) {
                    count++
                    sx += x
                    sy += y
                }
                x += s
            }
            y += s
        }
        if (count == 0) return Blob(0, 0f, 0f, 0f)
        return Blob(
            count = count,
            fraction = count.toFloat() / total,
            cx = (sx.toFloat() / count + 0.5f) / frame.width,
            cy = (sy.toFloat() / count + 0.5f) / frame.height,
        )
    }
}

/**
 * Mean absolute luminance change inside [roi] between consecutive frames, 0..1.
 * Used as a proxy for "is the truck / camera moving", for stuck detection and for confirming a stop.
 * It is a relative signal: on-screen animation outside the road view will also register.
 */
class MotionEstimator(private val roi: Roi, private val gridStep: Int = 4) {
    private var previous: IntArray? = null
    private var previousSize = 0

    fun reset() {
        previous = null
    }

    fun update(frame: Frame): Float {
        val rect = roi.toRect(frame.width, frame.height)
        val cols = (rect.width + gridStep - 1) / gridStep
        val rows = (rect.height + gridStep - 1) / gridStep
        val sample = IntArray(cols * rows)
        var i = 0
        var y = rect.y0
        while (y < rect.y1) {
            var x = rect.x0
            while (x < rect.x1) {
                val p = frame.argb[y * frame.width + x]
                sample[i++] = (77 * ((p shr 16) and 0xFF) + 150 * ((p shr 8) and 0xFF) + 29 * (p and 0xFF)) shr 8
                x += gridStep
            }
            y += gridStep
        }
        val prev = previous
        previous = sample
        if (prev == null || prev.size != sample.size) return 0f
        var sum = 0L
        for (k in sample.indices) sum += abs(sample[k] - prev[k])
        return sum.toFloat() / (sample.size * 255f)
    }
}
