package dev.toe3autopilot.core.setup

import dev.toe3autopilot.core.calibration.PictureEvidence
import dev.toe3autopilot.core.profile.ProfileEditing
import dev.toe3autopilot.core.vision.Frame
import dev.toe3autopilot.core.vision.GrayImage
import dev.toe3autopilot.core.vision.Roi
import dev.toe3autopilot.core.vision.TemplateMatcher
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * How each pixel of the driving picture behaved while the scenery moved: its average look and how much it changed.
 *
 * Why it exists: the "driving screen marker" and each control's look-alike picture used to be cut from ONE picture. For a
 * see-through control that patch contains the scenery that happened to be behind it, which is different a second later, so the
 * match score is dragged around by the scenery. With many driving pictures the patch is saved as the AVERAGE look of the
 * control (the scenery behind it averages out; the outline and symbol stay) together with a per-pixel WEIGHT, strong where the
 * pixel hardly ever changed and weak where it did (weight ~ 1 / (change^2 + noise^2), as in a weighted least-squares fit).
 * Matching is then a weighted normalised correlation (TemplateMatcher.allMasked): the steady outline decides, the scenery
 * barely counts, and an interior that is mostly scenery does not hide a missing outline.
 *
 * Only exists when there were enough pictures with moving scenery ([PictureEvidence.MIN_MOVING]); with one picture nothing
 * can be said about which pixels are steady, the patch is saved whole, and the profile says so.
 */
class StabilityMap(
    val width: Int,
    val height: Int,
    private val mean: FloatArray,
    private val std: FloatArray,
    private val ownUi: BooleanArray,
    /** Pictures with moving scenery this is based on. */
    val moving: Int,
    /** Typical change of the scenery (median over the picture). */
    val sceneStd: Float,
    /** A few of the moving pictures (grey), evenly spread: what the template is checked against to set its threshold. */
    private val kept: List<FloatArray> = emptyList(),
) {
    /** The AVERAGE look of [box] over the moving pictures (same pixel rectangle a patch cut with the same box has). */
    fun patch(box: Roi): GrayImage {
        val r = box.toRect(width, height)
        val out = IntArray(r.width * r.height)
        for (y in 0 until r.height) for (x in 0 until r.width) out[y * r.width + x] = mean[(r.y0 + y) * width + r.x0 + x].roundToInt().coerceIn(0, 255)
        return GrayImage(r.width, r.height, out)
    }

    /**
     * Per-pixel weights for [box] (255 = never changed ... 1 = changed like the scenery; 0 = HaulPilot's own button, which is
     * in every captured picture but is not part of the game).
     */
    fun maskFor(box: Roi): GrayImage {
        val r = box.toRect(width, height)
        val c = MIN_STEADY_STD * MIN_STEADY_STD
        val out = IntArray(r.width * r.height)
        for (y in 0 until r.height) for (x in 0 until r.width) {
            val i = (r.y0 + y) * width + r.x0 + x
            out[y * r.width + x] = if (ownUi[i]) 0 else maxOf(1, (255f * c / (std[i] * std[i] + c)).roundToInt())
        }
        return GrayImage(r.width, r.height, out)
    }

    /**
     * The score a live picture must reach to count as "this control / marker is there". The default stays unless the control
     * itself, on the collected driving pictures, only reaches a little more than that (a faint see-through control): then the
     * threshold follows it down, never below [MIN_ADAPTIVE_SCORE] (also the least the session accepts as recognition).
     */
    fun matchThreshold(box: Roi, default: Float): Float {
        val patch = patch(box)
        val w = maskFor(box)
        if (kept.size < 4 || !TemplateMatcher.maskUsable(patch, w)) return default
        val roi = ProfileEditing.searchRoi(box)
        val scores = kept.map { arr ->
            val g = GrayImage(width, height, IntArray(arr.size) { arr[it].roundToInt().coerceIn(0, 255) })
            TemplateMatcher.bestMasked(g, patch, w, roi)?.score ?: 0f
        }.sorted()
        val p10 = scores[(scores.size * 0.1f).toInt()]
        return (0.85f * p10).coerceIn(MIN_ADAPTIVE_SCORE, default)
    }

    /** Share of the box's pixels that stayed put (changed by less than [STEADY_FRACTION] of the scenery's own change). */
    fun steadyShare(box: Roi): Float {
        val r = box.toRect(width, height)
        val limit = maxOf(MIN_STEADY_STD, STEADY_FRACTION * sceneStd)
        var n = 0
        var k = 0
        for (y in r.y0 until r.y1) for (x in r.x0 until r.x1) {
            n++
            if (!ownUi[y * width + x] && std[y * width + x] <= limit) k++
        }
        return if (n == 0) 0f else k.toFloat() / n
    }

    /**
     * How well the box can recognise the screen by itself (0..1): the weighted structure of its average look (outline against
     * interior) relative to the weighted change of its pixels. A box that is mostly scenery (flat on average, changing a lot)
     * scores near 0, a crisp control near 1.
     */
    fun quality(box: Roi): Float {
        val r = box.toRect(width, height)
        if (r.width < 4 || r.height < 4) return 0f
        val patch = patch(box)
        val w = maskFor(box)
        if (!TemplateMatcher.maskUsable(patch, w)) return 0f
        var sw = 0.0
        var sm = 0.0
        for (i in patch.px.indices) {
            sw += w.px[i]
            sm += w.px[i].toDouble() * patch.px[i]
        }
        if (sw <= 0.0) return 0f
        val mu = sm / sw
        var sv = 0.0
        var sn = 0.0
        var k = 0
        for (y in 0 until r.height) for (x in 0 until r.width) {
            val i = y * r.width + x
            val wi = w.px[i].toDouble()
            val d = patch.px[i] - mu
            sv += wi * d * d
            val s = std[(r.y0 + y) * width + r.x0 + x]
            sn += wi * s * s
            k++
        }
        val structure = sqrt(sv / sw)
        val noise = sqrt(sn / sw).coerceAtLeast(MIN_STEADY_STD.toDouble())
        return min(1.0, (structure / noise) / SNR_FOR_FULL_QUALITY).toFloat()
    }

    companion object {
        /** A pixel counts as steady when it changed by less than this share of what the scenery changes. */
        const val STEADY_FRACTION = 0.35f

        /** Grey levels of noise that never count as change. */
        const val MIN_STEADY_STD = 3f

        const val MIN_ADAPTIVE_SCORE = 0.7f

        /** Structure-to-change ratio at which a box counts as fully reliable. */
        const val SNR_FOR_FULL_QUALITY = 5.0

        /** A box below this quality is not used as the driving-screen marker. */
        const val MIN_MARKER_QUALITY = 0.2f

        /** Null unless there were enough pictures with moving scenery. HaulPilot's own parts get no weight. */
        fun of(frames: List<FrameEntry>, preferred: Frame?): StabilityMap? {
            if (frames.size < PictureEvidence.MIN_MOVING) return null
            val ev = PictureEvidence.build(frames.map { it.frame }, preferred, frames.flatMap { it.exclusions }.distinct()) ?: return null
            val std = ev.temporalStd ?: return null
            if (!ev.multiFrame) return null
            val v = ArrayList<Float>()
            for (y in ev.viewport.y0 until ev.viewport.y1) for (x in ev.viewport.x0 until ev.viewport.x1) {
                val i = y * ev.width + x
                if (!ev.blocked[i]) v += std[i]
            }
            if (v.isEmpty()) return null
            v.sort()
            return StabilityMap(ev.width, ev.height, ev.ref, std, ev.ownUi, ev.moving, v[v.size / 2], ev.frames)
        }
    }
}
