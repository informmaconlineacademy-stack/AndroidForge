package dev.toe3autopilot.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionConfig
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import dev.toe3autopilot.app.capture.ScreenCaptureService
import dev.toe3autopilot.app.ui.Actions
import dev.toe3autopilot.app.ui.AppRoot
import dev.toe3autopilot.app.ui.HpTheme
import dev.toe3autopilot.core.capture.CaptureFault
import dev.toe3autopilot.core.profile.ProfileArchive
import dev.toe3autopilot.core.profile.ProfileLoad
import kotlinx.coroutines.launch

/**
 * The only activity. It owns everything that needs an Activity: permission dialogs, the screen-sharing consent, file
 * pickers and Android settings screens. The screens themselves observe AutopilotRuntime.
 *
 * Permissions are asked for at the point of need: notifications and screen sharing when the person connects the screen,
 * the accessibility service (after an in-app explanation) when they turn on touch control. Pickers hand back read-only
 * content Uris; no storage permission is requested.
 */
class MainActivity : ComponentActivity() {
    /** Profile waiting for the "save as" dialog of an export. */
    private var exportId: String? = null

    /** The notification permission is asked at most once per app start, right before the first screen-sharing dialog. */
    private var notificationAsked = false

    override fun onStart() {
        super.onStart()
        AutopilotRuntime.appVisible = true
    }

    override fun onStop() {
        AutopilotRuntime.appVisible = false
        super.onStop()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        AutopilotRuntime.init(this)
        // A restored activity must not re-open a screen that was already handled.
        if (savedInstanceState == null) handleOpen(intent)
        setContent {
            HpTheme {
                val projectionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
                    AutopilotRuntime.setAwaitingPermission(false)
                    val data = result.data
                    if (result.resultCode == RESULT_OK && data != null) {
                        ScreenCaptureService.start(this, result.resultCode, data)
                    } else {
                        AutopilotRuntime.reportCaptureFault(CaptureFault.PERMISSION_DENIED, "resultCode=${result.resultCode}, data=${if (data == null) "null" else "present"}")
                        AutopilotRuntime.noteInputFailure("Screen-capture permission was not granted")
                    }
                }
                val launchProjection = {
                    val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                    val intent = if (Build.VERSION.SDK_INT >= 34) {
                        // Android 14+: offer the whole screen; single-app sharing would hide the game's controls from the analysis.
                        mpm.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay())
                    } else {
                        mpm.createScreenCaptureIntent()
                    }
                    AutopilotRuntime.setAwaitingPermission(true)
                    try {
                        projectionLauncher.launch(intent)
                    } catch (e: Exception) {
                        AutopilotRuntime.setAwaitingPermission(false)
                        AutopilotRuntime.reportCaptureFault(CaptureFault.SERVICE_START_REJECTED, "the permission dialog could not be opened: ${e.javaClass.simpleName}")
                    }
                }
                // Asked first so the two system dialogs never overlap; screen sharing follows whatever the answer.
                val notifThenProjection = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { _ -> launchProjection() }
                val notifOnly = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
                    if (!granted) AutopilotRuntime.notice.value = "Notifications are off. You can allow them in Android's notification settings."
                }
                val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
                    val id = exportId
                    exportId = null
                    if (uri != null && id != null) AutopilotRuntime.ioScope.launch { AutopilotRuntime.notice.value = writeExport(uri, id) }
                }
                val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
                    if (uri != null) AutopilotRuntime.ioScope.launch { AutopilotRuntime.notice.value = readImport(uri) }
                }
                val screenshotLauncher = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(MAX_SCREENSHOTS)) { uris ->
                    if (uris.isNotEmpty()) AutopilotRuntime.setup.importScreenshots(uris)
                }
                // A gameplay clip. Nothing is copied: the picker hands back a read-only content Uri that is decoded on a
                // background thread. A clip never produces input.
                val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
                    if (uri != null) AutopilotRuntime.setup.importClip(uri)
                }
                val videoBrowser = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
                    if (uri != null) AutopilotRuntime.setup.importClip(uri)
                }
                val actions = Actions(
                    connectCapture = {
                        val needAsk = Build.VERSION.SDK_INT >= 33 && !notificationAsked &&
                            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                        if (needAsk) {
                            notificationAsked = true
                            notifThenProjection.launch(Manifest.permission.POST_NOTIFICATIONS)
                        } else {
                            launchProjection()
                        }
                    },
                    disconnectCapture = {
                        AutopilotRuntime.stopSession()
                        ScreenCaptureService.stop(this)
                    },
                    openAccessibilitySettings = { open(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) },
                    openAppDetails = { open(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))) },
                    launchGame = {
                        val i = packageManager.getLaunchIntentForPackage(AutopilotRuntime.gamePackage.value)
                        if (i == null) {
                            false
                        } else {
                            try {
                                startActivity(i)
                                true
                            } catch (e: Exception) {
                                false
                            }
                        }
                    },
                    installedLaunchables = { launchableApps() },
                    requestNotifications = {
                        if (Build.VERSION.SDK_INT >= 33) notifOnly.launch(Manifest.permission.POST_NOTIFICATIONS) else openNotificationSettings()
                    },
                    openNotificationSettings = { openNotificationSettings() },
                    openBatterySettings = {
                        // The list of apps exempt from battery optimisation. (Asking for the exemption directly needs a
                        // permission that Google Play restricts, so the person is sent to the list instead.)
                        if (!open(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))) {
                            open(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
                        }
                    },
                    pickScreenshots = {
                        safeLaunch { screenshotLauncher.launch(PickVisualMediaRequest(mediaType = ActivityResultContracts.PickVisualMedia.ImageOnly, maxItems = MAX_SCREENSHOTS, isOrderedSelection = false)) }
                    },
                    pickVideo = { safeLaunch { videoPicker.launch(PickVisualMediaRequest(mediaType = ActivityResultContracts.PickVisualMedia.VideoOnly, isOrderedSelection = false)) } },
                    browseVideo = { safeLaunch { videoBrowser.launch(arrayOf("video/*")) } },
                    exportProfile = { id ->
                        exportId = id
                        val name = AutopilotRuntime.profileList.value.firstOrNull { it.id == id }?.name ?: "profile"
                        safeLaunch { exportLauncher.launch("haulpilot-" + name.lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-').ifEmpty { "profile" } + ".zip") }
                    },
                    importProfile = { safeLaunch { importLauncher.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) } },
                    notificationsAllowed = { NotificationManagerCompat.from(this).areNotificationsEnabled() },
                    shareText = { subject, text ->
                        val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_SUBJECT, subject).putExtra(Intent.EXTRA_TEXT, text)
                        open(Intent.createChooser(send, subject))
                    },
                )
                AppRoot(actions)
            }
        }
    }

    /** Starts an Android screen; false (with a notice) when this phone has no such screen. */
    private fun open(i: Intent): Boolean = try {
        startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        true
    } catch (e: Exception) {
        AutopilotRuntime.notice.value = "That Android screen is not available on this phone."
        false
    }

    private fun openNotificationSettings() {
        open(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName))
    }

    /** A picker that is missing on this phone must not crash the app. */
    private fun safeLaunch(block: () -> Unit) {
        try {
            block()
        } catch (e: Exception) {
            AutopilotRuntime.notice.value = "No app on this phone can pick that kind of file."
        }
    }

    /** Writes profile [id] (text + control pictures) as a zip. Runs on a background thread. */
    private fun writeExport(uri: Uri, id: String): String = try {
        val repo = AutopilotRuntime.profiles
        val text = repo.profileText(id) ?: return "Export failed: the profile file is missing."
        val profile = (repo.load(id) as? ProfileLoad.Ok)?.profile ?: return "Export failed: the profile cannot be read."
        val pics = LinkedHashMap<String, ByteArray>()
        for (n in profile.templates.keys) repo.templateBytes(id, n)?.let { pics[n] = it }
        val bytes = ProfileArchive.pack(text, null, pics)
        val out = contentResolver.openOutputStream(uri) ?: return "Export failed: the file could not be opened for writing."
        out.use { it.write(bytes) }
        AutopilotRuntime.logInfo("Profile '${profile.name}' exported (${bytes.size / 1024} KB)")
        "Exported \"${profile.name}\" (${pics.size} control picture(s), ${bytes.size / 1024} KB)."
    } catch (e: Exception) {
        "Export failed: ${e.message ?: e.javaClass.simpleName}"
    }

    /** Reads a profile archive and adds it as a new, inactive profile. Runs on a background thread. */
    private fun readImport(uri: Uri): String = try {
        val input = contentResolver.openInputStream(uri) ?: return "Import failed: the file could not be opened."
        val bytes = input.use { ScreenshotImport.readLimited(it, 21L * 1024 * 1024) }
        val c = ProfileArchive.unpack(bytes)
        val taken = AutopilotRuntime.profileList.value.map { it.name.lowercase() }.toSet()
        var name = c.profile.name
        var n = 2
        while (name.lowercase() in taken) name = "${c.profile.name} ($n)".also { n++ }
        AutopilotRuntime.profiles.importProfile(c.profileText, c.templatesPng, name)
        AutopilotRuntime.refreshProfiles()
        AutopilotRuntime.logInfo("Profile imported as '$name' (${c.warnings.size} warning(s))")
        "Imported \"$name\"" + (if (c.warnings.isNotEmpty()) " with ${c.warnings.size} warning(s): ${c.warnings.first()}" else "") + ". Make it active in Profiles to use it."
    } catch (e: IllegalArgumentException) {
        "Import failed: ${e.message}"
    } catch (e: Exception) {
        "Import failed: ${e.message ?: e.javaClass.simpleName}"
    }

    /** Apps with a launcher icon, as (label, package), for picking the game. Needs only the launcher <queries> entry. */
    private fun launchableApps(): List<Pair<String, String>> {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(i, 0)
            .map { it.loadLabel(packageManager).toString() to it.activityInfo.packageName }
            .filter { it.second != packageName }
            .distinctBy { it.second }
            .sortedBy { it.first.lowercase() }
    }

    /** A screen to open, sent by the floating button ("Review in HaulPilot"). */
    private fun handleOpen(intent: Intent?) {
        val screen = intent?.getStringExtra(EXTRA_OPEN) ?: return
        AutopilotRuntime.openRequest.value = screen
        intent.removeExtra(EXTRA_OPEN)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleOpen(intent)
    }

    companion object {
        /** The system photo picker allows at least this many on every Android version. */
        private const val MAX_SCREENSHOTS = 40

        /** Intent extra naming a screen to open (see AutopilotRuntime.openRequest). */
        const val EXTRA_OPEN = "dev.toe3autopilot.OPEN"
    }
}
