package dev.toe3autopilot.core.overlay

import kotlin.math.roundToInt

/**
 * The part of the display a floating window may use, in the same pixel space the window manager positions windows in
 * (origin = top-left of the whole display). System bars and display cut-outs are already taken out, so a button that is
 * clamped to these bounds can never sit under the status bar, the navigation bar or a camera cut-out.
 */
data class UsableBounds(val left: Int, val top: Int, val right: Int, val bottom: Int) {
    init {
        require(right >= left && bottom >= top) { "empty bounds $this" }
    }

    val width: Int get() = right - left
    val height: Int get() = bottom - top

    companion object {
        fun ofSize(w: Int, h: Int) = UsableBounds(0, 0, maxOf(0, w), maxOf(0, h))
    }
}

/** Placement inside [UsableBounds]. Pure; the old screen-size based [OverlayPlacement] stays for its callers. */
object BoundedPlacement {
    fun clampX(x: Int, size: Int, b: UsableBounds) = x.coerceIn(b.left, maxOf(b.left, b.right - size))
    fun clampY(y: Int, size: Int, b: UsableBounds) = y.coerceIn(b.top, maxOf(b.top, b.bottom - size))

    fun place(pos: DockPosition, size: Int, b: UsableBounds, margin: Int): Pair<Int, Int> {
        val x = if (pos.rightSide) b.right - size - margin else b.left + margin
        val usable = maxOf(0, b.height - size - 2 * margin)
        val y = b.top + margin + (pos.yFraction.coerceIn(0f, 1f) * usable).roundToInt()
        return clampX(x, size, b) to clampY(y, size, b)
    }

    fun snap(x: Int, y: Int, size: Int, b: UsableBounds, margin: Int): DockPosition {
        val right = x + size / 2f >= b.left + b.width / 2f
        val usable = maxOf(1, b.height - size - 2 * margin)
        return DockPosition(right, ((y - b.top - margin).toFloat() / usable).coerceIn(0f, 1f))
    }

    /** Panel of [panelW] x [panelH] beside the button, on its inner side, fully inside [b] (top-aligned if it is taller than [b]). */
    fun panelAnchor(bx: Int, by: Int, size: Int, panelW: Int, panelH: Int, b: UsableBounds, gap: Int): Pair<Int, Int> {
        val onRight = bx + size / 2f >= b.left + b.width / 2f
        val px = if (onRight) bx - gap - panelW else bx + size + gap
        return clampX(px, panelW, b) to clampY(by, panelH, b)
    }

    /** Panel width: the design width, but never wider than the usable width minus a gutter on each side. */
    fun panelWidth(designPx: Int, b: UsableBounds, gutter: Int) = minOf(designPx, maxOf(1, b.width - 2 * gutter))
}

/**
 * Turns raw touch positions into a drag, with one rule for everything: the position is ALWAYS the position at touch-down plus
 * the finger's movement since touch-down (never accumulated per event, so it cannot drift), clamped to the bounds. Until the
 * finger has moved beyond the touch slop the gesture is still a candidate tap; once it has, it is a drag for good and its end
 * is never a tap, so a drag can never press a button.
 */
class DragTracker(private val guard: TapGuard) {
    enum class End { NONE, TAP, DRAG }

    data class Step(val started: Boolean, val x: Int, val y: Int)

    private var active = false
    private var dragging = false
    private var downX = 0f
    private var downY = 0f
    private var startX = 0
    private var startY = 0

    val isDragging: Boolean get() = dragging

    fun down(rawX: Float, rawY: Float, windowX: Int, windowY: Int) {
        active = true
        dragging = false
        downX = rawX
        downY = rawY
        startX = windowX
        startY = windowY
    }

    /** Null while the finger is still within the slop (or no gesture is active). */
    fun move(rawX: Float, rawY: Float, size: Int, b: UsableBounds): Step? {
        if (!active) return null
        var started = false
        if (!dragging) {
            if (guard.isTap(downX, downY, rawX, rawY)) return null
            dragging = true
            started = true
        }
        val x = BoundedPlacement.clampX(startX + (rawX - downX).roundToInt(), size, b)
        val y = BoundedPlacement.clampY(startY + (rawY - downY).roundToInt(), size, b)
        return Step(started, x, y)
    }

    fun up(): End {
        if (!active) return End.NONE
        val e = if (dragging) End.DRAG else End.TAP
        reset()
        return e
    }

    fun cancel(): End {
        val e = if (active && dragging) End.DRAG else End.NONE
        reset()
        return e
    }

    private fun reset() {
        active = false
        dragging = false
    }
}

/**
 * At most one owner of the floating windows exists at a time. A new owner (a reconnected accessibility service) claims the
 * slot and the previous one is released first, so two services can never both show a button.
 */
class OverlayOwnerSlot<T : Any>(private val release: (T) -> Unit) {
    private var owner: T? = null

    val current: T? get() = owner

    @Synchronized
    fun claim(next: T) {
        val prev = owner
        if (prev === next) return
        owner = next
        if (prev != null) try { release(prev) } catch (_: Exception) { }
    }

    @Synchronized
    fun drop(o: T) {
        if (owner === o) owner = null
    }
}

/** Holds at most one attached view. [ensure] is idempotent; [remove] detaches exactly once. */
class SingleWindow<V : Any>(private val attach: (V) -> Unit, private val detach: (V) -> Unit) {
    var view: V? = null
        private set

    val isShown: Boolean get() = view != null

    /** The attached view, creating and attaching it if there is none. Null if attaching failed (nothing is left behind). */
    fun ensure(create: () -> V): V? {
        view?.let { return it }
        val v = create()
        return try {
            attach(v)
            view = v
            v
        } catch (_: Exception) {
            null
        }
    }

    fun remove() {
        val v = view ?: return
        view = null
        try { detach(v) } catch (_: Exception) { }
    }
}

/** Many "something changed" requests in one burst become one refresh, run later on the UI thread. */
class RefreshCoalescer(private val post: (() -> Unit) -> Unit, private val action: () -> Unit) {
    private var pending = false
    private var generation = 0

    @Synchronized
    fun request() {
        if (pending) return
        pending = true
        val gen = generation
        post {
            val run = synchronized(this) {
                pending = false
                gen == generation
            }
            if (run) action()
        }
    }

    /** Drops a refresh that has been requested but not run yet. */
    @Synchronized
    fun cancel() {
        generation++
        pending = false
    }
}
