package dev.toe3autopilot.core.state

/**
 * Screens the driving assistant distinguishes. Menus, job lists and trailer coupling are deliberately absent: the user does
 * all of that by hand and starts the app while already driving.
 */
enum class GameState(val label: String, val drivingLike: Boolean = false) {
    GAME_NOT_FOREGROUND("Game not in foreground"),
    LOADING("Loading"),

    /** The normal driving view (HUD visible). */
    DRIVING("Driving", drivingLike = true),

    /** A dedicated parking / reversing view, if the game has one and the user calibrated it. */
    PARKING("Parking / reversing", drivingLike = true),

    /** The game's own "delivery complete" screen. Used only as evidence that the job has ended; the app never taps on it. */
    DELIVERY_COMPLETE("Delivery screen"),
    CRASH_OR_PENALTY("Crash / penalty"),
    UNEXPECTED_DIALOG("Unexpected dialog"),
    UNKNOWN("Unrecognised screen");
}

/**
 * Order in which state rules are evaluated. Interrupting screens (dialogs, crashes) come first so
 * they win over the HUD that may still be visible underneath them. When two rules are satisfied the
 * one with the higher confidence wins; ties go to the earlier entry.
 */
val DETECTION_PRIORITY: List<GameState> = listOf(
    GameState.UNEXPECTED_DIALOG,
    GameState.CRASH_OR_PENALTY,
    GameState.DELIVERY_COMPLETE,
    GameState.LOADING,
    GameState.PARKING,
    GameState.DRIVING,
)
