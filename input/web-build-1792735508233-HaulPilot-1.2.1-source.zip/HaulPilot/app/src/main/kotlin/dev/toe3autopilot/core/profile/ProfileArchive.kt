package dev.toe3autopilot.core.profile

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Export/import container for a calibration: a zip with `profile.properties`, optional `calibration.properties`
 * and `templates/<name>.png`. Import is defensive: sizes and entry counts are capped, only known file names are
 * read, nothing is ever written using a name from the archive, and the profile must parse strictly.
 */
object ProfileArchive {
    const val PROFILE_ENTRY = "profile.properties"
    const val CALIBRATION_ENTRY = "calibration.properties"
    private const val TEMPLATE_PREFIX = "templates/"
    private val TEMPLATE_NAME = Regex("[a-z0-9_]{1,64}")
    private const val MAX_ENTRIES = 300
    private const val MAX_TOTAL_BYTES = 20L * 1024 * 1024
    private const val MAX_TEXT_BYTES = 512 * 1024

    class Contents(
        val profileText: String,
        val profile: GameProfile,
        val calibrationText: String?,
        val templatesPng: Map<String, ByteArray>,
        val warnings: List<String>,
    )

    fun pack(profileText: String, calibrationText: String?, templatesPng: Map<String, ByteArray>): ByteArray {
        val out = ByteArrayOutputStream()
        ZipOutputStream(out).use { z ->
            fun put(name: String, bytes: ByteArray) {
                z.putNextEntry(ZipEntry(name))
                z.write(bytes)
                z.closeEntry()
            }
            put(PROFILE_ENTRY, profileText.toByteArray(Charsets.UTF_8))
            if (!calibrationText.isNullOrBlank()) put(CALIBRATION_ENTRY, calibrationText.toByteArray(Charsets.UTF_8))
            for ((n, b) in templatesPng.toSortedMap()) {
                require(TEMPLATE_NAME.matches(n)) { "Bad template name '$n'" }
                put("$TEMPLATE_PREFIX$n.png", b)
            }
        }
        return out.toByteArray()
    }

    /** @throws IllegalArgumentException if the archive is malformed, too large or holds an invalid profile. */
    fun unpack(bytes: ByteArray): Contents {
        val warnings = ArrayList<String>()
        var profileText: String? = null
        var calibrationText: String? = null
        val templates = LinkedHashMap<String, ByteArray>()
        var entries = 0
        var total = 0L
        try {
            ZipInputStream(ByteArrayInputStream(bytes)).use { z ->
                while (true) {
                    val e = z.nextEntry ?: break
                    entries++
                    require(entries <= MAX_ENTRIES) { "Archive has too many entries" }
                    if (e.isDirectory) continue
                    val data = readLimited(z, if (e.name.endsWith(".png")) MAX_TOTAL_BYTES else MAX_TEXT_BYTES.toLong())
                    total += data.size
                    require(total <= MAX_TOTAL_BYTES) { "Archive is too large" }
                    when {
                        e.name == PROFILE_ENTRY -> profileText = data.toString(Charsets.UTF_8)
                        e.name == CALIBRATION_ENTRY -> calibrationText = data.toString(Charsets.UTF_8)
                        e.name.startsWith(TEMPLATE_PREFIX) && e.name.endsWith(".png") -> {
                            val n = e.name.removePrefix(TEMPLATE_PREFIX).removeSuffix(".png")
                            if (TEMPLATE_NAME.matches(n)) templates[n] = data else warnings += "Ignored template with unsafe name"
                        }
                        else -> warnings += "Ignored unknown entry"
                    }
                }
            }
        } catch (e: java.io.IOException) {
            throw IllegalArgumentException("Not a valid archive: ${e.message}")
        }
        val text = profileText ?: throw IllegalArgumentException("The archive has no $PROFILE_ENTRY")
        val profile = ProfileCodec.parse(text) // strict; throws IllegalArgumentException
        for (n in profile.templates.keys) if (!templates.containsKey(n)) warnings += "Template image '$n' is missing from the archive"
        return Contents(text, profile, calibrationText, templates, warnings)
    }

    private fun readLimited(z: ZipInputStream, limit: Long): ByteArray {
        val out = ByteArrayOutputStream()
        val buf = ByteArray(8192)
        var n = 0L
        while (true) {
            val r = z.read(buf)
            if (r < 0) break
            n += r
            require(n <= limit) { "An entry in the archive is too large" }
            out.write(buf, 0, r)
        }
        return out.toByteArray()
    }
}
