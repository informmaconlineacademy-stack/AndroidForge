package dev.toe3autopilot.core.geometry

import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/*
 * ======================================================================================================================
 *  CANONICAL COORDINATE SYSTEM
 * ======================================================================================================================
 *
 *  Every saved control position, every saved region (minimap, templates, colour regions) and every analysis result is
 *  expressed in NORMALISED DISPLAY SPACE (NDS):
 *
 *      nx = displayPixelX / displayWidthPx        ny = displayPixelY / displayHeightPx
 *
 *  (0,0) is the top-left corner of the physical display in its CURRENT rotation, (1,1) the bottom-right corner.
 *
 *  Why the whole display: MediaProjection mirrors the whole default display (status bar, navigation bar and cut-out
 *  areas included) and AccessibilityService gestures are dispatched in whole-display pixels. Using the same reference
 *  at both ends means no inset arithmetic is needed between "what was seen" and "where to touch". Insets only matter for
 *  HaulPilot's own windows (the editor), and those are handled by the view transforms below, which work in the local
 *  coordinates of the view that receives the touches.
 *
 *  Rotation: both the capture surface and the gesture space follow the current display rotation. Truckers of Europe 3
 *  re-lays its interface when the orientation class changes (portrait <-> landscape) but not between the two landscape
 *  rotations, so saved NDS positions are valid in both landscape rotations and INVALID after a portrait/landscape change.
 *  That case is detected (LayoutCheck aspect test) and requires recalibration; positions are never rotated blindly.
 *  [Affine.rotateUnitSquare] exists for the cases where the content itself is rotated (tests, imported pictures).
 *
 *  Spaces and the transform that links each to NDS (all invertible, all unit-tested):
 *
 *      display pixels            <-> NDS   [DisplaySpace]
 *      capture-surface pixels    <-> NDS   [CaptureGeometry]  (mirrored display letter-boxed inside the surface)
 *      frame pixels              <-> NDS   [FrameSpace]       (frames are cropped to the mirrored content, see below)
 *      editor image pixels       <-> view  [FitTransform]     (picture fitted into the editor, letter-boxed)
 *      view pixels               <-> zoomed view pixels  [ZoomPan] (pinch-zoom / pan)
 *      NDS                       <-> zoomed view pixels  [EditorTransform] (the whole chain used by the editor)
 *
 *  The capture layer crops each captured image to [CaptureGeometry.cropRect] before it becomes a Frame, so for a Frame
 *  "normalised frame coordinates" and NDS are the same thing (up to the half-pixel rounding of the crop, < 0.25 % at the
 *  480-pixel processing size). That keeps every vision routine simple: they work in frame pixels and report NDS.
 */

/** A point or vector. */
data class Vec2(val x: Float, val y: Float) {
    operator fun plus(o: Vec2) = Vec2(x + o.x, y + o.y)
    operator fun minus(o: Vec2) = Vec2(x - o.x, y - o.y)
}

/** Axis-aligned rectangle; left/top inclusive, right/bottom exclusive. */
data class RectF(val left: Float, val top: Float, val right: Float, val bottom: Float) {
    val width: Float get() = right - left
    val height: Float get() = bottom - top
    val centerX: Float get() = (left + right) / 2f
    val centerY: Float get() = (top + bottom) / 2f
    val isEmpty: Boolean get() = width <= 0f || height <= 0f

    fun contains(x: Float, y: Float): Boolean = x >= left && x <= right && y >= top && y <= bottom

    fun intersect(o: RectF): RectF? {
        val l = max(left, o.left)
        val t = max(top, o.top)
        val r = min(right, o.right)
        val b = min(bottom, o.bottom)
        return if (r > l && b > t) RectF(l, t, r, b) else null
    }
}

/** Integer pixel rectangle [x0, x1) x [y0, y1). */
data class IntRect(val x0: Int, val y0: Int, val x1: Int, val y1: Int) {
    val width: Int get() = x1 - x0
    val height: Int get() = y1 - y0
}

/**
 * 2-D affine transform:
 *
 *     x' = a * x + b * y + c
 *     y' = d * x + e * y + f
 *
 * Composition is explicit: `t1.then(t2)` applies t1 first, then t2.
 */
data class Affine(val a: Float, val b: Float, val c: Float, val d: Float, val e: Float, val f: Float) {
    fun map(x: Float, y: Float): Vec2 = Vec2(a * x + b * y + c, d * x + e * y + f)

    fun map(p: Vec2): Vec2 = map(p.x, p.y)

    /** Bounding box of the transformed rectangle (exact for scale/translate/90-degree rotations). */
    fun mapRect(r: RectF): RectF {
        val p1 = map(r.left, r.top)
        val p2 = map(r.right, r.top)
        val p3 = map(r.left, r.bottom)
        val p4 = map(r.right, r.bottom)
        return RectF(
            minOf(p1.x, p2.x, p3.x, p4.x), minOf(p1.y, p2.y, p3.y, p4.y),
            maxOf(p1.x, p2.x, p3.x, p4.x), maxOf(p1.y, p2.y, p3.y, p4.y),
        )
    }

    /** This transform followed by [next]. */
    fun then(next: Affine): Affine = Affine(
        a = next.a * a + next.b * d,
        b = next.a * b + next.b * e,
        c = next.a * c + next.b * f + next.c,
        d = next.d * a + next.e * d,
        e = next.d * b + next.e * e,
        f = next.d * c + next.e * f + next.f,
    )

    val determinant: Float get() = a * e - b * d

    /** @throws IllegalStateException when the transform cannot be inverted (zero scale). */
    fun inverse(): Affine {
        val det = determinant
        check(abs(det) > 1e-12f) { "Transform is not invertible (determinant $det)" }
        val ia = e / det
        val ib = -b / det
        val id = -d / det
        val ie = a / det
        return Affine(ia, ib, -(ia * c + ib * f), id, ie, -(id * c + ie * f))
    }

    companion object {
        val IDENTITY = Affine(1f, 0f, 0f, 0f, 1f, 0f)

        fun scale(sx: Float, sy: Float = sx) = Affine(sx, 0f, 0f, 0f, sy, 0f)

        fun translate(tx: Float, ty: Float) = Affine(1f, 0f, tx, 0f, 1f, ty)

        /**
         * Rotates the unit square by [quarterTurns] x 90 degrees clockwise, mapping it onto itself
         * (0 -> identity; 1 -> (x, y) => (1 - y, x); 2 -> (1 - x, 1 - y); 3 -> (y, 1 - x)).
         */
        fun rotateUnitSquare(quarterTurns: Int): Affine = when (((quarterTurns % 4) + 4) % 4) {
            0 -> IDENTITY
            1 -> Affine(0f, -1f, 1f, 1f, 0f, 0f)
            2 -> Affine(-1f, 0f, 1f, 0f, -1f, 1f)
            else -> Affine(0f, 1f, 0f, -1f, 0f, 1f)
        }
    }
}

/** Physical display in its current rotation. Converts between display pixels and NDS. */
data class DisplaySpace(val widthPx: Int, val heightPx: Int) {
    init {
        require(widthPx > 0 && heightPx > 0) { "Display size must be positive: ${widthPx}x$heightPx" }
    }

    val aspect: Float get() = widthPx.toFloat() / heightPx

    /** NDS -> display pixels. */
    val toPixels: Affine get() = Affine.scale(widthPx.toFloat(), heightPx.toFloat())

    /** Display pixels -> NDS. */
    val toNormalized: Affine get() = Affine.scale(1f / widthPx, 1f / heightPx)

    /**
     * Pixel position for a touch at NDS ([nx], [ny]), clamped so it always lands on the display
     * (a point exactly at 1.0 would otherwise be one pixel outside the screen).
     */
    fun touchPoint(nx: Float, ny: Float): Vec2 {
        val p = toPixels.map(nx, ny)
        return Vec2(p.x.coerceIn(0f, widthPx - 1f), p.y.coerceIn(0f, heightPx - 1f))
    }
}

/**
 * Where the mirrored display lands inside the MediaProjection capture surface.
 *
 * Android scales the mirrored display uniformly to fit the virtual display and centres it (letter- or pillar-boxing any
 * aspect mismatch). [chooseSurfaceSize] picks a surface whose aspect is as close as possible to the display's, so the
 * boxes are at most a pixel; [cropRect] is what the capture layer keeps.
 */
data class CaptureGeometry(val displayW: Int, val displayH: Int, val surfaceW: Int, val surfaceH: Int) {
    init {
        require(displayW > 0 && displayH > 0 && surfaceW > 0 && surfaceH > 0) { "Sizes must be positive" }
    }

    val scale: Float get() = min(surfaceW.toFloat() / displayW, surfaceH.toFloat() / displayH)

    /** The mirrored display inside the surface, in surface pixels (fractional). */
    val contentRect: RectF
        get() {
            val cw = displayW * scale
            val ch = displayH * scale
            val l = (surfaceW - cw) / 2f
            val t = (surfaceH - ch) / 2f
            return RectF(l, t, l + cw, t + ch)
        }

    /** Pixel-aligned crop of [contentRect] (never empty, never outside the surface). */
    val cropRect: IntRect
        get() {
            val r = contentRect
            val x0 = r.left.roundToInt().coerceIn(0, surfaceW - 1)
            val y0 = r.top.roundToInt().coerceIn(0, surfaceH - 1)
            val x1 = r.right.roundToInt().coerceIn(x0 + 1, surfaceW)
            val y1 = r.bottom.roundToInt().coerceIn(y0 + 1, surfaceH)
            return IntRect(x0, y0, x1, y1)
        }

    /** Surface pixels -> NDS. */
    val surfaceToNormalized: Affine
        get() {
            val r = contentRect
            return Affine.translate(-r.left, -r.top).then(Affine.scale(1f / r.width, 1f / r.height))
        }

    /** NDS -> surface pixels. */
    val normalizedToSurface: Affine get() = surfaceToNormalized.inverse()

    companion object {
        /**
         * Capture surface for a [displayW] x [displayH] display with the long side limited to [longSide] pixels (never
         * upscaled). The short side is rounded to the nearest pixel, so the aspect error is below half a pixel.
         */
        fun chooseSurfaceSize(displayW: Int, displayH: Int, longSide: Int): Pair<Int, Int> {
            require(displayW > 0 && displayH > 0 && longSide > 0) { "Sizes must be positive" }
            val long = max(displayW, displayH)
            val target = min(longSide, long)
            val s = target.toFloat() / long
            val w = max(1, (displayW * s).roundToInt())
            val h = max(1, (displayH * s).roundToInt())
            return w to h
        }
    }
}

/** A captured frame of [width] x [height] pixels that covers the whole display (see the file comment). */
data class FrameSpace(val width: Int, val height: Int) {
    init {
        require(width > 0 && height > 0) { "Frame size must be positive" }
    }

    /** Frame pixels -> NDS. Pixel (i, j) covers [i, i+1) so its centre is at (i + 0.5) / width. */
    val toNormalized: Affine get() = Affine.scale(1f / width, 1f / height)

    val toPixels: Affine get() = Affine.scale(width.toFloat(), height.toFloat())

    /** Index of the pixel that contains NDS point ([nx], [ny]). */
    fun pixelAt(nx: Float, ny: Float): Pair<Int, Int> =
        (nx * width).toInt().coerceIn(0, width - 1) to (ny * height).toInt().coerceIn(0, height - 1)
}

/**
 * Fits an image of [imageW] x [imageH] into a view of [viewW] x [viewH] (uniform scale, centred, letter-boxed).
 * This is what the editor shows before any zoom.
 */
data class FitTransform(val imageW: Float, val imageH: Float, val viewW: Float, val viewH: Float) {
    init {
        require(imageW > 0f && imageH > 0f) { "Image size must be positive" }
    }

    val valid: Boolean get() = viewW > 0f && viewH > 0f

    val scale: Float get() = min(viewW / imageW, viewH / imageH)

    /** Where the image is drawn inside the view, in view pixels. */
    val imageRect: RectF
        get() {
            val w = imageW * scale
            val h = imageH * scale
            val l = (viewW - w) / 2f
            val t = (viewH - h) / 2f
            return RectF(l, t, l + w, t + h)
        }

    /** Image pixels -> view pixels. */
    val imageToView: Affine
        get() {
            val r = imageRect
            return Affine.scale(scale).then(Affine.translate(r.left, r.top))
        }

    val viewToImage: Affine get() = imageToView.inverse()
}

/**
 * Pinch-zoom and pan of a view's content: zoomed = view * scale + (tx, ty).
 * [scale] = 1 and t = (0, 0) is the un-zoomed view.
 */
data class ZoomPan(val scale: Float = 1f, val tx: Float = 0f, val ty: Float = 0f) {
    /** Un-zoomed view pixels -> zoomed view pixels (what is on screen). */
    val forward: Affine get() = Affine(scale, 0f, tx, 0f, scale, ty)

    /** On-screen (zoomed) pixels -> un-zoomed view pixels. */
    val backward: Affine get() = forward.inverse()

    /**
     * Zooms by [factor] keeping the on-screen point ([focusX], [focusY]) fixed, then pans by ([panX], [panY]).
     * The result is limited to [minScale]..[maxScale].
     */
    fun transformed(factor: Float, focusX: Float, focusY: Float, panX: Float, panY: Float, minScale: Float = 1f, maxScale: Float = MAX_SCALE): ZoomPan {
        val newScale = (scale * factor).coerceIn(minScale, maxScale)
        val k = newScale / scale
        return ZoomPan(newScale, focusX - (focusX - tx) * k + panX, focusY - (focusY - ty) * k + panY)
    }

    /**
     * Keeps [content] (un-zoomed view pixels, normally the fitted image rectangle) on screen: along an axis where the
     * zoomed content is larger than the view it may not reveal empty space past its edges; where it is smaller it is
     * centred. This is what stops the picture from drifting away while panning.
     */
    fun clampedTo(viewW: Float, viewH: Float, content: RectF): ZoomPan {
        fun axis(t: Float, start: Float, end: Float, view: Float): Float {
            val s = start * scale
            val e = end * scale
            val len = e - s
            return if (len <= view) (view - len) / 2f - s else t.coerceIn(view - e, -s)
        }
        return copy(tx = axis(tx, content.left, content.right, viewW), ty = axis(ty, content.top, content.bottom, viewH))
    }

    companion object {
        const val MAX_SCALE = 8f
        val NONE = ZoomPan()
    }
}

/**
 * The full chain used by the placement editor: NDS <-> picture pixels <-> fitted view <-> zoomed screen pixels.
 * Markers are drawn with [toScreen]; touches are interpreted with [toNormalized]. Because both use the same matrices the
 * picture and the markers cannot drift apart.
 */
data class EditorTransform(val fit: FitTransform, val zoom: ZoomPan) {
    /** NDS -> on-screen pixels of the editor view. */
    val forward: Affine
        get() = Affine.scale(fit.imageW, fit.imageH).then(fit.imageToView).then(zoom.forward)

    /** On-screen pixels of the editor view -> NDS (may lie outside 0..1 when the touch is outside the picture). */
    val backward: Affine get() = forward.inverse()

    fun toScreen(nx: Float, ny: Float): Vec2 = forward.map(nx, ny)

    /** The NDS point under an on-screen touch, or null when the touch is outside the picture. */
    fun toNormalized(sx: Float, sy: Float): Vec2? {
        if (!fit.valid) return null
        val p = backward.map(sx, sy)
        return if (p.x in 0f..1f && p.y in 0f..1f) p else null
    }

    /** Like [toNormalized] but clamps to the picture (used while dragging a handle past the edge). */
    fun toNormalizedClamped(sx: Float, sy: Float): Vec2 {
        val p = backward.map(sx, sy)
        return Vec2(p.x.coerceIn(0f, 1f), p.y.coerceIn(0f, 1f))
    }

    /** Size in NDS units of [px] on-screen pixels (horizontal, vertical), e.g. for touch-slop or nudge steps. */
    fun normalizedSizeOf(px: Float): Vec2 {
        val k = fit.scale * zoom.scale
        return Vec2(px / (k * fit.imageW), px / (k * fit.imageH))
    }
}
