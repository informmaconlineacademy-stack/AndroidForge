package dev.toe3autopilot.core.vision

import dev.toe3autopilot.core.profile.GameProfile
import dev.toe3autopilot.core.profile.TemplateStore

/** Where the route line lies relative to the truck, read from the navigation minimap. */
data class RouteReading(
    /** -1 (route is far to the left of the truck) .. +1 (far to the right). */
    val offset: Float,
    /** 0 (route continues straight ahead) .. 1 (route bends sharply further ahead). */
    val curvature: Float,
    /** 0..1: how much route-coloured evidence there was. */
    val confidence: Float,
    /** False when no route pixels are visible far ahead (route is ending: destination close, or lost). */
    val farVisible: Boolean,
    /** Signed version of [curvature]: positive = the road veers right further ahead, negative = left. */
    val bend: Float = 0f,
)

/** A located thing of interest, normalised coordinates. */
data class Target(val x: Float, val y: Float, val strength: Float)

/** Everything the agents may ask about the current frame. Faked in unit tests. */
interface Vision {
    /** Best match of a named template inside its calibrated region, or null if absent / below its threshold / not calibrated. */
    fun find(name: String): Match?

    fun findAll(name: String, max: Int = 8): List<Match>

    /** True if the named template or colour is part of the calibrated profile at all. */
    fun known(name: String): Boolean

    fun color(name: String): Blob?

    fun route(): RouteReading?

    /** Motion proxy 0..1 (see [MotionEstimator]). */
    fun motion(): Float

    fun has(name: String): Boolean = find(name) != null

    /** Locate by template first, then by colour region. */
    fun locate(name: String): Target? {
        find(name)?.let { return Target(it.x, it.y, it.score) }
        val b = color(name)
        if (b != null && b.found && b.fraction >= 0.002f) return Target(b.cx, b.cy, b.fraction)
        return null
    }
}

/** Caches template images rescaled to the live frame width. */
class TemplateProvider(private val store: TemplateStore, private val referenceWidth: Int) {
    private val cache = HashMap<String, GrayImage?>()

    fun get(name: String, frameWidth: Int): GrayImage? = cache.getOrPut("$name@$frameWidth") {
        val base = store.gray(name) ?: return@getOrPut null
        if (referenceWidth <= 0 || referenceWidth == frameWidth) {
            base
        } else {
            val s = frameWidth.toFloat() / referenceWidth
            val w = maxOf(2, Math.round(base.width * s))
            val h = maxOf(2, Math.round(base.height * s))
            base.resize(w, h)
        }
    }

    private val maskCache = HashMap<String, GrayImage?>()

    /**
     * The "steady pixels" mask saved beside [name] (see [MASK_SUFFIX]), scaled like the template; null when the template was
     * saved without one (a single picture, or an older profile), in which case matching uses every pixel as before.
     */
    fun maskFor(name: String, frameWidth: Int): GrayImage? = maskCache.getOrPut("$name@$frameWidth") {
        val m = store.gray(name + MASK_SUFFIX) ?: return@getOrPut null
        if (referenceWidth <= 0 || referenceWidth == frameWidth) m else {
            val s = frameWidth.toFloat() / referenceWidth
            m.resize(maxOf(2, Math.round(m.width * s)), maxOf(2, Math.round(m.height * s)))
        }
    }

    /** All hits of template [name] in [gray] (inside [roi], at least [minScore]): over the steady pixels only when a mask exists. */
    fun all(gray: GrayImage, name: String, frameWidth: Int, roi: Roi, minScore: Float, max: Int, masked: Boolean = true): List<Match> {
        val tpl = get(name, frameWidth) ?: return emptyList()
        val mask = if (masked) maskFor(name, frameWidth) else null
        return if (mask != null && TemplateMatcher.maskUsable(tpl, mask)) TemplateMatcher.allMasked(gray, tpl, mask, roi, minScore, max) else TemplateMatcher.all(gray, tpl, roi, minScore, max)
    }

    /** Best hit regardless of threshold (for diagnostics and control checks). */
    fun best(gray: GrayImage, name: String, frameWidth: Int, roi: Roi, masked: Boolean = true): Match? = all(gray, name, frameWidth, roi, -1f, 1, masked).firstOrNull()

    /** True when [name] is matched over its steady pixels only. */
    fun isMasked(name: String, frameWidth: Int): Boolean {
        val t = get(name, frameWidth) ?: return false
        val m = maskFor(name, frameWidth) ?: return false
        return TemplateMatcher.maskUsable(t, m)
    }

    fun clear() {
        cache.clear()
        maskCache.clear()
    }

    companion object {
        /** A template's mask is stored as another template with this suffix (so it travels with the profile everywhere). */
        const val MASK_SUFFIX = "_mask"
    }
}

/** [Vision] backed by a calibrated [GameProfile] and one captured [Frame]. Results are cached per frame. */
class ProfileVision(
    private val profile: GameProfile,
    private val templates: TemplateProvider,
    private val frame: Frame,
    private val motionProvider: () -> Float,
    private val routeEstimator: RouteEstimator?,
) : Vision {
    private val gray by lazy { frame.toGray() }
    private val matchCache = HashMap<String, List<Match>>()
    private val colorCache = HashMap<String, Blob?>()
    private var routeComputed = false
    private var routeValue: RouteReading? = null

    private fun matches(name: String): List<Match> = matchCache.getOrPut(name) {
        val spec = profile.templates[name] ?: return@getOrPut emptyList()
        // Only a mask the PROFILE lists belongs to this patch (an old one left in the store must not be applied to a new patch).
        templates.all(gray, name, frame.width, spec.roi, spec.minScore, 16, masked = profile.templates.containsKey(name + TemplateProvider.MASK_SUFFIX))
    }

    override fun find(name: String): Match? = matches(name).firstOrNull()

    override fun findAll(name: String, max: Int): List<Match> = matches(name).take(max)

    override fun known(name: String): Boolean = profile.templates.containsKey(name) || profile.colors.containsKey(name)

    override fun color(name: String): Blob? = colorCache.getOrPut(name) {
        val spec = profile.colors[name] ?: return@getOrPut null
        ColorMask.measure(frame, spec.roi, spec.target, step = 2)
    }

    override fun route(): RouteReading? {
        if (!routeComputed) {
            routeValue = routeEstimator?.read(frame)
            routeComputed = true
        }
        return routeValue
    }

    override fun motion(): Float = motionProvider()
}
