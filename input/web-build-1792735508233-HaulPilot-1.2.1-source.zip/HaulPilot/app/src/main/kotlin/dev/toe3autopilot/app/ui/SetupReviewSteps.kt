package dev.toe3autopilot.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.toe3autopilot.app.AutopilotRuntime
import dev.toe3autopilot.app.setup.SaveOutcome
import dev.toe3autopilot.app.setup.SaveTarget
import dev.toe3autopilot.core.calibration.CalibRole
import dev.toe3autopilot.core.calibration.ControlDetection
import dev.toe3autopilot.core.calibration.DetectionSource
import dev.toe3autopilot.core.calibration.DetectionStatus
import dev.toe3autopilot.core.profile.SteeringMode
import dev.toe3autopilot.core.setup.DraftEdits
import dev.toe3autopilot.core.setup.IssueSeverity
import dev.toe3autopilot.core.setup.SetupPhase
import dev.toe3autopilot.core.setup.SetupState

// ---- step 5: review candidates ---------------------------------------------------------------------------------------

@Composable
fun StepReview(env: UiEnv, state: SetupState) {
    val d = state.draft
    val sel = state.selectedFrame
    if (!d.analysed) {
        EmptyState(
            Glyph.TARGET, if (d.analysisSkipped) "Analysis skipped" else "Nothing analysed yet",
            if (d.analysisSkipped) "There are no candidates to review. Place the controls by hand." else "Run the analysis (step 4) to get candidates, or place the controls by hand (step 6).",
            if (d.analysisSkipped) "Place controls" else "Go to step 4",
        ) { env.nav.setupStep = if (d.analysisSkipped) SETUP_STEP_PLACE else SETUP_STEP_ANALYZE }
        return
    }
    BodyText("A candidate is only a proposal from the picture's shapes. Check where it sits on the picture, then confirm it, move it to the right spot, or reject it. Nothing is used until you confirm it.")
    if (sel != null) AnnotatedPicture(sel.frame, d, onClick = { env.nav.editor = EditorRequest(EditorMode.CONTROL, d.pendingCandidates.firstOrNull()?.role ?: CalibRole.ACCELERATOR) })
    val shown = d.controls.values.sortedBy { it.role.ordinal }
    if (shown.isEmpty()) {
        Banner(Tone.INFO, "No candidates were found", "That is normal when the controls are faint or the pictures were taken while standing still. Place them by hand.", "Place controls", { env.nav.setupStep = SETUP_STEP_PLACE })
    }
    shown.forEach { c -> CandidateCard(env, state, c) }
    val mm = d.minimap
    if (mm.box != null && !mm.boxConfirmed) {
        Banner(Tone.ATTENTION, "A minimap candidate was found", mm.note, "Check it in step 7", { env.nav.setupStep = SETUP_STEP_MINIMAP })
    }
    if (d.pendingCandidates.isEmpty() && shown.isNotEmpty()) {
        HpButton("Continue to placing", { env.nav.setupStep = SETUP_STEP_PLACE }, Modifier.fillMaxWidth())
    }
}

private fun sourceText(s: DetectionSource): String = when (s) {
    DetectionSource.SHAPE -> "From the shape of a fixed on-screen element"
    DetectionSource.USER -> "Placed or confirmed by you"
    DetectionSource.VIDEO -> "From a recorded clip"
    DetectionSource.DEMONSTRATION -> "From a demonstration"
    DetectionSource.PRIOR -> "A typical-layout guess"
}

@Composable
private fun CandidateCard(env: UiEnv, state: SetupState, c: ControlDetection) {
    val (word, tone) = when (c.status) {
        DetectionStatus.NONE -> "Not found" to Tone.NEUTRAL
        DetectionStatus.NEEDS_CONFIRMATION -> "Needs your check" to Tone.ATTENTION
        DetectionStatus.AUTO_CONFIRMED, DetectionStatus.CONFIRMED -> "Confirmed" to Tone.GOOD
        DetectionStatus.REJECTED -> "Rejected" to Tone.BAD
    }
    val busy = state.phase == SetupPhase.ANALYZING
    fun edit(done: String, f: (dev.toe3autopilot.core.setup.SetupDraft) -> dev.toe3autopilot.core.setup.SetupDraft) {
        if (AutopilotRuntime.setup.edit(f)) env.toast(done) else env.toast("Wait until the analysis has finished.")
    }
    HpCard(accent = if (c.status == DetectionStatus.NEEDS_CONFIRMATION) Hp.Warning else null) {
        SectionHeader(c.role.label, trailing = { StatusPill(word, tone) })
        if (c.status != DetectionStatus.NONE) {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                SmallText("Evidence strength (not a probability)")
                Meter(c.confidence, if (c.status.usable) Hp.Success else Hp.Warning, Modifier.fillMaxWidth())
            }
            SmallText(sourceText(c.source) + " · at ${pct(c.x)} across, ${pct(c.y)} down")
        }
        c.evidence.take(4).forEach { e -> SmallText("• $e", color = Hp.TextSecondary) }
        if (c.alternatives.isNotEmpty()) SmallText("${c.alternatives.size} other possible spot(s) were considered.")
        val open = { env.nav.editor = EditorRequest(EditorMode.CONTROL, c.role) }
        when (c.status) {
            DetectionStatus.NEEDS_CONFIRMATION -> Row(horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
                HpButton("Confirm", { edit("${c.role.label} confirmed.") { DraftEdits.confirm(it, c.role) } }, Modifier.weight(1f), enabled = !busy, glyph = Glyph.CHECK)
                HpButton("Move", open, Modifier.weight(1f), kind = BtnKind.SECONDARY, enabled = !busy, glyph = Glyph.TARGET)
                HpButton("Reject", { edit("${c.role.label} rejected.") { DraftEdits.reject(it, c.role) } }, kind = BtnKind.GHOST, enabled = !busy)
            }
            DetectionStatus.NONE, DetectionStatus.REJECTED -> HpButton("Place by hand", open, kind = BtnKind.SECONDARY, enabled = !busy, glyph = Glyph.TARGET)
            else -> Row(horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
                HpButton("Adjust", open, kind = BtnKind.SECONDARY, enabled = !busy, glyph = Glyph.TARGET)
                HpButton("Reset", { edit("${c.role.label} reset. Undo brings it back.") { DraftEdits.reset(it, c.role) } }, kind = BtnKind.GHOST, enabled = !busy)
            }
        }
    }
}

// ---- step 6: place / correct ----------------------------------------------------------------------------------------

@Composable
fun StepPlace(env: UiEnv, state: SetupState) {
    val d = state.draft
    val sel = state.selectedFrame
    if (sel == null) {
        EmptyState(Glyph.IMAGE, "Choose the driving screen first", "Controls are placed on the chosen picture of the normal driving view.", "Go to step 3") { env.nav.setupStep = SETUP_STEP_SCREEN }
        return
    }
    var confirmResetAll by rememberSaveable { mutableStateOf(false) }
    val busy = state.phase == SetupPhase.ANALYZING
    BodyText("Tap a control to open the editor. Zoom in with two fingers to place it exactly; a loupe shows the pixels under the crosshair.")

    HpCard {
        SectionHeader("Steering", subtitle = "How steering works in your game layout")
        Row(horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
            SteeringOption("Steering wheel", "Drag sideways", Glyph.WHEEL, d.steering == SteeringMode.SLIDER, Modifier.weight(1f)) {
                AutopilotRuntime.setup.edit { DraftEdits.chooseSteering(it, SteeringMode.SLIDER) }
            }
            SteeringOption("Left / right buttons", "Hold a button", Glyph.ARROW_LEFT, d.steering == SteeringMode.BUTTONS, Modifier.weight(1f)) {
                AutopilotRuntime.setup.edit { DraftEdits.chooseSteering(it, SteeringMode.BUTTONS) }
            }
        }
        if (d.steering == null) SmallText("Not chosen yet. Confirming a wheel or an arrow button also chooses it.")
        if (d.steering == SteeringMode.SLIDER) {
            val r = d.steerRadius ?: DraftEdits.DEFAULT_STEER_RADIUS
            SliderRow("Steering range", "± ${pct(r)} of the width", r, 0.03f..0.3f, subtitle = "How far HaulPilot drags sideways from the wheel's centre for full lock.") { v ->
                AutopilotRuntime.setup.edit { DraftEdits.setSteerRadius(it, v) }
            }
        }
    }

    AnnotatedPicture(sel.frame, d, onClick = { env.nav.editor = EditorRequest(EditorMode.CONTROL, firstMissing(d)) })

    HpCard {
        SectionHeader("Controls", subtitle = if (d.missingRequired.isEmpty()) "Everything needed is confirmed" else "Still needed: ${d.missingRequired.joinToString()}")
        val roles = if (d.steering == null) editorRoles(d) else setupRoles(d.steering)
        roles.forEach { r -> ControlRow(env, d.controls[r], r, required = r in d.requiredRoles || (d.steering == null && r != CalibRole.GEAR_REVERSE), busy = busy) }
        HpButton("Open the editor", { env.nav.editor = EditorRequest(EditorMode.CONTROL, firstMissing(d)) }, Modifier.fillMaxWidth(), enabled = !busy, glyph = Glyph.TARGET)
        HpButton("Reset all controls…", { confirmResetAll = true }, kind = BtnKind.GHOST, enabled = !busy && d.controls.isNotEmpty(), glyph = Glyph.REFRESH)
    }
    if (confirmResetAll) {
        ConfirmDialog(
            "Reset all controls?",
            "Every placed, confirmed, candidate and rejected control in this setup goes back to missing, and the steering choice is cleared. The minimap and the picture are kept. Undo can bring them back; saved profiles are not changed.",
            "Reset controls", { confirmResetAll = false }, danger = true,
        ) {
            confirmResetAll = false
            AutopilotRuntime.setup.edit { it.copy(controls = emptyMap(), steering = null, steerRadius = null) }
            env.toast("All controls reset. Undo brings them back.")
        }
    }
}

private fun firstMissing(d: dev.toe3autopilot.core.setup.SetupDraft): CalibRole =
    editorRoles(d).firstOrNull { d.controls[it]?.status?.usable != true } ?: CalibRole.ACCELERATOR

@Composable
private fun SteeringOption(title: String, sub: String, glyph: Glyph, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(Sp.radiusM)
    Row(
        modifier
            .clip(shape)
            .background(if (selected) Hp.Accent.copy(alpha = 0.12f) else Hp.Raised)
            .border(if (selected) 2.dp else 1.dp, if (selected) Hp.Accent else Hp.Border, shape)
            .selectable(selected, role = Role.RadioButton, onClick = onClick)
            .heightIn(min = 64.dp)
            .padding(Sp.m),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(Sp.s),
    ) {
        HpIcon(glyph, tint = if (selected) Hp.Accent else Hp.TextSecondary, size = 22.dp)
        Column {
            Text(title, style = MaterialTheme.typography.titleSmall, color = Hp.Text)
            SmallText(sub)
        }
    }
}

@Composable
private fun ControlRow(env: UiEnv, c: ControlDetection?, role: CalibRole, required: Boolean, busy: Boolean) {
    val (dot, word) = when {
        c == null || c.status == DetectionStatus.NONE -> Hp.TextMuted to "Missing"
        c.status.usable -> Hp.Success to (if (c.source == DetectionSource.USER && c.evidence.contains("placed by you")) "Placed by you" else "Confirmed")
        c.status == DetectionStatus.NEEDS_CONFIRMATION -> Hp.Warning to "Candidate: check it"
        else -> Hp.Danger to "Rejected"
    }
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(Sp.radiusM))
            .clickable(enabled = !busy, role = Role.Button) { env.nav.editor = EditorRequest(EditorMode.CONTROL, role) }
            .heightIn(min = 56.dp)
            .padding(vertical = Sp.xs),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(Sp.m),
    ) {
        Box(Modifier.size(10.dp).clip(CircleShape).background(dot))
        Column(Modifier.weight(1f)) {
            Text(role.label + if (required) "" else " (optional)", style = MaterialTheme.typography.titleSmall, color = Hp.Text)
            SmallText(word + (c?.takeIf { it.status != DetectionStatus.NONE }?.let { " · ${pct(it.x)} across, ${pct(it.y)} down" } ?: ""))
        }
        if (c != null && c.status != DetectionStatus.NONE) {
            IconAction(Glyph.REFRESH, "Reset ${role.label}", {
                if (AutopilotRuntime.setup.edit { DraftEdits.reset(it, role) }) env.toastWithUndo("${role.label} reset.") { AutopilotRuntime.setup.undo() }
            }, enabled = !busy)
        }
        HpIcon(Glyph.CHEVRON, tint = Hp.TextMuted, size = 18.dp)
    }
}

// ---- step 7: minimap -------------------------------------------------------------------------------------------------

@Composable
fun StepMinimap(env: UiEnv, state: SetupState) {
    val d = state.draft
    val mm = d.minimap
    val sel = state.selectedFrame
    if (sel == null) {
        EmptyState(Glyph.MAP, "Choose the driving screen first", "The minimap is marked on the chosen picture.", "Go to step 3") { env.nav.setupStep = SETUP_STEP_SCREEN }
        return
    }
    val busy = state.phase == SetupPhase.ANALYZING
    BodyText("Automatic driving follows the route line on the minimap. Everything else in the setup works without it, so you can skip this step and come back later.")
    AnnotatedPicture(sel.frame, d, onClick = { env.nav.editor = EditorRequest(EditorMode.MINIMAP_BOX) })
    HpCard {
        SectionHeader("Minimap", trailing = {
            StatusPill(
                when {
                    mm.complete -> "Done"
                    mm.skipped -> "Skipped"
                    else -> "To do"
                },
                when {
                    mm.complete -> Tone.GOOD
                    mm.skipped -> Tone.NEUTRAL
                    else -> Tone.ACTIVE
                },
            )
        })
        CheckLine(
            if (mm.box != null && mm.boxConfirmed) true else if (mm.box != null) false else null,
            "1. The minimap area",
            when {
                mm.box == null -> "Draw a box around the whole minimap."
                !mm.boxConfirmed -> "Suggested by the analysis (${mm.note ?: "changing content with vivid colours"}). Check that it covers the whole map."
                else -> "Marked."
            },
            if (mm.box != null && !mm.boxConfirmed) "Check the suggestion" else if (mm.box == null) "Mark the minimap" else "Adjust",
            { env.nav.editor = EditorRequest(EditorMode.MINIMAP_BOX) },
        )
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(Sp.m)) {
            Box(Modifier.weight(1f)) {
                CheckLine(
                    if (mm.routeColor != null) true else null, "2. The route colour",
                    if (mm.routeColor == null) "Tap the coloured route line on the minimap." else "Picked.",
                    if (mm.routeColor == null) "Pick the colour" else "Pick again",
                    { env.nav.editor = EditorRequest(EditorMode.ROUTE_COLOR) },
                )
            }
            mm.routeColor?.let { c ->
                Box(Modifier.size(32.dp).clip(RoundedCornerShape(Sp.radiusS)).background(Color(c.r, c.g, c.b)).border(1.dp, Hp.Border, RoundedCornerShape(Sp.radiusS)))
            }
        }
        CheckLine(
            if (mm.truck != null && mm.box != null && mm.boxConfirmed) true else null, "3. Your truck on the minimap",
            when {
                mm.truck == null -> "Put the crosshair on your truck's arrow."
                !mm.boxConfirmed -> "Suggested in the lower middle of the map; check it."
                else -> "Marked."
            },
            if (mm.truck == null) "Mark the truck" else "Adjust",
            { env.nav.editor = EditorRequest(EditorMode.TRUCK) },
        )
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(Sp.m)) {
            Box(Modifier.weight(1f)) {
                CheckLine(
                    if (mm.destinationColor != null) true else null, "4. Destination marker (optional)",
                    if (mm.destinationColor == null) "Without it the truck follows the route until it ends and then asks you. With it, it slows down near the destination and stops there." else "Picked.",
                    if (mm.destinationColor == null) "Pick the marker" else "Change",
                    { env.nav.editor = EditorRequest(EditorMode.DESTINATION) },
                )
            }
            mm.destinationColor?.let { c ->
                Box(Modifier.size(32.dp).clip(RoundedCornerShape(Sp.radiusS)).background(Color(c.r, c.g, c.b)).border(1.dp, Hp.Border, RoundedCornerShape(Sp.radiusS)))
            }
        }
        SmallText("The minimap must turn with the truck (heading-up: the truck always points up). A north-up map is not supported.")
        Row(horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
            if (!mm.skipped && !mm.complete) {
                HpButton("Skip for now", {
                    if (AutopilotRuntime.setup.edit { DraftEdits.skipMinimap(it) }) env.toast("Minimap skipped. Automatic driving will need it later.")
                }, kind = BtnKind.SECONDARY, enabled = !busy)
            }
            if (mm.box != null || mm.routeColor != null || mm.truck != null || mm.skipped) {
                HpButton("Clear minimap", {
                    if (AutopilotRuntime.setup.edit { DraftEdits.clearMinimap(it) }) env.toastWithUndo("Minimap cleared.") { AutopilotRuntime.setup.undo() }
                }, kind = BtnKind.GHOST, enabled = !busy)
            }
        }
    }
    HpCard {
        SectionHeader(
            "Driving-screen marker",
            subtitle = when {
                d.marker == null -> "None: a confirmed pedal will be used"
                d.markerSource == DetectionSource.USER -> "Marked by you"
                else -> "Found by the analysis"
            },
        )
        BodyText("A small part of the dashboard that never changes while driving. HaulPilot compares it with the live picture to know the normal driving view is showing before it presses anything.")
        Row(horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
            HpButton(if (d.marker == null) "Mark it" else "Adjust", { env.nav.editor = EditorRequest(EditorMode.MARKER) }, kind = BtnKind.SECONDARY, enabled = !busy)
            if (d.marker != null) {
                HpButton("Remove", {
                    if (AutopilotRuntime.setup.edit { it.copy(marker = null, markerSource = null) }) env.toastWithUndo("Screen marker removed.") { AutopilotRuntime.setup.undo() }
                }, kind = BtnKind.GHOST, enabled = !busy)
            }
        }
    }
}

// ---- step 8: validate ------------------------------------------------------------------------------------------------

@Composable
fun StepValidate(env: UiEnv, state: SetupState) {
    val d = state.draft
    val busy = state.phase.busy
    HpCard {
        SectionHeader("This setup")
        InfoRow("Driving picture", state.selectedFrame?.let { "#${it.id} (${it.frame.width}×${it.frame.height})" + if (d.drivingConfirmed) "" else ", not confirmed" } ?: "none")
        InfoRow("Confirmed controls", "${d.confirmedCount}")
        InfoRow("Steering", when (d.steering) { SteeringMode.SLIDER -> "Wheel"; SteeringMode.BUTTONS -> "Buttons"; null -> "not chosen" })
        InfoRow("Minimap", when { d.minimap.complete -> "complete"; d.minimap.skipped -> "skipped"; d.minimap.box != null -> "incomplete"; else -> "not set" })
        InfoRow("Screen marker", if (d.marker != null) "set" else "none (pedal used)")
        HpButton("Check for problems", { AutopilotRuntime.setup.validate() }, Modifier.fillMaxWidth(), enabled = !busy, glyph = Glyph.SHIELD)
        if (busy) SmallText("Available when nothing is being collected or analysed.")
    }
    if (state.issues.isNotEmpty() || state.validatedCurrent) {
        if (!state.validatedCurrent) Banner(Tone.INFO, "These results are out of date", "The setup changed after the last check. Check again.")
        val errors = state.issues.filter { it.severity == IssueSeverity.ERROR }
        val warnings = state.issues.filter { it.severity == IssueSeverity.WARNING }
        if (state.validatedCurrent && errors.isEmpty()) {
            Banner(Tone.GOOD, "No blocking problems", if (warnings.isEmpty()) "You can save the profile." else "${warnings.size} warning(s) below; you can still save.", "Go to Save", { env.nav.setupStep = SETUP_STEP_SAVE })
        }
        if (errors.isNotEmpty()) {
            HpCard(accent = Hp.Danger) {
                SectionHeader("Must be fixed (${errors.size})")
                errors.forEach { i -> CheckLine(false, i.message, null, i.role?.let { "Fix ${it.label}" }, i.role?.let { r -> { env.nav.editor = EditorRequest(EditorMode.CONTROL, r) } }) }
            }
        }
        if (warnings.isNotEmpty()) {
            HpCard(accent = Hp.Warning) {
                SectionHeader("Worth checking (${warnings.size})")
                warnings.forEach { i -> CheckLine(false, i.message, null, i.role?.let { "Check ${it.label}" }, i.role?.let { r -> { env.nav.editor = EditorRequest(EditorMode.CONTROL, r) } }) }
            }
        }
    }
    val forDriving = d.missingRequired + listOfNotNull(if (!d.minimap.complete) "Minimap, route colour and truck" else null)
    if (forDriving.isNotEmpty()) {
        HpCard {
            SectionHeader("Still needed for Auto Drive")
            SmallText("You can save without these; Start Auto Drive stays unavailable until they are set.")
            forDriving.forEach { CheckLine(null, it) }
        }
    }
}

// ---- step 9: save ----------------------------------------------------------------------------------------------------

@Composable
fun StepSave(env: UiEnv, state: SetupState) {
    val profiles by AutopilotRuntime.profileList.collectAsStateWithLifecycle()
    val targets = profiles.filter { it.readable }
    val active = targets.firstOrNull { it.active }
    // null = a new profile.
    var chosenId by rememberSaveable { mutableStateOf(active?.id) }
    val targetId = chosenId?.takeIf { id -> targets.any { it.id == id } }
    var name by rememberSaveable { mutableStateOf("") }
    var saving by remember { mutableStateOf(false) }
    var outcome by remember { mutableStateOf<SaveOutcome?>(null) }
    val nameOk = name.isNotBlank() && profiles.none { it.name.equals(name.trim(), ignoreCase = true) }
    val useNew = targetId == null

    if (!state.canSave && outcome == null) {
        Banner(
            Tone.ATTENTION, if (state.validatedCurrent) "Fix the problems first" else "Check the setup first",
            "Saving is possible once the check in step 8 finds no blocking problem.", "Go to step 8", { env.nav.setupStep = SETUP_STEP_VALIDATE },
        )
    }
    HpCard {
        SectionHeader("Save to", subtitle = "The profile you save to becomes the active one")
        targets.forEach { p ->
            SaveChoice(
                targetId == p.id, "Update \"${p.name}\"" + if (p.active) " (active)" else "",
                "Replaces its controls and minimap. The version before is kept: Profiles → Undo last change.",
            ) { chosenId = p.id }
        }
        SaveChoice(useNew, "A new profile", "Keeps every existing profile as it is.") { chosenId = null }
        if (useNew) {
            OutlinedTextField(
                value = name, onValueChange = { name = it.take(60) }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                label = { Text("Profile name") }, placeholder = { Text("For example: TOE3 landscape") },
                isError = name.isNotBlank() && !nameOk,
                supportingText = { if (name.isNotBlank() && !nameOk) Text("A profile with this name exists already") },
            )
        }
        HpButton(
            if (saving) "Saving…" else "Save and make it active",
            {
                val target = targetId?.let { SaveTarget.Existing(it) } ?: SaveTarget.New(name.trim())
                saving = true
                AutopilotRuntime.ioScope.launchSafely {
                    try {
                        val r = AutopilotRuntime.setup.save(target)
                        outcome = r
                        AutopilotRuntime.notice.value = r.message
                    } finally {
                        saving = false
                    }
                }
            },
            Modifier.fillMaxWidth(), enabled = state.canSave && !saving && (!useNew || nameOk), glyph = Glyph.CHECK,
        )
        if (useNew && !nameOk && state.canSave) SmallText("Enter a new name to save.")
    }
    outcome?.let { o ->
        HpCard(accent = if (o.ok) Hp.Success else Hp.Danger) {
            SectionHeader(if (o.ok) "Saved" else "Not saved")
            BodyText(o.message, color = Hp.Text)
            if (o.applied.isNotEmpty()) {
                SmallText("Saved:")
                o.applied.forEach { CheckLine(true, it) }
            }
            if (o.skipped.isNotEmpty()) {
                SmallText("Not saved (not confirmed):")
                o.skipped.forEach { CheckLine(null, it) }
            }
            o.warnings.forEach { SmallText("• $it", color = Hp.Warning) }
            if (o.notReadyToDrive.isNotEmpty()) {
                SmallText("Auto Drive still needs:")
                o.notReadyToDrive.forEach { CheckLine(false, it) }
            }
            if (o.ok) HpButton("Next: test it safely", { env.nav.setupStep = SETUP_STEP_TEST }, Modifier.fillMaxWidth())
        }
    }
}

@Composable
private fun SaveChoice(selected: Boolean, title: String, sub: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(Sp.radiusM))
            .selectable(selected, role = Role.RadioButton, onClick = onClick)
            .heightIn(min = 56.dp)
            .padding(vertical = Sp.xs),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(Sp.s),
    ) {
        RadioButton(selected = selected, onClick = null, colors = RadioButtonDefaults.colors(selectedColor = Hp.Accent, unselectedColor = Hp.TextSecondary))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall, color = Hp.Text)
            SmallText(sub)
        }
    }
}

// ---- step 10: test -----------------------------------------------------------------------------------------------------

@Composable
fun StepTest(env: UiEnv, state: SetupState) {
    val gameView by AutopilotRuntime.gameView.collectAsStateWithLifecycle()
    val captureOn by AutopilotRuntime.captureActive.collectAsStateWithLifecycle()
    var running by remember { mutableStateOf(false) }
    val saved = state.phase == SetupPhase.CONFIRMED && !state.dirty
    if (!saved) {
        Banner(Tone.ATTENTION, "Save the setup first", "The test checks the saved, active profile.", "Go to step 9", { env.nav.setupStep = SETUP_STEP_SAVE })
    }
    HpCard {
        SectionHeader("Safe test", subtitle = "No touches are sent")
        BodyText("The test checks the saved profile against the newest picture of the game: is the screen shape the same, is the driving screen recognised, are the controls where the profile says?")
        SmallText("Open the game on the normal driving view with the screen connected, come back here within 15 seconds and run the test.")
        val age = gameView?.let { (System.currentTimeMillis() - it.timestampMs).coerceAtLeast(0) }
        InfoRow(
            "Newest picture of the game",
            when {
                !captureOn -> "screen not connected"
                age == null -> "none yet"
                else -> "${age / 1000} s ago" + if (age > 15_000) " (too old)" else ""
            },
            if (age != null && age <= 15_000 && captureOn) Hp.Success else Hp.Warning,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
            HpButton("Open the game", { env.openGame() }, Modifier.weight(1f), kind = BtnKind.SECONDARY, glyph = Glyph.PLAY)
            HpButton(
                if (running) "Testing…" else "Run the test",
                {
                    running = true
                    AutopilotRuntime.ioScope.launchSafely {
                        try {
                            AutopilotRuntime.setup.runTest()
                        } finally {
                            running = false
                        }
                    }
                },
                Modifier.weight(1f), enabled = saved && !running, glyph = Glyph.SHIELD,
            )
        }
    }
    state.test?.let { t ->
        HpCard(accent = if (t.passed) Hp.Success else Hp.Warning) {
            SectionHeader(if (t.passed) "All required checks passed" else "Some checks did not pass", subtitle = "Run at ${formatClock(t.atMs)}")
            SmallText(t.summary, color = if (t.verifiedLive) Hp.Success else Hp.Warning, maxLines = 4)
            t.checks.forEach { c -> CheckLine(c.ok, c.title + if (c.required) "" else " (optional)", c.detail) }
            if (t.passed) {
                SmallText("This shows recognition works on this picture. It does not prove the game will react to every touch; stay ready to take over on the first drive.")
                HpButton("Go to the Dashboard", { env.nav.open(Tab.DASHBOARD) }, Modifier.fillMaxWidth())
            }
        }
    }
}
