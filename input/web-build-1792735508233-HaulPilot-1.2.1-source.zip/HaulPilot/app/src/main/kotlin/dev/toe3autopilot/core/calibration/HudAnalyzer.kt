package dev.toe3autopilot.core.calibration

import dev.toe3autopilot.core.vision.Frame
import dev.toe3autopilot.core.vision.Roi
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Finds on-screen elements that stay in place while the scenery moves (buttons, wheels, readouts, minimap frames).
 *
 * Method: over a sequence of frames, count how often each pixel lies on a strong edge. Pixels that are on an edge in
 * (almost) every frame belong to something that does not move with the world, i.e. an overlay. Nearby persistent
 * edge pixels are grouped into elements. Using edges instead of flat colours lets semi-transparent buttons work,
 * as long as their outline survives the changing background.
 *
 * What this CANNOT do: tell what an element is. Meaning comes from [ControlCandidateDetector] (shape and arrangement,
 * always to be confirmed) or from the person. A static scene (menu, paused game, parked truck with a still camera) gives no information, and the
 * analysis says so instead of guessing.
 */
object HudAnalyzer {
    const val MIN_FRAMES = 10
    const val MIN_SCENE_CHANGE = 0.04f
    private const val EDGE_THRESHOLD = 32
    private const val PERSISTENCE_THRESHOLD = 0.8f
    private const val MAX_ELEMENTS = 32
    private const val CORE_ERODE = 2
    private const val SPLIT_REACH = 4
    private const val REGROUP_MARGIN = 2
    private const val INFORMATIVE_CHANGE = 0.02
    private const val MIN_INFORMATIVE = 6
    private const val MIN_EDGE_DENSITY = 0.04f

    fun analyse(frames: List<Frame>): HudAnalysis {
        if (frames.isEmpty()) return failed(0, 0, 0, 0f, "No frames to analyse")
        val w = frames.last().width
        val h = frames.last().height
        val used = frames.filter { it.width == w && it.height == h }
        if (used.size < MIN_FRAMES) {
            return failed(w, h, used.size, 0f, "Need at least $MIN_FRAMES frames of the same size, have ${used.size}")
        }
        val n = used.size
        val grays = used.map { it.toGray().px }

        // 1. Is the scene changing enough to tell overlay from world? Only pictures that differ from the one before are
        //    informative: while the truck stands still EVERYTHING keeps its edges, so a still picture says nothing about
        //    what is an overlay and would make scenery edges look persistent.
        var changeSum = 0.0
        val informative = ArrayList<IntArray>()
        for (k in 1 until n) {
            val a = grays[k - 1]
            val b = grays[k]
            var c = 0
            for (i in a.indices) if (abs(a[i] - b[i]) > 10) c++
            val change = c.toDouble() / a.size
            changeSum += change
            if (change >= INFORMATIVE_CHANGE) informative += b
        }
        val sceneChange = (changeSum / (n - 1)).toFloat()
        if (sceneChange < MIN_SCENE_CHANGE || informative.size < MIN_INFORMATIVE) {
            return failed(
                w, h, n, sceneChange,
                "The picture barely changes (${(sceneChange * 100).roundToInt()}%), so fixed buttons cannot be told apart from the background. " +
                    "Drive or turn the camera while observing.",
            )
        }

        // 2. Edge persistence. An overlay edge keeps both its position AND its direction (bright-to-dark stays
        //    bright-to-dark); an edge of the moving world flips direction at random, so counting the four
        //    directions separately suppresses scenery that happens to have edges at the same place now and then.
        val counts = Array(4) { IntArray(w * h) }
        val nInf = informative.size
        for (g in informative) {
            for (y in 1 until h - 1) {
                val row = y * w
                for (x in 1 until w - 1) {
                    val i = row + x
                    val gx = g[i + 1] - g[i - 1]
                    val gy = g[i + w] - g[i - w]
                    if (abs(gx) + abs(gy) > EDGE_THRESHOLD) {
                        val cls = if (abs(gx) >= abs(gy)) (if (gx > 0) 0 else 1) else (if (gy > 0) 2 else 3)
                        counts[cls][i]++
                    }
                }
            }
        }
        // Classes 0/1 = gradient mostly +x / -x, 2/3 = mostly +y / -y. A curved outline (a wheel rim) changes class around
        // the 45-degree points, where frame-to-frame noise decides between two NEIGHBOURING classes; counting the best pair
        // of neighbouring classes keeps such rims whole. Scenery edges flip between OPPOSITE classes and still fail.
        val count = IntArray(w * h) { i ->
            val c0 = counts[0][i]
            val c1 = counts[1][i]
            val c2 = counts[2][i]
            val c3 = counts[3][i]
            max(max(c0 + c2, c0 + c3), max(c1 + c2, c1 + c3))
        }
        val need = Math.ceil((PERSISTENCE_THRESHOLD * nInf).toDouble()).toInt()
        val mask = BooleanArray(w * h) { count[it] >= need }

        // 3. Group nearby persistent edge pixels (dilate, then connected components).
        // Small on purpose: neighbouring buttons (accelerator next to brake) must not be glued together.
        val r = max(1, (0.003f * max(w, h)).roundToInt())
        val dilated = dilate(mask, w, h, r)
        // "Cores": what survives eroding the dilated mask. Solid outlines (buttons, pedals, rings, map frames) keep a core;
        // a thin persistent line (the edge of a straight road seen from a chase camera, a lane line) does not. A component
        // with two or more cores is two elements joined by such a line and is split (see splitByCores).
        val core = erode(dilated, w, h, CORE_ERODE)
        val coreLabel = labelComponents(core, w, h)
        val label = IntArray(w * h)
        val stack = IntArray(w * h)
        val found = ArrayList<HudElement>()
        var next = 0
        val ctx = ElementContext(w, h, nInf, mask, count)
        for (start in dilated.indices) {
            if (!dilated[start] || label[start] != 0) continue
            next++
            var sp = 0
            stack[sp++] = start
            label[start] = next
            val pixels = ArrayList<Int>()
            val cores = HashSet<Int>()
            while (sp > 0) {
                val i = stack[--sp]
                val x = i % w
                val y = i / w
                pixels += i
                if (coreLabel[i] != 0) cores += coreLabel[i]
                if (x > 0 && dilated[i - 1] && label[i - 1] == 0) { label[i - 1] = next; stack[sp++] = i - 1 }
                if (x < w - 1 && dilated[i + 1] && label[i + 1] == 0) { label[i + 1] = next; stack[sp++] = i + 1 }
                if (y > 0 && dilated[i - w] && label[i - w] == 0) { label[i - w] = next; stack[sp++] = i - w }
                if (y < h - 1 && dilated[i + w] && label[i + w] == 0) { label[i + w] = next; stack[sp++] = i + w }
            }
            val parts = if (cores.size <= 1) emptyList() else regroup(splitByCores(pixels, coreLabel, cores, dilated, w, h), coreLabel, w)
            if (parts.size <= 1) {
                element(ctx, pixels.filter { mask[it] }, split = false)?.let { found += it }
            } else {
                for (part in parts) element(ctx, part.filter { mask[it] }, split = true)?.let { found += it }
            }
        }

        // 4. A button's icon and its ring are one control: drop elements nested inside a button-sized element.
        val byArea = found.sortedByDescending { it.areaFraction }
        val kept = ArrayList<HudElement>()
        for (e in byArea) {
            val nested = kept.any { k -> isButtonSized(k, w, h) && containedIn(e.box, k.box) }
            if (!nested) kept += e
        }
        val elements = kept.sortedByDescending { it.score }.take(MAX_ELEMENTS)
        if (elements.isEmpty()) return failed(w, h, n, sceneChange, "No persistent on-screen elements were found")
        return HudAnalysis(w, h, n, sceneChange, elements, ok = true, problem = null)
    }

    private fun failed(w: Int, h: Int, n: Int, change: Float, why: String) =
        HudAnalysis(w, h, n, change, emptyList(), ok = false, problem = why)

    private class ElementContext(val w: Int, val h: Int, val n: Int, val mask: BooleanArray, val count: IntArray)

    /** Builds an element from its persistent edge pixels, or null when they do not look like an on-screen element. */
    private fun element(c: ElementContext, edge: List<Int>, split: Boolean): HudElement? {
        val w = c.w
        val h = c.h
        if (edge.size < 10) return null
        var minX = w
        var maxX = -1
        var minY = h
        var maxY = -1
        var persSum = 0.0
        for (i in edge) {
            val x = i % w
            val y = i / w
            if (x < minX) minX = x
            if (x > maxX) maxX = x
            if (y < minY) minY = y
            if (y > maxY) maxY = y
            persSum += c.count[i].toDouble() / c.n
        }
        val bw = maxX - minX + 1
        val bh = maxY - minY + 1
        val minSide = max(6f, 0.04f * min(w, h))
        // Real overlay elements have a solid outline; random persistent specks scattered over a large box do not.
        val density = edge.size.toFloat() / (bw * bh)
        if (density < MIN_EDGE_DENSITY) return null
        if (bw < minSide || bh < minSide || bw > 0.5f * w || bh > 0.6f * h) return null
        val aspect = bw.toFloat() / bh
        val side = max(bw, bh) / min(w, h).toFloat()
        val sizeScore = when {
            side < 0.08f -> side / 0.08f
            side > 0.30f -> max(0.3f, 0.30f / side)
            else -> 1f
        }
        val shapeScore = if (aspect in 0.7f..1.43f) 1f else max(0.3f, 1f - abs(ln(aspect)) / 2f)
        val persistence = (persSum / edge.size).toFloat()
        // Ring-ness: share of edge pixels close to the ellipse inscribed in the box (1 = a ring, ~0.45 = a rectangle outline).
        val cx = (minX + maxX) / 2f
        val cy = (minY + maxY) / 2f
        val rx = max(1f, bw / 2f)
        val ry = max(1f, bh / 2f)
        var onRing = 0
        var inner = 0
        for (i in edge) {
            val dx = (i % w - cx) / rx
            val dy = (i / w - cy) / ry
            val rho = sqrt(dx * dx + dy * dy)
            if (rho in 0.72f..1.12f) onRing++
            if (rho < 0.5f) inner++
        }
        val box = Roi(minX.toFloat() / w, minY.toFloat() / h, (maxX + 1).toFloat() / w, (maxY + 1).toFloat() / h)
        return HudElement(
            box = box,
            cx = (box.left + box.right) / 2f,
            cy = (box.top + box.bottom) / 2f,
            persistence = persistence,
            aspect = aspect,
            areaFraction = (bw * bh).toFloat() / (w * h),
            score = persistence * shapeScore * sizeScore,
            ringness = onRing.toFloat() / edge.size,
            centerFill = inner.toFloat() / edge.size,
            edgeDensity = density,
            splitFromLarger = split,
        )
    }

    /**
     * Splits a component holding several cores. Every pixel is given to the core that reaches it first through the
     * component (breadth-first from all cores at once), but only within [SPLIT_REACH] pixels of a core: the long thin
     * line that joined two elements is left out instead of being attached to either of them.
     */
    private fun splitByCores(pixels: List<Int>, coreLabel: IntArray, cores: Set<Int>, inComponent: BooleanArray, w: Int, h: Int): List<List<Int>> {
        val owner = HashMap<Int, Int>(pixels.size * 2)
        val dist = HashMap<Int, Int>(pixels.size * 2)
        val queue = ArrayDeque<Int>()
        for (i in pixels) {
            val cl = coreLabel[i]
            if (cl != 0 && cl in cores) {
                owner[i] = cl
                dist[i] = 0
                queue.addLast(i)
            }
        }
        while (queue.isNotEmpty()) {
            val i = queue.removeFirst()
            val d = dist.getValue(i)
            if (d >= SPLIT_REACH) continue
            val x = i % w
            val y = i / w
            for (j in intArrayOf(if (x > 0) i - 1 else -1, if (x < w - 1) i + 1 else -1, if (y > 0) i - w else -1, if (y < h - 1) i + w else -1)) {
                if (j < 0 || !inComponent[j] || owner.containsKey(j)) continue
                owner[j] = owner.getValue(i)
                dist[j] = d + 1
                queue.addLast(j)
            }
        }
        return owner.entries.groupBy({ it.value }, { it.key }).values.toList()
    }

    /**
     * Puts split parts back together when their boxes overlap or touch: a ring whose core broke into arcs is still one
     * ring. Only parts that stand apart (two pedals joined by a road edge) stay separate.
     */
    private fun regroup(parts: List<List<Int>>, coreLabel: IntArray, w: Int): List<List<Int>> {
        if (parts.size <= 1) return parts
        // Compare the boxes of the CORES, not of the parts: each part also holds the first few pixels of the thin line
        // that joined it to its neighbour, which would make two separate pedals look as if they touched.
        val boxes = parts.map { p ->
            var x0 = Int.MAX_VALUE; var y0 = Int.MAX_VALUE; var x1 = -1; var y1 = -1
            for (i in p) {
                if (coreLabel[i] == 0) continue
                val x = i % w; val y = i / w
                if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y
            }
            intArrayOf(x0, y0, x1, y1)
        }
        val parent = IntArray(parts.size) { it }
        fun find(i: Int): Int {
            var r = i
            while (parent[r] != r) r = parent[r]
            return r
        }
        val m = REGROUP_MARGIN
        for (a in parts.indices) for (b in a + 1 until parts.size) {
            val ba = boxes[a]
            val bb = boxes[b]
            val touch = ba[0] - m <= bb[2] && bb[0] - m <= ba[2] && ba[1] - m <= bb[3] && bb[1] - m <= ba[3]
            if (touch) parent[find(a)] = find(b)
        }
        return parts.indices.groupBy { find(it) }.values.map { idx -> idx.flatMap { parts[it] } }
    }

    private fun labelComponents(m: BooleanArray, w: Int, h: Int): IntArray {
        val label = IntArray(w * h)
        val stack = IntArray(w * h)
        var next = 0
        for (start in m.indices) {
            if (!m[start] || label[start] != 0) continue
            next++
            var sp = 0
            stack[sp++] = start
            label[start] = next
            while (sp > 0) {
                val i = stack[--sp]
                val x = i % w
                val y = i / w
                if (x > 0 && m[i - 1] && label[i - 1] == 0) { label[i - 1] = next; stack[sp++] = i - 1 }
                if (x < w - 1 && m[i + 1] && label[i + 1] == 0) { label[i + 1] = next; stack[sp++] = i + 1 }
                if (y > 0 && m[i - w] && label[i - w] == 0) { label[i - w] = next; stack[sp++] = i - w }
                if (y < h - 1 && m[i + w] && label[i + w] == 0) { label[i + w] = next; stack[sp++] = i + w }
            }
        }
        return label
    }

    /** Box erosion by [r] pixels (a pixel survives only if its whole (2r+1)^2 neighbourhood is set). */
    private fun erode(mask: BooleanArray, w: Int, h: Int, r: Int): BooleanArray {
        val iw = w + 1
        val integral = IntArray(iw * (h + 1))
        for (y in 0 until h) {
            var rowSum = 0
            for (x in 0 until w) {
                if (mask[y * w + x]) rowSum++
                integral[(y + 1) * iw + (x + 1)] = integral[y * iw + (x + 1)] + rowSum
            }
        }
        val out = BooleanArray(w * h)
        val full = (2 * r + 1) * (2 * r + 1)
        for (y in r until h - r) {
            for (x in r until w - r) {
                val s = integral[(y + r + 1) * iw + (x + r + 1)] - integral[(y - r) * iw + (x + r + 1)] -
                    integral[(y + r + 1) * iw + (x - r)] + integral[(y - r) * iw + (x - r)]
                out[y * w + x] = s == full
            }
        }
        return out
    }

    private fun isButtonSized(e: HudElement, w: Int, h: Int): Boolean {
        val side = max((e.box.right - e.box.left) * w, (e.box.bottom - e.box.top) * h) / min(w, h)
        return side <= 0.30f
    }

    private fun containedIn(inner: Roi, outer: Roi): Boolean {
        val l = max(inner.left, outer.left)
        val t = max(inner.top, outer.top)
        val rr = min(inner.right, outer.right)
        val b = min(inner.bottom, outer.bottom)
        if (rr <= l || b <= t) return false
        val inter = (rr - l) * (b - t)
        val area = (inner.right - inner.left) * (inner.bottom - inner.top)
        return inter >= 0.9f * area
    }

    /** Box dilation by [r] pixels using an integral image. */
    private fun dilate(mask: BooleanArray, w: Int, h: Int, r: Int): BooleanArray {
        val iw = w + 1
        val integral = IntArray(iw * (h + 1))
        for (y in 0 until h) {
            var rowSum = 0
            for (x in 0 until w) {
                if (mask[y * w + x]) rowSum++
                integral[(y + 1) * iw + (x + 1)] = integral[y * iw + (x + 1)] + rowSum
            }
        }
        val out = BooleanArray(w * h)
        for (y in 0 until h) {
            val y0 = max(0, y - r)
            val y1 = min(h, y + r + 1)
            for (x in 0 until w) {
                val x0 = max(0, x - r)
                val x1 = min(w, x + r + 1)
                val s = integral[y1 * iw + x1] - integral[y0 * iw + x1] - integral[y1 * iw + x0] + integral[y0 * iw + x0]
                out[y * w + x] = s > 0
            }
        }
        return out
    }
}

/** Colour helper shared by the minimap detection. Nothing here guesses a control or a region from its screen position. */
object CalibrationGuesses {
    /** Most frequent vivid colour inside [box]; a guess at the route-line colour. Null if nothing vivid. */
    fun routeColorGuess(frame: Frame, box: Roi): Int? {
        val r = box.toRect(frame.width, frame.height)
        val buckets = HashMap<Int, Int>()
        var total = 0
        for (y in r.y0 until r.y1) for (x in r.x0 until r.x1) {
            total++
            val p = frame.argb[y * frame.width + x]
            val rr = (p shr 16) and 0xFF
            val gg = (p shr 8) and 0xFF
            val bb = p and 0xFF
            val mx = max(rr, max(gg, bb))
            val mn = min(rr, min(gg, bb))
            if (mx < 128 || mx == 0 || (mx - mn).toFloat() / mx < 0.5f) continue
            val key = ((rr shr 4) shl 8) or ((gg shr 4) shl 4) or (bb shr 4)
            buckets[key] = (buckets[key] ?: 0) + 1
        }
        val best = buckets.maxByOrNull { it.value } ?: return null
        if (best.value < total * 0.01f) return null
        val k = best.key
        return (((k shr 8) and 0xF) * 17 shl 16) or (((k shr 4) and 0xF) * 17 shl 8) or ((k and 0xF) * 17)
    }
}
