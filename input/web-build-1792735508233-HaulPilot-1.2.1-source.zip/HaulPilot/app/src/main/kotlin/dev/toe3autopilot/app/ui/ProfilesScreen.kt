package dev.toe3autopilot.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.toe3autopilot.app.AutopilotRuntime
import dev.toe3autopilot.core.Control
import dev.toe3autopilot.core.profile.ProfileSummary
import dev.toe3autopilot.core.profile.SteeringMode

/** What a dialog on this screen is about. */
private sealed class ProfileDialog {
    object New : ProfileDialog()
    data class Rename(val p: ProfileSummary) : ProfileDialog()
    data class Duplicate(val p: ProfileSummary) : ProfileDialog()
    data class Delete(val p: ProfileSummary) : ProfileDialog()
    data class UndoChange(val p: ProfileSummary) : ProfileDialog()
    data class Edit(val p: ProfileSummary) : ProfileDialog()
}

/**
 * Profiles: one per screen layout / game version. Create, edit (in Smart Setup), rename, duplicate, activate, export,
 * import and delete; deleting can be undone from the snackbar, and the version before the last save can be restored.
 * Nothing that would change the profile under a running drive is allowed while one runs.
 */
@Composable
fun ProfilesScreen(env: UiEnv) {
    val profiles by AutopilotRuntime.profileList.collectAsStateWithLifecycle()
    val snap by AutopilotRuntime.snapshot.collectAsStateWithLifecycle()
    val armed by AutopilotRuntime.armedMessage.collectAsStateWithLifecycle()
    val setup by AutopilotRuntime.setup.state.collectAsStateWithLifecycle()
    var dialog by remember { mutableStateOf<ProfileDialog?>(null) }
    val driving = snap.status.isActiveLoop || armed != null || snap.status == dev.toe3autopilot.core.session.SessionStatus.PAUSED ||
        snap.status == dev.toe3autopilot.core.session.SessionStatus.NEEDS_ASSIST
    val lockReason = if (driving) "Stop the drive to change profiles." else null

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = Sp.gutter, vertical = Sp.m),
        verticalArrangement = Arrangement.spacedBy(Sp.m),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
            Column(Modifier.weight(1f)) {
                Text("${profiles.size} profile(s)", style = MaterialTheme.typography.titleMedium, color = Hp.Text)
                SmallText("The active profile is the one Auto Drive uses.")
            }
            HpButton("Import", { env.actions.importProfile() }, kind = BtnKind.SECONDARY, glyph = Glyph.DOWNLOAD, enabled = !driving)
            HpButton("New", { dialog = ProfileDialog.New }, glyph = Glyph.PLUS, enabled = !driving)
        }
        if (lockReason != null) Banner(Tone.INFO, lockReason, "Profiles are read-only while a drive is running or paused.")
        if (profiles.isEmpty()) {
            EmptyState(
                Glyph.PROFILES, "No profiles yet",
                "A profile stores where the controls and the minimap are for one screen layout. Smart Setup creates one; you can also import one exported from another phone.",
                "Start Smart Setup",
            ) { env.nav.openSetup(SETUP_STEP_CONNECT) }
        }
        profiles.forEach { p -> ProfileCard(env, p, driving, setup.phase.busy) { dialog = it } }
        SmallText("Export saves a profile as a .zip (positions and small control pictures; no screenshots of your game). Import checks the file strictly before using it.")
        Spacer(Modifier.height(Sp.l))
    }

    when (val d = dialog) {
        null -> {}
        ProfileDialog.New -> NameDialog(
            "New profile", "", "Create", { dialog = null },
            validate = { n -> if (profiles.any { it.name.equals(n, ignoreCase = true) }) "That name is taken" else null },
        ) { name ->
            dialog = null
            AutopilotRuntime.ioScope.launchSafely {
                AutopilotRuntime.profiles.create(name, AutopilotRuntime.gamePackage.value)
                AutopilotRuntime.refreshProfiles()
                AutopilotRuntime.notice.value = "Created \"$name\". It is empty: set it up in Smart Setup and choose it in step 9 (Save)."
            }
        }
        is ProfileDialog.Rename -> NameDialog(
            "Rename profile", d.p.name, "Rename", { dialog = null },
            validate = { n -> if (profiles.any { it.id != d.p.id && it.name.equals(n, ignoreCase = true) }) "That name is taken" else null },
        ) { name ->
            dialog = null
            AutopilotRuntime.ioScope.launchSafely {
                val r = AutopilotRuntime.profiles.rename(d.p.id, name)
                AutopilotRuntime.refreshProfiles()
                AutopilotRuntime.notice.value = if (r.ok) "Renamed to \"$name\"." else "Not renamed: ${r.error}"
            }
        }
        is ProfileDialog.Duplicate -> NameDialog(
            "Duplicate profile", "${d.p.name} copy", "Duplicate", { dialog = null },
            validate = { n -> if (profiles.any { it.name.equals(n, ignoreCase = true) }) "That name is taken" else null },
        ) { name ->
            dialog = null
            AutopilotRuntime.ioScope.launchSafely {
                val id = AutopilotRuntime.profiles.duplicate(d.p.id, name)
                AutopilotRuntime.refreshProfiles()
                AutopilotRuntime.notice.value = if (id != null) "Copied to \"$name\"." else "The copy could not be made."
            }
        }
        is ProfileDialog.Delete -> ConfirmDialog(
            "Delete \"${d.p.name}\"?",
            (if (d.p.active) "This is the active profile; another one becomes active, or none. " else "") +
                "You can undo this right after deleting. Export it first if you want a copy.",
            "Delete", { dialog = null }, danger = true,
        ) {
            dialog = null
            AutopilotRuntime.ioScope.launchSafely {
                val del = AutopilotRuntime.profiles.delete(d.p.id)
                AutopilotRuntime.refreshProfiles()
                if (del == null) {
                    AutopilotRuntime.notice.value = "The profile could not be deleted."
                } else {
                    env.toastWithUndo("Deleted \"${del.name}\".") {
                        AutopilotRuntime.ioScope.launchSafely {
                            val ok = AutopilotRuntime.profiles.undoDelete(del)
                            AutopilotRuntime.refreshProfiles()
                            AutopilotRuntime.notice.value = if (ok) "\"${del.name}\" is back." else "It could not be restored."
                        }
                    }
                }
            }
        }
        is ProfileDialog.UndoChange -> ConfirmDialog(
            "Undo the last change to \"${d.p.name}\"?",
            "The version before the last save comes back (controls, minimap and control pictures). The current version becomes the one you can undo to.",
            "Undo last change", { dialog = null },
        ) {
            dialog = null
            AutopilotRuntime.ioScope.launchSafely {
                val r = AutopilotRuntime.profiles.undoLastChange(d.p.id)
                AutopilotRuntime.refreshProfiles()
                AutopilotRuntime.notice.value = if (r.ok) "Previous version of \"${d.p.name}\" restored." else "Not restored: ${r.error}"
            }
        }
        is ProfileDialog.Edit -> ConfirmDialog(
            "Edit \"${d.p.name}\" in Smart Setup?",
            "Its controls and minimap replace what is currently in Smart Setup" + (if (setup.dirty) " (your unsaved setup changes there can be brought back with Undo)" else "") +
                ". Nothing is saved until you save again.",
            "Edit", { dialog = null },
        ) {
            dialog = null
            val err = AutopilotRuntime.setup.editProfile(d.p.id)
            if (err != null) env.toast(err) else env.nav.openSetup(if (setup.selectedFrame != null) SETUP_STEP_PLACE else SETUP_STEP_CAPTURE)
        }
    }
}

@Composable
private fun ProfileCard(env: UiEnv, p: ProfileSummary, driving: Boolean, setupBusy: Boolean, open: (ProfileDialog) -> Unit) {
    var menu by remember { mutableStateOf(false) }
    var details by rememberSaveable(p.id) { mutableStateOf(false) }
    HpCard(accent = if (p.active) Hp.Primary else null) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(Sp.xs)) {
                Text(p.name, style = MaterialTheme.typography.titleMedium, color = Hp.Text)
                Row(horizontalArrangement = Arrangement.spacedBy(Sp.xs)) {
                    if (p.active) StatusPill("Active", Tone.ACTIVE)
                    when {
                        !p.readable -> StatusPill("Damaged", Tone.BAD)
                        p.notReady.isEmpty() -> StatusPill("Ready to drive", Tone.GOOD)
                        else -> StatusPill("${p.notReady.size} missing", Tone.ATTENTION)
                    }
                }
            }
            Box {
                IconAction(Glyph.MORE, "Actions for ${p.name}", { menu = true })
                DropdownMenu(menu, { menu = false }, containerColor = Hp.RaisedHigh) {
                    val pick = { d: ProfileDialog ->
                        menu = false
                        open(d)
                    }
                    if (p.readable) {
                        MenuItem(if (setupBusy) "Edit in Smart Setup (busy: collecting or analysing)" else "Edit in Smart Setup", !driving && !setupBusy) { pick(ProfileDialog.Edit(p)) }
                        MenuItem("Rename", !driving) { pick(ProfileDialog.Rename(p)) }
                        MenuItem("Duplicate", !driving) { pick(ProfileDialog.Duplicate(p)) }
                        MenuItem("Export as .zip") {
                            menu = false
                            env.actions.exportProfile(p.id)
                        }
                    }
                    if (p.canUndoLastChange) MenuItem("Undo last change…", !driving) { pick(ProfileDialog.UndoChange(p)) }
                    MenuItem("Delete…", !driving) { pick(ProfileDialog.Delete(p)) }
                }
            }
        }
        if (!p.readable) {
            BodyText("This profile cannot be read (${p.error ?: "unknown reason"}). " + if (p.canUndoLastChange) "Undo last change may bring back the earlier version." else "Delete it, or import a working copy.")
        } else {
            val ctrl = p.controls
            val steering = when {
                p.steering == SteeringMode.SLIDER && Control.STEER_CENTER in ctrl -> "wheel"
                p.steering == SteeringMode.BUTTONS && Control.STEER_LEFT in ctrl && Control.STEER_RIGHT in ctrl -> "buttons"
                else -> "not set"
            }
            SmallText(
                listOfNotNull(
                    p.layout?.let { "Screen $it" },
                    "pedals ${if (Control.ACCELERATOR in ctrl && Control.BRAKE in ctrl) "set" else "missing"}",
                    "steering $steering",
                    "minimap ${if (p.hasMinimap) "set" else "missing"}",
                    p.updatedMs?.let { "saved ${formatDateTime(it)}" },
                ).joinToString(" · "),
            )
            if (details && p.notReady.isNotEmpty()) {
                p.notReady.forEach { CheckLine(false, it) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(Sp.s), verticalAlignment = Alignment.CenterVertically) {
                if (!p.active) {
                    HpButton(
                        "Make active",
                        {
                            AutopilotRuntime.ioScope.launchSafely {
                                val ok = AutopilotRuntime.profiles.activate(p.id)
                                AutopilotRuntime.refreshProfiles()
                                AutopilotRuntime.notice.value = if (ok) "\"${p.name}\" is now active." else "It could not be activated."
                            }
                        },
                        kind = BtnKind.SECONDARY, enabled = !driving, glyph = Glyph.STAR,
                    )
                }
                if (p.notReady.isNotEmpty()) {
                    HpButton(if (details) "Hide what is missing" else "What is missing?", { details = !details }, kind = BtnKind.GHOST, height = 40.dp)
                }
            }
        }
    }
}

@Composable
private fun MenuItem(label: String, enabled: Boolean = true, onClick: () -> Unit) {
    DropdownMenuItem(text = { Text(label) }, enabled = enabled, onClick = onClick)
}
