package dev.toe3autopilot.core.session

import dev.toe3autopilot.core.Control
import dev.toe3autopilot.core.Point

/**
 * "Assisted" input: NOTHING is injected into the game. It only remembers what the automation would do so
 * the UI can show it ("hold ACCELERATOR", "tap ACCEPT_JOB") while the person performs the touches.
 * Used when the accessibility service is unavailable, or by choice.
 */
class AssistInputController : InputController {
    override val kind: InputKind = InputKind.ASSISTED
    override val isReady: Boolean = true
    override val isHealthy: Boolean = true

    @Volatile
    var currentHolds: Set<Control> = emptySet()
        private set

    @Volatile
    var lastTap: Point? = null
        private set

    override fun setHolds(holds: Map<Control, Point>) {
        currentHolds = holds.keys.toSet()
    }

    override fun tapAt(point: Point) {
        lastTap = point
    }

    override fun releaseAll() {
        currentHolds = emptySet()
    }
}
