package dev.toe3autopilot.app.capture

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.IntentFilter
import android.os.SystemClock
import dev.toe3autopilot.core.capture.CaptureFault
import dev.toe3autopilot.core.geometry.CaptureGeometry
import dev.toe3autopilot.core.geometry.IntRect
import dev.toe3autopilot.core.session.SessionStatus
import kotlinx.coroutines.CancellationException
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.core.content.IntentCompat
import dev.toe3autopilot.R
import dev.toe3autopilot.app.AutopilotRuntime
import dev.toe3autopilot.core.session.FrameSource
import dev.toe3autopilot.core.vision.Frame
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/** Latest captured frame, shared between the capture service (producer) and the session (consumer). */
class ScreenFrameSource : FrameSource {
    @Volatile
    private var frame: Frame? = null

    @Volatile
    private var active = false

    /** Minimum time between converted frames; the session adjusts this to save battery. */
    @Volatile
    var minIntervalMs: Long = 1000L

    override val isActive: Boolean get() = active

    override fun latest(): Frame? = frame

    fun setActive(a: Boolean) {
        active = a
        if (!a) frame = null
    }

    fun publish(f: Frame) {
        frame = f
    }
}

/**
 * Foreground service that owns the MediaProjection, converts screenshots to small [Frame]s and hosts the
 * automation loop. Everything it holds is released when the user stops the session, the projection is revoked
 * (system "stop sharing" control) or the service is destroyed.
 *
 * Not verified on a device: written against the documented MediaProjection contract (foreground service of type
 * mediaProjection started BEFORE getMediaProjection, a Callback registered BEFORE createVirtualDisplay).
 */
class ScreenCaptureService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var loop: Job? = null
    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    /** Where the mirrored display lies inside the capture surface; frames are cropped to it (see core.geometry). */
    @Volatile
    private var crop: IntRect? = null
    private var lastConvertAt = 0L
    private var conversionFailures = 0
    private var readerFailures = 0
    private var lastDiagnosisAt = 0L

    /** True once we ourselves are tearing capture down, so the projection's onStop callback is not reported as a fault. */
    @Volatile
    private var stoppingByUs = false
    private var lastBusyAt = 0L
    private var lastNotifKey = ""
    private var receiverRegistered = false

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == Intent.ACTION_SCREEN_OFF) AutopilotRuntime.onScreenOff()
        }
    }

    override fun onCreate() {
        super.onCreate()
        AutopilotRuntime.init(this)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        AutopilotRuntime.init(this)
        when (intent?.action) {
            ACTION_START -> startCapture(intent)
            ACTION_STOP -> {
                AutopilotRuntime.stopSession()
                shutdown("Disconnected by user")
            }
            ACTION_EMERGENCY -> AutopilotRuntime.emergencyStop("Notification stop action")
            ACTION_PAUSE -> AutopilotRuntime.pause()
            ACTION_RESUME -> AutopilotRuntime.resume()
            ACTION_STOP_SESSION -> AutopilotRuntime.stopSession()
            else -> {}
        }
        // Not sticky on purpose: a MediaProjection grant cannot be recreated without the user, so a restarted service
        // would have nothing to capture. After the system kills the service the user simply connects again.
        if (projection == null && intent?.action != ACTION_START) stopSelf()
        return START_NOT_STICKY
    }

    private fun startCapture(intent: Intent) {
        if (projection != null) return
        stoppingByUs = false
        AutopilotRuntime.captureHealth.onCaptureStarted()
        AutopilotRuntime.noteCaptureStarted()
        // Android 14+: the foreground service (type mediaProjection) must be running before getMediaProjection().
        try {
            ServiceCompat.startForeground(
                this, NOTIF_ID, buildNotification(),
                if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION else 0,
            )
        } catch (e: Exception) {
            // For example SecurityException (missing foreground-service permission) or a background-start restriction.
            failStart(CaptureFault.SERVICE_START_REJECTED, e)
            return
        }
        AutopilotRuntime.captureEndReason.value = null
        AutopilotRuntime.discardEndedSession()
        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
        val data = IntentCompat.getParcelableExtra(intent, EXTRA_DATA, Intent::class.java)
        if (data == null) {
            failStart(CaptureFault.TOKEN_INVALID, null, "no permission data was passed to the service")
            return
        }
        val t = HandlerThread("haulpilot-capture").also { it.start() }
        thread = t
        val h = Handler(t.looper)
        handler = h
        val p: MediaProjection
        try {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            // The SDK declares this as nullable (null if the permission result is no longer valid).
            p = mpm.getMediaProjection(resultCode, data) ?: run {
                failStart(CaptureFault.TOKEN_INVALID, null, "Android returned no projection")
                return
            }
        } catch (e: Exception) {
            failStart(CaptureFault.TOKEN_INVALID, e)
            return
        }
        projection = p
        try {
            p.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    if (stoppingByUs) return
                    // User tapped the system "stop sharing" control, or the system revoked the projection (it can also
                    // end when the device locks). Everything is released; the user connects again.
                    AutopilotRuntime.session?.stop()
                    AutopilotRuntime.reportCaptureFault(CaptureFault.PROJECTION_STOPPED)
                    shutdown("Screen capture was stopped by Android or by you (for example the system \"stop sharing\" control or a screen lock)")
                }

                // Android 14+: the shared content changed size (for example the display rotated). Follow it.
                override fun onCapturedContentResize(width: Int, height: Int) {
                    val proj = projection ?: return
                    val hh = handler ?: return
                    hh.post {
                        if (!configure(proj, hh)) {
                            AutopilotRuntime.reportCaptureFault(CaptureFault.RECONFIGURE_FAILED)
                            AutopilotRuntime.session?.emergencyStop("Could not follow the new screen size")
                        }
                    }
                }

                // Android 14+: the shared content is hidden (another window covers it). Pictures then do not show the game.
                override fun onCapturedContentVisibilityChanged(isVisible: Boolean) {
                    AutopilotRuntime.logInfo(if (isVisible) "Captured screen is visible again" else "Captured screen is hidden by another window")
                }
            }, h)
        } catch (e: Exception) {
            failStart(CaptureFault.TOKEN_INVALID, e)
            return
        }
        if (!configure(p, h)) {
            AutopilotRuntime.session?.stop()
            shutdown(AutopilotRuntime.captureHealth.diagnose().title)
            return
        }
        AutopilotRuntime.frameSource.setActive(true)
        AutopilotRuntime.captureActive.value = true
        AutopilotRuntime.refreshCaptureDiagnosis()
        registerScreenReceiver()
        startLoop()
    }

    /** Records why starting failed (as a typed fault, not a guess) and releases whatever was created so far. */
    private fun failStart(fault: CaptureFault, e: Exception?, note: String? = null) {
        AutopilotRuntime.session?.stop()
        AutopilotRuntime.reportCaptureFault(fault, note ?: e?.javaClass?.simpleName)
        shutdown(fault.title)
    }

    /**
     * Create (or re-create after rotation) the ImageReader / VirtualDisplay at the processing resolution.
     * Returns false after reporting the specific fault (reader or display) when something could not be created.
     */
    private fun configure(p: MediaProjection, h: Handler): Boolean {
        val (dw, dh) = AutopilotRuntime.realDisplaySize(this)
        if (dw <= 0 || dh <= 0) {
            AutopilotRuntime.reportCaptureFault(CaptureFault.VIRTUAL_DISPLAY_FAILED, "the display size is unknown")
            return false
        }
        // A surface with the display's own aspect ratio (to the nearest pixel), so the mirrored picture is not boxed.
        val (pw, ph) = CaptureGeometry.chooseSurfaceSize(dw, dh, AutopilotRuntime.PROCESSING_LONG_SIDE)
        val geometry = CaptureGeometry(dw, dh, pw, ph)
        val dpi = resources.displayMetrics.densityDpi
        val newReader = try {
            // 3 buffers: one may be held back as "pending" (see onImage) while acquireLatestImage() still has room to work.
            ImageReader.newInstance(pw, ph, PixelFormat.RGBA_8888, 3).also { it.setOnImageAvailableListener({ r -> onImage(r) }, h) }
        } catch (e: Exception) {
            AutopilotRuntime.reportCaptureFault(CaptureFault.IMAGE_READER_FAILED, e.javaClass.simpleName)
            return false
        }
        try {
            val vd = virtualDisplay
            if (vd == null) {
                virtualDisplay = p.createVirtualDisplay(
                    "haulpilot-capture", pw, ph, dpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    newReader.surface, null, h,
                ) ?: run {
                    newReader.close()
                    AutopilotRuntime.reportCaptureFault(CaptureFault.VIRTUAL_DISPLAY_FAILED, "Android returned no display")
                    return false
                }
            } else {
                vd.resize(pw, ph, dpi)
                vd.surface = newReader.surface
            }
        } catch (e: Exception) {
            newReader.close()
            AutopilotRuntime.reportCaptureFault(CaptureFault.VIRTUAL_DISPLAY_FAILED, e.javaClass.simpleName)
            return false
        }
        pending?.close()
        pending = null
        reader?.close()
        reader = newReader
        crop = geometry.cropRect
        return true
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val p = projection ?: return
        val h = handler ?: return
        h.post {
            val ok = try {
                configure(p, h)
            } catch (e: Exception) {
                false
            }
            if (!ok) {
                AutopilotRuntime.reportCaptureFault(CaptureFault.RECONFIGURE_FAILED)
                AutopilotRuntime.session?.emergencyStop("Could not adapt screen capture to the new orientation")
            }
        }
    }

    /**
     * An image that arrived too soon after the previous conversion. Root cause of stale pictures: such images used to be
     * dropped, and because a VirtualDisplay only produces a new image when the screen changes, a screen that then stopped
     * changing (paused game, a menu, this app) left the preview and the vision engine with an older picture than the one on
     * screen. Now the newest early image is kept and converted as soon as the interval has passed.
     */
    private var pending: Image? = null
    private var pendingScheduled = false

    private fun onImage(r: ImageReader) {
        val img = try {
            r.acquireLatestImage()
        } catch (e: Exception) {
            // IllegalStateException when the reader is closed or its buffers are exhausted.
            if (++readerFailures == 5) AutopilotRuntime.reportCaptureFault(CaptureFault.IMAGE_READER_FAILED, e.javaClass.simpleName)
            return
        } ?: return
        readerFailures = 0
        val now = System.currentTimeMillis()
        val wait = AutopilotRuntime.frameSource.minIntervalMs - (now - lastConvertAt)
        if (wait > 0) {
            pending?.close()
            pending = img
            if (!pendingScheduled) {
                pendingScheduled = true
                handler?.postDelayed({ convertPending() }, wait)
            }
            return
        }
        pending?.close()
        pending = null
        convert(img, now)
    }

    private fun convertPending() {
        pendingScheduled = false
        val img = pending ?: return
        pending = null
        convert(img, System.currentTimeMillis())
    }

    private fun convert(img: Image, now: Long) {
        try {
            lastConvertAt = now
            val frame = try {
                toFrame(img, now)
            } catch (e: Exception) {
                if (++conversionFailures == 3) AutopilotRuntime.reportCaptureFault(CaptureFault.CONVERSION_FAILED, e.javaClass.simpleName)
                return
            }
            conversionFailures = 0
            AutopilotRuntime.frameSource.publish(frame)
            // One place decides what the picture shows (game, this app, another app); the preview, the calibration and
            // the driving session all use this same frame.
            AutopilotRuntime.onCapturedFrame(frame)
        } finally {
            try {
                img.close()
            } catch (_: Exception) {
            }
        }
    }

    /**
     * Converts the captured image into a [Frame], keeping only the mirrored display ([crop]) so that a frame's normalised
     * coordinates are screen coordinates (see dev.toe3autopilot.core.geometry).
     */
    private fun toFrame(img: Image, timestampMs: Long): Frame {
        val iw = img.width
        val ih = img.height
        val c = crop?.takeIf { it.x1 <= iw && it.y1 <= ih } ?: IntRect(0, 0, iw, ih)
        val w = c.width
        val h = c.height
        val plane = img.planes[0]
        val buf = plane.buffer
        val rowStride = plane.rowStride
        val pixelStride = plane.pixelStride
        val out = IntArray(w * h)
        val row = ByteArray(rowStride)
        for (y in 0 until h) {
            buf.position((c.y0 + y) * rowStride)
            buf.get(row, 0, minOf(rowStride, buf.remaining()))
            var o = c.x0 * pixelStride
            var i = y * w
            for (x in 0 until w) {
                val r = row[o].toInt() and 0xFF
                val g = row[o + 1].toInt() and 0xFF
                val b = row[o + 2].toInt() and 0xFF
                out[i++] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
                o += pixelStride
            }
        }
        return Frame(w, h, out, timestampMs)
    }

    private fun startLoop() {
        loop?.cancel()
        lastBusyAt = SystemClock.elapsedRealtime()
        loop = scope.launch {
            while (isActive) {
                try {
                    val wait = loopOnce()
                    if (wait < 0) return@launch
                    delay(wait)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    AutopilotRuntime.noteInputFailure("Background loop error: ${e.javaClass.simpleName}")
                    delay(500)
                }
            }
        }
    }

    /** One pass of the background loop. Returns the delay before the next pass, or -1 when the service has shut down. */
    private fun loopOnce(): Long {
        val frames = AutopilotRuntime.frameSource
        val s = AutopilotRuntime.session
        var wait = IDLE_LOOP_MS
        var sessionActive = false
        if (s != null) {
            wait = s.tick()
            sessionActive = s.currentSnapshot().status.isActiveLoop
            frames.minIntervalMs = s.suggestedCaptureIntervalMs()
            if (s.shouldReleaseCapture()) {
                // Session ended (stop / emergency stop / finished): do not keep capturing the screen.
                shutdown("The session ended, so screen capture was released")
                return -1
            }
        }
        val setupCollecting = AutopilotRuntime.setupBusy()
        if (!sessionActive) {
            // Smart Setup keeps about three pictures a second; otherwise one a second is plenty while idle.
            frames.minIntervalMs = if (setupCollecting) SETUP_FRAME_MS else IDLE_FRAME_MS
        }

        val recorder = AutopilotRuntime.recorder
        if (recorder.recording.value) {
            val inFront = AutopilotRuntime.gameInFront()
            val f = frames.latest()
            if (inFront == null) {
                // Without the accessibility service nobody can tell whether the picture shows the game or something private.
                recorder.stop()
                AutopilotRuntime.logInfo("Snapshot recording stopped: the app cannot tell that the game is in front (enable the accessibility service)")
            } else if (inFront && f != null && !AutopilotRuntime.appVisible) {
                recorder.maybeSave(f, System.currentTimeMillis())
            }
        }

        val now = SystemClock.elapsedRealtime()
        if (now - lastDiagnosisAt >= 1000L) {
            lastDiagnosisAt = now
            AutopilotRuntime.refreshCaptureDiagnosis()
            AutopilotRuntime.pumpSetup()
        }
        if (sessionActive || setupCollecting || recorder.recording.value) lastBusyAt = now
        if (now - lastBusyAt > IDLE_RELEASE_MS) {
            shutdown("Screen capture was released after ${IDLE_RELEASE_MS / 60_000} minutes without a session, calibration or recording")
            return -1
        }
        refreshNotification()
        return wait
    }

    private fun registerScreenReceiver() {
        if (receiverRegistered) return
        try {
            ContextCompat.registerReceiver(this, screenReceiver, IntentFilter(Intent.ACTION_SCREEN_OFF), ContextCompat.RECEIVER_NOT_EXPORTED)
            receiverRegistered = true
        } catch (e: Exception) {
            AutopilotRuntime.noteInputFailure("Could not watch for the screen turning off: ${e.javaClass.simpleName}")
        }
    }

    private fun shutdown(reason: String) {
        stoppingByUs = true
        AutopilotRuntime.captureHealth.onCaptureEnded()
        if (AutopilotRuntime.captureEndReason.value == null) AutopilotRuntime.captureEndReason.value = reason
        AutopilotRuntime.recorder.stop()
        if (receiverRegistered) {
            try {
                unregisterReceiver(screenReceiver)
            } catch (_: Exception) {
            }
            receiverRegistered = false
        }
        AutopilotRuntime.captureActive.value = false
        AutopilotRuntime.frameSource.setActive(false)
        AutopilotRuntime.refreshLink()
        // A running Smart Setup collection cannot continue without pictures: it stops now (keeping what it has).
        AutopilotRuntime.captureEnded(reason)
        crop = null
        loop?.cancel()
        loop = null
        try {
            virtualDisplay?.release()
        } catch (_: Exception) {
        }
        virtualDisplay = null
        try {
            pending?.close()
        } catch (_: Exception) {
        }
        pending = null
        try {
            reader?.close()
        } catch (_: Exception) {
        }
        reader = null
        try {
            projection?.stop()
        } catch (_: Exception) {
        }
        projection = null
        thread?.quitSafely()
        thread = null
        handler = null
        AutopilotRuntime.refreshCaptureDiagnosis()
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        // Safety net: also covers the system killing the service.
        AutopilotRuntime.session?.stop()
        shutdown("Service destroyed")
        scope.cancel()
        super.onDestroy()
    }

    private fun pending(code: Int, action: String): PendingIntent =
        PendingIntent.getService(
            this, code, Intent(this, ScreenCaptureService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

    /** Title, text and which buttons to show, from the current session / calibration / recording state. */
    private class NotifContent(val text: String, val canPause: Boolean, val canResume: Boolean, val canStopSession: Boolean)

    private fun notifContent(): NotifContent {
        val snap = AutopilotRuntime.snapshot.value
        val setup = AutopilotRuntime.setup.state.value
        val rec = AutopilotRuntime.recorder.recording.value
        val active = snap.status.isActiveLoop
        val paused = snap.status == SessionStatus.PAUSED || snap.status == SessionStatus.NEEDS_ASSIST
        val calibrating = setup.phase.busy
        val main = when {
            calibrating -> "Smart Setup: ${setup.message}"
            active || paused -> "${snap.status.label}: ${snap.task}"
            else -> getString(R.string.notif_text)
        }
        val text = if (rec) "$main  \u25CF Saving sample snapshots" else main
        return NotifContent(text, active, paused, active || paused)
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, getString(R.string.notif_channel_name), NotificationManager.IMPORTANCE_LOW),
        )
        val c = notifContent()
        val b = Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_truck)
            .setContentTitle(getString(R.string.notif_title))
            .setContentText(c.text)
            .setStyle(Notification.BigTextStyle().bigText(c.text))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
        packageManager.getLaunchIntentForPackage(packageName)?.let { launch ->
            b.setContentIntent(PendingIntent.getActivity(this, 0, launch, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
        }
        // Android shows at most three actions; the emergency stop is always the first.
        b.addAction(Notification.Action.Builder(null, getString(R.string.notif_action_stop), pending(1, ACTION_EMERGENCY)).build())
        if (c.canPause) b.addAction(Notification.Action.Builder(null, getString(R.string.notif_action_pause), pending(2, ACTION_PAUSE)).build())
        if (c.canResume) b.addAction(Notification.Action.Builder(null, getString(R.string.notif_action_resume), pending(3, ACTION_RESUME)).build())
        if (c.canStopSession) b.addAction(Notification.Action.Builder(null, getString(R.string.notif_action_end), pending(4, ACTION_STOP_SESSION)).build())
        if (!c.canStopSession) b.addAction(Notification.Action.Builder(null, getString(R.string.notif_action_disconnect), pending(5, ACTION_STOP)).build())
        return b.build()
    }

    /** Re-posts the notification only when what it says changed. */
    private fun refreshNotification() {
        val c = notifContent()
        val key = "${c.text}|${c.canPause}|${c.canResume}|${c.canStopSession}"
        if (key == lastNotifKey) return
        lastNotifKey = key
        try {
            getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification())
        } catch (_: Exception) {
        }
    }

    companion object {
        const val ACTION_START = "dev.toe3autopilot.action.START_CAPTURE"
        const val ACTION_STOP = "dev.toe3autopilot.action.STOP_CAPTURE"
        const val ACTION_EMERGENCY = "dev.toe3autopilot.action.EMERGENCY_STOP"
        const val ACTION_PAUSE = "dev.toe3autopilot.action.PAUSE"
        const val ACTION_RESUME = "dev.toe3autopilot.action.RESUME"
        const val ACTION_STOP_SESSION = "dev.toe3autopilot.action.STOP_SESSION"
        private const val IDLE_LOOP_MS = 250L
        private const val IDLE_FRAME_MS = 1000L
        private const val SETUP_FRAME_MS = 250L
        private const val IDLE_RELEASE_MS = 20L * 60_000L
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_DATA = "data"
        private const val CHANNEL = "session"
        private const val NOTIF_ID = 1001

        fun start(context: Context, resultCode: Int, data: Intent) {
            val i = Intent(context, ScreenCaptureService::class.java)
                .setAction(ACTION_START).putExtra(EXTRA_RESULT_CODE, resultCode).putExtra(EXTRA_DATA, data)
            ContextCompat.startForegroundService(context, i)
        }

        fun stop(context: Context) {
            context.startService(Intent(context, ScreenCaptureService::class.java).setAction(ACTION_STOP))
        }
    }
}
