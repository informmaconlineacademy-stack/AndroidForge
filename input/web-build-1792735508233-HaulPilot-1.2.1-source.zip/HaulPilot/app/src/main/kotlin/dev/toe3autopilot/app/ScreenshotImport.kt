package dev.toe3autopilot.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import dev.toe3autopilot.app.capture.SampleRecorder
import dev.toe3autopilot.core.geometry.CaptureGeometry
import dev.toe3autopilot.core.vision.Frame
import java.io.ByteArrayOutputStream
import java.io.InputStream

/**
 * Loading screenshots the person picked, scaled the way live frames are. A phone screenshot covers the whole display, so
 * its normalised coordinates are screen coordinates, like a live frame's.
 */
object ScreenshotImport {
    const val MAX_IMAGES = 40
    private const val MAX_BYTES_PER_IMAGE = 25L * 1024 * 1024

    class Loaded(val frames: List<Frame>, val failed: Int)

    fun load(context: Context, uris: List<Uri>): Loaded {
        val frames = ArrayList<Frame>()
        var failed = 0
        for (uri in uris.take(MAX_IMAGES)) {
            val f = try {
                loadOne(context, uri)
            } catch (e: Exception) {
                null
            } catch (e: OutOfMemoryError) {
                null
            }
            if (f == null) failed++ else frames += f
        }
        return Loaded(frames, failed + maxOf(0, uris.size - MAX_IMAGES))
    }

    private fun loadOne(context: Context, uri: Uri): Frame? {
        val bytes = context.contentResolver.openInputStream(uri)?.use { readLimited(it, MAX_BYTES_PER_IMAGE) } ?: return null
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        val long = maxOf(bounds.outWidth, bounds.outHeight)
        var sample = 1
        while (long / (sample * 2) >= AutopilotRuntime.PROCESSING_LONG_SIDE) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val decoded = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts) ?: return null
        // Same aspect-exact size rule as live capture, so a screenshot's positions are the phone's screen positions.
        val (pw, ph) = CaptureGeometry.chooseSurfaceSize(decoded.width, decoded.height, AutopilotRuntime.PROCESSING_LONG_SIDE)
        val scaled = Bitmap.createScaledBitmap(decoded, pw, ph, true)
        if (scaled !== decoded) decoded.recycle()
        return SampleRecorder.bitmapToFrame(scaled)
    }

    /** Reads at most [max] bytes; throws if the stream is larger (so a huge file cannot exhaust memory). */
    fun readLimited(input: InputStream, max: Long): ByteArray {
        val out = ByteArrayOutputStream()
        val buf = ByteArray(16 * 1024)
        var total = 0L
        while (true) {
            val n = input.read(buf)
            if (n < 0) break
            total += n
            if (total > max) throw IllegalArgumentException("The file is larger than ${max / (1024 * 1024)} MB")
            out.write(buf, 0, n)
        }
        return out.toByteArray()
    }
}
