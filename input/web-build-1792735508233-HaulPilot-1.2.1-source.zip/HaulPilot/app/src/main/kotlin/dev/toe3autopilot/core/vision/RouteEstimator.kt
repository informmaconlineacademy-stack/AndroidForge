package dev.toe3autopilot.core.vision

import dev.toe3autopilot.core.clampF
import dev.toe3autopilot.core.profile.NavProfile
import kotlin.math.abs

/**
 * Reads the navigation route from a heading-up minimap by finding route-coloured pixels directly
 * ahead of the truck marker.
 *
 *  - The strip between the truck marker and `lookahead` x minimap-height above it is split into a
 *    NEAR half (closest to the truck) and a FAR half.
 *  - offset    = horizontal distance of the NEAR route centroid from the truck marker.
 *  - curvature = horizontal shift between NEAR and FAR centroids (how sharply the road bends ahead);
 *    bend is the same shift with its sign (positive: the road veers to the right further ahead).
 *
 * Limitations: needs a heading-up minimap and a route colour that is distinct from the rest of the map.
 */
class RouteEstimator(private val nav: NavProfile) {

    fun read(frame: Frame): RouteReading? {
        val map = nav.minimapRoi
        val halfWidth = (map.right - map.left) / 2f
        if (halfWidth <= 0f) return null
        val mapHeight = map.bottom - map.top
        val farTop = maxOf(map.top, nav.truckY - nav.lookahead * mapHeight)
        val bottom = minOf(map.bottom, nav.truckY)
        val mid = (farTop + bottom) / 2f
        val minBand = 2f / frame.height
        if (bottom - farTop < 2 * minBand) return null

        val near = ColorMask.measure(frame, Roi(map.left, mid, map.right, bottom), nav.routeColor)
        if (!near.found) return null
        val far = ColorMask.measure(frame, Roi(map.left, farTop, map.right, mid), nav.routeColor)

        val bandPixels = (map.right - map.left) * frame.width * (bottom - mid) * frame.height
        // A route line covering ~3% of the near band counts as full confidence.
        val confidence = clampF(near.count / maxOf(1f, bandPixels * 0.03f), 0f, 1f)
        val offset = clampF((near.cx - nav.truckX) / halfWidth, -1f, 1f)
        val bend = if (far.found) clampF((far.cx - near.cx) / halfWidth, -1f, 1f) else 0f
        return RouteReading(offset, abs(bend), confidence, far.found, bend)
    }
}
