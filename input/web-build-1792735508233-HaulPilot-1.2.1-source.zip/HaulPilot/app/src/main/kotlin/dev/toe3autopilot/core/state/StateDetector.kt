package dev.toe3autopilot.core.state

import dev.toe3autopilot.core.profile.GameProfile
import dev.toe3autopilot.core.vision.Vision

/**
 * @property state     debounced state (changes only after [StateDetector.stableFramesRequired] agreeing frames)
 * @property candidate what this single frame looks like
 * @property confidence mean template score of the candidate's rule (0 when nothing matched)
 * @property stableTicks consecutive ticks [state] has been unchanged
 */
data class StateEstimate(val state: GameState, val candidate: GameState, val confidence: Float, val stableTicks: Int)

/**
 * Classifies the screen by evaluating the profile's state rules against the current [Vision].
 *
 * A rule is a list of template names that must ALL be present; a name prefixed with '!' must be absent.
 * Only the templates referenced by rules are matched (lazily, cached per frame) to keep CPU use low.
 */
class StateDetector(
    private val profile: GameProfile,
    private val stableFramesRequired: Int = 2,
) {
    private var current = GameState.UNKNOWN
    private var pending: GameState? = null
    private var pendingCount = 0
    private var stable = 0
    private val recent = ArrayDeque<GameState>()
    private var lastCandidate = GameState.UNKNOWN
    private var lastConfidence = 0f

    fun reset() {
        current = GameState.UNKNOWN
        pending = null
        pendingCount = 0
        stable = 0
        recent.clear()
        lastCandidate = GameState.UNKNOWN
        lastConfidence = 0f
    }

    fun update(vision: Vision): StateEstimate {
        var best = GameState.UNKNOWN
        var bestConf = 0f
        for (s in DETECTION_PRIORITY) {
            val rule = profile.stateRules[s] ?: continue
            val c = evaluate(rule, vision)
            if (c > bestConf) {
                best = s
                bestConf = c
            }
        }
        lastCandidate = best
        lastConfidence = bestConf
        return debounce(best, bestConf)
    }

    /**
     * The capture delivered no new frame because the screen did not change. That is evidence that the last
     * candidate PERSISTS, so it counts as one more agreeing observation (without re-analysing the picture).
     */
    fun repeat(): StateEstimate = debounce(lastCandidate, lastConfidence)

    private fun debounce(best: GameState, conf: Float): StateEstimate {
        recent.addLast(best)
        while (recent.size > ENTRY_WINDOW) recent.removeFirst()
        if (best == current) {
            stable++
            pending = null
            pendingCount = 0
        } else {
            if (pending == best) pendingCount++ else {
                pending = best
                pendingCount = 1
            }
            // Leaving a state (or switching) needs [stableFramesRequired] agreeing pictures in a row, as before. ENTERING the driving
            // view also counts when it was seen in most of the last few pictures: scenery behind see-through controls makes the
            // marker score flicker around its threshold, and two hits in a row may never come although the screen is the driving view.
            val entering = best.drivingLike && !current.drivingLike && recent.count { it == best } >= ENTRY_HITS
            if (pendingCount >= stableFramesRequired || entering) {
                current = best
                stable = 1
                pending = null
                pendingCount = 0
            }
        }
        return StateEstimate(current, best, conf, stable)
    }

    private fun evaluate(rule: List<String>, vision: Vision): Float {
        var sum = 0f
        var n = 0
        for (item in rule) {
            if (item.startsWith("!")) {
                if (vision.has(item.substring(1))) return 0f
            } else {
                val m = vision.find(item) ?: return 0f
                sum += m.score
                n++
            }
        }
        return if (n == 0) 0.7f else sum / n
    }

    private companion object {
        /** The newest pictures remembered for entering the driving view, and how many of them must show it. */
        const val ENTRY_WINDOW = 5
        const val ENTRY_HITS = 3
    }
}
