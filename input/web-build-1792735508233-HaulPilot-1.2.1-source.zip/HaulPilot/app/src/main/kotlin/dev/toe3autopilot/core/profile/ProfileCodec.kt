package dev.toe3autopilot.core.profile

import dev.toe3autopilot.core.Control
import dev.toe3autopilot.core.Point
import dev.toe3autopilot.core.state.GameState
import dev.toe3autopilot.core.vision.ColorTarget
import dev.toe3autopilot.core.vision.Roi
import dev.toe3autopilot.core.vision.fmt
import dev.toe3autopilot.core.vision.parseFloats
import java.io.StringReader
import java.util.Properties

/**
 * Text (java.util.Properties) serialisation of a [GameProfile]. Parsing is strict so typos in a
 * hand-edited profile are reported instead of silently ignored. Throws [IllegalArgumentException].
 *
 * Example:
 * ```
 * name=Pixel 8 landscape
 * game.package=com.example.game
 * reference.width=640
 * steering.mode=SLIDER
 * steering.radius=0.12
 * control.ACCELERATOR=0.91,0.80
 * template.hud_marker.roi=0.0,0.0,0.5,0.2
 * template.hud_marker.min=0.82
 * state.DRIVING=hud_marker
 * color.parking_zone.roi=0.2,0.3,0.8,0.9
 * color.parking_zone.target=0,200,0,40
 * nav.minimap.roi=0.02,0.55,0.25,0.98
 * nav.route.color=255,215,0,45
 * nav.truck=0.135,0.9
 * extra.parking.direction=REVERSE
 * ```
 */
object ProfileCodec {
    private val NAME = Regex("[a-z0-9_]+")
    private val REMOVED_STATES = setOf("MAIN_MENU", "JOB_LIST", "JOB_DETAILS")
    private val REMOVED_CONTROLS = setOf("COUPLE", "OPEN_JOBS", "ACCEPT_JOB", "NEXT_PAGE", "CONFIRM", "CLOSE_DIALOG")

    fun parse(text: String): GameProfile {
        val props = Properties()
        props.load(StringReader(text))

        var name = "unnamed"
        var pkg = ""
        var refWidth = 0
        var steeringMode = SteeringMode.SLIDER
        var steerRadius = 0.12f
        val templateRoi = HashMap<String, Roi>()
        val templateMin = HashMap<String, Float>()
        val colorRoi = HashMap<String, Roi>()
        val colorTarget = HashMap<String, ColorTarget>()
        val rules = LinkedHashMap<GameState, List<String>>()
        val controls = LinkedHashMap<Control, Point>()
        val extras = LinkedHashMap<String, String>()
        var navRoi: Roi? = null
        var navColor: ColorTarget? = null
        var navTruck: List<Float>? = null
        var navLook = 0.6f

        for (key in props.stringPropertyNames().sorted()) {
            val v = props.getProperty(key).trim()
            try {
                when {
                    key == "name" -> name = v
                    key == "game.package" -> pkg = v
                    key == "reference.width" -> refWidth = v.toIntOrNull() ?: throw IllegalArgumentException("not an integer")
                    key == "steering.mode" -> steeringMode = SteeringMode.valueOf(v.uppercase())
                    key == "steering.radius" -> steerRadius = v.toFloatOrNull() ?: throw IllegalArgumentException("not a number")
                    key.startsWith("template.") -> {
                        val rest = key.removePrefix("template.")
                        val dot = rest.lastIndexOf('.')
                        require(dot > 0) { "expected template.<name>.roi|min" }
                        val n = rest.substring(0, dot)
                        require(NAME.matches(n)) { "template names must match [a-z0-9_]+" }
                        when (rest.substring(dot + 1)) {
                            "roi" -> templateRoi[n] = Roi.parse(v)
                            "min" -> templateMin[n] = v.toFloatOrNull()?.also { require(it in 0f..1f) { "min must be 0..1" } }
                                ?: throw IllegalArgumentException("not a number")
                            else -> throw IllegalArgumentException("unknown template attribute")
                        }
                    }
                    key.startsWith("color.") -> {
                        val rest = key.removePrefix("color.")
                        val dot = rest.lastIndexOf('.')
                        require(dot > 0) { "expected color.<name>.roi|target" }
                        val n = rest.substring(0, dot)
                        require(NAME.matches(n)) { "colour names must match [a-z0-9_]+" }
                        when (rest.substring(dot + 1)) {
                            "roi" -> colorRoi[n] = Roi.parse(v)
                            "target" -> colorTarget[n] = ColorTarget.parse(v)
                            else -> throw IllegalArgumentException("unknown colour attribute")
                        }
                    }
                    key.startsWith("state.") -> {
                        val sName = key.removePrefix("state.")
                        // Profiles made before the app became drive-only may still contain job/menu screens: they are ignored.
                        if (sName in REMOVED_STATES) continue
                        val s = if (sName == "DRIVING_COUPLED" || sName == "DRIVING_UNCOUPLED") GameState.DRIVING else GameState.valueOf(sName)
                        val names = v.split(",").map { it.trim() }.filter { it.isNotEmpty() }
                        require(names.isNotEmpty()) { "rule is empty" }
                        // The old "trailer attached" rule describes the normal driving view and takes precedence over the "no trailer" one.
                        if (sName == "DRIVING_UNCOUPLED" && rules.containsKey(s)) continue
                        rules[s] = names
                    }
                    key.startsWith("control.") -> {
                        val cName = key.removePrefix("control.")
                        if (cName in REMOVED_CONTROLS) continue
                        val c = Control.valueOf(cName)
                        val f = parseFloats(v, 2)
                        require(f.all { it in 0f..1f }) { "coordinates must be 0..1" }
                        controls[c] = Point(f[0], f[1])
                    }
                    key == "nav.minimap.roi" -> navRoi = Roi.parse(v)
                    key == "nav.route.color" -> navColor = ColorTarget.parse(v)
                    key == "nav.truck" -> navTruck = parseFloats(v, 2)
                    key == "nav.lookahead" -> navLook = v.toFloatOrNull() ?: throw IllegalArgumentException("not a number")
                    key.startsWith("extra.") -> extras[key.removePrefix("extra.")] = v
                    else -> throw IllegalArgumentException("unknown key")
                }
            } catch (e: IllegalArgumentException) {
                throw IllegalArgumentException("Profile key '$key': ${e.message}", e)
            }
        }

        val templates = templateRoi.mapValues { (n, roi) -> TemplateSpec(n, roi, templateMin[n] ?: 0.80f) }
        for (n in templateMin.keys) require(templateRoi.containsKey(n)) { "Template '$n' has a min score but no roi" }
        val colors = HashMap<String, ColorSpec>()
        for (n in colorRoi.keys + colorTarget.keys) {
            val roi = colorRoi[n] ?: throw IllegalArgumentException("Colour '$n' has no roi")
            val t = colorTarget[n] ?: throw IllegalArgumentException("Colour '$n' has no target")
            colors[n] = ColorSpec(n, roi, t)
        }
        for ((s, names) in rules) {
            for (item in names) {
                val n = item.removePrefix("!")
                require(templates.containsKey(n)) { "state.${s.name} refers to unknown template '$n'" }
            }
        }
        val nav = if (navRoi != null && navColor != null && navTruck != null) {
            NavProfile(navRoi, navColor, navTruck[0], navTruck[1], navLook)
        } else {
            require(navRoi == null && navColor == null && navTruck == null) {
                "nav.minimap.roi, nav.route.color and nav.truck must all be set together"
            }
            null
        }
        return GameProfile(name, pkg, refWidth, templates, colors, rules, controls, steeringMode, steerRadius, nav, extras)
    }

    fun format(p: GameProfile): String {
        val sb = StringBuilder()
        sb.append("name=").append(p.name).append('\n')
        sb.append("game.package=").append(p.gamePackage).append('\n')
        sb.append("reference.width=").append(p.referenceWidth).append('\n')
        sb.append("steering.mode=").append(p.steeringMode.name).append('\n')
        sb.append("steering.radius=").append(fmt(p.steerRadius)).append('\n')
        for ((c, pt) in p.controls.toSortedMap()) sb.append("control.").append(c.name).append('=').append(fmt(pt.x)).append(',').append(fmt(pt.y)).append('\n')
        for ((n, t) in p.templates.toSortedMap()) {
            sb.append("template.").append(n).append(".roi=").append(t.roi.format()).append('\n')
            sb.append("template.").append(n).append(".min=").append(fmt(t.minScore)).append('\n')
        }
        for ((n, c) in p.colors.toSortedMap()) {
            sb.append("color.").append(n).append(".roi=").append(c.roi.format()).append('\n')
            sb.append("color.").append(n).append(".target=").append(c.target.format()).append('\n')
        }
        for ((s, names) in p.stateRules.toSortedMap()) sb.append("state.").append(s.name).append('=').append(names.joinToString(",")).append('\n')
        p.nav?.let {
            sb.append("nav.minimap.roi=").append(it.minimapRoi.format()).append('\n')
            sb.append("nav.route.color=").append(it.routeColor.format()).append('\n')
            sb.append("nav.truck=").append(fmt(it.truckX)).append(',').append(fmt(it.truckY)).append('\n')
            sb.append("nav.lookahead=").append(fmt(it.lookahead)).append('\n')
        }
        for ((k, v) in p.extras.toSortedMap()) sb.append("extra.").append(k).append('=').append(v).append('\n')
        return sb.toString()
    }
}
