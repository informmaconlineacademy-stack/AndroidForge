package dev.toe3autopilot.core.capture

import dev.toe3autopilot.core.Clock

/**
 * Which app HaulPilot is working for (the TARGET GAME) is a different fact from which app is on screen right now (the
 * FOREGROUND APP). 1.0/1.1 mixed them up: starting a collection from the floating button made "whatever app was last seen in
 * front" the game, and a Google Play services window (com.google.android.gms, for example the Play Games sign-in banner)
 * became the selected game. Everything after that was judged against the wrong package: the game counted as "not in front",
 * the session paused, no picture of the game was offered to the profile test ("live picture: no").
 *
 * Rules (all pure, unit-tested):
 *  - The target game only changes when the person chooses it ([GameTarget.problemWith] says whether a package may be chosen).
 *    Nothing in the app changes it by itself.
 *  - Windows of helper services (Play services, Play Store billing sheets, permission dialogs) are small pop-ups that appear
 *    over the game. They are tracked separately ([ForegroundView.helper]); they neither replace the foreground app nor count
 *    as the game, and while one is fresh no touch is sent ([ForegroundView.touchSafe]).
 */
object GameTarget {
    /** Packages that are never a game: HaulPilot's own services are handled by [FrameGate.couldBeGame]; these are Google / system helpers. */
    private val NEVER_A_GAME = setOf(
        "com.google.android.gms", "com.google.android.gsf", "com.android.vending", "com.google.android.googlequicksearchbox",
        "com.google.android.apps.googleassistant", "com.android.settings", "com.android.permissioncontroller",
        "com.google.android.permissioncontroller", "com.android.chrome", "com.google.android.webview",
        "com.google.android.apps.messaging", "com.android.phone", "com.android.dialer", "com.google.android.dialer",
    )

    /** Packages whose windows appear OVER a game for a moment (sign-in banners, consent / permission dialogs, billing). */
    private val HELPER_OVERLAYS = setOf(
        "com.google.android.gms", "com.google.android.gsf", "com.android.vending",
        "com.android.permissioncontroller", "com.google.android.permissioncontroller",
    )

    fun isHelperOverlay(pkg: String?): Boolean = pkg != null && (pkg in HELPER_OVERLAYS || pkg.startsWith("com.google.android.gms."))

    /**
     * A saved selection that can never be a game (1.0 / 1.1.0 could save a Play services window as "the game") is replaced by
     * [default]; a good one is kept untouched. [Repair.message] is the log line when something was repaired.
     */
    data class Repair(val value: String, val message: String?)

    fun repair(saved: String, ownPackage: String, default: String): Repair {
        val problem = problemWith(saved, ownPackage) ?: return Repair(saved, null)
        return Repair(default, "The saved game \"$saved\" cannot be a game ($problem). Restored $default.")
    }

    /** Null when [pkg] may be chosen as the game, otherwise why not (plain words, shown to the person). */
    fun problemWith(pkg: String?, ownPackage: String): String? {
        if (pkg.isNullOrBlank()) return "No app is selected."
        if (pkg == ownPackage) return "HaulPilot cannot be its own game."
        if (pkg in NEVER_A_GAME || isHelperOverlay(pkg)) return "$pkg is a Google / system service, not a game."
        if (!FrameGate.couldBeGame(pkg, ownPackage)) return "$pkg is a launcher or system screen, not a game."
        return null
    }
}

/** What the tracker knows at one moment. */
data class ForegroundView(
    /** The target game (what the person selected). */
    val selected: String,
    /** The last real app seen in front (never a helper overlay, HaulPilot, the keyboard or the system UI). Null = none seen. */
    val app: String?,
    /** The most recent helper-overlay window (for example Play services) and how long ago it appeared. */
    val helper: String?,
    val helperAgeMs: Long,
    /** The accessibility service is connected, so [app] means something. */
    val trackerLive: Boolean,
) {
    /** The helper window appeared recently enough that it may still be covering the game. */
    val helperFresh: Boolean get() = helper != null && helperAgeMs in 0 until ForegroundTracker.HELPER_HOLD_MS

    /** true = the selected game is the app in front, false = another app is, null = cannot tell. */
    val gameInFront: Boolean?
        get() = when {
            !trackerLive || selected.isBlank() || app == null -> null
            else -> app == selected
        }

    /** True when it is safe to send a touch: the selected game is the app in front and no helper window is fresh on top of it. */
    val touchSafe: Boolean get() = gameInFront == true && !helperFresh

    /** Both facts, always together, for the log and for messages. */
    fun describe(): String =
        "selected game: ${selected.ifBlank { "none" }}; in front: ${app ?: "unknown"}" +
            (if (helper != null) "; helper window: $helper (${helperAgeMs / 1000} s ago)" else "")

    /** What to tell the person when the game is not usable, with how to get back. Null when it is. */
    fun howToReturn(): String? = when {
        !trackerLive -> "HaulPilot cannot see which app is in front (the accessibility service is off)."
        selected.isBlank() -> "No game is selected: choose it in Settings → Game & screen capture."
        app == null -> "HaulPilot has not seen the game come to the front yet. Open $selected."
        app != selected -> "$app is in front, not $selected. Open $selected (the Open the game button, or its icon), then resume."
        helperFresh -> "A $helper window just appeared over the game. Close it, then resume."
        else -> null
    }
}

/**
 * Remembers which app is in front, from accessibility window-change events (package names only). Thread-safe.
 *
 * Events from HaulPilot itself, the keyboard and the system UI are ignored (they are not "the foreground app"). Helper
 * overlays are remembered separately. Everything else is the foreground app.
 */
class ForegroundTracker(private val clock: Clock, private val ownPackage: String) {
    private val lock = Any()
    private var app: String? = null
    private var helper: String? = null
    private var helperAt = 0L
    private var live = false

    /** What changed, for the log (null when the event changed nothing worth a line). */
    data class Change(val kind: Kind, val pkg: String) {
        enum class Kind { APP, HELPER }
    }

    fun setLive(on: Boolean) = synchronized(lock) {
        live = on
        if (!on) {
            app = null
            helper = null
        }
    }

    fun onWindowChanged(pkg: String?): Change? = synchronized(lock) {
        if (pkg.isNullOrBlank() || pkg == ownPackage || pkg == "com.android.systemui" || pkg.contains("inputmethod")) return null
        if (GameTarget.isHelperOverlay(pkg)) {
            val first = helper != pkg || clock.nowMs() - helperAt > HELPER_HOLD_MS
            helper = pkg
            helperAt = clock.nowMs()
            return if (first) Change(Change.Kind.HELPER, pkg) else null
        }
        helper = null // a real app window came up: whatever helper was over the previous one is gone
        if (app == pkg) return null
        app = pkg
        Change(Change.Kind.APP, pkg)
    }

    fun view(selected: String): ForegroundView = synchronized(lock) {
        val now = clock.nowMs()
        ForegroundView(selected, app, helper, if (helper == null) 0L else now - helperAt, live)
    }

    /** The app in front, for callers that only need the package. */
    fun app(): String? = synchronized(lock) { app }

    companion object {
        /** A helper window is assumed to still be over the game for this long (no event arrives when it closes). */
        const val HELPER_HOLD_MS = 6_000L
    }
}

/**
 * The last line of defence before a touch is dispatched: independent of the session logic, a gesture is only sent while the
 * selected game is the app in front. Never Play services, HaulPilot or another app.
 */
object TouchGate {
    fun allowed(view: ForegroundView): Boolean = view.touchSafe
}
