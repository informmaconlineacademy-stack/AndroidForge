package dev.toe3autopilot.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.os.VibrationEffect
import android.os.Vibrator
import dev.toe3autopilot.core.session.SessionSnapshot
import dev.toe3autopilot.core.session.SessionStatus

/**
 * The one notification that tells the person something happened while they were not looking: the truck is parked, or the
 * automation stopped and needs them. It is separate from the ongoing capture notification (which disappears when the
 * session ends and the screen capture is released).
 */
object Notifier {
    private const val CHANNEL = "alerts"
    private const val NOTIF_ID = 1002
    private val PATTERN = longArrayOf(0, 400, 200, 400)

    fun alert(context: Context, snap: SessionSnapshot, vibrate: Boolean) {
        val (title, text) = when (snap.status) {
            SessionStatus.FINISHED ->
                "Parked" to "Driving has stopped. Please unload, detach the trailer, collect payment and choose the next job yourself."
            SessionStatus.NEEDS_ASSIST, SessionStatus.ERROR ->
                "Needs assistance" to (snap.lastError ?: snap.task)
            SessionStatus.EMERGENCY_STOPPED ->
                "Emergency stop" to "All driving inputs were stopped. Nothing will move until you start again."
            else -> return
        }
        var posted = false
        try {
            val nm = context.getSystemService(NotificationManager::class.java)
            if (nm.areNotificationsEnabled()) {
                nm.createNotificationChannel(
                    NotificationChannel(CHANNEL, "Parked / needs help", NotificationManager.IMPORTANCE_HIGH).also {
                        it.enableVibration(vibrate)
                        it.vibrationPattern = PATTERN
                        it.description = "Tells you when the truck is parked or when the automation has stopped and needs you."
                    },
                )
                val b = Notification.Builder(context, CHANNEL)
                    .setSmallIcon(dev.toe3autopilot.R.drawable.ic_stat_truck)
                    .setContentTitle(title)
                    .setContentText(text)
                    .setStyle(Notification.BigTextStyle().bigText(text))
                    .setCategory(Notification.CATEGORY_ALARM)
                    .setAutoCancel(true)
                    .setOnlyAlertOnce(false)
                context.packageManager.getLaunchIntentForPackage(context.packageName)?.let { launch ->
                    b.setContentIntent(PendingIntent.getActivity(context, 10, launch, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
                }
                nm.notify(NOTIF_ID, b.build())
                posted = true
            }
        } catch (_: Exception) {
        }
        // Without notification permission the person would not notice: vibrate at least.
        if (!posted && vibrate) {
            try {
                context.getSystemService(Vibrator::class.java)?.vibrate(VibrationEffect.createWaveform(PATTERN, -1))
            } catch (_: Exception) {
            }
        }
    }

    /** A short buzz, for countdowns when the phone is held away from the eyes. */
    fun buzz(context: Context, ms: Long) {
        try {
            context.getSystemService(Vibrator::class.java)?.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (_: Exception) {
        }
    }

    fun clear(context: Context) {
        try {
            context.getSystemService(NotificationManager::class.java).cancel(NOTIF_ID)
        } catch (_: Exception) {
        }
    }
}
