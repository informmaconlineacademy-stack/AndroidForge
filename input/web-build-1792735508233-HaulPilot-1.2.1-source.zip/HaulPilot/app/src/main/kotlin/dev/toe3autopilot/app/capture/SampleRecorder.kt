package dev.toe3autopilot.app.capture

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import dev.toe3autopilot.core.vision.Frame
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File

/** One saved sample snapshot. */
data class SavedSnapshot(val file: File, val timeMs: Long, val bytes: Long)

/**
 * Optional, user-started saving of **sampled snapshots** (small JPEG pictures at the processing resolution, one every
 * few seconds). It is deliberately not a video recorder: Android allows one virtual display per screen-capture grant
 * and continuous video would cost battery, storage and privacy for no calibration benefit.
 *
 * Privacy rules enforced by the caller ([maybeSave] is only given frames while the game is known to be in front):
 * recording is never on by default, never survives the end of screen capture, and everything stays in the app's
 * private storage where the user can list and delete it.
 */
class SampleRecorder(context: Context) {
    private val dir = File(context.filesDir, "snapshots").also { it.mkdirs() }

    private val _recording = MutableStateFlow(false)
    val recording: StateFlow<Boolean> = _recording.asStateFlow()

    private val _items = MutableStateFlow<List<SavedSnapshot>>(emptyList())

    /** Newest first. */
    val items: StateFlow<List<SavedSnapshot>> = _items.asStateFlow()

    @Volatile
    private var intervalMs = 5000L

    @Volatile
    private var maxFrames = 150

    @Volatile
    private var lastSavedAt = 0L

    @Volatile
    private var lastSavedStamp = Long.MIN_VALUE

    init {
        refresh()
    }

    fun start(intervalSec: Int, maxFrames: Int) {
        intervalMs = intervalSec.coerceIn(1, 60) * 1000L
        this.maxFrames = maxFrames.coerceIn(10, 400)
        lastSavedAt = 0L
        _recording.value = true
    }

    fun stop() {
        _recording.value = false
    }

    /** Saves [frame] if recording is on and the interval has elapsed. Safe to call every loop iteration; call off the main thread. */
    @Synchronized
    fun maybeSave(frame: Frame, nowMs: Long) {
        if (!_recording.value) return
        if (nowMs - lastSavedAt < intervalMs) return
        if (frame.timestampMs != 0L && frame.timestampMs == lastSavedStamp) return
        try {
            val bmp = Bitmap.createBitmap(frame.argb, frame.width, frame.height, Bitmap.Config.ARGB_8888)
            File(dir, "snap_$nowMs.jpg").outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 80, it) }
            bmp.recycle()
            lastSavedAt = nowMs
            lastSavedStamp = frame.timestampMs
            prune()
            refresh()
        } catch (e: Exception) {
            // Storage full or unwritable: stop rather than fail silently on every frame.
            _recording.value = false
        }
    }

    private fun prune() {
        val files = listFiles()
        var excess = files.size - maxFrames
        var i = files.size - 1 // listFiles() is newest first, so the oldest are at the end
        while (excess > 0 && i >= 0) {
            files[i].delete()
            i--
            excess--
        }
    }

    private fun listFiles(): List<File> =
        dir.listFiles { f -> f.name.startsWith("snap_") && f.name.endsWith(".jpg") }
            ?.sortedByDescending { stamp(it) }
            .orEmpty()

    private fun stamp(f: File): Long = f.name.removePrefix("snap_").removeSuffix(".jpg").toLongOrNull() ?: 0L

    fun refresh() {
        _items.value = listFiles().map { SavedSnapshot(it, stamp(it), it.length()) }
    }

    fun delete(item: SavedSnapshot) {
        item.file.delete()
        refresh()
    }

    fun deleteAll() {
        listFiles().forEach { it.delete() }
        refresh()
    }

    fun totalBytes(): Long = _items.value.sumOf { it.bytes }

    /** Decodes a saved snapshot back into a [Frame] (call off the main thread). Null if the file is unreadable. */
    fun load(item: SavedSnapshot): Frame? = decode(item.file)

    /** Up to [limit] snapshots spread evenly over everything saved, oldest first, for offline HUD analysis. */
    fun sampleForAnalysis(limit: Int): List<Frame> {
        val n = limit.coerceAtLeast(2)
        val all = _items.value.reversed()
        if (all.isEmpty()) return emptyList()
        val picked = if (all.size <= n) all else List(n) { i -> all[i * (all.size - 1) / (n - 1)] }
        return picked.mapNotNull { load(it) }
    }

    companion object {
        fun decode(file: File): Frame? {
            val bmp = BitmapFactory.decodeFile(file.absolutePath) ?: return null
            return bitmapToFrame(bmp)
        }

        /** Converts (and recycles) a bitmap into a [Frame]. */
        fun bitmapToFrame(bmp: Bitmap): Frame {
            val w = bmp.width
            val h = bmp.height
            val px = IntArray(w * h)
            bmp.getPixels(px, 0, w, 0, 0, w, h)
            bmp.recycle()
            return Frame(w, h, px)
        }
    }
}
