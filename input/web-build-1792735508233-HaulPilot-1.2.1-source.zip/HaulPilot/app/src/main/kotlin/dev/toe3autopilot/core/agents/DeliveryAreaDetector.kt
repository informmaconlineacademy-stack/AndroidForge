package dev.toe3autopilot.core.agents

import dev.toe3autopilot.core.profile.GameProfile
import dev.toe3autopilot.core.vision.Vision
import kotlin.math.hypot

/** How close the truck is to the delivery point, as far as the calibrated cues show. */
enum class DeliveryCue { NONE, NEAR, AT }

/**
 * Decides, from cues the USER calibrated, whether the truck has reached the delivery area. It cannot know where the
 * destination is by itself. Cues, strongest first:
 *
 *  - colour `destination_marker` (a region covering the minimap): its position relative to the truck marker, in
 *    minimap-sized units. Closer than `extra.delivery.nearDist` (default 0.55) = NEAR, closer than
 *    `extra.delivery.atDist` (default 0.15) = AT;
 *  - template `destination_near`: a marker the game shows when the destination is close = NEAR;
 *  - `parking_zone` (template or colour) visible = NEAR.
 *
 * Debounced: a level is only reported after [confirmTicks] consecutive observations, and it falls back only after
 * [holdMs] without it, so one noisy frame can neither start nor cancel the approach.
 */
class DeliveryAreaDetector(
    private val confirmTicks: Int = 3,
    private val holdMs: Long = 8000L,
) {
    var level: DeliveryCue = DeliveryCue.NONE
        private set

    /** Which cue produced the current level (for the log / UI). */
    var reason: String? = null
        private set

    private var candidate = DeliveryCue.NONE
    private var candidateTicks = 0
    private var lastSupportAt = 0L

    fun reset() {
        level = DeliveryCue.NONE
        reason = null
        candidate = DeliveryCue.NONE
        candidateTicks = 0
        lastSupportAt = 0L
    }

    fun update(vision: Vision, profile: GameProfile, now: Long): DeliveryCue {
        val (raw, why) = observe(vision, profile)
        if (raw == candidate) candidateTicks++ else {
            candidate = raw
            candidateTicks = 1
        }
        if (raw >= level && raw != DeliveryCue.NONE) lastSupportAt = now
        when {
            raw > level && candidateTicks >= confirmTicks -> {
                level = raw
                reason = why
                lastSupportAt = now
            }
            raw < level && now - lastSupportAt > holdMs -> {
                level = raw
                reason = why
            }
        }
        return level
    }

    private fun observe(vision: Vision, profile: GameProfile): Pair<DeliveryCue, String?> {
        var best = DeliveryCue.NONE
        var why: String? = null
        fun offer(c: DeliveryCue, r: String) {
            if (c > best) {
                best = c
                why = r
            }
        }
        val nav = profile.nav
        if (nav != null && vision.known("destination_marker")) {
            val blob = vision.color("destination_marker")
            if (blob != null && blob.found && blob.fraction >= MIN_MARKER_FRACTION) {
                val mapW = nav.minimapRoi.right - nav.minimapRoi.left
                val mapH = nav.minimapRoi.bottom - nav.minimapRoi.top
                val d = hypot((blob.cx - nav.truckX) / mapW, (blob.cy - nav.truckY) / mapH)
                val nearDist = profile.extraFloat("delivery.nearDist", 0.55f)
                val atDist = profile.extraFloat("delivery.atDist", 0.15f)
                if (d <= atDist) offer(DeliveryCue.AT, "destination marker at the truck on the minimap")
                else if (d <= nearDist) offer(DeliveryCue.NEAR, "destination marker close on the minimap")
            }
        }
        if (vision.has("destination_near")) offer(DeliveryCue.NEAR, "destination-near marker")
        if (vision.locate("parking_zone") != null) offer(DeliveryCue.NEAR, "parking area visible")
        return best to why
    }

    companion object {
        /** A destination marker smaller than this share of its search region is ignored as noise. */
        const val MIN_MARKER_FRACTION = 0.002f
    }
}
