package dev.toe3autopilot.core.setup

import dev.toe3autopilot.core.Point
import dev.toe3autopilot.core.calibration.CalibRole
import dev.toe3autopilot.core.calibration.ControlDetection
import dev.toe3autopilot.core.calibration.DetectionSource
import dev.toe3autopilot.core.calibration.DetectionStatus
import dev.toe3autopilot.core.calibration.HudAnalysis
import dev.toe3autopilot.core.calibration.LayoutSignature
import dev.toe3autopilot.core.calibration.MinimapSuggestion
import dev.toe3autopilot.core.profile.SteeringMode
import dev.toe3autopilot.core.vision.ColorTarget
import dev.toe3autopilot.core.vision.Frame
import dev.toe3autopilot.core.vision.Roi

/*
 * Smart Setup model. Everything here is plain data or pure functions; [SetupSession] owns the one mutable copy.
 *
 * All positions are in normalised display space (see dev.toe3autopilot.core.geometry).
 */

/**
 * The calibration job's own state. The interface observes this (it never keeps a separate status):
 *
 *     NOT_STARTED -> CAPTURING -> REVIEW_REQUIRED -> ANALYZING -> REVIEW_REQUIRED -> VALIDATING -> CONFIRMED
 *
 * FAILED and CANCELLED can follow CAPTURING or ANALYZING; collected pictures and the draft survive both, so the person
 * can retry, analyse what was collected, or place everything by hand. Any edit after VALIDATING or CONFIRMED returns to
 * REVIEW_REQUIRED, because the validation no longer describes the draft.
 */
enum class SetupPhase(val label: String) {
    NOT_STARTED("Not started"),
    CAPTURING("Capturing pictures"),
    ANALYZING("Analysing"),
    REVIEW_REQUIRED("Needs your review"),
    VALIDATING("Validated"),
    CONFIRMED("Saved"),
    FAILED("Stopped with a problem"),
    CANCELLED("Cancelled");

    val busy: Boolean get() = this == CAPTURING || this == ANALYZING
}

/** The ten steps of the guided workflow, in order. */
enum class SetupStep(val number: Int, val title: String, val short: String) {
    CONNECT(1, "Connect to the game", "Connect"),
    CAPTURE(2, "Capture gameplay pictures", "Capture"),
    SELECT_SCREEN(3, "Choose the driving screen", "Screen"),
    ANALYZE(4, "Analyse the pictures", "Analyse"),
    REVIEW(5, "Review detected controls", "Review"),
    PLACE(6, "Place or correct controls", "Controls"),
    MINIMAP(7, "Minimap and navigation", "Minimap"),
    VALIDATE(8, "Validate the setup", "Validate"),
    SAVE(9, "Save the profile", "Save"),
    TEST(10, "Test the setup safely", "Test"),
}

enum class StepStatus { TODO, DONE, SKIPPED, ATTENTION, BLOCKED }

data class StepState(val step: SetupStep, val status: StepStatus, val detail: String)

/** Where a picture came from. */
enum class FrameOriginKind(val label: String) { LIVE("live capture"), SCREENSHOT("screenshot"), CLIP("video clip") }

/** What a picture shows, judged only from evidence in it. Never a claim beyond that evidence. */
enum class ScreenEvidence(val label: String) {
    /** The scenery moved compared with the picture before and the fixed driving elements are visible. */
    DRIVING_LIKELY("Moving scenery and driving controls visible"),

    /** The scenery moved; whether the driving controls are visible is not known yet (before the analysis). */
    MOVING("Moving scenery"),

    /** Nothing changed since the picture before: a menu, a pause screen or a standing truck look like this. */
    STILL("Still picture (menu, pause or a stopped truck?)"),

    /** A large part is black: a loading screen or a protected view look like this. */
    PARTLY_BLACK("Large black area (loading?)"),

    /** Fixed driving elements are mostly missing: probably not the driving view. */
    HUD_MISSING("Driving controls mostly missing"),

    /** A single picture: nothing to compare it with. */
    SINGLE("Single picture (nothing to compare with)"),
}

/** One collected picture in the gallery. */
data class FrameEntry(
    val id: Int,
    val frame: Frame,
    val origin: FrameOriginKind,
    /** Share of the picture that changed since the previous collected picture (null for the first / imported ones). */
    val motion: Float?,
    val evidence: ScreenEvidence,
    /** Share of the analysed fixed elements visible in this picture (null before the analysis). */
    val hudVisible: Float? = null,
    /**
     * Parts of the picture that HaulPilot itself drew over the game when it was taken (its floating button, its open
     * panel), NDS. They are never searched for controls.
     */
    val exclusions: List<Roi> = emptyList(),
)

data class MinimapDraft(
    val box: Roi? = null,
    /** The person saw and accepted the box (a detected box starts unconfirmed). */
    val boxConfirmed: Boolean = false,
    val routeColor: ColorTarget? = null,
    val truck: Point? = null,
    /** The person chose to do the minimap later. Other steps are not blocked by it. */
    val skipped: Boolean = false,
    /**
     * Optional: colour of the destination marker on the minimap. With it the truck slows down near the destination and
     * stops there; without it, it follows the route until the route ends or is lost.
     */
    val destinationColor: ColorTarget? = null,
    /** Evidence text when the box came from the analysis. */
    val note: String? = null,
) {
    val complete: Boolean get() = box != null && boxConfirmed && routeColor != null && truck != null
}

/**
 * Everything the person has set up so far. Controls use [ControlDetection]: NONE (missing), NEEDS_CONFIRMATION
 * (a candidate), CONFIRMED (confirmed or placed by the person) or REJECTED.
 */
data class SetupDraft(
    /** Picture size the positions were made on (aspect ratio is what matters for the layout check). */
    val layout: LayoutSignature? = null,
    val drivingFrameId: Int? = null,
    val drivingConfirmed: Boolean = false,
    /** Steering style; null until the person confirms a wheel or a button pair, or chooses one. */
    val steering: SteeringMode? = null,
    /** Horizontal drag range for a steering wheel / slider, as a fraction of the screen width. */
    val steerRadius: Float? = null,
    val controls: Map<CalibRole, ControlDetection> = emptyMap(),
    val minimap: MinimapDraft = MinimapDraft(),
    /** Region used to recognise the driving screen (a steady dashboard part), with how it was chosen. */
    val marker: Roi? = null,
    val markerSource: DetectionSource? = null,
    /** The analysis ran on these pictures (it may have found nothing). */
    val analysed: Boolean = false,
    val analysisSkipped: Boolean = false,
) {
    fun control(role: CalibRole): ControlDetection? = controls[role]

    fun confirmed(role: CalibRole): Boolean = controls[role]?.status?.usable == true

    val confirmedCount: Int get() = controls.values.count { it.status.usable }

    val pendingCandidates: List<ControlDetection>
        get() = controls.values.filter { it.status == DetectionStatus.NEEDS_CONFIRMATION }

    /** Roles that must be confirmed before the automation may use this setup. */
    val requiredRoles: List<CalibRole>
        get() = listOf(CalibRole.ACCELERATOR, CalibRole.BRAKE) + when (steering) {
            SteeringMode.SLIDER -> listOf(CalibRole.STEER_WHEEL)
            SteeringMode.BUTTONS -> listOf(CalibRole.STEER_LEFT, CalibRole.STEER_RIGHT)
            null -> emptyList()
        }

    val missingRequired: List<String>
        get() {
            val out = ArrayList<String>()
            for (r in requiredRoles) if (!confirmed(r)) out += r.label
            if (steering == null) out += "Steering type"
            return out
        }

    companion object {
        val EMPTY = SetupDraft()
    }
}

enum class IssueSeverity { ERROR, WARNING }

/** A problem found by [DraftValidator]. ERROR blocks saving; WARNING is shown but does not block. */
data class SetupIssue(val severity: IssueSeverity, val message: String, val role: CalibRole? = null)

data class AnalysisResult(
    val hud: HudAnalysis,
    val detections: Map<CalibRole, ControlDetection>,
    val minimap: MinimapSuggestion?,
    /** Steady dashboard element proposed as the driving-screen marker, if one was found. */
    val marker: Roi?,
    /** Share of fixed elements visible, per frame id. */
    val hudVisibility: Map<Int, Float>,
    val notes: List<String>,
    /** Outlines that may be controls (fixed ones when the scenery moved), NDS: the editor snaps a tap to them. */
    val outlines: List<Roi> = emptyList(),
    /** The analysis could compare many pictures with moving scenery (strong evidence) rather than one picture. */
    val multiFrame: Boolean = false,
    /** What the evidence was based on, in plain words. */
    val basis: String = "",
    /** The game area searched, when black bands were left out (NDS). */
    val viewport: Roi? = null,
)

/** Honest progress of a running analysis: [fraction] moves only when a stage has really finished. */
data class AnalysisProgress(val fraction: Float, val stage: String)

/** Undo / redo for any immutable value. Bounded. */
class History<T>(private val limit: Int = 60) {
    private val undo = ArrayDeque<T>()
    private val redo = ArrayDeque<T>()

    val canUndo: Boolean get() = undo.isNotEmpty()
    val canRedo: Boolean get() = redo.isNotEmpty()

    /** Records [before] as the state to return to; clears the redo stack (a new branch of edits). */
    fun record(before: T) {
        undo.addLast(before)
        while (undo.size > limit) undo.removeFirst()
        redo.clear()
    }

    /** Returns the state to restore, given the [current] one (which becomes redoable). */
    fun undo(current: T): T? {
        val prev = undo.removeLastOrNull() ?: return null
        redo.addLast(current)
        return prev
    }

    fun redo(current: T): T? {
        val next = redo.removeLastOrNull() ?: return null
        undo.addLast(current)
        return next
    }

    fun clear() {
        undo.clear()
        redo.clear()
    }
}

/** Checks a draft before it may be saved. Pure. */
object DraftValidator {
    /** Two controls closer than this (in screen fractions) are almost certainly the same spot placed twice. */
    const val MIN_SEPARATION = 0.035f

    fun validate(d: SetupDraft): List<SetupIssue> {
        val out = ArrayList<SetupIssue>()
        if (d.layout == null) out += SetupIssue(IssueSeverity.ERROR, "There is no picture to calibrate on yet. Capture or import gameplay pictures first.")
        val usable = d.controls.values.filter { it.status.usable }
        for (c in usable) {
            if (c.x !in 0f..1f || c.y !in 0f..1f) out += SetupIssue(IssueSeverity.ERROR, "${c.role.label} lies outside the screen.", c.role)
        }
        // Two different controls on the same spot: one of them is wrong, and pressing it would do the wrong thing.
        for (i in usable.indices) for (j in i + 1 until usable.size) {
            val a = usable[i]
            val b = usable[j]
            if (sameSpotAllowed(a.role, b.role)) continue
            if (dist(a.x, a.y, b.x, b.y) < MIN_SEPARATION) {
                out += SetupIssue(IssueSeverity.ERROR, "${a.role.label} and ${b.role.label} are on the same spot. Move one of them.", b.role)
            }
        }
        val l = d.controls[CalibRole.STEER_LEFT]
        val r = d.controls[CalibRole.STEER_RIGHT]
        if (d.steering == SteeringMode.BUTTONS && l != null && r != null && l.status.usable && r.status.usable && l.x > r.x) {
            out += SetupIssue(IssueSeverity.ERROR, "Steer left is placed to the right of steer right. Swap them.", CalibRole.STEER_LEFT)
        }
        val acc = d.controls[CalibRole.ACCELERATOR]
        val brk = d.controls[CalibRole.BRAKE]
        if (acc != null && brk != null && acc.status.usable && brk.status.usable && acc.x < brk.x - 0.02f) {
            out += SetupIssue(IssueSeverity.WARNING, "The accelerator is placed to the left of the brake. That is unusual; check you did not swap them.", CalibRole.ACCELERATOR)
        }
        if (d.steering == SteeringMode.SLIDER) {
            val wheel = d.controls[CalibRole.STEER_WHEEL]
            val radius = d.steerRadius ?: 0.12f
            if (wheel != null && wheel.status.usable && (wheel.x - radius < 0f || wheel.x + radius > 1f)) {
                out += SetupIssue(IssueSeverity.WARNING, "The steering range reaches past the screen edge; full lock on one side will not be possible.", CalibRole.STEER_WHEEL)
            }
        }
        val mm = d.minimap
        val box = mm.box
        if (box != null && mm.boxConfirmed) {
            val hFrac = box.bottom - box.top
            if (hFrac < 0.05f) out += SetupIssue(IssueSeverity.ERROR, "The minimap area is too small to read the route. Make the box cover the whole map.")
            if (hFrac > 0.8f || (box.right - box.left) > 0.8f) out += SetupIssue(IssueSeverity.ERROR, "The minimap area covers most of the screen. Make the box cover only the map.")
            mm.truck?.let { t ->
                if (!(t.x >= box.left && t.x <= box.right && t.y >= box.top && t.y <= box.bottom)) {
                    out += SetupIssue(IssueSeverity.ERROR, "Your truck's position must be inside the minimap box.")
                }
            }
            for (c in usable) {
                if (c.x >= box.left && c.x <= box.right && c.y >= box.top && c.y <= box.bottom) {
                    out += SetupIssue(IssueSeverity.WARNING, "${c.role.label} lies inside the minimap area. Check the box or the control.", c.role)
                }
            }
            mm.routeColor?.let { col ->
                val hi = maxOf(col.r, col.g, col.b)
                val lo = minOf(col.r, col.g, col.b)
                if (hi < 60 || hi - lo < 40) out += SetupIssue(IssueSeverity.ERROR, "The route colour is grey or black, which the map background also is. Tap the coloured route line itself.")
            }
            mm.destinationColor?.let { dest ->
                val route = mm.routeColor
                if (route != null && colourDistance(dest, route) < SAME_COLOUR) {
                    out += SetupIssue(IssueSeverity.ERROR, "The destination marker has the same colour as the route line, so it cannot mark the destination. Pick the destination icon itself, or remove it.")
                }
            }
        }
        if (d.confirmedCount == 0 && !(mm.box != null && mm.boxConfirmed)) {
            out += SetupIssue(IssueSeverity.ERROR, "Nothing is confirmed yet. Confirm or place at least one control.")
        }
        return out
    }

    fun canSave(issues: List<SetupIssue>): Boolean = issues.none { it.severity == IssueSeverity.ERROR }

    /** Colours closer than this (sum of channel differences) cannot be told apart on the minimap. */
    const val SAME_COLOUR = 60

    fun colourDistance(a: ColorTarget, b: ColorTarget): Int = kotlin.math.abs(a.r - b.r) + kotlin.math.abs(a.g - b.g) + kotlin.math.abs(a.b - b.b)

    private fun sameSpotAllowed(a: CalibRole, b: CalibRole): Boolean {
        // A wheel and the buttons are alternatives; only one style is used.
        val steer = setOf(CalibRole.STEER_WHEEL, CalibRole.STEER_LEFT, CalibRole.STEER_RIGHT)
        return (a == CalibRole.STEER_WHEEL && b in steer) || (b == CalibRole.STEER_WHEEL && a in steer)
    }

    private fun dist(ax: Float, ay: Float, bx: Float, by: Float): Float = kotlin.math.hypot(ax - bx, ay - by)
}
