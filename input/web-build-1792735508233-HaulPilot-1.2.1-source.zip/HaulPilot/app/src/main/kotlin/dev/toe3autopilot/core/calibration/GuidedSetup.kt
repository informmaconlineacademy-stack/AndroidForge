package dev.toe3autopilot.core.calibration

import dev.toe3autopilot.core.profile.ProfileEditing
import dev.toe3autopilot.core.vision.ColorTarget
import dev.toe3autopilot.core.vision.Frame
import dev.toe3autopilot.core.vision.Roi
import kotlin.math.max
import kotlin.math.min

/** Small pure helpers used by Smart Setup's picture-based steps. */
object GuidedSetup {
    /**
     * Picks the fixed on-screen element that best identifies the driving view: present in nearly every analysed picture,
     * not a control (a control may change its look when pressed), not the minimap (its content changes), not tiny
     * (unreliable) and not huge (would include scenery).
     */
    fun pickDrivingMarker(hud: HudAnalysis, avoid: List<Roi>): HudElement? =
        hud.elements
            .filter { it.persistence >= 0.8f && it.areaFraction in 0.0006f..0.05f }
            .filter { e -> avoid.none { overlaps(it, e.box) } }
            .maxByOrNull { it.persistence * 2f + min(it.areaFraction * 40f, 1f) }

    /** Average colour of a small square around a tap (5 x 5 pixels at the processing resolution). */
    fun colorAt(frame: Frame, x: Float, y: Float, tolerance: Int = 45): ColorTarget {
        val px = (x * frame.width).toInt().coerceIn(0, frame.width - 1)
        val py = (y * frame.height).toInt().coerceIn(0, frame.height - 1)
        val x0 = max(0, px - 2)
        val x1 = min(frame.width, px + 3)
        val y0 = max(0, py - 2)
        val y1 = min(frame.height, py + 3)
        return ProfileEditing.averageColor(frame, Roi(x0.toFloat() / frame.width, y0.toFloat() / frame.height, x1.toFloat() / frame.width, y1.toFloat() / frame.height), tolerance)
    }

    /** Route lines and markers are saturated colours; grey or very dark taps are almost always the map background. */
    fun colourProblem(c: ColorTarget): String? {
        val hi = max(c.r, max(c.g, c.b))
        val lo = min(c.r, min(c.g, c.b))
        return when {
            hi < 60 -> "That spot is almost black. Tap exactly on the coloured route line (zoom in with two fingers if needed)."
            hi - lo < 40 -> "That spot is grey, not a colour. Tap exactly on the coloured route line."
            else -> null
        }
    }

    private fun overlaps(a: Roi, b: Roi): Boolean = a.left < b.right && b.left < a.right && a.top < b.bottom && b.top < a.bottom
}

/**
 * Tap-to-identify: when the person taps a control, use the fixed on-screen element under the finger (so the region fits
 * the button) instead of a box of arbitrary size. Falls back to a square around the tap. Positions are NDS.
 */
object TapSnap {
    fun boxFor(hud: HudAnalysis?, x: Float, y: Float, aspect: Float, fallbackHeight: Float = 0.12f): Roi {
        val hit = hud?.elements
            ?.filter { x >= it.box.left && x <= it.box.right && y >= it.box.top && y <= it.box.bottom && it.areaFraction <= 0.08f }
            ?.minByOrNull { it.areaFraction }
        if (hit != null) return hit.box
        return square(x, y, aspect, fallbackHeight)
    }

    /** Same, using bare boxes (what Smart Setup keeps of the analysis). */
    fun boxFor(boxes: List<Roi>, x: Float, y: Float, aspect: Float, fallbackHeight: Float = 0.12f): Roi {
        val hit = boxes
            .filter { x >= it.left && x <= it.right && y >= it.top && y <= it.bottom && (it.right - it.left) * (it.bottom - it.top) <= 0.08f }
            .minByOrNull { (it.right - it.left) * (it.bottom - it.top) }
        return hit ?: square(x, y, aspect, fallbackHeight)
    }

    private fun square(x: Float, y: Float, aspect: Float, h: Float): Roi {
        val w = (h / aspect).coerceIn(0.03f, 0.3f)
        val l = (x - w / 2).coerceIn(0f, 1f - w)
        val t = (y - h / 2).coerceIn(0f, 1f - h)
        return Roi(l, t, l + w, t + h)
    }
}
