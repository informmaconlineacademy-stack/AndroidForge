package dev.toe3autopilot.app.setup

import android.content.Context
import android.net.Uri
import dev.toe3autopilot.app.ScreenshotImport
import dev.toe3autopilot.app.calibration.VideoImporter
import dev.toe3autopilot.app.data.SetupDraftStore
import dev.toe3autopilot.core.AutomationSettings
import dev.toe3autopilot.core.WallClock
import dev.toe3autopilot.core.calibration.VideoValidator
import dev.toe3autopilot.core.capture.FrameOrigin
import dev.toe3autopilot.core.profile.ProfileLoad
import dev.toe3autopilot.core.profile.ProfileRepository
import dev.toe3autopilot.core.session.LogLevel
import dev.toe3autopilot.core.setup.DraftApply
import dev.toe3autopilot.core.setup.DraftCodec
import dev.toe3autopilot.core.setup.FrameOriginKind
import dev.toe3autopilot.core.setup.SetupAnalysis
import dev.toe3autopilot.core.setup.SetupDraft
import dev.toe3autopilot.core.setup.SetupIssue
import dev.toe3autopilot.core.setup.SetupPhase
import dev.toe3autopilot.core.setup.SetupSession
import dev.toe3autopilot.core.setup.SetupState
import dev.toe3autopilot.core.setup.SetupTestReport
import dev.toe3autopilot.core.setup.SetupVerifier
import dev.toe3autopilot.core.vision.Frame
import dev.toe3autopilot.core.vision.Roi
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/** Progress of a screenshot or clip import (null when none is running). */
data class ImportProgress(val label: String, val fraction: Float?)

/** Where Save writes the setup. */
sealed class SaveTarget {
    /** Replace (and keep using) an existing profile. */
    data class Existing(val id: String) : SaveTarget()

    /** A new profile with this name. */
    data class New(val name: String) : SaveTarget()
}

/** What happened when the person pressed Save. */
data class SaveOutcome(
    val ok: Boolean,
    val message: String,
    val applied: List<String> = emptyList(),
    val skipped: List<String> = emptyList(),
    val warnings: List<String> = emptyList(),
    val notReadyToDrive: List<String> = emptyList(),
    val profileId: String? = null,
)

/**
 * Android side of Smart Setup. Owns the one [SetupSession] (the single source of truth the screens observe), feeds it
 * live pictures, runs imports and the analysis off the main thread as cancellable jobs, saves through the
 * [ProfileRepository], and keeps the draft on disk so it survives the app being closed.
 *
 * It never sends a touch and never starts a drive.
 */
class SetupController(
    private val appContext: Context,
    private val repo: ProfileRepository,
    private val draftStore: SetupDraftStore,
    private val scope: CoroutineScope,
    private val log: (LogLevel, String) -> Unit,
    private val gamePackage: () -> String,
    private val settings: () -> AutomationSettings,
    /** The newest live pictures of the SELECTED game, oldest first (empty when none), for the safe test. */
    private val recentGameFrames: () -> List<Frame>,
    /** The selected game and what is in front, as two separate facts. */
    private val foreground: () -> dev.toe3autopilot.core.capture.ForegroundView,
    /** Called after a profile was saved or changed, so the lists refresh. */
    private val onProfilesChanged: () -> Unit,
) {
    val session = SetupSession(WallClock)

    private val _state = MutableStateFlow(session.state())
    val state: StateFlow<SetupState> = _state.asStateFlow()

    private val _import = MutableStateFlow<ImportProgress?>(null)
    val importProgress: StateFlow<ImportProgress?> = _import.asStateFlow()

    private var analysisJob: Job? = null
    private var importJob: Job? = null
    private var persistJob: Job? = null
    private var lastPersisted: Pair<SetupDraft, Int?>? = null

    @Volatile
    private var importCancelled = false

    init {
        restore()
    }

    // ---- state ----------------------------------------------------------------------------------------------

    private fun publish() {
        val s = session.state()
        if (_state.value != s) _state.value = s
        schedulePersist(s)
        // Auto-Calibrate: when its collection has finished, the analysis starts by itself (no step to find and press).
        if (s.autoAnalyze && s.phase == SetupPhase.REVIEW_REQUIRED && analysisJob?.isActive != true) analyze()
    }

    // ---- live capture -----------------------------------------------------------------------------------------

    /** Null when collecting started, otherwise why not. */
    fun startCapture(keepPictures: Boolean = false): String? {
        val err = session.startCapture(keepPictures)
        if (err == null) log(LogLevel.INFO, "Smart Setup: collecting live pictures")
        publish()
        return err
    }

    /**
     * Auto-Calibrate: collects while the person drives (only pictures with moving scenery count), then analyses by itself.
     * Earlier pictures are dropped; everything already placed or confirmed is kept. Null when started, otherwise why not.
     */
    fun autoCalibrate(): String? {
        if (analysisJob?.isActive == true) return "An analysis is running; wait for it or cancel it."
        val err = session.startAuto()
        if (err == null) log(LogLevel.INFO, "Auto-Calibrate: collecting pictures while driving")
        publish()
        return err
    }

    fun stopCapture() {
        session.stopCapture()
        publish()
    }

    /**
     * Every captured picture (capture thread). Cheap unless the picture is kept. [exclusions] are HaulPilot's own windows
     * over the game at that moment (normalised display space); they are never searched for controls.
     */
    fun onFrame(frame: Frame, origin: FrameOrigin, exclusions: List<Roi> = emptyList()) {
        if (_state.value.phase != SetupPhase.CAPTURING) return
        session.offer(frame, origin, exclusions)
        publish()
    }

    /** Connection facts, about once a second from the capture loop. */
    fun onLink(captureOn: Boolean, linkProblem: String?, origin: FrameOrigin?) {
        if (_state.value.phase != SetupPhase.CAPTURING) return
        session.onLink(captureOn, linkProblem, origin)
        val s = session.state()
        if (s.phase == SetupPhase.FAILED) log(LogLevel.WARN, "Smart Setup: collection stopped: ${s.problem}")
        publish()
    }

    /** Cancels whatever is running (collection, import, analysis). Pictures and the draft are kept. */
    fun cancel() {
        analysisJob?.cancel()
        importCancelled = true
        importJob?.cancel()
        _import.value = null
        session.cancel()
        publish()
    }

    // ---- imports ------------------------------------------------------------------------------------------------

    fun importScreenshots(uris: List<Uri>) {
        if (importJob?.isActive == true) return
        importCancelled = false
        _import.value = ImportProgress("Reading ${uris.size} picture(s)", null)
        importJob = scope.launch(Dispatchers.IO) {
            try {
                val loaded = ScreenshotImport.load(appContext, uris)
                val err = session.importFrames(loaded.frames, FrameOriginKind.SCREENSHOT)
                log(LogLevel.INFO, "Smart Setup: ${loaded.frames.size} screenshot(s) imported, ${loaded.failed} unreadable")
                if (err != null) session.reportProblem(err)
                if (loaded.failed > 0 && err == null) log(LogLevel.WARN, "${loaded.failed} picture(s) could not be read")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                log(LogLevel.WARN, "Screenshot import failed: ${e.javaClass.simpleName}")
            } finally {
                _import.value = null
                publish()
            }
        }
    }

    fun importClip(uri: Uri) {
        if (importJob?.isActive == true) return
        importCancelled = false
        _import.value = ImportProgress("Checking the video", null)
        importJob = scope.launch(Dispatchers.IO) {
            try {
                val (info, failure) = VideoImporter.readInfo(appContext, uri)
                if (info == null) {
                    importFailed(failure?.message ?: "The video could not be opened.")
                    return@launch
                }
                val check = VideoValidator.checkInfo(info)
                if (!check.usable) {
                    importFailed(check.problems.first())
                    return@launch
                }
                val r = VideoImporter.load(appContext, uri, info, onProgress = { p -> _import.value = ImportProgress("Reading pictures from the video", p) }, isCancelled = { importCancelled })
                when (r) {
                    is VideoImporter.Result.Failed -> if (!importCancelled) importFailed(r.message)
                    is VideoImporter.Result.Ok -> {
                        val err = session.importFrames(r.frames, FrameOriginKind.CLIP)
                        log(LogLevel.INFO, "Smart Setup: ${r.frames.size}/${r.requested} pictures read from a clip")
                        if (err != null) importFailed(err)
                    }
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                importFailed("The video could not be processed (${e.javaClass.simpleName}).")
            } finally {
                _import.value = null
                publish()
            }
        }
    }

    /** Uses saved sample snapshots (Settings -> Diagnostics) as pictures. */
    fun importFrames(frames: List<Frame>, kind: FrameOriginKind): String? {
        val err = session.importFrames(frames, kind)
        publish()
        return err
    }

    private fun importFailed(msg: String) {
        log(LogLevel.WARN, "Smart Setup import: $msg")
        session.reportProblem(msg)
    }

    // ---- picture choice, analysis -------------------------------------------------------------------------------

    fun selectFrame(id: Int): String? {
        val e = session.selectDrivingFrame(id)
        publish()
        return e
    }

    fun removeFrame(id: Int) {
        session.removeFrame(id)
        publish()
    }

    /** Starts the analysis unless one is running (duplicates are refused by the session as well). */
    fun analyze() {
        if (analysisJob?.isActive == true) return
        val job = session.beginAnalysis()
        publish()
        if (job == null) return
        analysisJob = scope.launch(Dispatchers.Default) {
            try {
                var lastPublished = 0L
                val r = SetupAnalysis.run(
                    job.frames, job.selectedId,
                    progress = { p ->
                        session.reportProgress(job, p)
                        val now = System.currentTimeMillis()
                        // At most a few UI updates a second; the stages themselves are coarse.
                        if (now - lastPublished >= 150L || p.fraction >= 1f) {
                            lastPublished = now
                            publish()
                        }
                    },
                ) { !isActive }
                if (r != null && session.completeAnalysis(job, r)) {
                    log(LogLevel.INFO, (if (job.auto) "Auto-Calibrate" else "Smart Setup") + " analysis: " + r.notes.joinToString(" | "))
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                session.failAnalysis(job, e.javaClass.simpleName)
                log(LogLevel.WARN, "Smart Setup analysis failed: ${e.javaClass.simpleName}: ${e.message}")
            } catch (e: OutOfMemoryError) {
                session.failAnalysis(job, "not enough memory")
                log(LogLevel.WARN, "Smart Setup analysis ran out of memory")
            } finally {
                publish()
            }
        }
    }

    fun skipAnalysis() {
        session.skipAnalysis()
        publish()
    }

    // ---- editing --------------------------------------------------------------------------------------------------

    fun edit(transform: (SetupDraft) -> SetupDraft): Boolean {
        val ok = session.edit(transform)
        publish()
        return ok
    }

    fun undo(): Boolean = session.undo().also { publish() }

    fun redo(): Boolean = session.redo().also { publish() }

    fun validate(): List<SetupIssue> = session.validate().also { publish() }

    // ---- save / test ------------------------------------------------------------------------------------------------

    /** Writes the validated draft to a profile and makes it the active one. Blocking file work: call off the main thread. */
    fun save(target: SaveTarget): SaveOutcome {
        val st = session.state()
        if (!st.canSave) return SaveOutcome(false, "Validate the setup without errors first.")
        val base = (target as? SaveTarget.Existing)?.let { (repo.load(it.id) as? ProfileLoad.Ok)?.profile }
        if (target is SaveTarget.Existing && base == null && repo.load(target.id) !is ProfileLoad.Missing) {
            // A damaged profile is not merged with; the setup is written as a fresh version of it.
            log(LogLevel.WARN, "Saving over a damaged profile; its earlier content is not reused")
        }
        val name = when (target) {
            is SaveTarget.Existing -> base?.name ?: target.id
            is SaveTarget.New -> target.name.trim().ifEmpty { "My profile" }
        }
        val r = DraftApply.apply(
            base, st.draft, st.selectedFrame?.frame, name, gamePackage(), System.currentTimeMillis(),
            (target as? SaveTarget.Existing)?.let { repo.storeFor(it.id) },
            // Control pictures are made from the steady parts of all collected pictures (null with fewer than six).
            dev.toe3autopilot.core.setup.StabilityMap.of(st.frames, st.selectedFrame?.frame),
        )
        if (!r.ok) {
            session.markSaveFailed(r.problem ?: "unknown problem")
            publish()
            return SaveOutcome(false, "Not saved: ${r.problem}")
        }
        val id = when (target) {
            is SaveTarget.Existing -> target.id
            is SaveTarget.New -> try {
                repo.create(name, gamePackage())
            } catch (e: Exception) {
                session.markSaveFailed("the profile could not be created (${e.message})")
                publish()
                return SaveOutcome(false, "Not saved: the profile could not be created.")
            }
        }
        val res = repo.save(id, r.profile!!, r.patches, replaceTemplates = r.fresh)
        if (!res.ok) {
            session.markSaveFailed(res.error ?: "unknown problem")
            publish()
            log(LogLevel.ERROR, "Saving profile '$name' failed: ${res.error}")
            return SaveOutcome(false, res.error ?: "Not saved.")
        }
        repo.activate(id)
        session.markSaved(name)
        publish()
        onProfilesChanged()
        log(LogLevel.INFO, "Smart Setup saved to profile '$name' (${r.applied.size} item(s); ${r.skipped.size} skipped)")
        return SaveOutcome(
            true, "Saved to \"$name\" and made it the active profile.", r.applied, r.skipped, r.warnings, r.notReadyToDrive, id,
        )
    }

    /** Step 10: checks the active profile against the newest live picture. Sends no touch. Call off the main thread. */
    fun runTest(): SetupTestReport {
        val p = repo.active()
        val report = if (p == null) {
            SetupTestReport(listOf(dev.toe3autopilot.core.setup.TestCheck("A saved, active profile exists", false, "Save the setup first.")), System.currentTimeMillis())
        } else {
            SetupVerifier.verify(p, repo, recentGameFrames(), System.currentTimeMillis(), settings(), foreground())
        }
        session.recordTest(report)
        publish()
        log(LogLevel.INFO, "Smart Setup test: " + report.checks.joinToString { "${it.title}=${if (it.ok) "ok" else "no"}" })
        return report
    }

    /** Loads a saved profile's controls for editing in Smart Setup. */
    fun editProfile(id: String): String? {
        val p = (repo.load(id) as? ProfileLoad.Ok)?.profile ?: return "That profile cannot be read."
        session.loadDraft(DraftApply.fromProfile(p), p.name)
        publish()
        return null
    }

    /** Starts over. Saved profiles are not touched. */
    fun resetAll() {
        analysisJob?.cancel()
        importCancelled = true
        importJob?.cancel()
        _import.value = null
        session.resetAll()
        lastPersisted = null
        scope.launch(Dispatchers.IO) {
            try {
                draftStore.clear()
            } catch (_: Exception) {
            }
        }
        publish()
        log(LogLevel.INFO, "Smart Setup was reset (saved profiles unchanged)")
    }

    // ---- persistence --------------------------------------------------------------------------------------------------

    private fun schedulePersist(s: SetupState) {
        val key = s.draft to s.draft.drivingFrameId
        if (key == lastPersisted) return
        lastPersisted = key
        val text = DraftCodec.format(s.draft, s.savedProfile, s.dirty)
        val picture = s.selectedFrame?.frame
        persistJob?.cancel()
        persistJob = scope.launch(Dispatchers.IO) {
            delay(PERSIST_DELAY_MS)
            try {
                draftStore.write(text, picture)
            } catch (e: Exception) {
                log(LogLevel.WARN, "The setup could not be saved for later: ${e.javaClass.simpleName}")
            }
        }
    }

    private fun restore() {
        try {
            val text = draftStore.readText() ?: return
            val parsed = DraftCodec.parse(text)
            val pic = try {
                draftStore.readPicture()
            } catch (e: Exception) {
                null
            }
            session.restore(parsed.draft, pic, parsed.savedProfile, parsed.dirty)
            parsed.warnings.forEach { log(LogLevel.WARN, "Saved setup: $it") }
            val s = session.state()
            lastPersisted = s.draft to s.draft.drivingFrameId
            _state.value = s
        } catch (e: Exception) {
            log(LogLevel.WARN, "The unfinished setup could not be restored: ${e.javaClass.simpleName}")
        }
    }

    companion object {
        private const val PERSIST_DELAY_MS = 400L
    }
}
