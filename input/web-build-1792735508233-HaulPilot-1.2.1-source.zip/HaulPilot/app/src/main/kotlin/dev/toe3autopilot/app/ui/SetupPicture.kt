package dev.toe3autopilot.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.sp
import dev.toe3autopilot.core.calibration.CalibRole
import dev.toe3autopilot.core.calibration.DetectionStatus
import dev.toe3autopilot.core.geometry.EditorTransform
import dev.toe3autopilot.core.geometry.FitTransform
import dev.toe3autopilot.core.geometry.ZoomPan
import dev.toe3autopilot.core.profile.SteeringMode
import dev.toe3autopilot.core.setup.DraftEdits
import dev.toe3autopilot.core.setup.SetupDraft
import dev.toe3autopilot.core.vision.Frame
import dev.toe3autopilot.core.vision.Roi

/*
 * Drawing of a picture and the setup on top of it. The SAME EditorTransform maps the picture and every marker, both in
 * the small previews and in the full-screen editor, so a marker can never drift away from what it marks.
 */

/** Short names used on the picture. */
fun roleShort(r: CalibRole): String = when (r) {
    CalibRole.ACCELERATOR -> "Accelerator"
    CalibRole.BRAKE -> "Brake"
    CalibRole.STEER_WHEEL -> "Wheel"
    CalibRole.STEER_LEFT -> "Left"
    CalibRole.STEER_RIGHT -> "Right"
    CalibRole.GEAR_REVERSE -> "Reverse"
    CalibRole.SPEED_READOUT -> "Speed"
}

/** The controls Smart Setup works with, in the order they are shown. */
fun setupRoles(steering: SteeringMode?): List<CalibRole> = listOf(CalibRole.ACCELERATOR, CalibRole.BRAKE) + when (steering) {
    SteeringMode.SLIDER -> listOf(CalibRole.STEER_WHEEL)
    SteeringMode.BUTTONS -> listOf(CalibRole.STEER_LEFT, CalibRole.STEER_RIGHT)
    null -> emptyList()
} + CalibRole.GEAR_REVERSE

/** Remembers the picture as an ImageBitmap (converted once per frame). */
@Composable
fun rememberImage(frame: Frame): ImageBitmap {
    val bmp = rememberBitmap(frame)
    return remember(bmp) { bmp.asImageBitmap() }
}

/** Draws [img] (a [Frame] of [w] x [h] pixels) through [t]: pixel-exact, no smoothing, so zooming shows the real pixels. */
fun DrawScope.drawPicture(img: ImageBitmap, w: Int, h: Int, t: EditorTransform) {
    val origin = t.toScreen(0f, 0f)
    val s = t.fit.scale * t.zoom.scale
    withTransform({
        translate(origin.x, origin.y)
        scale(s, s, pivot = Offset.Zero)
    }) {
        drawImage(img, IntOffset.Zero, IntSize(w, h), IntOffset.Zero, IntSize(w, h), filterQuality = FilterQuality.None)
    }
}

private fun DrawScope.rectOf(t: EditorTransform, r: Roi): Pair<Offset, Size> {
    val a = t.toScreen(r.left, r.top)
    val b = t.toScreen(r.right, r.bottom)
    return Offset(a.x, a.y) to Size(b.x - a.x, b.y - a.y)
}

fun DrawScope.drawRoi(t: EditorTransform, r: Roi, color: Color, width: Float, dashed: Boolean) {
    val (o, s) = rectOf(t, r)
    drawRect(color, o, s, style = Stroke(width, pathEffect = if (dashed) PathEffect.dashPathEffect(floatArrayOf(width * 4f, width * 3f)) else null))
}

/** A small label with a dark backing so it is readable on any part of the game picture. */
fun DrawScope.drawLabel(measurer: TextMeasurer, text: String, at: Offset, color: Color, above: Boolean = true) {
    val layout = measurer.measure(text, TextStyle(color = color, fontSize = 11.sp, fontWeight = FontWeight.SemiBold))
    val pad = 4f * density
    val w = layout.size.width + pad * 2
    val h = layout.size.height + pad
    var x = at.x - w / 2f
    var y = if (above) at.y - h - 6f * density else at.y + 6f * density
    x = x.coerceIn(0f, (size.width - w).coerceAtLeast(0f))
    y = y.coerceIn(0f, (size.height - h).coerceAtLeast(0f))
    drawRoundRect(Color(0xE60B0F15), Offset(x, y), Size(w, h), CornerRadius(6f * density))
    drawText(layout, topLeft = Offset(x + pad, y + pad / 2f))
}

/** A ring marker with a centre dot. */
fun DrawScope.drawPointMarker(at: Offset, color: Color, emphasised: Boolean) {
    val r = (if (emphasised) 11f else 8f) * density
    drawCircle(Color(0x990B0F15), r + 2.5f * density, at)
    drawCircle(color, r, at, style = Stroke((if (emphasised) 3f else 2.2f) * density))
    drawCircle(color, 2.2f * density, at)
}

/**
 * Everything the draft knows, on the picture: confirmed controls (green), candidates (yellow, dashed), the control
 * being worked on ([highlight], cyan), the wheel's steering range, the minimap box, the truck and the screen marker.
 */
fun DrawScope.drawDraft(
    t: EditorTransform,
    d: SetupDraft,
    measurer: TextMeasurer,
    highlight: CalibRole? = null,
    showMinimap: Boolean = true,
    showMarker: Boolean = true,
    skipRole: CalibRole? = null,
) {
    val dp = density
    if (showMarker) d.marker?.let { m ->
        drawRoi(t, m, Hp.Info.copy(alpha = 0.8f), 1.5f * dp, dashed = true)
        val p = t.toScreen(m.left, m.bottom)
        drawLabel(measurer, "Screen marker", Offset(p.x + 40f * dp, p.y), Hp.Info, above = false)
    }
    if (showMinimap) {
        val mm = d.minimap
        mm.box?.let { b ->
            drawRoi(t, b, if (mm.boxConfirmed) Hp.Accent else Hp.Warning, 2f * dp, dashed = !mm.boxConfirmed)
            val p = t.toScreen((b.left + b.right) / 2f, b.top)
            drawLabel(measurer, if (mm.boxConfirmed) "Minimap" else "Minimap?", Offset(p.x, p.y), if (mm.boxConfirmed) Hp.Accent else Hp.Warning)
        }
        mm.truck?.let { tr ->
            val p = t.toScreen(tr.x, tr.y)
            drawCircle(Color(0x990B0F15), 7f * dp, Offset(p.x, p.y))
            drawCircle(Hp.Primary, 5f * dp, Offset(p.x, p.y))
        }
    }
    for ((role, c) in d.controls) {
        if (role == skipRole) continue
        if (c.status == DetectionStatus.NONE) continue
        if (c.status == DetectionStatus.REJECTED && role != highlight) continue
        val color = when {
            role == highlight -> Hp.Accent
            c.status.usable -> Hp.Success
            c.status == DetectionStatus.NEEDS_CONFIRMATION -> Hp.Warning
            else -> Hp.TextMuted
        }
        c.box?.let { drawRoi(t, it, color.copy(alpha = 0.9f), 1.6f * dp, dashed = !c.status.usable) }
        val p = t.toScreen(c.x, c.y)
        val at = Offset(p.x, p.y)
        if (role == CalibRole.STEER_WHEEL && d.steering == SteeringMode.SLIDER && c.status.usable) {
            val r = d.steerRadius ?: DraftEdits.DEFAULT_STEER_RADIUS
            val l = t.toScreen((c.x - r).coerceAtLeast(0f), c.y)
            val rr = t.toScreen((c.x + r).coerceAtMost(1f), c.y)
            drawLine(color.copy(alpha = 0.8f), Offset(l.x, l.y), Offset(rr.x, rr.y), 2f * dp, pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f * dp, 4f * dp)))
            drawCircle(color, 3f * dp, Offset(l.x, l.y))
            drawCircle(color, 3f * dp, Offset(rr.x, rr.y))
        }
        drawPointMarker(at, color, role == highlight)
        val word = when {
            c.status == DetectionStatus.REJECTED -> "${roleShort(role)} (rejected)"
            c.status == DetectionStatus.NEEDS_CONFIRMATION -> "${roleShort(role)}?"
            else -> roleShort(role)
        }
        drawLabel(measurer, word, at, color)
    }
}

/**
 * The chosen picture with the setup drawn on it, fitted to its own aspect ratio. Tapping it opens the editor.
 */
@Composable
fun AnnotatedPicture(
    frame: Frame,
    draft: SetupDraft,
    modifier: Modifier = Modifier,
    highlight: CalibRole? = null,
    showMinimap: Boolean = true,
    description: String = "The chosen driving picture with the controls marked on it",
    onClick: (() -> Unit)? = null,
) {
    val img = rememberImage(frame)
    val measurer = rememberTextMeasurer()
    var size by remember { mutableStateOf(IntSize.Zero) }
    val base = modifier
        .fillMaxWidth()
        .aspectRatio(frame.width.toFloat() / frame.height)
        .clip(RoundedCornerShape(Sp.radiusM))
        .background(Hp.Raised)
        .onSizeChanged { size = it }
        .semantics { contentDescription = description }
    Box(if (onClick != null) base.clickable(role = Role.Button, onClick = onClick) else base) {
        Canvas(Modifier.fillMaxSize().clipToBounds()) {
            if (size.width <= 0 || size.height <= 0) return@Canvas
            val t = EditorTransform(FitTransform(frame.width.toFloat(), frame.height.toFloat(), size.width.toFloat(), size.height.toFloat()), ZoomPan.NONE)
            drawPicture(img, frame.width, frame.height, t)
            drawDraft(t, draft, measurer, highlight, showMinimap)
        }
    }
}
