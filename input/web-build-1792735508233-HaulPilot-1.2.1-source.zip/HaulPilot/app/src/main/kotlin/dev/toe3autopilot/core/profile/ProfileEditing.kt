package dev.toe3autopilot.core.profile

import dev.toe3autopilot.core.Control
import dev.toe3autopilot.core.Point
import dev.toe3autopilot.core.clampF
import dev.toe3autopilot.core.state.GameState
import dev.toe3autopilot.core.vision.ColorTarget
import dev.toe3autopilot.core.vision.Frame
import dev.toe3autopilot.core.vision.PixelRect
import dev.toe3autopilot.core.vision.Roi

/**
 * Pure functions behind the calibration screen, kept Android-free so they can be unit-tested.
 * They never throw for ordinary UI input; invalid names are reported through [validateName].
 */
object ProfileEditing {
    private val NAME = Regex("[a-z0-9_]+")

    fun validateName(name: String): String? =
        if (NAME.matches(name)) null else "Use only lowercase letters, digits and underscores"

    /** Rectangle dragged on a [viewW]x[viewH] view -> normalised ROI, clamped, with a minimum size. Null if too small. */
    fun roiFromDrag(x0: Float, y0: Float, x1: Float, y1: Float, viewW: Float, viewH: Float, minFraction: Float = 0.01f): Roi? {
        if (viewW <= 0f || viewH <= 0f) return null
        val l = clampF(minOf(x0, x1) / viewW, 0f, 1f)
        val r = clampF(maxOf(x0, x1) / viewW, 0f, 1f)
        val t = clampF(minOf(y0, y1) / viewH, 0f, 1f)
        val b = clampF(maxOf(y0, y1) / viewH, 0f, 1f)
        if (r - l < minFraction || b - t < minFraction) return null
        return Roi(l, t, r, b)
    }

    /** Search area for a template captured at [found]: the template's rectangle grown by [margin] on each side. */
    fun searchRoi(found: Roi, margin: Float = 0.08f): Roi = Roi(
        clampF(found.left - margin, 0f, 1f), clampF(found.top - margin, 0f, 1f),
        clampF(found.right + margin, 0f, 1f), clampF(found.bottom + margin, 0f, 1f),
    )

    /** Pixel rectangle of [roi] inside [frame] (what gets cropped out as the template image). */
    fun cropRect(roi: Roi, frame: Frame): PixelRect = roi.toRect(frame.width, frame.height)

    /** Mean colour of the pixels in [roi] as a match target. */
    fun averageColor(frame: Frame, roi: Roi, tolerance: Int = 45): ColorTarget {
        val r = roi.toRect(frame.width, frame.height)
        var sr = 0L
        var sg = 0L
        var sb = 0L
        var n = 0L
        for (y in r.y0 until r.y1) {
            for (x in r.x0 until r.x1) {
                val p = frame.argb[y * frame.width + x]
                sr += (p shr 16) and 0xFF
                sg += (p shr 8) and 0xFF
                sb += p and 0xFF
                n++
            }
        }
        if (n == 0L) return ColorTarget(0, 0, 0, tolerance)
        return ColorTarget((sr / n).toInt(), (sg / n).toInt(), (sb / n).toInt(), tolerance)
    }

    /** Templates are stored at the frame width they were taken from; a profile can only use one width. */
    fun widthProblem(profile: GameProfile, frameWidth: Int): String? =
        if (profile.referenceWidth != 0 && profile.templates.isNotEmpty() && profile.referenceWidth != frameWidth) {
            "This snapshot is ${frameWidth}px wide but existing templates were taken at ${profile.referenceWidth}px " +
                "(different screen size or orientation). Clear the profile's templates or use the same orientation."
        } else {
            null
        }

    /** [frameHeight] is recorded (as `reference.height`) so a later change of screen layout can be detected. */
    fun withTemplate(p: GameProfile, name: String, searchArea: Roi, frameWidth: Int, minScore: Float = 0.80f, frameHeight: Int? = null): GameProfile =
        p.copy(
            referenceWidth = frameWidth,
            templates = p.templates + (name to TemplateSpec(name, searchArea, clampF(minScore, 0.5f, 0.99f))),
            extras = if (frameHeight != null && frameHeight > 0) p.extras + ("reference.height" to frameHeight.toString()) else p.extras,
        )

    fun withoutTemplate(p: GameProfile, name: String): GameProfile {
        // Also drop it from state rules so the profile stays internally consistent (ProfileCodec rejects dangling refs).
        val rules = p.stateRules.mapValues { (_, names) -> names.filter { it.removePrefix("!") != name } }.filterValues { it.isNotEmpty() }
        return p.copy(templates = p.templates - name, stateRules = rules)
    }

    fun withControl(p: GameProfile, c: Control, at: Point): GameProfile =
        p.copy(controls = p.controls + (c to Point(clampF(at.x, 0f, 1f), clampF(at.y, 0f, 1f))))

    fun withColor(p: GameProfile, name: String, roi: Roi, target: ColorTarget): GameProfile =
        p.copy(colors = p.colors + (name to ColorSpec(name, roi, target)))

    /** Parses "a, b, !c" into a rule; unknown template names are reported rather than dropped. */
    fun withStateRule(p: GameProfile, state: GameState, text: String): Pair<GameProfile, String?> {
        val names = text.split(",").map { it.trim() }.filter { it.isNotEmpty() }
        if (names.isEmpty()) return p.copy(stateRules = p.stateRules - state) to null
        val unknown = names.map { it.removePrefix("!") }.filter { !p.templates.containsKey(it) }
        if (unknown.isNotEmpty()) return p to "Unknown template(s): ${unknown.joinToString()}. Mark them first."
        return p.copy(stateRules = p.stateRules + (state to names)) to null
    }

    fun withNavMinimap(p: GameProfile, minimap: Roi): GameProfile {
        val old = p.nav
        return p.copy(
            nav = NavProfile(
                minimapRoi = minimap,
                routeColor = old?.routeColor ?: ColorTarget(255, 200, 0, 45),
                truckX = old?.truckX ?: ((minimap.left + minimap.right) / 2f),
                truckY = old?.truckY ?: (minimap.top + (minimap.bottom - minimap.top) * 0.75f),
                lookahead = old?.lookahead ?: 0.6f,
            ),
        )
    }

    /** Null if no minimap region has been marked yet (the other nav fields depend on it). */
    fun withRouteColor(p: GameProfile, color: ColorTarget): GameProfile? = p.nav?.let { p.copy(nav = it.copy(routeColor = color)) }

    fun withTruckMarker(p: GameProfile, at: Point): GameProfile? =
        p.nav?.let { p.copy(nav = it.copy(truckX = clampF(at.x, 0f, 1f), truckY = clampF(at.y, 0f, 1f))) }

    fun withSteering(p: GameProfile, mode: SteeringMode, radius: Float): GameProfile =
        p.copy(steeringMode = mode, steerRadius = clampF(radius, 0.02f, 0.4f))
}
