package dev.toe3autopilot.core.setup

import dev.toe3autopilot.core.AutomationSettings
import dev.toe3autopilot.core.capture.ForegroundView
import dev.toe3autopilot.core.calibration.LayoutCheck
import dev.toe3autopilot.core.profile.GameProfile
import dev.toe3autopilot.core.profile.ProfileReadiness
import dev.toe3autopilot.core.profile.TemplateStore
import dev.toe3autopilot.core.state.FrameChecks
import dev.toe3autopilot.core.state.GameState
import dev.toe3autopilot.core.state.RecognitionDiagnosis
import dev.toe3autopilot.core.state.StateEstimate
import dev.toe3autopilot.core.state.StateDetector
import dev.toe3autopilot.core.vision.Frame
import dev.toe3autopilot.core.vision.ProfileVision
import dev.toe3autopilot.core.vision.RouteEstimator
import dev.toe3autopilot.core.vision.TemplateProvider

/**
 * Step 10: tests a saved profile against a live picture WITHOUT sending any touch. Each check is something the
 * automation itself relies on, measured the same way the automation measures it.
 */
object SetupVerifier {
    /** Pictures older than this are not "live". */
    const val LIVE_MAX_AGE_MS = 15_000L

    /** Up to this many of the newest pictures are judged together: one picture is allowed to be a bad one. */
    const val RECENT_FRAMES = 5

    /** Of those, this many (or all of them, with fewer pictures) must show the driving view. */
    const val NEEDED_HITS = 3

    /**
     * @param frames the newest pictures of the SELECTED game, oldest first (empty = none arrived)
     * @param front what is in front and what the selected game is, or null when that cannot be known here
     *
     * The saved profile and the live picture are judged separately and the report says which one failed: a complete saved
     * profile never implies that a live picture of the game exists.
     */
    fun verify(
        profile: GameProfile, store: TemplateStore, frames: List<Frame>, nowMs: Long, settings: AutomationSettings = AutomationSettings(),
        front: ForegroundView? = null,
    ): SetupTestReport {
        val checks = ArrayList<TestCheck>()
        val readiness = ProfileReadiness.problems(profile, settings, store)
        checks += TestCheck(
            "Everything needed for driving is set up (saved profile)",
            readiness.isEmpty(),
            if (readiness.isEmpty()) "Accelerator, brake, steering, driving screen and minimap are all saved. This says nothing about the live picture; see the checks below." else readiness.joinToString("; "),
        )
        if (front != null) {
            checks += TestCheck(
                "The selected game is the app in front",
                front.gameInFront == true && !front.helperFresh,
                if (front.gameInFront == true && !front.helperFresh) "${front.selected} is in front." else (front.howToReturn() ?: "Not confirmed.") + " [${front.describe()}]",
            )
        }
        val fresh = frames.filter { nowMs - it.timestampMs <= LIVE_MAX_AGE_MS }
        if (fresh.isEmpty()) {
            val why = when {
                front != null && front.gameInFront != true -> "No picture of ${front.selected.ifBlank { "the selected game" }} arrived because ${front.app ?: "another app"} is in front, not the game. Open the game and show the driving view, then test again."
                frames.isNotEmpty() -> "The newest picture of the game is ${(nowMs - frames.last().timestampMs) / 1000} s old. Keep the game in front while testing."
                else -> "No picture of the selected game has arrived yet. Connect the screen, open the game and show its driving view, then test again."
            }
            checks += TestCheck("A live picture of the selected game is available", false, why)
            return SetupTestReport(checks, nowMs)
        }
        val frame = fresh.last()
        val validity = FrameChecks.assess(frame)
        checks += TestCheck(
            "A live picture of the selected game is available",
            validity.usable,
            if (validity.usable) "${frame.width}x${frame.height} picture, ${(nowMs - frame.timestampMs).coerceAtLeast(0) / 1000} s old (${validity.label.lowercase()})."
            else "The newest picture is ${validity.label.lowercase()}: that is a capture problem (protected window, loading, or screen sharing stopped), not a game picture.",
        )
        if (!validity.usable) return SetupTestReport(checks, nowMs)
        val geometry = LayoutCheck.layoutProblem(profile, frame.width, frame.height)
        checks += TestCheck("The screen has the shape the profile was made for", geometry == null, geometry ?: "Matches.")
        if (geometry != null) return SetupTestReport(checks, nowMs)

        val provider = TemplateProvider(store, profile.referenceWidth)
        val router = profile.nav?.let { RouteEstimator(it) }
        val usable = fresh.takeLast(RECENT_FRAMES).filter { FrameChecks.assess(it).usable }
        var hits = 0
        var lastEst: StateEstimate? = null
        for (f in usable) {
            val detector = StateDetector(profile)
            val vision = ProfileVision(profile, provider, f, { 0f }, router)
            detector.update(vision)
            val est = detector.update(vision)
            // Each picture is judged on its own (its candidate), not through the debounce: this counts pictures.
            if (est.candidate.drivingLike && est.confidence >= MIN_CONFIDENCE) hits++
            if (f === usable.last()) lastEst = est
        }
        val need = minOf(NEEDED_HITS, usable.size)
        val recognised = usable.isNotEmpty() && hits >= need
        val est = lastEst
        checks += TestCheck(
            "The driving screen is recognised",
            recognised,
            if (recognised) "Recognised in $hits of the last ${usable.size} picture(s) (newest: ${est?.candidate?.label}, match ${((est?.confidence ?: 0f) * 100).toInt()}%)."
            else RecognitionDiagnosis.explain(
                profile, provider, usable, est?.candidate ?: GameState.UNKNOWN, est?.confidence ?: 0f, hits, usable.size, fresh.size - usable.size,
                front?.gameInFront, MIN_CONFIDENCE, nowMs,
            ).let { r -> "Recognised in $hits of the last ${usable.size} picture(s). ${r.reason} ${r.advice.firstOrNull() ?: ""}".trim() },
        )
        val v = LayoutCheck.verifyControls(profile, frame.toGray(), provider, frame.width)
        checks += if (v.evaluated < 2) {
            TestCheck("The controls are where they were saved", true, "Fewer than two control pictures are stored; not checked.", required = false)
        } else {
            TestCheck("The controls are where they were saved", !v.stale, "${v.matched} of ${v.evaluated} controls found at their saved positions.")
        }
        val nav = profile.nav
        if (nav != null) {
            val r = RouteEstimator(nav).read(frame)
            checks += TestCheck(
                "The route line is visible on the minimap",
                r != null && r.confidence >= 0.2f,
                if (r == null) "No route-coloured pixels were found ahead of the truck. With an active job the route must be visible; otherwise this is expected."
                else "Route seen (evidence ${(r.confidence * 100).toInt()}%, offset ${"%+.2f".format(java.util.Locale.ROOT, r.offset)}).",
                required = false,
            )
        }
        return SetupTestReport(checks, nowMs)
    }

    /** Same threshold the session uses before it sends any input. */
    const val MIN_CONFIDENCE = 0.7f

    /** True when the picture would be classified as the driving view (used by the Test step's quick status). */
    fun recognisesDriving(profile: GameProfile, store: TemplateStore, frame: Frame): Boolean {
        val provider = TemplateProvider(store, profile.referenceWidth)
        val d = StateDetector(profile)
        val v = ProfileVision(profile, provider, frame, { 0f }, null)
        d.update(v)
        val e = d.update(v)
        return e.state == GameState.DRIVING && e.confidence >= MIN_CONFIDENCE
    }
}
