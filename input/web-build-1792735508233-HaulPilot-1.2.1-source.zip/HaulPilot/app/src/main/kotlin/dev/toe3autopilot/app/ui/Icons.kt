package dev.toe3autopilot.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** The app's icon set: line glyphs drawn on a 24-unit grid with one stroke weight, so every icon matches. */
enum class Glyph {
    DASHBOARD, SETUP, PROFILES, SETTINGS, PLAY, PAUSE, STOP, CHECK, WARNING, INFO, CLOSE, BACK, CHEVRON, PLUS, UNDO, REDO,
    CAMERA, IMAGE, VIDEO, REFRESH, TRASH, EDIT, COPY, STAR, WHEEL, PEDAL, MAP, LINK, SHIELD, LOG, UPLOAD, DOWNLOAD, FIT,
    MORE, TARGET, TRUCK, HISTORY, ARROW_UP, ARROW_DOWN, ARROW_LEFT, ARROW_RIGHT, TOUCH, DOT,
}

/**
 * Draws [glyph]. Decorative by default; pass [description] when the icon is the only label of a control.
 */
@Composable
fun HpIcon(glyph: Glyph, modifier: Modifier = Modifier, tint: Color = Hp.TextSecondary, size: Dp = 24.dp, description: String? = null) {
    val m = if (description != null) modifier.semantics { contentDescription = description } else modifier
    Canvas(m.size(size)) { drawGlyph(glyph, tint) }
}

private fun DrawScope.drawGlyph(g: Glyph, c: Color) {
    val u = size.minDimension / 24f
    val sw = 1.9f * u
    val stroke = Stroke(width = sw, cap = StrokeCap.Round, join = StrokeJoin.Round)
    fun p(x: Float, y: Float) = Offset(x * u, y * u)
    fun line(x1: Float, y1: Float, x2: Float, y2: Float) = drawLine(c, p(x1, y1), p(x2, y2), sw, StrokeCap.Round)
    fun circle(cx: Float, cy: Float, r: Float, fill: Boolean = false) =
        drawCircle(c, r * u, p(cx, cy), style = if (fill) Fill else stroke)
    fun rect(l: Float, t: Float, r: Float, b: Float, rad: Float = 2f, fill: Boolean = false) =
        drawRoundRect(c, p(l, t), Size((r - l) * u, (b - t) * u), CornerRadius(rad * u, rad * u), style = if (fill) Fill else stroke)
    fun path(fill: Boolean = false, block: Path.() -> Unit) {
        val path = Path().apply(block)
        drawPath(path, c, style = if (fill) Fill else stroke)
    }
    fun Path.m(x: Float, y: Float) = moveTo(x * u, y * u)
    fun Path.l(x: Float, y: Float) = lineTo(x * u, y * u)

    when (g) {
        Glyph.DASHBOARD -> {
            // speedometer dial
            drawArc(c, 150f, 240f, false, p(3f, 4f), Size(18f * u, 18f * u), style = stroke)
            line(12f, 13f, 16.5f, 8.5f)
            circle(12f, 13f, 1.4f, fill = true)
        }
        Glyph.SETUP -> {
            circle(12f, 12f, 7f)
            line(12f, 2f, 12f, 6f); line(12f, 18f, 12f, 22f); line(2f, 12f, 6f, 12f); line(18f, 12f, 22f, 12f)
            circle(12f, 12f, 1.6f, fill = true)
        }
        Glyph.PROFILES -> {
            rect(4f, 7f, 20f, 20f, 2.5f)
            line(7f, 4f, 17f, 4f)
            line(8f, 11.5f, 16f, 11.5f); line(8f, 15.5f, 13f, 15.5f)
        }
        Glyph.SETTINGS -> {
            circle(12f, 12f, 3.2f)
            for (k in 0 until 8) {
                val a = Math.toRadians(k * 45.0)
                val x1 = 12f + 6.2f * Math.cos(a).toFloat()
                val y1 = 12f + 6.2f * Math.sin(a).toFloat()
                val x2 = 12f + 9f * Math.cos(a).toFloat()
                val y2 = 12f + 9f * Math.sin(a).toFloat()
                line(x1, y1, x2, y2)
            }
            circle(12f, 12f, 6.2f)
        }
        Glyph.PLAY -> path(fill = true) { m(8f, 5f); l(19f, 12f); l(8f, 19f); close() }
        Glyph.PAUSE -> { rect(6.5f, 5f, 10f, 19f, 1f, fill = true); rect(14f, 5f, 17.5f, 19f, 1f, fill = true) }
        Glyph.STOP -> rect(6f, 6f, 18f, 18f, 2f, fill = true)
        Glyph.CHECK -> path { m(5f, 12.5f); l(10f, 17.5f); l(19f, 7f) }
        Glyph.WARNING -> {
            path { m(12f, 3.5f); l(21.5f, 20f); l(2.5f, 20f); close() }
            line(12f, 10f, 12f, 14f)
            circle(12f, 17f, 1.1f, fill = true)
        }
        Glyph.INFO -> { circle(12f, 12f, 9f); line(12f, 11f, 12f, 16.5f); circle(12f, 7.8f, 1.1f, fill = true) }
        Glyph.CLOSE -> { line(6f, 6f, 18f, 18f); line(18f, 6f, 6f, 18f) }
        Glyph.BACK -> { line(19f, 12f, 5f, 12f); path { m(11f, 6f); l(5f, 12f); l(11f, 18f) } }
        Glyph.CHEVRON -> path { m(9f, 5f); l(16f, 12f); l(9f, 19f) }
        Glyph.PLUS -> { line(12f, 5f, 12f, 19f); line(5f, 12f, 19f, 12f) }
        Glyph.UNDO -> {
            path { m(8f, 5f); l(4f, 9f); l(8f, 13f) }
            path { m(4f, 9f); l(14f, 9f); cubicTo(18f * u, 9f * u, 20f * u, 12f * u, 20f * u, 14.5f * u); cubicTo(20f * u, 17f * u, 18f * u, 19f * u, 14f * u, 19f * u); l(10f, 19f) }
        }
        Glyph.REDO -> {
            path { m(16f, 5f); l(20f, 9f); l(16f, 13f) }
            path { m(20f, 9f); l(10f, 9f); cubicTo(6f * u, 9f * u, 4f * u, 12f * u, 4f * u, 14.5f * u); cubicTo(4f * u, 17f * u, 6f * u, 19f * u, 10f * u, 19f * u); l(14f, 19f) }
        }
        Glyph.CAMERA -> { rect(3f, 7f, 21f, 19f, 2.5f); circle(12f, 13f, 3.5f); path { m(8f, 7f); l(9.5f, 4.5f); l(14.5f, 4.5f); l(16f, 7f) } }
        Glyph.IMAGE -> { rect(3f, 5f, 21f, 19f, 2.5f); circle(8.5f, 9.5f, 1.6f); path { m(3.5f, 17f); l(9f, 12f); l(13f, 15.5f); l(16f, 13f); l(20.5f, 17f) } }
        Glyph.VIDEO -> { rect(3f, 6f, 16f, 18f, 2.5f); path { m(16f, 10f); l(21f, 7.5f); l(21f, 16.5f); l(16f, 14f) } }
        Glyph.REFRESH -> {
            drawArc(c, 300f, 280f, false, p(4.5f, 4.5f), Size(15f * u, 15f * u), style = stroke)
            path { m(15.5f, 3f); l(19.5f, 5.5f); l(16f, 8.5f) }
        }
        Glyph.TRASH -> { line(4f, 7f, 20f, 7f); path { m(6.5f, 7f); l(7.5f, 20f); l(16.5f, 20f); l(17.5f, 7f) }; path { m(9.5f, 7f); l(10f, 4f); l(14f, 4f); l(14.5f, 7f) } }
        Glyph.EDIT -> { path { m(4f, 20f); l(5f, 15.5f); l(15.5f, 5f); l(19f, 8.5f); l(8.5f, 19f); close() }; line(13.5f, 7f, 17f, 10.5f) }
        Glyph.COPY -> { rect(8f, 8f, 20f, 20f, 2f); path { m(16f, 8f); l(16f, 4f); l(4f, 4f); l(4f, 16f); l(8f, 16f) } }
        Glyph.STAR -> path(fill = true) {
            for (k in 0 until 10) {
                val r = if (k % 2 == 0) 9f else 4f
                val a = Math.toRadians(-90.0 + k * 36.0)
                val x = 12f + r * Math.cos(a).toFloat()
                val y = 12.5f + r * Math.sin(a).toFloat()
                if (k == 0) m(x, y) else l(x, y)
            }
            close()
        }
        Glyph.WHEEL -> { circle(12f, 12f, 8.5f); circle(12f, 12f, 2.2f); line(3.8f, 11f, 9.8f, 11.5f); line(14.2f, 11.5f, 20.2f, 11f); line(12f, 14.2f, 12f, 20.3f) }
        Glyph.PEDAL -> { rect(7f, 3f, 17f, 21f, 2.5f); line(9.5f, 7f, 14.5f, 7f); line(9.5f, 10.5f, 14.5f, 10.5f); line(9.5f, 14f, 14.5f, 14f) }
        Glyph.MAP -> { path { m(3f, 6f); l(9f, 4f); l(15f, 6f); l(21f, 4f); l(21f, 18f); l(15f, 20f); l(9f, 18f); l(3f, 20f); close() }; line(9f, 4f, 9f, 18f); line(15f, 6f, 15f, 20f) }
        Glyph.LINK -> {
            rect(3f, 8.5f, 12f, 15.5f, 3.5f)
            rect(12f, 8.5f, 21f, 15.5f, 3.5f)
        }
        Glyph.SHIELD -> { path { m(12f, 3f); l(19.5f, 6f); l(19f, 13f); cubicTo(18f * u, 17f * u, 15f * u, 19.5f * u, 12f * u, 21f * u); cubicTo(9f * u, 19.5f * u, 6f * u, 17f * u, 5f * u, 13f * u); l(4.5f, 6f); close() }; path { m(8.5f, 12f); l(11f, 14.5f); l(15.5f, 9.5f) } }
        Glyph.LOG -> { rect(5f, 3f, 19f, 21f, 2f); line(8.5f, 8f, 15.5f, 8f); line(8.5f, 12f, 15.5f, 12f); line(8.5f, 16f, 12.5f, 16f) }
        Glyph.UPLOAD -> { line(12f, 16f, 12f, 4f); path { m(7f, 9f); l(12f, 4f); l(17f, 9f) }; line(5f, 20f, 19f, 20f) }
        Glyph.DOWNLOAD -> { line(12f, 4f, 12f, 16f); path { m(7f, 11f); l(12f, 16f); l(17f, 11f) }; line(5f, 20f, 19f, 20f) }
        Glyph.FIT -> { path { m(4f, 9f); l(4f, 4f); l(9f, 4f) }; path { m(15f, 4f); l(20f, 4f); l(20f, 9f) }; path { m(20f, 15f); l(20f, 20f); l(15f, 20f) }; path { m(9f, 20f); l(4f, 20f); l(4f, 15f) } }
        Glyph.MORE -> { circle(12f, 5.5f, 1.6f, fill = true); circle(12f, 12f, 1.6f, fill = true); circle(12f, 18.5f, 1.6f, fill = true) }
        Glyph.TARGET -> { circle(12f, 12f, 8f); circle(12f, 12f, 3.5f); line(12f, 1.5f, 12f, 5f); line(12f, 19f, 12f, 22.5f); line(1.5f, 12f, 5f, 12f); line(19f, 12f, 22.5f, 12f) }
        Glyph.TRUCK -> { rect(2.5f, 6f, 14f, 16f, 1.5f); path { m(14f, 9f); l(18.5f, 9f); l(21.5f, 12.5f); l(21.5f, 16f); l(14f, 16f) }; circle(7f, 18f, 2f); circle(17f, 18f, 2f) }
        Glyph.HISTORY -> { circle(12f, 12f, 8.5f); path { m(12f, 7.5f); l(12f, 12f); l(15f, 14f) } }
        Glyph.ARROW_UP -> path { m(6f, 15f); l(12f, 9f); l(18f, 15f) }
        Glyph.ARROW_DOWN -> path { m(6f, 9f); l(12f, 15f); l(18f, 9f) }
        Glyph.ARROW_LEFT -> path { m(15f, 6f); l(9f, 12f); l(15f, 18f) }
        Glyph.ARROW_RIGHT -> path { m(9f, 6f); l(15f, 12f); l(9f, 18f) }
        Glyph.TOUCH -> { circle(12f, 9f, 4.5f); path { m(12f, 9f); l(12f, 20f) }; path { m(8f, 20f); l(16f, 20f) } }
        Glyph.DOT -> circle(12f, 12f, 4f, fill = true)
    }
}
