package dev.toe3autopilot.core.geometry

import dev.toe3autopilot.core.vision.Roi
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/** What a touch on a box grabs. */
enum class BoxHandle { TOP_LEFT, TOP_RIGHT, BOTTOM_LEFT, BOTTOM_RIGHT, MOVE }

/**
 * Pure editing of a rectangular region in NDS (minimap area, driving-screen marker). Every result is a valid [Roi]: inside
 * the picture, never inverted and never smaller than [MIN_SIZE] in either direction.
 */
object BoxEditing {
    const val MIN_SIZE = 0.02f

    /** The box spanned by two corners in any order (a drag from one corner to the other). */
    fun fromCorners(ax: Float, ay: Float, bx: Float, by: Float): Roi {
        var l = min(ax, bx).coerceIn(0f, 1f)
        var r = max(ax, bx).coerceIn(0f, 1f)
        var t = min(ay, by).coerceIn(0f, 1f)
        var b = max(ay, by).coerceIn(0f, 1f)
        if (r - l < MIN_SIZE) {
            if (l + MIN_SIZE <= 1f) {
                r = l + MIN_SIZE
            } else {
                r = 1f
                l = 1f - MIN_SIZE
            }
        }
        if (b - t < MIN_SIZE) {
            if (t + MIN_SIZE <= 1f) {
                b = t + MIN_SIZE
            } else {
                b = 1f
                t = 1f - MIN_SIZE
            }
        }
        return Roi(l, t, r, b)
    }

    /** A box of [w] x [h] centred on ([cx], [cy]), shifted (not shrunk) to stay inside the picture. */
    fun around(cx: Float, cy: Float, w: Float, h: Float): Roi {
        val ww = w.coerceIn(MIN_SIZE, 1f)
        val hh = h.coerceIn(MIN_SIZE, 1f)
        val l = (cx - ww / 2f).coerceIn(0f, 1f - ww)
        val t = (cy - hh / 2f).coerceIn(0f, 1f - hh)
        return Roi(l, t, l + ww, t + hh)
    }

    /**
     * Moves the grabbed corner to ([x], [y]); the opposite corner stays where it is. The grabbed corner may not cross the
     * opposite one (it stops [MIN_SIZE] short), so a resize never turns the box inside out.
     */
    fun resize(box: Roi, handle: BoxHandle, x: Float, y: Float): Roi {
        val cx = x.coerceIn(0f, 1f)
        val cy = y.coerceIn(0f, 1f)
        return when (handle) {
            BoxHandle.TOP_LEFT -> Roi(min(cx, box.right - MIN_SIZE).coerceAtLeast(0f), min(cy, box.bottom - MIN_SIZE).coerceAtLeast(0f), box.right, box.bottom)
            BoxHandle.TOP_RIGHT -> Roi(box.left, min(cy, box.bottom - MIN_SIZE).coerceAtLeast(0f), max(cx, box.left + MIN_SIZE).coerceAtMost(1f), box.bottom)
            BoxHandle.BOTTOM_LEFT -> Roi(min(cx, box.right - MIN_SIZE).coerceAtLeast(0f), box.top, box.right, max(cy, box.top + MIN_SIZE).coerceAtMost(1f))
            BoxHandle.BOTTOM_RIGHT -> Roi(box.left, box.top, max(cx, box.left + MIN_SIZE).coerceAtMost(1f), max(cy, box.top + MIN_SIZE).coerceAtMost(1f))
            BoxHandle.MOVE -> box
        }
    }

    /** Moves the whole box by ([dx], [dy]), stopping at the picture edges; the size never changes. */
    fun move(box: Roi, dx: Float, dy: Float): Roi {
        val w = box.right - box.left
        val h = box.bottom - box.top
        val l = (box.left + dx).coerceIn(0f, 1f - w)
        val t = (box.top + dy).coerceIn(0f, 1f - h)
        return Roi(l, t, l + w, t + h)
    }

    /**
     * What an on-screen touch at ([sx], [sy]) grabs: the nearest corner within [radiusPx] screen pixels, else the inside
     * of the box (MOVE), else nothing. Works in screen pixels so the grab area is the same at every zoom level.
     */
    fun hitTest(t: EditorTransform, box: Roi, sx: Float, sy: Float, radiusPx: Float): BoxHandle? {
        val corners = listOf(
            BoxHandle.TOP_LEFT to t.toScreen(box.left, box.top),
            BoxHandle.TOP_RIGHT to t.toScreen(box.right, box.top),
            BoxHandle.BOTTOM_LEFT to t.toScreen(box.left, box.bottom),
            BoxHandle.BOTTOM_RIGHT to t.toScreen(box.right, box.bottom),
        )
        val best = corners.minByOrNull { (_, p) -> hypot(p.x - sx, p.y - sy) }!!
        if (hypot(best.second.x - sx, best.second.y - sy) <= radiusPx) return best.first
        val a = t.toScreen(box.left, box.top)
        val b = t.toScreen(box.right, box.bottom)
        return if (sx in a.x..b.x && sy in a.y..b.y) BoxHandle.MOVE else null
    }

    /** Same box (within half a processing pixel at 480 px): used to tell "accepted as suggested" from "changed". */
    fun same(a: Roi?, b: Roi?, eps: Float = 0.001f): Boolean {
        if (a == null || b == null) return a == b
        return abs(a.left - b.left) < eps && abs(a.top - b.top) < eps && abs(a.right - b.right) < eps && abs(a.bottom - b.bottom) < eps
    }
}
