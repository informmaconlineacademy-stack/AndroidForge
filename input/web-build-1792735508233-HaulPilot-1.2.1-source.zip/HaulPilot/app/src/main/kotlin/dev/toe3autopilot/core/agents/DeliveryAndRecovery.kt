package dev.toe3autopilot.core.agents

import dev.toe3autopilot.core.HelpKind
import dev.toe3autopilot.core.Decision
import dev.toe3autopilot.core.profile.GameProfile
import dev.toe3autopilot.core.state.GameState
import dev.toe3autopilot.core.vision.Vision

/**
 * Handles screens and situations that should not last: unexpected dialogs, crash/penalty screens, long loading,
 * unrecognised screens, being stuck, and spending too long in one state. Every path is bounded and ends in NeedHelp.
 *
 * It never taps anything: an unexpected dialog or a crash screen while driving means the situation is not one this app
 * understands, so the truck is stopped and the user is asked to take over.
 */
class RecoveryAgent(private val limits: Limits = Limits()) {
    data class Limits(
        val loadingMs: Long = 60_000,
        val unknownMs: Long = 8_000,
        val stuckMs: Long = 8_000,
        val stuckThrottle: Float = 0.2f,
        val stuckMotion: Float = 0.004f,
        val dwellMs: Map<GameState, Long> = mapOf(
            GameState.DRIVING to 4 * 3_600_000L,
            GameState.PARKING to 600_000L,
        ),
    )

    private var stateEnteredAt = 0L
    private var lastState = GameState.UNKNOWN
    private var stuckSince: Long? = null
    var lastRecoveryNote: String? = null
        private set

    fun reset() {
        stateEnteredAt = 0L
        lastState = GameState.UNKNOWN
        stuckSince = null
        lastRecoveryNote = null
    }

    fun resetBudgets() {
        stuckSince = null
    }

    /**
     * @param commandedThrottle throttle the session asked for on the previous tick (0 if none)
     * @return a recovery decision, or null when everything is normal and the regular agent should act
     */
    fun check(state: GameState, vision: Vision, profile: GameProfile, now: Long, commandedThrottle: Float): Decision? {
        if (state != lastState) {
            lastState = state
            stateEnteredAt = now
            stuckSince = null
        }
        val dwell = now - stateEnteredAt

        val d: Decision? = when (state) {
            GameState.UNEXPECTED_DIALOG -> Decision.NeedHelp("An unexpected dialog is on screen. Stopped: please deal with it yourself.", HelpKind.SCREEN_UNKNOWN)
            GameState.CRASH_OR_PENALTY -> Decision.NeedHelp("A crash or penalty screen is showing. Stopped: please take over.", HelpKind.SCREEN_UNKNOWN)
            GameState.LOADING ->
                if (dwell > limits.loadingMs) Decision.NeedHelp("Loading for more than ${limits.loadingMs / 1000}s", HelpKind.SCREEN_UNKNOWN)
                else Decision.Wait("Loading")
            GameState.UNKNOWN ->
                if (dwell > limits.unknownMs) Decision.NeedHelp("Screen not recognised for ${dwell / 1000}s", HelpKind.SCREEN_UNKNOWN)
                else Decision.Wait("Unrecognised screen: waiting")
            GameState.GAME_NOT_FOREGROUND -> Decision.Wait("Game is not in the foreground")
            else -> null
        }
        if (d != null) {
            lastRecoveryNote = d.note
            return d
        }

        limits.dwellMs[state]?.let { max ->
            if (dwell > max) return Decision.NeedHelp("${state.label} for more than ${max / 1000}s")
        }
        return stuckCheck(state, vision, now, commandedThrottle)
    }

    /**
     * "Throttle is being asked for but nothing on screen moves" for [Limits.stuckMs] means the truck is blocked or the game is
     * not responding. Reversing blindly is not attempted: the truck is stopped and the user is asked to take over.
     */
    private fun stuckCheck(state: GameState, vision: Vision, now: Long, commandedThrottle: Float): Decision? {
        if (!state.drivingLike) return null
        val trying = commandedThrottle >= limits.stuckThrottle
        val still = vision.motion() <= limits.stuckMotion
        if (trying && still) {
            val since = stuckSince ?: now.also { stuckSince = it }
            if (now - since > limits.stuckMs) {
                stuckSince = null
                lastRecoveryNote = "Truck not moving"
                return Decision.NeedHelp("The truck does not seem to move although throttle is applied. Stopped: please check.", HelpKind.NOT_MOVING)
            }
        } else {
            stuckSince = null
        }
        return null
    }
}
