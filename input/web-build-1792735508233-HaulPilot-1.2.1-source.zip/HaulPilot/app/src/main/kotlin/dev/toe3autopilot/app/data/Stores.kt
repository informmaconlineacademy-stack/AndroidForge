package dev.toe3autopilot.app.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import dev.toe3autopilot.core.AutomationSettings
import dev.toe3autopilot.core.profile.ImageCodec
import dev.toe3autopilot.core.profile.ProfileRepository
import dev.toe3autopilot.core.session.LogEntry
import dev.toe3autopilot.core.session.SessionHistoryCodec
import dev.toe3autopilot.core.session.SessionRecord
import dev.toe3autopilot.core.vision.Frame
import dev.toe3autopilot.core.vision.GrayImage
import java.io.ByteArrayOutputStream
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Default game package; the user can change or auto-detect it in Settings (this id is NOT verified). */
const val DEFAULT_GAME_PACKAGE = "com.WandaSoftware.TruckersofEurope3"

/** Options of the background-operation and recording features (kept apart from the automation settings). */
data class AppOptions(
    /** Show the floating Start/Pause/Resume/Stop panel (needs the accessibility service) while capture is connected. */
    val showPanel: Boolean = true,
    /** Seconds between saved sample snapshots while recording. */
    val recordIntervalSec: Int = 5,
    /** Oldest snapshots are deleted beyond this count. */
    val recordMaxFrames: Int = 150,
    /** Vibrate on countdowns and when a drive stops (useful when the app is not on screen). */
    val vibrateCues: Boolean = true,
    /** The person accepted the in-app disclosure about the accessibility service (required before it is switched on). */
    val accessibilityDisclosureAccepted: Boolean = false,
    /** The first-run welcome card on the Dashboard was dismissed. */
    val welcomeDismissed: Boolean = false,
) {
    fun sanitized() = copy(
        recordIntervalSec = recordIntervalSec.coerceIn(1, 60),
        recordMaxFrames = recordMaxFrames.coerceIn(10, 400),
    )
}

class OptionsStore(context: Context) {
    private val prefs = context.getSharedPreferences("options", Context.MODE_PRIVATE)

    fun load(): AppOptions = AppOptions(
        showPanel = prefs.getBoolean("showPanel", true),
        recordIntervalSec = prefs.getInt("recordIntervalSec", 5),
        recordMaxFrames = prefs.getInt("recordMaxFrames", 150),
        vibrateCues = prefs.getBoolean("vibrateCues", true),
        accessibilityDisclosureAccepted = prefs.getBoolean("a11yDisclosure", false),
        welcomeDismissed = prefs.getBoolean("welcomeDismissed", false),
    ).sanitized()

    fun save(o: AppOptions) {
        prefs.edit().putBoolean("showPanel", o.showPanel).putInt("recordIntervalSec", o.recordIntervalSec)
            .putInt("recordMaxFrames", o.recordMaxFrames).putBoolean("vibrateCues", o.vibrateCues)
            .putBoolean("a11yDisclosure", o.accessibilityDisclosureAccepted)
            .putBoolean("welcomeDismissed", o.welcomeDismissed).apply()
    }
}

class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("settings", Context.MODE_PRIVATE)

    fun load(): AutomationSettings {
        val d = AutomationSettings()
        return AutomationSettings(
            speedLevel = prefs.getFloat("speedLevel", d.speedLevel),
            approachSpeed = prefs.getFloat("approachSpeed", d.approachSpeed),
            sensitivity = prefs.getFloat("sensitivity", d.sensitivity),
            tryParking = prefs.getBoolean("tryParking", d.tryParking),
            assistedMode = prefs.getBoolean("assistedMode", d.assistedMode),
            recognitionTimeoutSec = prefs.getInt("recognitionTimeoutSec", d.recognitionTimeoutSec),
            frozenPictureSec = prefs.getInt("frozenPictureSec", d.frozenPictureSec),
            foregroundGraceSec = prefs.getInt("foregroundGraceSec", d.foregroundGraceSec),
            unknownScreenSec = prefs.getInt("unknownScreenSec", d.unknownScreenSec),
            roadLostSec = prefs.getInt("roadLostSec", d.roadLostSec),
        ).sanitized()
    }

    fun save(s: AutomationSettings) {
        prefs.edit()
            .putFloat("speedLevel", s.speedLevel).putFloat("approachSpeed", s.approachSpeed)
            .putFloat("sensitivity", s.sensitivity).putBoolean("tryParking", s.tryParking)
            .putBoolean("assistedMode", s.assistedMode)
            .putInt("recognitionTimeoutSec", s.recognitionTimeoutSec).putInt("frozenPictureSec", s.frozenPictureSec)
            .putInt("foregroundGraceSec", s.foregroundGraceSec).putInt("unknownScreenSec", s.unknownScreenSec)
            .putInt("roadLostSec", s.roadLostSec)
            .apply()
    }

    fun gamePackage(): String = prefs.getString("gamePackage", DEFAULT_GAME_PACKAGE) ?: DEFAULT_GAME_PACKAGE

    fun saveGamePackage(pkg: String) {
        prefs.edit().putString("gamePackage", pkg.trim()).apply()
    }
}

/** Template pictures as lossless PNG. */
object AndroidImageCodec : ImageCodec {
    override fun encode(img: GrayImage): ByteArray {
        val px = IntArray(img.px.size) { i ->
            val v = img.px[i].coerceIn(0, 255)
            (0xFF shl 24) or (v shl 16) or (v shl 8) or v
        }
        val bmp = Bitmap.createBitmap(px, img.width, img.height, Bitmap.Config.ARGB_8888)
        try {
            val out = ByteArrayOutputStream()
            check(bmp.compress(Bitmap.CompressFormat.PNG, 100, out)) { "PNG encoding failed" }
            return out.toByteArray()
        } finally {
            bmp.recycle()
        }
    }

    override fun decode(bytes: ByteArray): GrayImage? {
        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null
        return try {
            val w = bmp.width
            val h = bmp.height
            val px = IntArray(w * h)
            bmp.getPixels(px, 0, w, 0, 0, w, h)
            Frame(w, h, px).toGray()
        } finally {
            bmp.recycle()
        }
    }

    /** A colour picture (the chosen driving screen) as PNG, for the setup draft. */
    fun encodeFrame(f: Frame): ByteArray {
        val bmp = Bitmap.createBitmap(f.argb, f.width, f.height, Bitmap.Config.ARGB_8888)
        try {
            val out = ByteArrayOutputStream()
            check(bmp.compress(Bitmap.CompressFormat.PNG, 100, out)) { "PNG encoding failed" }
            return out.toByteArray()
        } finally {
            bmp.recycle()
        }
    }

    fun decodeFrame(bytes: ByteArray): Frame? {
        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null
        return try {
            val w = bmp.width
            val h = bmp.height
            val px = IntArray(w * h)
            bmp.getPixels(px, 0, w, 0, 0, w, h)
            Frame(w, h, px, System.currentTimeMillis())
        } finally {
            bmp.recycle()
        }
    }
}

/** The Smart Setup draft and its driving picture, so an unfinished setup survives the app being closed or killed. */
class SetupDraftStore(context: Context) {
    private val dir = File(context.filesDir, "setup").also { it.mkdirs() }
    private val text = File(dir, "draft.properties")
    private val picture = File(dir, "driving.png")

    fun readText(): String? = if (text.exists()) text.readText() else null

    fun readPicture(): Frame? = if (picture.exists()) AndroidImageCodec.decodeFrame(picture.readBytes()) else null

    fun write(draftText: String, drivingPicture: Frame?) {
        ProfileRepository.atomicWrite(text, draftText.toByteArray())
        if (drivingPicture != null) ProfileRepository.atomicWrite(picture, AndroidImageCodec.encodeFrame(drivingPicture)) else picture.delete()
    }

    fun clear() {
        text.delete()
        picture.delete()
    }
}

/** Recent drives for the Dashboard and Diagnostics. */
class SessionHistoryStore(context: Context) {
    private val file = File(context.filesDir, "sessions.tsv")

    @Synchronized
    fun load(): List<SessionRecord> = try {
        if (file.exists()) SessionHistoryCodec.parse(file.readText()) else emptyList()
    } catch (e: Exception) {
        emptyList()
    }

    @Synchronized
    fun append(r: SessionRecord): List<SessionRecord> {
        val all = (load() + r).takeLast(SessionHistoryCodec.MAX)
        ProfileRepository.atomicWrite(file, SessionHistoryCodec.format(all).toByteArray())
        return all
    }

    @Synchronized
    fun clear() {
        file.delete()
    }
}

/** Bounded on-disk copy of the session log for troubleshooting. Contains states and actions only. */
class LogFile(context: Context, private val maxBytes: Long = 200_000) {
    private val file = File(context.filesDir, "session.log")
    private val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)

    @Synchronized
    fun append(e: LogEntry) {
        try {
            if (file.exists() && file.length() > maxBytes) {
                // Keep the newest half.
                val text = file.readText()
                file.writeText(text.substring(text.length / 2).substringAfter('\n', ""))
            }
            file.appendText("${fmt.format(Date(e.timeMs))} ${e.level} ${e.message}\n")
        } catch (_: Exception) {
            // A full disk must never break the app; the in-memory log still works.
        }
    }

    @Synchronized
    fun clear() {
        file.delete()
    }

    @Synchronized
    fun readTail(maxChars: Int = 20_000): String =
        if (file.exists()) file.readText().takeLast(maxChars) else ""
}
