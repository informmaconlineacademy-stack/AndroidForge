package dev.toe3autopilot.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import dev.toe3autopilot.app.AutopilotRuntime
import dev.toe3autopilot.app.setup.SaveOutcome
import dev.toe3autopilot.app.setup.SaveTarget
import dev.toe3autopilot.core.calibration.CalibRole
import dev.toe3autopilot.core.calibration.DetectionStatus
import dev.toe3autopilot.core.geometry.EditorTransform
import dev.toe3autopilot.core.geometry.FitTransform
import dev.toe3autopilot.core.geometry.Vec2
import dev.toe3autopilot.core.geometry.ZoomPan
import dev.toe3autopilot.core.profile.SteeringMode
import dev.toe3autopilot.core.setup.AutoReview
import dev.toe3autopilot.core.setup.AutoStage
import dev.toe3autopilot.core.setup.DraftEdits
import dev.toe3autopilot.core.setup.IssueSeverity
import dev.toe3autopilot.core.setup.SetupPhase
import dev.toe3autopilot.core.setup.SetupRecovery
import dev.toe3autopilot.core.setup.SetupState
import dev.toe3autopilot.core.vision.Frame
import kotlin.math.hypot

/*
 * Auto-Calibrate: the one-action calibration.
 *
 *     Connect -> Collect (drive forward; only pictures with moving scenery count) -> Analyse (real progress)
 *       -> Review (every found control as a marker on the picture: drag it, tap a missing one, try the next spot)
 *       -> Confirm -> Validate -> Save -> Safe test (no touches)
 *
 * Everything shown comes from the one SetupState (AutoReview.stage derives where the flow is), so this screen, the
 * Smart Setup steps and the floating button always agree. Nothing found is used before the person confirms it, and a
 * control that was not found is shown as missing, never guessed. The ten Smart Setup steps stay available as the manual
 * fallback.
 */

private enum class AutoStep(val title: String) { CONNECT("Connect"), COLLECT("Collect"), ANALYSE("Analyse"), REVIEW("Review"), SAVE("Save"), TEST("Test") }

@Composable
fun AutoCalibrateScreen(env: UiEnv, onClose: () -> Unit) {
    val state by AutopilotRuntime.setup.state.collectAsStateWithLifecycle()
    val captureOn by AutopilotRuntime.captureActive.collectAsStateWithLifecycle()
    val stage = AutoReview.stage(state, captureOn)
    // After Confirm the review shows the save / test panel until the person goes back to the markers.
    var finishing by rememberSaveable { mutableStateOf(false) }
    LaunchedEffect(stage) { if (stage != AutoStage.REVIEW) finishing = false }

    Box(
        Modifier
            .fillMaxSize()
            .background(Hp.Bg)
            // Swallows touches no child handled, so nothing behind this screen reacts.
            .pointerInput(Unit) { awaitEachGesture { awaitFirstDown(requireUnconsumed = false) } },
    ) {
        Column(Modifier.fillMaxSize()) {
            AutoTopBar(state, stage, onClose)
            EmergencyBar()
            AutoRail(current(stage, state, finishing))
            if (stage == AutoStage.REVIEW) {
                ReviewStage(env, state, finishing, { finishing = it }, onClose, Modifier.weight(1f).fillMaxWidth())
            } else {
                Column(
                    Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = Sp.gutter, vertical = Sp.m),
                    verticalArrangement = Arrangement.spacedBy(Sp.m),
                ) {
                    when (stage) {
                        AutoStage.CONNECT -> ConnectStage(env)
                        AutoStage.READY -> ReadyStage(env, state)
                        AutoStage.COLLECTING -> CollectingStage(env, state)
                        AutoStage.ANALYSING -> AnalysingStage(state)
                        AutoStage.ANALYSE_READY -> AnalyseReadyStage(env, state)
                        AutoStage.FAILED -> FailedStage(env, state)
                        AutoStage.REVIEW -> {}
                    }
                    ManualFallback(env, onClose)
                    Spacer(Modifier.height(Sp.l))
                }
            }
        }
    }
}

private fun current(stage: AutoStage, s: SetupState, finishing: Boolean): AutoStep = when (stage) {
    AutoStage.CONNECT -> AutoStep.CONNECT
    AutoStage.READY, AutoStage.COLLECTING -> AutoStep.COLLECT
    AutoStage.ANALYSING, AutoStage.ANALYSE_READY -> AutoStep.ANALYSE
    AutoStage.FAILED -> if (s.frames.isEmpty()) AutoStep.COLLECT else AutoStep.ANALYSE
    AutoStage.REVIEW -> when {
        !finishing -> AutoStep.REVIEW
        s.phase == SetupPhase.CONFIRMED && !s.dirty -> AutoStep.TEST
        else -> AutoStep.SAVE
    }
}

@Composable
private fun AutoTopBar(state: SetupState, stage: AutoStage, onClose: () -> Unit) {
    BarSurface {
        Row(
            Modifier.windowInsetsPadding(WindowInsets.statusBars).heightIn(min = 56.dp).padding(horizontal = Sp.xs),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconAction(Glyph.CLOSE, "Close Auto-Calibrate (a running collection or analysis continues)", onClose)
            Column(Modifier.weight(1f).padding(horizontal = Sp.xs)) {
                Text("Auto-Calibrate", Modifier.semantics { heading() }, style = MaterialTheme.typography.titleMedium, color = Hp.Text, maxLines = 1)
                Text(
                    when (stage) {
                        AutoStage.CONNECT -> "Step 1: connect the screen"
                        AutoStage.READY -> "Step 2: collect pictures while you drive"
                        AutoStage.COLLECTING -> "Collecting…"
                        AutoStage.ANALYSING -> "Analysing…"
                        AutoStage.ANALYSE_READY -> "Pictures ready to analyse"
                        AutoStage.REVIEW -> "Check the markers, then confirm"
                        AutoStage.FAILED -> "Stopped"
                    },
                    style = MaterialTheme.typography.bodySmall, color = Hp.TextMuted, maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
            if (stage == AutoStage.REVIEW) {
                IconAction(Glyph.UNDO, "Undo", { AutopilotRuntime.setup.undo() }, enabled = state.canUndo)
                IconAction(Glyph.REDO, "Redo", { AutopilotRuntime.setup.redo() }, enabled = state.canRedo)
            }
        }
    }
}

@Composable
private fun AutoRail(current: AutoStep) {
    Row(
        Modifier.fillMaxWidth().background(Hp.Surface).horizontalScroll(rememberScrollState()).padding(horizontal = Sp.m, vertical = Sp.s),
        horizontalArrangement = Arrangement.spacedBy(Sp.s),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        AutoStep.entries.forEach { s ->
            val done = s.ordinal < current.ordinal
            val now = s == current
            Row(
                Modifier.semantics(mergeDescendants = true) {
                    contentDescription = "${s.title}: " + when {
                        done -> "done"
                        now -> "current step"
                        else -> "later"
                    }
                },
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Box(
                    Modifier.size(22.dp).clip(CircleShape).background(if (now) Hp.Accent else if (done) Hp.Success.copy(alpha = 0.18f) else Hp.Raised),
                    contentAlignment = Alignment.Center,
                ) {
                    if (done) HpIcon(Glyph.CHECK, tint = Hp.Success, size = 13.dp)
                    else Text("${s.ordinal + 1}", style = MaterialTheme.typography.labelSmall, color = if (now) Hp.OnAccent else Hp.TextMuted)
                }
                Text(s.title, style = MaterialTheme.typography.labelMedium, color = if (now) Hp.Text else Hp.TextMuted)
            }
        }
    }
}

// ---- before the review -------------------------------------------------------------------------------------------------

@Composable
private fun ConnectStage(env: UiEnv) {
    val link by AutopilotRuntime.link.collectAsStateWithLifecycle()
    HpCard(accent = Hp.Accent) {
        SectionHeader("Connect the screen", subtitle = link.state.label)
        BodyText(
            "Auto-Calibrate finds the pedals and steering controls in live pictures of the game while you drive: the scenery moves, " +
                "the controls stay put. Nothing is sent anywhere and nothing is pressed.",
        )
        SmallText("Android shows its own screen-sharing dialog. Choose \"Entire screen\": sharing a single app hides the game's controls.")
        HpButton("Connect screen", { env.actions.connectCapture() }, Modifier.fillMaxWidth(), glyph = Glyph.LINK, height = 56.dp)
    }
    HpCard {
        SectionHeader("Live capture blocked?", subtitle = "Black pictures, or a phone that does not allow screen sharing")
        BodyText("Screenshots of the normal driving view work too (several taken while driving work best). Each one is analysed the same way; from a single picture the evidence is weaker and every marker must be checked.")
        HpButton("Use screenshots", { env.actions.pickScreenshots() }, kind = BtnKind.SECONDARY, glyph = Glyph.IMAGE)
    }
}

@Composable
private fun ReadyStage(env: UiEnv, state: SetupState) {
    val view by AutopilotRuntime.gameView.collectAsStateWithLifecycle()
    val game by AutopilotRuntime.gamePackage.collectAsStateWithLifecycle()
    HpCard(accent = Hp.Primary) {
        SectionHeader("Collect pictures while you drive", subtitle = "About 15 seconds")
        BodyText(
            "Tap Start, switch to the game and drive forward normally. HaulPilot counts only pictures in which the scenery moves " +
                "(${state.target} are enough), stops by itself and analyses them. Its floating button shows the count and is left out of every picture.",
        )
        LivePreview(view)
        HpButton(
            "Start Auto-Calibrate",
            {
                val msg = AutopilotRuntime.startAutoCalibrate(fromOverlay = false)
                if (AutopilotRuntime.setup.state.value.phase == SetupPhase.CAPTURING) {
                    msg?.let { env.toast(it) }
                    env.openGame()
                } else {
                    env.toast(msg ?: "Auto-Calibrate could not start.")
                }
            },
            Modifier.fillMaxWidth(), glyph = Glyph.TARGET, height = 56.dp, enabled = game.isNotBlank(),
        )
        if (game.isBlank()) SmallText("Choose the game first (Settings → Game & screen capture).", color = Hp.Warning)
        if (state.frames.isNotEmpty() && state.phase == SetupPhase.CANCELLED) {
            HpButton("Analyse the ${state.frames.size} picture(s) already collected", { AutopilotRuntime.setup.analyze() }, kind = BtnKind.SECONDARY)
        }
    }
}

@Composable
private fun CollectingStage(env: UiEnv, state: SetupState) {
    val view by AutopilotRuntime.gameView.collectAsStateWithLifecycle()
    HpCard(accent = Hp.Accent) {
        if (state.auto) {
            SectionHeader("Collecting", subtitle = "Only pictures with moving scenery count")
            ProgressLine("${state.runMoving} of ${state.target} pictures with moving scenery", (state.runMoving.toFloat() / state.target.coerceAtLeast(1)).coerceIn(0f, 1f))
        } else {
            SectionHeader("Collecting (Smart Setup)")
            ProgressLine("${state.runCollected} of ${state.target} pictures", (state.runCollected.toFloat() / state.target.coerceAtLeast(1)).coerceIn(0f, 1f))
        }
        Text(state.message, Modifier.semantics { liveRegion = LiveRegionMode.Polite }, style = MaterialTheme.typography.bodyMedium, color = Hp.Text)
        if (state.stillSkipped > 0) SmallText("${state.stillSkipped} still picture(s) were left out: the truck was standing.")
        if (state.rejectedFrames > 0) SmallText("${state.rejectedFrames} black or blank picture(s) were ignored.")
        LivePreview(view)
        HpButton("Open the game", { env.openGame() }, Modifier.fillMaxWidth(), glyph = Glyph.PLAY)
        Row(horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
            HpButton(
                if (state.auto) "Stop and analyse now" else "Stop and use these", { AutopilotRuntime.setup.stopCapture() },
                Modifier.weight(1f), kind = BtnKind.SECONDARY, enabled = state.runCollected > 0,
            )
            HpButton("Cancel", { AutopilotRuntime.setup.cancel() }, kind = BtnKind.GHOST, glyph = Glyph.CLOSE)
        }
        if (state.runCollected == 0) SmallText("Stop becomes available once a picture of the game has arrived.")
    }
}

@Composable
private fun AnalysingStage(state: SetupState) {
    HpCard(accent = Hp.Accent) {
        SectionHeader("Analysing ${state.frames.size} picture(s)")
        val p = state.progress
        ProgressLine(p?.stage ?: "Starting", p?.fraction)
        BodyText("Separating the fixed on-screen controls from the moving scenery, then measuring their outlines and how they are arranged (two pedals side by side, a mirrored pair of arrows, a ring-shaped wheel).")
        SmallText("The percentage moves only when a stage has really finished.")
        HpButton("Cancel the analysis", { AutopilotRuntime.setup.cancel() }, kind = BtnKind.GHOST, glyph = Glyph.CLOSE)
    }
}

@Composable
private fun AnalyseReadyStage(env: UiEnv, state: SetupState) {
    val captureOn by AutopilotRuntime.captureActive.collectAsStateWithLifecycle()
    HpCard(accent = Hp.Primary) {
        SectionHeader("${state.frames.size} picture(s) ready", subtitle = state.frames.groupBy { it.origin.label }.entries.joinToString { "${it.value.size} ${it.key}(s)" })
        if (state.frames.size < 6) {
            SmallText("With so few pictures the scenery cannot be told apart from the controls; every marker found is weaker evidence and must be checked.", color = Hp.Warning)
        }
        HpButton("Analyse", { AutopilotRuntime.setup.analyze() }, Modifier.fillMaxWidth(), glyph = Glyph.TARGET, height = 56.dp)
        if (captureOn) {
            HpButton("Collect new pictures instead", {
                val msg = AutopilotRuntime.startAutoCalibrate(fromOverlay = false)
                if (AutopilotRuntime.setup.state.value.phase == SetupPhase.CAPTURING) env.openGame() else env.toast(msg ?: "Auto-Calibrate could not start.")
            }, kind = BtnKind.SECONDARY)
        }
    }
}

@Composable
private fun FailedStage(env: UiEnv, state: SetupState) {
    HpCard(accent = Hp.Danger) {
        SectionHeader("Auto-Calibrate stopped")
        BodyText(state.problem ?: "Something stopped the collection.", color = Hp.Text)
        if (state.message.isNotBlank()) SmallText(state.message)
        val rec = state.recovery
        if (rec != null) HpButton(rec.label, { env.runAutoRecovery(rec) }, Modifier.fillMaxWidth())
        if (state.frames.isNotEmpty()) HpButton("Analyse the ${state.frames.size} picture(s) collected", { AutopilotRuntime.setup.analyze() }, kind = BtnKind.SECONDARY)
    }
}

private fun UiEnv.runAutoRecovery(r: SetupRecovery) {
    when (r) {
        SetupRecovery.CONNECT_SCREEN -> actions.connectCapture()
        SetupRecovery.OPEN_GAME -> openGame()
        SetupRecovery.CHOOSE_GAME -> nav.open(Tab.SETTINGS, SettingsPage.CAPTURE)
        SetupRecovery.IMPORT_PICTURES -> actions.pickScreenshots()
        SetupRecovery.DRIVE_AND_RETRY, SetupRecovery.RETRY -> {
            val msg = AutopilotRuntime.startAutoCalibrate(fromOverlay = false)
            if (AutopilotRuntime.setup.state.value.phase == SetupPhase.CAPTURING) openGame() else toast(msg ?: "Auto-Calibrate could not start.")
        }
    }
}

@Composable
private fun ManualFallback(env: UiEnv, onClose: () -> Unit) {
    HpCard {
        SectionHeader("Prefer to place the controls yourself?")
        BodyText("The ten Smart Setup steps do everything by hand, with a zoomable editor. Whatever Auto-Calibrate already found stays.")
        HpButton("Open the manual steps", {
            onClose()
            env.nav.openSetup(suggestedStep())
        }, kind = BtnKind.GHOST)
    }
}

/** The newest live picture of the game (about twice a second), or why there is none. */
@Composable
private fun LivePreview(frame: Frame?) {
    val fresh = frame != null && System.currentTimeMillis() - frame.timestampMs < 5_000L
    if (frame != null && fresh) {
        FramePicture(frame, description = "Live picture of the game as HaulPilot sees it")
        SmallText("What HaulPilot sees right now.")
    } else {
        Box(
            Modifier.fillMaxWidth().heightIn(min = 72.dp).clip(RoundedCornerShape(Sp.radiusM)).background(Hp.Raised).padding(Sp.m),
            contentAlignment = Alignment.Center,
        ) {
            SmallText(if (frame == null) "No picture of the game yet. Open the game; its pictures appear here." else "No recent picture of the game: the game is not in front.")
        }
    }
}

// ---- review -------------------------------------------------------------------------------------------------------------

@Composable
private fun ReviewStage(env: UiEnv, state: SetupState, finishing: Boolean, setFinishing: (Boolean) -> Unit, onClose: () -> Unit, modifier: Modifier) {
    val entry = state.selectedFrame ?: return
    val frame = entry.frame
    val d = state.draft
    val mode = AutoReview.steering(d)
    val roles = AutoReview.roles(mode)
    var selected by remember { mutableStateOf<CalibRole?>(null) }
    val sel = selected?.takeIf { it in roles } ?: AutoReview.firstUnresolved(d, mode)

    Column(modifier) {
        if (!finishing) {
            ReviewPicture(
                frame, state, roles, sel, Modifier.weight(1f).fillMaxWidth(),
                onSelect = { selected = it },
                onPlaced = { role ->
                    // Next control that still needs the person, so a full review is a quick run.
                    val after = AutopilotRuntime.setup.state.value.draft
                    AutoReview.nextUnresolved(after, AutoReview.steering(after), role)?.let { selected = it }
                },
            )
            ReviewPanel(env, state, mode, roles, sel, { selected = it }, onConfirmed = { setFinishing(true) }, onClose = onClose)
        } else {
            Column(
                Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = Sp.gutter, vertical = Sp.m),
                verticalArrangement = Arrangement.spacedBy(Sp.m),
            ) {
                AnnotatedPicture(frame, d, description = "The driving picture with the confirmed controls")
                FinishPanel(env, state, onBack = { setFinishing(false) }, onFix = { role ->
                    selected = role
                    setFinishing(false)
                }, onClose = onClose)
                Spacer(Modifier.height(Sp.l))
            }
        }
    }
}

/**
 * The picture with every control of the review as a marker. One finger on a marker drags it; a tap elsewhere puts the
 * selected control there; two fingers zoom and move the picture (one finger moves it while zoomed in). Markers and
 * touches go through the same [EditorTransform], so what is shown is exactly what is stored.
 */
@Composable
private fun ReviewPicture(
    frame: Frame,
    state: SetupState,
    roles: List<CalibRole>,
    selected: CalibRole,
    modifier: Modifier,
    onSelect: (CalibRole) -> Unit,
    onPlaced: (CalibRole) -> Unit,
) {
    val img = rememberImage(frame)
    val measurer = rememberTextMeasurer()
    val density = LocalDensity.current
    var viewSize by remember { mutableStateOf(IntSize.Zero) }
    var zoom by remember(frame) { mutableStateOf(ZoomPan.NONE) }
    var dragRole by remember { mutableStateOf<CalibRole?>(null) }
    var dragPos by remember { mutableStateOf<Vec2?>(null) }
    val latestDraft = rememberUpdatedState(state.draft)
    val latestRoles = rememberUpdatedState(roles)
    val latestSelected = rememberUpdatedState(selected)
    val latestOutlines = rememberUpdatedState(state.hudBoxes)
    val grabPx = with(density) { 30.dp.toPx() }
    val aspect = frame.width.toFloat() / frame.height

    fun transform(): EditorTransform? {
        if (viewSize.width <= 0 || viewSize.height <= 0) return null
        return EditorTransform(FitTransform(frame.width.toFloat(), frame.height.toFloat(), viewSize.width.toFloat(), viewSize.height.toFloat()), zoom)
    }

    fun commit(role: CalibRole, p: Vec2) {
        val d = latestDraft.value
        val box = AutoReview.regionFor(d.controls[role], latestOutlines.value, p.x, p.y, aspect)
        if (AutopilotRuntime.setup.edit { DraftEdits.place(it, role, p.x, p.y, box) }) onPlaced(role)
    }

    Box(modifier.background(Hp.Bg)) {
        Canvas(
            Modifier
                .fillMaxSize()
                .clipToBounds()
                .onSizeChanged { viewSize = it }
                .semantics { contentDescription = reviewDescription(latestDraft.value, roles, selected) }
                .pointerInput(frame) {
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        var multi = false
                        var dragging = false
                        var travelled = 0f
                        val t0 = transform()
                        val p0 = t0?.toNormalized(down.position.x, down.position.y)
                        val grab = if (t0 != null && p0 != null) {
                            val u = t0.normalizedSizeOf(grabPx)
                            AutoReview.hit(latestDraft.value, latestRoles.value, p0.x, p0.y, u.x, u.y)
                        } else null
                        var pos: Vec2? = grab?.let { r -> latestDraft.value.controls[r]?.let { Vec2(it.x, it.y) } }
                        try {
                            while (true) {
                                val ev = awaitPointerEvent()
                                val pressed = ev.changes.filter { it.pressed }
                                if (pressed.isEmpty()) break
                                val t = transform() ?: continue
                                if (pressed.size >= 2) {
                                    multi = true
                                    dragRole = null
                                    dragPos = null
                                    val c = ev.calculateCentroid(useCurrent = true)
                                    val pan = ev.calculatePan()
                                    zoom = zoom.transformed(ev.calculateZoom(), c.x, c.y, pan.x, pan.y)
                                        .clampedTo(viewSize.width.toFloat(), viewSize.height.toFloat(), t.fit.imageRect)
                                    ev.changes.forEach { it.consume() }
                                    continue
                                }
                                if (multi) continue
                                val ch = pressed[0]
                                val delta = ch.position - ch.previousPosition
                                travelled += hypot(delta.x, delta.y)
                                if (!dragging && travelled > viewConfiguration.touchSlop) {
                                    dragging = true
                                    if (grab != null) {
                                        onSelect(grab)
                                        dragRole = grab
                                    }
                                }
                                if (!dragging) continue
                                ch.consume()
                                if (grab == null) {
                                    // Not on a marker: move the picture (only does something while zoomed in).
                                    zoom = zoom.transformed(1f, 0f, 0f, delta.x, delta.y)
                                        .clampedTo(viewSize.width.toFloat(), viewSize.height.toFloat(), t.fit.imageRect)
                                    continue
                                }
                                val unit = t.normalizedSizeOf(1f)
                                val cur = pos ?: continue
                                pos = Vec2((cur.x + delta.x * unit.x).coerceIn(0f, 1f), (cur.y + delta.y * unit.y).coerceIn(0f, 1f))
                                dragPos = pos
                            }
                            val end = pos
                            if (dragging && grab != null && end != null) {
                                commit(grab, end)
                            } else if (!multi && !dragging) {
                                if (grab != null) {
                                    onSelect(grab)
                                } else if (p0 != null) {
                                    commit(latestSelected.value, p0)
                                }
                            }
                        } finally {
                            dragRole = null
                            dragPos = null
                        }
                    }
                },
        ) {
            val t = transform() ?: return@Canvas
            drawPicture(img, frame.width, frame.height, t)
            val d = state.draft
            val dp = density.density
            // Fixed elements that were measured but are not assigned to any control: faint, dashed, unlabelled. Tapping one with a
            // control selected puts the control there (the tap snaps to it); nothing is proposed for them.
            for (o in AutoReview.unassigned(d, state.hudBoxes)) drawRoi(t, o, Hp.TextMuted.copy(alpha = 0.45f), 1f * dp, dashed = true)
            // Faint numbered rings: the other spots the analysis considered for the selected control ("Try the next spot").
            d.controls[selected]?.takeIf { it.status == DetectionStatus.NEEDS_CONFIRMATION }?.alternatives?.forEachIndexed { i, a ->
                val p = t.toScreen(a.x, a.y)
                drawCircle(Hp.TextMuted.copy(alpha = 0.9f), 7f * dp, Offset(p.x, p.y), style = Stroke(1.5f * dp))
                drawLabel(measurer, "${i + 2}", Offset(p.x, p.y + 4f * dp), Hp.TextMuted, above = false)
            }
            d.marker?.let { m ->
                drawRoi(t, m, Hp.Info.copy(alpha = 0.7f), 1.2f * dp, dashed = true)
                val p = t.toScreen(m.left, m.bottom)
                drawLabel(measurer, "Screen marker", Offset(p.x + 40f * dp, p.y), Hp.Info, above = false)
            }
            d.minimap.box?.let { b ->
                drawRoi(t, b, if (d.minimap.boxConfirmed) Hp.Accent else Hp.Warning, 1.6f * dp, dashed = !d.minimap.boxConfirmed)
                val p = t.toScreen((b.left + b.right) / 2f, b.top)
                drawLabel(measurer, if (d.minimap.boxConfirmed) "Minimap" else "Minimap?", Offset(p.x, p.y), if (d.minimap.boxConfirmed) Hp.Accent else Hp.Warning)
            }
            for (role in roles) {
                val c = d.controls[role] ?: continue
                val dragged = role == dragRole
                if (!dragged && (c.status == DetectionStatus.NONE || c.status == DetectionStatus.REJECTED)) continue
                val isSel = role == selected
                val color = when {
                    isSel -> Hp.Accent
                    c.status.usable -> Hp.Success
                    else -> Hp.Warning
                }
                val at = if (dragged) dragPos ?: Vec2(c.x, c.y) else Vec2(c.x, c.y)
                if (!dragged) c.box?.let { drawRoi(t, it, color.copy(alpha = 0.85f), 1.6f * dp, dashed = !c.status.usable) }
                val p = t.toScreen(at.x, at.y)
                drawPointMarker(Offset(p.x, p.y), color, isSel)
                drawLabel(measurer, if (c.status == DetectionStatus.NEEDS_CONFIRMATION && !dragged) "${roleShort(role)}?" else roleShort(role), Offset(p.x, p.y), color)
            }
        }
        Column(Modifier.align(Alignment.BottomEnd).padding(Sp.s), verticalArrangement = Arrangement.spacedBy(Sp.xs)) {
            ZoomTool(Glyph.PLUS, "Zoom in") {
                val t = transform()
                if (t != null) zoom = zoom.transformed(1.6f, viewSize.width / 2f, viewSize.height / 2f, 0f, 0f).clampedTo(viewSize.width.toFloat(), viewSize.height.toFloat(), t.fit.imageRect)
            }
            ZoomTool(Glyph.FIT, "Show the whole picture") { zoom = ZoomPan.NONE }
        }
    }
}

private fun reviewDescription(d: dev.toe3autopilot.core.setup.SetupDraft, roles: List<CalibRole>, selected: CalibRole): String {
    val parts = roles.map { r ->
        val c = d.controls[r]
        when {
            c == null || c.status == DetectionStatus.NONE -> "${r.label} missing"
            c.status == DetectionStatus.REJECTED -> "${r.label} rejected"
            else -> "${r.label} at ${pct(c.x)} across, ${pct(c.y)} down" + if (c.status == DetectionStatus.NEEDS_CONFIRMATION) ", to check" else ", confirmed"
        }
    }
    return "Game picture with markers. Selected: ${selected.label}. Tap the picture to put it there, or drag a marker. " + parts.joinToString("; ")
}

@Composable
private fun ZoomTool(glyph: Glyph, description: String, onClick: () -> Unit) {
    Box(
        Modifier
            .size(Sp.touch)
            .clip(CircleShape)
            .background(Hp.Surface.copy(alpha = 0.92f))
            .border(1.dp, Hp.Border, CircleShape)
            .clickable(role = Role.Button, onClick = onClick)
            .semantics { contentDescription = description },
        contentAlignment = Alignment.Center,
    ) { HpIcon(glyph, tint = Hp.Text, size = 20.dp) }
}

@Composable
private fun ReviewPanel(
    env: UiEnv,
    state: SetupState,
    mode: SteeringMode?,
    roles: List<CalibRole>,
    sel: CalibRole,
    onSelect: (CalibRole) -> Unit,
    onConfirmed: () -> Unit,
    onClose: () -> Unit,
) {
    val d = state.draft
    val c = d.controls[sel]
    val missing = AutoReview.stillToPlace(d, mode)
    val toConfirm = AutoReview.pending(d, roles)
    BarSurface {
        Column(
            Modifier.windowInsetsPadding(WindowInsets.navigationBars).heightIn(max = 360.dp).verticalScroll(rememberScrollState())
                .padding(horizontal = Sp.l, vertical = Sp.m),
            verticalArrangement = Arrangement.spacedBy(Sp.s),
        ) {
            if (AutoReview.unassigned(d, state.hudBoxes).isNotEmpty()) {
                SmallText("Faint dashed outlines are other fixed elements that were found but not assigned to any control. Pick a control, then tap one of them to use it; nothing is chosen for you.", maxLines = 3)
            }
            val basis = state.analysisBasis
            if (basis != null && !state.analysisMultiFrame) {
                SmallText("Found from $basis: weaker evidence. Check every marker; driving forward while collecting gives much better results.", color = Hp.Warning, maxLines = 3)
            }
            if (mode == null) {
                Text("How do you steer in the game?", style = MaterialTheme.typography.titleSmall, color = Hp.Text)
                Row(horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
                    SteerChoice("Left / right buttons", Modifier.weight(1f)) { AutopilotRuntime.setup.edit { DraftEdits.chooseSteering(it, SteeringMode.BUTTONS) } }
                    SteerChoice("Steering wheel", Modifier.weight(1f)) { AutopilotRuntime.setup.edit { DraftEdits.chooseSteering(it, SteeringMode.SLIDER) } }
                }
                SmallText("No steering control was recognised, so nothing is assumed. Choose, then tap it on the picture.")
            }
            Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
                roles.forEach { r -> RoleChip(r, d.controls[r], r == sel, optional = r == CalibRole.GEAR_REVERSE) { onSelect(r) } }
            }
            Text(sel.label + if (sel == CalibRole.GEAR_REVERSE) " (optional, only for parking)" else "", style = MaterialTheme.typography.titleSmall, color = Hp.Text)
            SmallText(AutoReview.describe(c), color = Hp.TextSecondary)
            if (c != null && c.status == DetectionStatus.NEEDS_CONFIRMATION) {
                c.evidence.take(3).forEach { SmallText("• $it", maxLines = 2) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(Sp.s), verticalAlignment = Alignment.CenterVertically) {
                if (c != null && c.status == DetectionStatus.NEEDS_CONFIRMATION && c.alternatives.isNotEmpty()) {
                    HpButton("Next spot (${c.alternatives.size})", { AutopilotRuntime.setup.edit { DraftEdits.nextAlternative(it, sel) } }, kind = BtnKind.SECONDARY, height = 44.dp)
                }
                if (c != null && c.status == DetectionStatus.NEEDS_CONFIRMATION) {
                    HpButton("Not this", { AutopilotRuntime.setup.edit { DraftEdits.reject(it, sel) } }, kind = BtnKind.GHOST, height = 44.dp)
                }
                if (c != null && c.status.usable) {
                    HpButton("Clear", { AutopilotRuntime.setup.edit { DraftEdits.reset(it, sel) } }, kind = BtnKind.GHOST, height = 44.dp)
                }
                Spacer(Modifier.weight(1f))
                HpButton("Fine-tune", { env.nav.editor = EditorRequest(EditorMode.CONTROL, sel) }, kind = BtnKind.GHOST, glyph = Glyph.TARGET, height = 44.dp)
            }
            if (mode != null) {
                val other = if (mode == SteeringMode.BUTTONS) SteeringMode.SLIDER else SteeringMode.BUTTONS
                Text(
                    if (mode == SteeringMode.BUTTONS) "My game uses a steering wheel instead" else "My game uses left / right buttons instead",
                    Modifier.clip(RoundedCornerShape(Sp.radiusS)).clickable(role = Role.Button) {
                        AutopilotRuntime.setup.edit { DraftEdits.chooseSteering(it, other) }
                    }.heightIn(min = 40.dp).padding(vertical = Sp.s),
                    style = MaterialTheme.typography.labelLarge, color = Hp.Accent,
                )
            }
            Hairline()
            val canConfirm = mode != null && missing.isEmpty()
            HpButton(
                if (toConfirm.isEmpty()) "Continue: check and save" else "Confirm ${toConfirm.size} found control(s) and continue",
                {
                    val now = AutopilotRuntime.setup.state.value
                    val shown = AutoReview.roles(AutoReview.steering(now.draft))
                    val ok = AutopilotRuntime.setup.edit { DraftEdits.confirmReviewed(it, now.selectedFrame, emptyMap(), shown) }
                    if (!ok) {
                        env.toast("Wait until the analysis has finished.")
                        return@HpButton
                    }
                    AutopilotRuntime.setup.validate()
                    onConfirmed()
                },
                Modifier.fillMaxWidth(), enabled = canConfirm, glyph = Glyph.CHECK, height = 52.dp,
            )
            when {
                mode == null -> SmallText("Choose how you steer first.")
                missing.isNotEmpty() -> SmallText("Still to place: ${missing.joinToString { it.label }}. Select it above and tap where it is on the picture.", color = Hp.Warning)
                else -> SmallText("Only what you can see is right should be confirmed. Wrong markers: drag them, try the next spot, or tap \"Not this\".")
            }
            Row(horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
                HpButton("Auto-Calibrate again", {
                    val msg = AutopilotRuntime.startAutoCalibrate(fromOverlay = false)
                    if (AutopilotRuntime.setup.state.value.phase == SetupPhase.CAPTURING) env.openGame() else env.toast(msg ?: "Auto-Calibrate could not start.")
                }, kind = BtnKind.GHOST, height = 40.dp)
                HpButton("Other picture", {
                    onClose()
                    env.nav.openSetup(SETUP_STEP_SCREEN)
                }, kind = BtnKind.GHOST, height = 40.dp)
            }
        }
    }
}

@Composable
private fun SteerChoice(label: String, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(Sp.radiusM)
    Box(
        modifier
            .clip(shape)
            .background(Hp.Raised)
            .border(1.dp, Hp.Accent, shape)
            .clickable(role = Role.Button, onClick = onClick)
            .heightIn(min = 48.dp)
            .padding(horizontal = Sp.m, vertical = Sp.s),
        contentAlignment = Alignment.Center,
    ) { Text(label, style = MaterialTheme.typography.labelLarge, color = Hp.Text, maxLines = 1) }
}

@Composable
private fun RoleChip(role: CalibRole, c: dev.toe3autopilot.core.calibration.ControlDetection?, selected: Boolean, optional: Boolean, onClick: () -> Unit) {
    val (dot, word) = when {
        c == null || c.status == DetectionStatus.NONE -> Hp.TextMuted to (if (optional) "optional" else "missing")
        c.status.usable -> Hp.Success to "confirmed"
        c.status == DetectionStatus.NEEDS_CONFIRMATION -> Hp.Warning to "found, to check"
        else -> Hp.Danger to "rejected"
    }
    Row(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(if (selected) Hp.Accent.copy(alpha = 0.16f) else Hp.Raised)
            .border(1.dp, if (selected) Hp.Accent else Hp.Border, RoundedCornerShape(50))
            .clickable(role = Role.Tab, onClick = onClick)
            .heightIn(min = 40.dp)
            .padding(horizontal = Sp.m)
            .semantics { contentDescription = "${role.label}, $word" + if (selected) ", selected" else "" },
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(dot))
        Text(roleShort(role), style = MaterialTheme.typography.labelLarge, color = if (selected) Hp.Text else Hp.TextSecondary)
    }
}

// ---- confirm -> validate -> save -> test -----------------------------------------------------------------------------------

@Composable
private fun FinishPanel(env: UiEnv, state: SetupState, onBack: () -> Unit, onFix: (CalibRole) -> Unit, onClose: () -> Unit) {
    val profiles by AutopilotRuntime.profileList.collectAsStateWithLifecycle()
    val d = state.draft
    val errors = state.issues.filter { it.severity == IssueSeverity.ERROR }
    val warnings = state.issues.filter { it.severity == IssueSeverity.WARNING }
    val saved = state.phase == SetupPhase.CONFIRMED && !state.dirty

    // ---- validation ----
    HpCard(accent = if (!state.validatedCurrent) null else if (errors.isEmpty()) Hp.Success else Hp.Danger) {
        SectionHeader("Check", subtitle = "${d.confirmedCount} control(s) confirmed")
        when {
            !state.validatedCurrent -> {
                BodyText("The setup changed since the last check.")
                HpButton("Check again", { AutopilotRuntime.setup.validate() }, Modifier.fillMaxWidth(), glyph = Glyph.SHIELD)
            }
            errors.isNotEmpty() -> {
                BodyText("Fix these before saving:", color = Hp.Text)
                errors.forEach { i -> CheckLine(false, i.message, null, i.role?.let { "Fix ${it.label}" }, i.role?.let { r -> { onFix(r) } }) }
            }
            else -> CheckLine(true, "No blocking problems", if (warnings.isEmpty()) null else "${warnings.size} thing(s) worth checking below.")
        }
        warnings.forEach { i -> CheckLine(null, i.message, null, i.role?.let { "Check ${it.label}" }, i.role?.let { r -> { onFix(r) } }) }
        HpButton("Back to the markers", onBack, kind = BtnKind.GHOST, glyph = Glyph.BACK)
    }

    // ---- save ----
    val targets = profiles.filter { it.readable }
    val active = targets.firstOrNull { it.active }
    var chosenId by rememberSaveable { mutableStateOf(active?.id) }
    val targetId = chosenId?.takeIf { id -> targets.any { it.id == id } }
    var name by rememberSaveable { mutableStateOf(uniqueName(profiles.map { it.name })) }
    var saving by remember { mutableStateOf(false) }
    var outcome by remember { mutableStateOf<SaveOutcome?>(null) }
    val nameOk = name.isNotBlank() && profiles.none { it.name.equals(name.trim(), ignoreCase = true) }
    val useNew = targetId == null
    HpCard(accent = if (saved) Hp.Success else null) {
        SectionHeader("Save", subtitle = "The profile you save to becomes the active one")
        targets.forEach { p ->
            Choice(targetId == p.id, "Update \"${p.name}\"" + if (p.active) " (active)" else "", "Its earlier version is kept: Profiles → Undo last change.") { chosenId = p.id }
        }
        Choice(useNew, "A new profile", "Keeps every existing profile as it is.") { chosenId = null }
        if (useNew) {
            OutlinedTextField(
                value = name, onValueChange = { name = it.take(60) }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                label = { Text("Profile name") }, isError = name.isNotBlank() && !nameOk,
                supportingText = { if (name.isNotBlank() && !nameOk) Text("A profile with this name exists already") },
            )
        }
        HpButton(
            if (saving) "Saving…" else if (saved) "Saved" else "Save and make it active",
            {
                val target = targetId?.let { SaveTarget.Existing(it) } ?: SaveTarget.New(name.trim())
                saving = true
                AutopilotRuntime.ioScope.launchSafely {
                    try {
                        val r = AutopilotRuntime.setup.save(target)
                        outcome = r
                        AutopilotRuntime.notice.value = r.message
                    } finally {
                        saving = false
                    }
                }
            },
            Modifier.fillMaxWidth(), enabled = state.canSave && !saving && !saved && (!useNew || nameOk), glyph = Glyph.CHECK,
        )
        when {
            saved -> {}
            !state.validatedCurrent -> SmallText("Check the setup first (above).")
            errors.isNotEmpty() -> SmallText("Saving becomes available once nothing above blocks it.")
            useNew && !nameOk -> SmallText("Enter a name that is not used yet.")
        }
        outcome?.let { o ->
            BodyText(o.message, color = if (o.ok) Hp.Success else Hp.Danger)
            o.applied.forEach { CheckLine(true, it) }
            o.skipped.forEach { CheckLine(null, "$it (not confirmed, not saved)") }
            if (o.notReadyToDrive.isNotEmpty()) {
                SmallText("Auto Drive still needs:")
                o.notReadyToDrive.forEach { CheckLine(false, it) }
            }
        }
        if (!d.minimap.complete) {
            CheckLine(null, "Minimap", "Automatic driving follows the route on the minimap. Mark it in Smart Setup (step 7); the controls do not depend on it.", "Mark the minimap") {
                onClose()
                env.nav.openSetup(SETUP_STEP_MINIMAP)
            }
        }
    }

    // ---- safe test ----
    if (saved) AutoTestCard(env, state)
}

@Composable
private fun Choice(selected: Boolean, title: String, sub: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(Sp.radiusM))
            .selectable(selected, role = Role.RadioButton, onClick = onClick)
            .heightIn(min = 56.dp)
            .padding(vertical = Sp.xs),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(Sp.s),
    ) {
        RadioButton(selected = selected, onClick = null, colors = RadioButtonDefaults.colors(selectedColor = Hp.Accent, unselectedColor = Hp.TextSecondary))
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall, color = Hp.Text)
            SmallText(sub)
        }
    }
}

private fun uniqueName(taken: List<String>): String {
    val base = "TOE3 Auto-Calibrate"
    val lower = taken.map { it.lowercase() }.toSet()
    if (base.lowercase() !in lower) return base
    var n = 2
    while ("$base $n".lowercase() in lower) n++
    return "$base $n"
}

@Composable
private fun AutoTestCard(env: UiEnv, state: SetupState) {
    val view by AutopilotRuntime.gameView.collectAsStateWithLifecycle()
    var running by remember { mutableStateOf(false) }
    HpCard(accent = state.test?.let { if (it.passed) Hp.Success else Hp.Warning }) {
        SectionHeader("Safe test", subtitle = "Read-only: no touches are sent")
        BodyText("Checks the saved profile against the newest live picture of the game: same screen shape, driving screen recognised, controls where the profile says.")
        val age = view?.let { (System.currentTimeMillis() - it.timestampMs).coerceAtLeast(0) }
        InfoRow(
            "Newest picture of the game",
            when {
                age == null -> "none yet"
                else -> "${age / 1000} s ago" + if (age > 15_000) " (too old: open the game, then come back)" else ""
            },
            if (age != null && age <= 15_000) Hp.Success else Hp.Warning,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
            HpButton("Open the game", { env.openGame() }, Modifier.weight(1f), kind = BtnKind.SECONDARY, glyph = Glyph.PLAY)
            HpButton(
                if (running) "Testing…" else "Run the test",
                {
                    running = true
                    AutopilotRuntime.ioScope.launchSafely {
                        try {
                            AutopilotRuntime.setup.runTest()
                        } finally {
                            running = false
                        }
                    }
                },
                Modifier.weight(1f), enabled = !running, glyph = Glyph.SHIELD,
            )
        }
        state.test?.let { t ->
            Text(if (t.passed) "All required checks passed" else "Some checks did not pass", style = MaterialTheme.typography.titleSmall, color = if (t.passed) Hp.Success else Hp.Warning)
            SmallText(t.summary, color = if (t.verifiedLive) Hp.Success else Hp.Warning, maxLines = 4)
            t.checks.forEach { c -> CheckLine(c.ok, c.title + if (c.required) "" else " (optional)", c.detail) }
            if (t.passed) SmallText("This shows recognition works on this picture. It does not prove the game reacts to every touch; stay ready to take over on the first drive.")
        }
    }
}
