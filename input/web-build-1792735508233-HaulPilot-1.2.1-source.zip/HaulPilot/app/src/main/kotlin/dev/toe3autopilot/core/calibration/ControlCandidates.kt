package dev.toe3autopilot.core.calibration

import dev.toe3autopilot.core.vision.Frame
import dev.toe3autopilot.core.vision.GrayImage
import dev.toe3autopilot.core.vision.Roi
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sqrt

/**
 * Proposes which on-screen element is which driving control, from evidence in the pictures only.
 *
 * It works on the closed outlines [ShapeFinder] measured (see there for what is measured) and on how they are ARRANGED:
 *
 *  - Pedals: two tall-ish outlines side by side with aligned bottoms (or both cut off by the bottom of the game area). The
 *    left one is proposed as the brake, the right one as the accelerator (how real pedals and Truckers of Europe 3's pedals
 *    are arranged). With many pictures, see-through insides (the scenery keeps changing behind translucent controls) count
 *    for them and a solid inside (the truck in a chase camera) counts against them.
 *  - Steering buttons: two outlines of the same size side by side on one line; insides that are mirror images (a left and
 *    a right arrow) strengthen the proposal.
 *  - Steering wheel: a large ring (a band with an outer and an inner edge), when no button pair beats it.
 *  - Minimap: a framed element containing a vivid route colour; an inside that keeps changing (a scrolling map) adds to it.
 *  - Driving-screen marker: a steady, solid element that is not a control and not HaulPilot's own button.
 *
 * Screen position is only ever a small extra weight (and always said so), never a reason on its own. With many pictures
 * an outline must also be FIXED: present in most of the individual pictures while the scenery moves. Nothing here is
 * trusted: every proposal is NEEDS_CONFIRMATION from [DetectionSource.SHAPE], capped at [ControlDetection.SHAPE_MAX_CONFIDENCE]
 * (and at [SINGLE_PICTURE_MAX_CONFIDENCE] from a single picture). The person confirms, moves or replaces each one; the next
 * best arrangements are attached as [ControlDetection.alternatives]. A control without evidence (reverse gear in
 * particular) is reported as not found, never invented.
 *
 * It does NOT assume a control changes its look when pressed. If a pressed-state analysis of the same pictures exists
 * ([VideoCalibrationResult]) and agrees, that is added as supporting evidence.
 */
object ControlCandidateDetector {
    /** Highest confidence from a single picture: the scenery could not be separated from the on-screen controls. */
    const val SINGLE_PICTURE_MAX_CONFIDENCE = 0.45f

    /** With many pictures, an outline must be present in at least this share of them to count as fixed on the screen. */
    const val FIXED = ShapeFinder.FIXED_SHARE

    private const val CROWD_DISCS = 80
    private const val CROWD_RECTS = 160

    /** Largest steering wheel, as a share of the game-area height (a thumb-operated control). */
    const val MAX_WHEEL_DIAMETER = 0.5f

    /** Lowest arrangement score that is still proposed (many pictures). Below it the control is reported as not found. */
    const val MIN_PROPOSAL = 0.34f

    /** Same, from a single picture, where textured scenery produces many more look-alike outlines. */
    const val MIN_PROPOSAL_SINGLE = 0.40f

    /**
     * Largest size of a pedal or a steering button, as a share of the game area: these are thumb controls. (Larger closed
     * outlines in a driving picture are the truck, buildings or signs.)
     */
    const val MAX_CONTROL_WIDTH = 0.14f
    const val MAX_CONTROL_HEIGHT = 0.55f

    data class Result(
        val detections: Map<CalibRole, ControlDetection>,
        val minimap: MinimapSuggestion?,
        /** Plain-language findings for the analysis report. */
        val notes: List<String>,
        /** Steady element proposed for recognising the driving screen (never a control, never HaulPilot's own UI). */
        val marker: Roi? = null,
        /** Outlines that may be controls (fixed ones with many pictures), NDS; used to snap a tap to an element. */
        val outlines: List<Roi> = emptyList(),
        val multiFrame: Boolean = false,
        /** What the evidence was based on, in plain words. */
        val basis: String = "",
        /** The game area searched (NDS), when black bands were left out. */
        val viewport: Roi? = null,
    )

    /** Diagnostics hook (the fixture probe prints every scored arrangement). Never set in the app. */
    @Volatile
    var trace: ((String) -> Unit)? = null

    val ROLES = listOf(CalibRole.ACCELERATOR, CalibRole.BRAKE, CalibRole.STEER_LEFT, CalibRole.STEER_RIGHT, CalibRole.STEER_WHEEL, CalibRole.GEAR_REVERSE)

    /** Earlier entry point, kept for callers that analyse plain pictures (no HaulPilot UI to leave out). */
    fun detect(@Suppress("UNUSED_PARAMETER") hud: HudAnalysis, frames: List<Frame>, pressedEvidence: VideoCalibrationResult? = null): Result =
        detect(PictureEvidence.build(frames, frames.lastOrNull()), pressedEvidence) ?: empty("the analysis was cancelled")

    /**
     * @param ev the evidence (null when there is no picture)
     * @param isCancelled checked between stages; returns null when cancelled
     * @param progress 0..1, called between stages (honest: it moves when a stage really finished)
     */
    fun detect(
        ev: PictureEvidence?,
        pressedEvidence: VideoCalibrationResult? = null,
        isCancelled: () -> Boolean = { false },
        progress: (Float) -> Unit = {},
    ): Result? {
        if (ev == null) return empty("no pictures to analyse")
        val fw = ev.width
        val fh = ev.height
        val vp = ev.viewport
        val multi = ev.multiFrame
        val cap = if (multi) ControlDetection.SHAPE_MAX_CONFIDENCE else SINGLE_PICTURE_MAX_CONFIDENCE
        val minProposal = if (multi) MIN_PROPOSAL else MIN_PROPOSAL_SINGLE
        val notes = ArrayList<String>()
        notes += "Analysed ${ev.basis}."
        if (vp.x0 > 0 || vp.y0 > 0 || vp.x1 < fw || vp.y1 < fh) notes += GameViewport.describe(vp, fw, fh)
        if (ev.exclusions.isNotEmpty()) notes += "HaulPilot's own button was left out of the search."
        if (!multi) {
            notes += "From a single picture the scenery cannot be told apart from the on-screen controls, so every candidate is " +
                "weaker. Driving forward for a few seconds while collecting gives much better evidence."
        }

        progress(0.05f)
        val discs = ShapeFinder.discs(ev, 200)
        if (isCancelled()) return null
        progress(0.45f)
        val rects = ShapeFinder.rects(ev, 300)
        if (isCancelled()) return null
        progress(0.85f)

        fun fixed(s: Shape) = !multi || (s.persistence ?: 0f) >= FIXED
        val fixedDiscs = discs.filter(::fixed)
        val fixedRects = rects.filter(::fixed)
        val all = fixedDiscs + fixedRects
        if (multi) {
            notes += "${all.size} outlines stay in place while the scenery moves (${discs.size + rects.size - all.size} moving ones were ignored)."
        } else {
            notes += "${all.size} closed outlines were measured in the picture."
        }

        val out = LinkedHashMap<CalibRole, ControlDetection>()
        val used = ArrayList<Shape>()
        var mapShape: Shape? = null
        fun free(s: Shape): Boolean {
            val m = mapShape
            if (m != null && overlap(m, s)) return false
            return used.none { ShapeFinder.iouPx(it, s) > 0.1f || contains(it, s) || contains(s, it) }
        }
        // Clutter is judged against a fixed number of the strongest outlines, so it does not depend on list lengths.
        val crowdPool = fixedDiscs.take(CROWD_DISCS) + fixedRects.take(CROWD_RECTS)
        fun crowd(s: Shape): Int = crowdPool.count { it !== s && overlap(it, s) && ShapeFinder.iouPx(it, s) < 0.6f }

        /**
         * Penalty for a busy area: a control drawn over the scenery is one clean outline, while a textured object (the
         * truck, a building, bushes) produces many overlapping outlines.
         */
        fun clutter(vararg shapes: Shape, evidence: MutableList<String>): Float {
            val avg = shapes.sumOf { crowd(it) }.toFloat() / shapes.size
            if (avg <= 3f) return 0f
            evidence += "${avg.roundToInt()} other outlines overlap ${if (shapes.size > 1) "each of them" else "it"} on average (a busy, textured area makes this less certain)"
            return min(0.15f, 0.01f * (avg - 3f))
        }

        val single = if (multi) emptyList() else listOf("found in a single picture: weaker evidence")

        /** Cut off by the left, right or top edge of the game area (a pedal may reach the bottom edge, nothing else). */
        fun cutAtSide(s: Shape) = s.x0 - 2 < vp.x0 || s.x1 + 2 > vp.x1 || s.y0 - 2 < vp.y0

        fun partlyOutside(vararg shapes: Shape, evidence: MutableList<String>): Float {
            if (shapes.none(::cutAtSide)) return 0f
            evidence += "part of it lies outside the game area (on-screen controls are drawn completely inside it)"
            return 0.06f
        }

        // ---- minimap first: nothing inside the map can be a pedal or a button ------------------------------------------
        var bestMap: Scored? = null
        val globalHues = if (multi) hueCounts(ev, ev.viewport.x0, ev.viewport.y0, ev.viewport.x1, ev.viewport.y1) else null
        // From a single picture, coloured scenery (signs, poles, cars) cannot be told from a map; it is marked by hand then.
        for (e in if (multi) all else emptyList()) {
            if (!free(e)) continue
            val area = e.w.toFloat() * e.h / (fw.toFloat() * fh)
            if (area !in 0.012f..0.25f || e.w.toFloat() / e.h !in 0.5f..2.2f) continue
            val inner = shrink(e, 0.15f) ?: continue
            // The route colour belongs to the map: a vivid HUE that is common inside the frame and rare just around it
            // (green grass or a blue sky are saturated colours too, but they are everywhere).
            val hin = hues(ev, inner[0], inner[1], inner[2], inner[3], null)
            val hout = hues(ev, e.x0 - 2 - band(e), e.y0 - 2 - band(e), e.x1 + 2 + band(e), e.y1 + 2 + band(e), e)
            // ...and rare in the rest of the game area too (grass fills large parts of a driving picture).
            val boxCounts = hueCounts(ev, e.x0, e.y0, e.x1, e.y1)
            val g = globalHues!!
            val restN = g[HUES] - boxCounts[HUES]
            var bestHue = -1
            var vividIn = 0f
            for (k in 0 until HUES) {
                if (hout[k] > 0.5f * hin[k]) continue
                val rest = if (restN > 0f) (g[k] - boxCounts[k]) / restN else 0f
                if (rest > hin[k] / 3f) continue
                // Most of the picture's pixels of this hue must be inside (a route line is drawn only on the map).
                if (g[k] <= 0f || boxCounts[k] / g[k] < 0.7f) continue
                if (hin[k] > vividIn) {
                    vividIn = hin[k]
                    bestHue = k
                }
            }
            trace?.invoke("map? ${box(e)} hue=$bestHue in=$vividIn area=$area")
            if (bestHue < 0 || vividIn < 0.004f) continue
            val ev2 = ArrayList<String>()
            var s = 0.18f + 0.17f
            ev2 += "a framed element containing a vivid colour that is not around it (${(vividIn * 1000).roundToInt() / 10f}% of its inside), as a route line does"
            if (multi) {
                val dyn = ev.medianStd(inner[0], inner[1], inner[2], inner[3])
                if (dyn >= 8f) {
                    s += 0.15f
                    ev2 += "its inside keeps changing (median change ${dyn.roundToInt()} grey levels) while its frame stays put, as a scrolling map does"
                } else if (vividIn < 0.02f) {
                    // A little colour on something that never changes (a label on the truck) is not a map.
                    continue
                }
            }
            // Between nested outlines of the same map (its frame, a half split by the route line) prefer the larger one.
            s += min(0.05f, area)
            if (bestMap == null || s > bestMap.score) bestMap = Scored(e, e, s, ev2)
        }
        val minimap = bestMap?.let { m ->
            used += m.a
            mapShape = m.a
            val box = m.a.roi(fw, fh)
            val inner = shrinkRoi(box, 0.08f) ?: box
            MinimapSuggestion(
                box, CalibrationGuesses.routeColorGuess(ev.colour, inner),
                "Minimap candidate (${pct(min(m.score, cap))}% evidence): " + m.evidence.joinToString("; ") + ". Check the box covers the whole map.",
            )
        }
        notes += when {
            minimap != null -> "Found a minimap candidate."
            !multi -> "The minimap is not searched in a single picture; mark it by hand (the other steps do not depend on it)."
            else -> "No minimap was recognised; mark it by hand (the other steps do not depend on it)."
        }

        // ---- pedals -------------------------------------------------------------------------------------------------
        // Parts of a larger round element (the numbers and windows of a gauge) are not controls. Only a crisp, complete
        // round outline counts as such an element: two dark buttons side by side also fit inside a vague larger circle.
        val bigDiscs = fixedDiscs.filter { it.consistency >= 0.9f && it.sharpness >= 0.6f && !it.cut && it.radius >= 0.08f * vp.height }
        fun inBigDisc(s: Shape): Boolean = bigDiscs.any { d -> d !== s && d.radius >= 1.8f * (max(s.w, s.h) / 2f) && insideDisc(d, s) }
        // A pedal often has a light bar or grip ribs across it, so its outline is found as stacked parts with the same left
        // and right edges; those are joined into the whole pedal.
        val (stacked, partsOf) = stackJoined(ev, fixedRects)
        // A round element (a button, a gauge) also has a square outline around it; pedals are (rounded) rectangles, whose
        // corners a circle cannot follow, so an outline that coincides with a round one is not a pedal.
        fun round(r: Shape): Boolean {
            val m = max(r.w, r.h).toFloat()
            // ...and the round outline describes it at least as well as the rectangle does.
            return fixedDiscs.any { d ->
                d.darkInside == r.darkInside && abs(d.cx - r.cx) <= 0.2f * m && abs(d.cy - r.cy) <= 0.2f * m && d.radius / m in 0.38f..0.62f &&
                    d.consistency >= r.consistency - 0.02f && d.sharpness >= 0.9f * r.sharpness
            }
        }
        val pedalLike = stacked.filter { r ->
            val sized = r.h >= 0.10f * vp.height && r.h <= MAX_CONTROL_HEIGHT * vp.height && r.w >= 0.025f * vp.width && r.w <= MAX_CONTROL_WIDTH * vp.width &&
                r.h.toFloat() / r.w >= 0.7f && free(r)
            if (sized && trace != null && (inBigDisc(r) || round(r))) trace?.invoke("pedal-reject ${box(r)} inBigDisc=${inBigDisc(r)} round=${round(r)}")
            sized && !inBigDisc(r) && !round(r)
        }
        // A pedal's outline, not the grip ribs inside it: drop outlines nested in a similar-width, clear outline of the same
        // kind, and the parts of a joined outline.
        fun swallows(outer: Shape, inner: Shape): Boolean =
            outer !== inner && outer.darkInside == inner.darkInside && ShapeFinder.nested(outer, inner) &&
                (partsOf[outer]?.any { it === inner } == true ||
                    abs(outer.w - inner.w) <= 0.25f * outer.w && outer.consistency >= max(0.9f, inner.consistency - 0.05f) &&
                    outer.sharpness >= 0.5f * inner.sharpness)
        val pedalShapes = pedalLike.filter { inner -> pedalLike.none { outer -> swallows(outer, inner) } }
        trace?.let { t ->
            pedalLike.forEach { inner ->
                val by = pedalLike.firstOrNull { outer -> swallows(outer, inner) }
                t("pedal-like ${box(inner)} dark=${inner.darkInside} cons=${inner.consistency} sharp=${inner.sharpness} kept=${by == null} by=${by?.let { box(it) + (if (partsOf.containsKey(it)) "J" else "") }} see=${inner.seeThrough} pers=${inner.persistence}")
            }
        }
        val pedalPairs = ArrayList<Scored>()
        for (a in pedalShapes) for (b in pedalShapes) {
            if (a === b || a.cx >= b.cx || a.darkInside != b.darkInside) continue
            val gap = b.x0 - a.x1
            // The two pedals sit close together (a gap well under a pedal's width).
            if (gap < -2 || gap > 0.6f * max(a.w, b.w)) continue
            val vOverlap = min(a.y1, b.y1) - max(a.y0, b.y0)
            if (vOverlap < 0.5f * min(a.h, b.h)) continue
            val bothCut = a.y1 >= vp.y1 - 2 && b.y1 >= vp.y1 - 2
            val bottomDiff = abs(a.y1 - b.y1)
            if (!bothCut && bottomDiff > 0.06f * vp.height) continue
            if (max(a.w, b.w).toFloat() / min(a.w, b.w) > 2.2f) continue
            val ev2 = ArrayList<String>()
            var s = 0.18f
            ev2 += "two upright outlines stand side by side (${a.w}x${a.h} and ${b.w}x${b.h} px): the arrangement of a pedal pair"
            s += 0.10f * min(a.consistency, b.consistency) + 0.08f * min(1f, min(a.sharpness, b.sharpness))
            ev2 += "both outlines are clear (${pct(min(a.consistency, b.consistency))}% of each edge, sharpness ${pct(min(a.sharpness, b.sharpness))}%)"
            s += 0.05f
            ev2 += if (bothCut) "both reach the bottom edge of the game area" else "their bottoms are aligned (within ${pct(bottomDiff.toFloat() / vp.height)}% of the height)"
            if (b.h > a.h * 1.05f) {
                s += 0.04f
                ev2 += "the right one is taller, as an accelerator usually is"
            }
            if (max(a.y1, b.y1) >= vp.y1 - 0.10f * vp.height && min(a.y1, b.y1) >= vp.y1 - 0.16f * vp.height) {
                s += 0.04f
                ev2 += "both reach down to the bottom edge of the screen, where pedals are drawn (a small extra weight only)"
            }
            // Two pedals drawn in one style look alike inside (the same translucent fill over similar scenery).
            val ia = insideMedian(ev, a)
            val ib = insideMedian(ev, b)
            val fillDiff = abs(ia - ib)
            if (fillDiff <= 15f) {
                s += 0.03f
                ev2 += "both look alike inside (median grey ${ia.roundToInt()} and ${ib.roundToInt()})"
            } else if (fillDiff >= 25f) {
                s -= 0.10f
                ev2 += "one is much darker inside than the other (median grey ${ia.roundToInt()} and ${ib.roundToInt()}): not a matching pair"
            }
            val joined = listOf(a, b).count { partsOf.containsKey(it) }
            if (joined > 0) {
                ev2 += (if (joined == 2) "each outline was" else "one outline was") + " found in parts (a bar or grip ribs across the pedal) and joined"
            }
            if (multi) {
                val p = min(a.persistence ?: 0f, b.persistence ?: 0f)
                s += 0.10f * p
                ev2 += "both stay in place in ${pct(p)}% of the pictures while the scenery moves"
                val sa = a.seeThrough
                val sb = b.seeThrough
                if (sa != null && sb != null) {
                    if (min(sa, sb) >= 0.25f) {
                        s += 0.08f
                        ev2 += "the scenery keeps changing inside both (${pct(min(sa, sb))}% of the change around them): translucent controls"
                    } else if (max(sa, sb) < 0.12f) {
                        s -= 0.08f
                        ev2 += "nothing changes inside them although the scenery around them moves: more like a solid object (the truck?) than translucent controls"
                    }
                }
                if (min(a.detail, b.detail) >= 1.0f) {
                    s += 0.03f
                    ev2 += "both show fine detail inside (a grip pattern?)"
                }
            }
            s -= clutter(a, b, evidence = ev2)
            s -= partlyOutside(a, b, evidence = ev2)
            if (b.cx > (vp.x0 + vp.x1) / 2f) {
                s += 0.02f
                ev2 += "on the right side of the screen (a small extra weight only)"
            }
            pedalPairs += Scored(a, b, s, ev2)
        }
        pedalPairs.sortByDescending { it.score }
        trace?.let { t -> pedalPairs.take(8).forEach { t("pedal pair ${"%.3f".format(it.score)} L=${box(it.a)} R=${box(it.b)} dark=${it.a.darkInside} ${it.evidence}") } }
        val pressedAcc = pressedEvidence?.detections?.get(CalibRole.ACCELERATOR)?.takeIf { it.status == DetectionStatus.NEEDS_CONFIRMATION && it.source == DetectionSource.VIDEO }
        val pressedBrake = pressedEvidence?.detections?.get(CalibRole.BRAKE)?.takeIf { it.status == DetectionStatus.NEEDS_CONFIRMATION && it.source == DetectionSource.VIDEO }
        val bestPedals = pedalPairs.firstOrNull()?.takeIf { it.score >= minProposal }
        if (bestPedals != null) {
            val others = distinctPairs(pedalPairs.drop(1), bestPedals).take(2)
            val (brake, acc) = bestPedals.a to bestPedals.b
            used += brake
            used += acc
            out[CalibRole.ACCELERATOR] = candidate(
                ev, CalibRole.ACCELERATOR, acc, bestPedals.score + support(ev, acc, pressedAcc), cap,
                bestPedals.evidence + "proposed as the ACCELERATOR because it is the right-hand one" + supportNote(ev, acc, pressedAcc) + single,
                others.map { alt(ev, it.b, it.score, cap, "right-hand outline of another possible pedal pair", it.evidence + "proposed as the ACCELERATOR because it is the right-hand one" + single) },
            )
            out[CalibRole.BRAKE] = candidate(
                ev, CalibRole.BRAKE, brake, bestPedals.score + support(ev, brake, pressedBrake), cap,
                bestPedals.evidence + "proposed as the BRAKE because it is the left-hand one" + supportNote(ev, brake, pressedBrake) + single,
                others.map { alt(ev, it.a, it.score, cap, "left-hand outline of another possible pedal pair", it.evidence + "proposed as the BRAKE because it is the left-hand one" + single) },
            )
            notes += "Found a pedal pair: brake on the left, accelerator on the right."
        } else {
            out[CalibRole.ACCELERATOR] = none(CalibRole.ACCELERATOR, "no pair of pedal-shaped outlines was found")
            notes += "No pedal pair was found; tap the accelerator and the brake on the picture."
            out[CalibRole.BRAKE] = none(CalibRole.BRAKE, "no pair of pedals was found, so the brake cannot be told apart")
        }
        if (isCancelled()) return null

        // ---- steering buttons: a pair of equal outlines on one line ---------------------------------------------------
        val buttonShapes = all.filter { s ->
            val d = size(s)
            d >= 0.06f * vp.height && d <= MAX_CONTROL_HEIGHT * vp.height && s.w <= MAX_CONTROL_WIDTH * vp.width &&
                s.w.toFloat() / s.h in 0.7f..1.45f && free(s) && !inBigDisc(s)
        }
        val buttonPairs = ArrayList<Scored>()
        for (a in buttonShapes) for (b in buttonShapes) {
            if (a === b || a.cx >= b.cx || a.kind != b.kind || a.darkInside != b.darkInside) continue
            val sa = size(a)
            val sb = size(b)
            if (max(sa, sb) / min(sa, sb) > 1.3f) continue
            val avg = (sa + sb) / 2f
            if (abs(a.cy - b.cy) > 0.2f * avg) continue
            val gap = b.x0 - a.x1
            if (gap < -0.1f * avg || gap > 1.2f * avg) continue
            val mirror = ShapeFinder.ncc(ev, a, b, mirror = true)
            val plain = ShapeFinder.ncc(ev, a, b, mirror = false)
            val ev2 = ArrayList<String>()
            var s = 0.18f
            val word = if (a.kind == ShapeKind.DISC) "round" else "square"
            ev2 += "two $word outlines of the same size side by side on one line (${a.w} and ${b.w} px wide): the arrangement of a left/right pair"
            s += 0.10f * min(a.consistency, b.consistency) + 0.08f * min(1f, min(a.sharpness, b.sharpness))
            ev2 += "both outlines are clear (${pct(min(a.consistency, b.consistency))}% of each edge, sharpness ${pct(min(a.sharpness, b.sharpness))}%)"
            if (mirror >= 0.3f) {
                s += 0.12f * ((mirror - 0.3f) / 0.6f).coerceIn(0f, 1f)
                ev2 += "their insides are mirror images of each other (mirror match ${pct(mirror)}%)"
            }
            if (mirror > plain + 0.1f) {
                s += 0.04f
                ev2 += "they match better mirrored than unmirrored (${pct(plain)}%), as a left and a right arrow do"
            }
            if (multi) {
                val p = min(a.persistence ?: 0f, b.persistence ?: 0f)
                s += 0.10f * p
                ev2 += "both stay in place in ${pct(p)}% of the pictures while the scenery moves"
            }
            s -= clutter(a, b, evidence = ev2)
            // A button is drawn completely: one that runs off the picture (or under HaulPilot's own UI) is something else.
            if (a.cut || b.cut || a.y1 + 2 > vp.y1 || b.y1 + 2 > vp.y1) {
                s -= 0.10f
                ev2 += "part of it is outside the picture or hidden, while a button is drawn completely"
            } else {
                s -= partlyOutside(a, b, evidence = ev2)
            }
            if (b.cx < (vp.x0 + vp.x1) / 2f) {
                s += 0.02f
                ev2 += "on the left side of the screen (a small extra weight only)"
            }
            buttonPairs += Scored(a, b, s, ev2)
        }
        buttonPairs.sortByDescending { it.score }
        trace?.let { t -> buttonPairs.take(8).forEach { t("button pair ${"%.3f".format(it.score)} L=${box(it.a)} R=${box(it.b)} ${it.evidence}") } }

        // ---- steering wheel: a large ring ---------------------------------------------------------------------------
        val wheels = ArrayList<Scored>()
        for (d in fixedDiscs) {
            if (d.radius < 0.07f * vp.height || !free(d)) continue
            val fit = ShapeFinder.rim(ev, d)
            val rim = fit.score
            trace?.invoke("ring? ${box(d)} r=${d.radius} rim=$fit")
            // From one picture, curved scenery (a bend, a bush) easily looks like a ring; ask for a clearer rim there.
            if (rim < (if (multi) 0.6f else 0.75f)) continue
            // The wheel is the whole ring, out to its outer edge.
            val ro = fit.outerRadius.roundToInt()
            if (fit.outerRadius < 0.10f * vp.height || 2f * fit.outerRadius > MAX_WHEEL_DIAMETER * vp.height) continue
            val whole = d.copy(x0 = d.cx.roundToInt() - ro, y0 = d.cy.roundToInt() - ro, x1 = d.cx.roundToInt() + ro, y1 = d.cy.roundToInt() + ro, radius = fit.outerRadius)
            val ev2 = ArrayList<String>()
            var s = 0.20f + 0.10f * d.consistency + 0.08f * min(1f, d.sharpness) + 0.12f * ((rim - 0.6f) / 0.4f).coerceIn(0f, 1f)
            ev2 += "a large ring (diameter ${pct(2 * fit.outerRadius / vp.height)}% of the screen height) with an outer and an inner edge (${pct(rim)}%): the shape of a steering wheel"
            if (multi) {
                s += 0.10f * (d.persistence ?: 0f)
                ev2 += "it stays in place in ${pct(d.persistence ?: 0f)}% of the pictures while the scenery moves"
            }
            s -= clutter(whole, evidence = ev2)
            if (cutAtSide(whole) || whole.y1 > vp.y1) {
                s -= 0.06f
                ev2 += "part of it lies outside the game area (a steering wheel is drawn completely inside it)"
            }
            if (d.cx < (vp.x0 + vp.x1) / 2f) {
                s += 0.02f
                ev2 += "on the left side of the screen (a small extra weight only)"
            }
            ev2 += "steering is then done by holding the wheel and dragging sideways; check the steering range afterwards"
            wheels += Scored(whole, whole, s, ev2)
        }
        wheels.sortByDescending { it.score }
        trace?.let { t -> wheels.take(5).forEach { t("wheel ${"%.3f".format(it.score)} ${box(it.a)} ${it.evidence.first()}") } }
        trace?.let { t -> buttonShapes.forEach { t("button shape ${box(it)} r=${it.radius} cons=${it.consistency} sharp=${it.sharpness}") } }

        val pair = buttonPairs.firstOrNull()?.takeIf { it.score >= minProposal }
        val wheel = wheels.firstOrNull()?.takeIf { it.score >= minProposal }
        if (pair != null && (wheel == null || pair.score >= wheel.score)) {
            used += pair.a
            used += pair.b
            val others = distinctPairs(buttonPairs.drop(1), pair).take(2)
            out[CalibRole.STEER_LEFT] = candidate(
                ev, CalibRole.STEER_LEFT, pair.a, pair.score, cap, pair.evidence + "proposed as STEER LEFT because it is the left one of the pair" + single,
                others.map { alt(ev, it.a, it.score, cap, "left outline of another possible button pair", it.evidence + "proposed as STEER LEFT because it is the left one of the pair" + single) },
            )
            out[CalibRole.STEER_RIGHT] = candidate(
                ev, CalibRole.STEER_RIGHT, pair.b, pair.score, cap, pair.evidence + "proposed as STEER RIGHT because it is the right one of the pair" + single,
                others.map { alt(ev, it.b, it.score, cap, "right outline of another possible button pair", it.evidence + "proposed as STEER RIGHT because it is the right one of the pair" + single) },
            )
            out[CalibRole.STEER_WHEEL] = none(
                CalibRole.STEER_WHEEL, "a pair of steering buttons was found instead of a wheel",
                wheels.take(2).map { alt(ev, it.a, it.score, cap, "a ring that could be a steering wheel", it.evidence + single) },
            )
            notes += "Found two equal buttons side by side: steering left and right."
        } else if (wheel != null) {
            used += wheel.a
            out[CalibRole.STEER_WHEEL] = candidate(
                ev, CalibRole.STEER_WHEEL, wheel.a, wheel.score, cap, wheel.evidence + single,
                wheels.drop(1).take(2).map { alt(ev, it.a, it.score, cap, "another ring", it.evidence + single) },
            )
            out[CalibRole.STEER_LEFT] = none(CalibRole.STEER_LEFT, "a steering wheel was found instead of left/right buttons")
            out[CalibRole.STEER_RIGHT] = none(CalibRole.STEER_RIGHT, "a steering wheel was found instead of left/right buttons")
            notes += "Found a round steering wheel."
        } else {
            out[CalibRole.STEER_WHEEL] = none(CalibRole.STEER_WHEEL, "no large ring was found")
            out[CalibRole.STEER_LEFT] = none(CalibRole.STEER_LEFT, "no pair of equal buttons side by side was found")
            out[CalibRole.STEER_RIGHT] = none(CalibRole.STEER_RIGHT, "no pair of equal buttons side by side was found")
            notes += "No steering control was recognised; tap the steering wheel or the left/right buttons on the picture."
        }

        // ---- reverse: never guessed -----------------------------------------------------------------------------------
        out[CalibRole.GEAR_REVERSE] = none(
            CalibRole.GEAR_REVERSE,
            "a reverse button looks like any other small button in a picture, so it is not guessed; place it by hand (only needed for parking)",
        )
        if (isCancelled()) return null

        // ---- steady marker for the driving screen ----------------------------------------------------------------------
        val marker = if (multi) {
            all.filter { s ->
                (s.persistence ?: 0f) >= 0.8f && free(s) && (s.seeThrough ?: 0f) < 0.2f &&
                    (s.w.toFloat() * s.h / (fw.toFloat() * fh)) in 0.0006f..0.05f
            }.maxByOrNull { (it.persistence ?: 0f) * 2f + it.quality }?.roi(fw, fh)
        } else null

        progress(1f)
        // For snapping a tap to an element: outer, control-sized outlines only (not the grip ribs or symbols inside them).
        fun area(s: Shape) = s.w.toFloat() * s.h / (fw.toFloat() * fh)
        val elementLike = all.filter { area(it) <= 0.08f }
        val outlines = elementLike.filter { s -> elementLike.none { o -> o !== s && ShapeFinder.nested(o, s) } }.map { it.roi(fw, fh) }
        val vpRoi = if (vp.x0 > 0 || vp.y0 > 0 || vp.x1 < fw || vp.y1 < fh) {
            Roi(vp.x0.toFloat() / fw, vp.y0.toFloat() / fh, vp.x1.toFloat() / fw, vp.y1.toFloat() / fh)
        } else null
        return Result(out, minimap, notes, marker, outlines, multi, ev.basis, vpRoi)
    }

    private class Scored(val a: Shape, val b: Shape, val score: Float, val evidence: List<String>)

    /** Median grey of the inside of [s] (a fifth away from its outline) on the analysed picture. */
    private fun insideMedian(ev: PictureEvidence, s: Shape): Float {
        val mx = max(1, s.w / 5)
        val my = max(1, s.h / 5)
        val v = ArrayList<Float>()
        for (y in max(0, s.y0 + my) until min(ev.height, s.y1 - my)) for (x in max(0, s.x0 + mx) until min(ev.width, s.x1 - mx)) {
            if (!ev.blocked[y * ev.width + x]) v += ev.ref[y * ev.width + x]
        }
        if (v.isEmpty()) return 0f
        v.sort()
        return v[v.size / 2]
    }

    /** [s] lies well inside the disc [d] (its corners within 92 % of the radius): a part of it, not touching its rim. */
    private fun insideDisc(d: Shape, s: Shape): Boolean {
        val r = 0.92f * d.radius
        fun inR(x: Int, y: Int) = (x - d.cx) * (x - d.cx) + (y - d.cy) * (y - d.cy) <= r * r
        return inR(s.x0, s.y0) && inR(s.x1, s.y0) && inR(s.x0, s.y1) && inR(s.x1, s.y1)
    }

    /**
     * Rectangles plus the joins of vertically stacked rectangles that share their left and right edges (a pedal crossed by
     * a light bar is found as an upper and a lower part). Returns the list and, for each join, its parts.
     */
    private fun stackJoined(ev: PictureEvidence, rects: List<Shape>): Pair<List<Shape>, Map<Shape, List<Shape>>> {
        val parts = java.util.IdentityHashMap<Shape, List<Shape>>()
        val out = ArrayList(rects)
        val seen = HashSet<Long>()
        for (a in rects) for (b in rects) {
            if (a === b || a.kind != ShapeKind.RECT || b.kind != ShapeKind.RECT || a.darkInside != b.darkInside) continue
            if (b.y0 <= a.y0 || b.y1 <= a.y1) continue
            // b continues a downwards: touching or overlapping (a bar between them may be a few pixels high).
            if (b.y0 - a.y1 > 6) continue
            val tol = 0.15f * max(a.w, b.w) + 2f
            if (abs(a.x0 - b.x0) > tol || abs(a.x1 - b.x1) > tol) continue
            val x0 = min(a.x0, b.x0)
            val x1 = max(a.x1, b.x1)
            val key = ((x0.toLong() * 4096 + a.y0) * 4096 + x1) * 4096 + b.y1
            if (!seen.add(key)) continue
            if (rects.any { it.x0 == x0 && it.y0 == a.y0 && it.x1 == x1 && it.y1 == b.y1 && it.darkInside == a.darkInside }) continue
            fun minN(p: Float?, q: Float?) = if (p == null || q == null) null else min(p, q)
            // The joined outline is measured on the picture like any other (its sides run along both parts).
            val m = ShapeFinder.probeRect(ev, x0, a.y0, x1, b.y1, a.darkInside)
            val cons = m[4]
            if (cons < ShapeFinder.MIN_RECT_SCORE) continue
            val j = Shape(
                ShapeKind.RECT, x0, a.y0, x1, b.y1, a.darkInside,
                cons, m[5].coerceAtLeast(0f), m[6], a.cut || b.cut || m.subList(0, 4).any { it.isNaN() },
                minN(a.persistence, b.persistence), minN(a.seeThrough, b.seeThrough), max(a.detail, b.detail),
            )
            parts[j] = listOf(a, b)
            out += j
        }
        return out to parts
    }

    /** Pairs that do not reuse the outlines of [best] (alternatives must be different places). */
    private fun distinctPairs(rest: List<Scored>, best: Scored): List<Scored> {
        val picked = ArrayList<Scored>()
        for (p in rest) {
            val clash = (listOf(best) + picked).any { q ->
                ShapeFinder.iouPx(p.a, q.a) > 0.3f || ShapeFinder.iouPx(p.b, q.b) > 0.3f || ShapeFinder.iouPx(p.a, q.b) > 0.3f || ShapeFinder.iouPx(p.b, q.a) > 0.3f
            }
            if (!clash) picked += p
        }
        return picked
    }

    private fun box(s: Shape) = "(${s.x0},${s.y0},${s.x1},${s.y1})"

    private fun size(s: Shape): Float = if (s.kind == ShapeKind.DISC) 2f * s.radius else max(s.w, s.h).toFloat()

    private fun overlap(a: Shape, b: Shape) = a.x0 < b.x1 && b.x0 < a.x1 && a.y0 < b.y1 && b.y0 < a.y1

    private fun contains(a: Shape, b: Shape) = b.x0 >= a.x0 && b.x1 <= a.x1 && b.y0 >= a.y0 && b.y1 <= a.y1

    private fun candidate(
        ev: PictureEvidence,
        role: CalibRole,
        s: Shape,
        score: Float,
        cap: Float,
        evidence: List<String>,
        alternatives: List<Alternative>,
    ) = ControlDetection(
        role = role,
        x = (s.cx / ev.width).coerceIn(0f, 1f),
        y = (s.cy / ev.height).coerceIn(0f, 1f),
        box = s.roi(ev.width, ev.height),
        confidence = score.coerceIn(0f, min(cap, ControlDetection.SHAPE_MAX_CONFIDENCE)),
        status = DetectionStatus.NEEDS_CONFIRMATION,
        source = DetectionSource.SHAPE,
        evidence = evidence + "found from the pictures only: please confirm it is the ${role.label.lowercase()}",
        alternatives = alternatives,
    )

    /** An alternative carries the same cap as a proposal, so showing it instead can never raise the evidence shown. */
    private fun alt(ev: PictureEvidence, s: Shape, score: Float, cap: Float, note: String, evidence: List<String>) =
        Alternative(
            (s.cx / ev.width).coerceIn(0f, 1f), (s.cy / ev.height).coerceIn(0f, 1f), s.roi(ev.width, ev.height),
            score.coerceIn(0f, min(cap, ControlDetection.SHAPE_MAX_CONFIDENCE)), note,
            evidence + "found from the pictures only: please confirm it",
        )

    private fun none(role: CalibRole, why: String, alternatives: List<Alternative> = emptyList()) =
        ControlDetection.none(role, why, alternatives).copy(source = DetectionSource.SHAPE)

    private fun empty(why: String): Result {
        val out = LinkedHashMap<CalibRole, ControlDetection>()
        for (r in ROLES) out[r] = none(r, why)
        return Result(out, null, listOf("Nothing could be analysed: $why"))
    }

    private fun support(ev: PictureEvidence, s: Shape, d: ControlDetection?): Float {
        val b = d?.box ?: return 0f
        return if (iou(b, s.roi(ev.width, ev.height)) >= 0.5f) 0.10f else 0f
    }

    private fun supportNote(ev: PictureEvidence, s: Shape, d: ControlDetection?): List<String> {
        val b = d?.box ?: return emptyList()
        return if (iou(b, s.roi(ev.width, ev.height)) >= 0.5f) listOf("its look also changed together with the scenery speed (supporting evidence)") else emptyList()
    }

    /** Inner part of a shape as [x0, y0, x1, y1] pixels, or null when too small. */
    private fun shrink(s: Shape, f: Float): IntArray? {
        val dx = (s.w * f).roundToInt()
        val dy = (s.h * f).roundToInt()
        val a = intArrayOf(s.x0 + dx, s.y0 + dy, s.x1 - dx, s.y1 - dy)
        return if (a[2] > a[0] + 1 && a[3] > a[1] + 1) a else null
    }

    private fun shrinkRoi(r: Roi, f: Float): Roi? {
        val dx = (r.right - r.left) * f
        val dy = (r.bottom - r.top) * f
        val l = r.left + dx
        val t = r.top + dy
        val rr = r.right - dx
        val b = r.bottom - dy
        return if (rr > l && b > t) Roi(l, t, rr, b) else null
    }

    private const val HUES = 12

    private fun band(s: Shape) = max(3, min(s.w, s.h) / 6)

    /**
     * Share of pixels of each vivid hue (12 bins of 30 degrees) in [x0,x1) x [y0,y1) of the colour picture, leaving out
     * [hole] (widened by 2 px), HaulPilot's own parts and the black bands.
     */
    private fun hues(ev: PictureEvidence, x0: Int, y0: Int, x1: Int, y1: Int, hole: Shape?): FloatArray {
        val frame = ev.colour
        val out = FloatArray(HUES)
        var n = 0
        for (y in max(0, y0) until min(frame.height, y1)) for (x in max(0, x0) until min(frame.width, x1)) {
            if (hole != null && x >= hole.x0 - 2 && x < hole.x1 + 2 && y >= hole.y0 - 2 && y < hole.y1 + 2) continue
            if (ev.blocked[y * frame.width + x]) continue
            n++
            val c = frame.argb[y * frame.width + x]
            if (!vivid(c)) continue
            out[hueBin(c)] += 1f
        }
        if (n > 0) for (k in 0 until HUES) out[k] /= n
        return out
    }

    /** Pixel counts per vivid hue in [x0,x1) x [y0,y1) (index [HUES] holds the number of pixels looked at). */
    private fun hueCounts(ev: PictureEvidence, x0: Int, y0: Int, x1: Int, y1: Int): FloatArray {
        val frame = ev.colour
        val out = FloatArray(HUES + 1)
        for (y in max(0, y0) until min(frame.height, y1)) for (x in max(0, x0) until min(frame.width, x1)) {
            if (ev.blocked[y * frame.width + x]) continue
            out[HUES] += 1f
            val c = frame.argb[y * frame.width + x]
            if (vivid(c)) out[hueBin(c)] += 1f
        }
        return out
    }

    private fun hueBin(c: Int): Int {
        val r = ((c shr 16) and 0xFF) / 255f
        val g = ((c shr 8) and 0xFF) / 255f
        val b = (c and 0xFF) / 255f
        val mx = max(r, max(g, b))
        val mn = min(r, min(g, b))
        val d = mx - mn
        if (d <= 0f) return 0
        var h = when (mx) {
            r -> 60f * (((g - b) / d) % 6f)
            g -> 60f * ((b - r) / d + 2f)
            else -> 60f * ((r - g) / d + 4f)
        }
        if (h < 0f) h += 360f
        return (h / 30f).toInt().coerceIn(0, HUES - 1)
    }

    private fun vivid(c: Int): Boolean {
        val rr = (c shr 16) and 0xFF
        val gg = (c shr 8) and 0xFF
        val bb = c and 0xFF
        val mx = max(rr, max(gg, bb))
        val mn = min(rr, min(gg, bb))
        return mx >= 128 && (mx - mn).toFloat() / mx >= 0.5f
    }

    fun iou(a: Roi, b: Roi): Float {
        val l = max(a.left, b.left)
        val t = max(a.top, b.top)
        val r = min(a.right, b.right)
        val bt = min(a.bottom, b.bottom)
        if (r <= l || bt <= t) return 0f
        val inter = (r - l) * (bt - t)
        val union = (a.right - a.left) * (a.bottom - a.top) + (b.right - b.left) * (b.bottom - b.top) - inter
        return if (union <= 0f) 0f else inter / union
    }

    private fun pct(v: Float) = (v * 100).roundToInt()
}

/** Per-pixel temporal mean and standard deviation of a set of same-sized frames (grey levels). */
class TemporalStats private constructor(val width: Int, val height: Int, val mean: FloatArray, val std: FloatArray) {
    /** Mean of the temporal standard deviation inside [r]. High = the content there keeps changing. */
    fun meanStd(r: Roi): Float {
        val p = r.toRect(width, height)
        var s = 0.0
        var n = 0
        for (y in p.y0 until p.y1) for (x in p.x0 until p.x1) {
            s += std[y * width + x]
            n++
        }
        return if (n == 0) 0f else (s / n).toFloat()
    }

    /**
     * Normalised cross-correlation of the time-averaged pictures inside [a] and [b] (both resized to a common size);
     * with [mirrorSecond] the second picture is flipped left-right first. -1..1, 0 when either is flat.
     */
    fun ncc(a: Roi, b: Roi, mirrorSecond: Boolean): Float {
        val pa = patch(a) ?: return 0f
        val pb = patch(b) ?: return 0f
        val n = PATCH * PATCH
        var ma = 0.0
        var mb = 0.0
        for (i in 0 until n) {
            ma += pa.px[i]
            mb += pb.px[i]
        }
        ma /= n
        mb /= n
        var sab = 0.0
        var saa = 0.0
        var sbb = 0.0
        for (y in 0 until PATCH) for (x in 0 until PATCH) {
            val va = pa.px[y * PATCH + x] - ma
            val vb = pb.px[y * PATCH + (if (mirrorSecond) PATCH - 1 - x else x)] - mb
            sab += va * vb
            saa += va * va
            sbb += vb * vb
        }
        if (saa < 1e-6 || sbb < 1e-6) return 0f
        return (sab / sqrt(saa * sbb)).toFloat()
    }

    private fun patch(r: Roi): GrayImage? {
        val p = r.toRect(width, height)
        if (p.width < 3 || p.height < 3) return null
        val px = IntArray(p.width * p.height)
        for (y in 0 until p.height) for (x in 0 until p.width) px[y * p.width + x] = mean[(p.y0 + y) * width + p.x0 + x].toInt()
        return GrayImage(p.width, p.height, px).resize(PATCH, PATCH)
    }

    companion object {
        private const val PATCH = 24

        fun of(frames: List<Frame>): TemporalStats {
            val f0 = frames.first()
            val w = f0.width
            val h = f0.height
            val n = w * h
            val sum = DoubleArray(n)
            val sq = DoubleArray(n)
            var k = 0
            for (f in frames) {
                if (f.width != w || f.height != h) continue
                k++
                val g = f.toGray().px
                for (i in 0 until n) {
                    val v = g[i].toDouble()
                    sum[i] += v
                    sq[i] += v * v
                }
            }
            val mean = FloatArray(n)
            val std = FloatArray(n)
            for (i in 0 until n) {
                val m = sum[i] / k
                mean[i] = m.toFloat()
                std[i] = sqrt(max(0.0, sq[i] / k - m * m)).toFloat()
            }
            return TemporalStats(w, h, mean, std)
        }
    }
}
