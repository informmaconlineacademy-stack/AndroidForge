package dev.toe3autopilot.core.vision

/** An ARGB screenshot already scaled to the processing resolution. [timestampMs] is the capture time. */
class Frame(val width: Int, val height: Int, val argb: IntArray, val timestampMs: Long = 0L) {
    init {
        require(width > 0 && height > 0) { "Frame size must be positive" }
        require(argb.size == width * height) { "Pixel buffer size does not match ${width}x$height" }
    }

    fun toGray(): GrayImage {
        val out = IntArray(argb.size)
        for (i in argb.indices) {
            val p = argb[i]
            out[i] = (77 * ((p shr 16) and 0xFF) + 150 * ((p shr 8) and 0xFF) + 29 * (p and 0xFF)) shr 8
        }
        return GrayImage(width, height, out)
    }

    companion object {
        fun solid(width: Int, height: Int, rgb: Int, timestampMs: Long = 0L): Frame =
            Frame(width, height, IntArray(width * height) { (0xFF shl 24) or (rgb and 0xFFFFFF) }, timestampMs)
    }
}

/** 8-bit luminance image stored as ints 0..255. */
class GrayImage(val width: Int, val height: Int, val px: IntArray) {
    init {
        require(width > 0 && height > 0) { "Image size must be positive" }
        require(px.size == width * height) { "Pixel buffer size does not match ${width}x$height" }
    }

    /** Crop to [x0,x1) x [y0,y1). */
    fun crop(x0: Int, y0: Int, x1: Int, y1: Int): GrayImage {
        require(x0 in 0 until x1 && x1 <= width && y0 in 0 until y1 && y1 <= height) { "Crop outside image" }
        val w = x1 - x0
        val h = y1 - y0
        val out = IntArray(w * h)
        for (y in 0 until h) {
            System.arraycopy(px, (y0 + y) * width + x0, out, y * w, w)
        }
        return GrayImage(w, h, out)
    }

    /** Box-filter resize (area average when shrinking, nearest-like when enlarging). */
    fun resize(newW: Int, newH: Int): GrayImage {
        require(newW > 0 && newH > 0) { "Target size must be positive" }
        if (newW == width && newH == height) return this
        val out = IntArray(newW * newH)
        for (dy in 0 until newH) {
            val sy0 = dy * height / newH
            val sy1 = maxOf(sy0 + 1, (dy + 1) * height / newH)
            for (dx in 0 until newW) {
                val sx0 = dx * width / newW
                val sx1 = maxOf(sx0 + 1, (dx + 1) * width / newW)
                var sum = 0
                var n = 0
                for (sy in sy0 until sy1) {
                    for (sx in sx0 until sx1) {
                        sum += px[sy * width + sx]
                        n++
                    }
                }
                out[dy * newW + dx] = sum / n
            }
        }
        return GrayImage(newW, newH, out)
    }
}

/** Pixel rectangle, [x0,x1) x [y0,y1). */
data class PixelRect(val x0: Int, val y0: Int, val x1: Int, val y1: Int) {
    val width: Int get() = x1 - x0
    val height: Int get() = y1 - y0
}

/** Region of interest in normalised (0..1) screen coordinates. Using ROIs keeps calibration resolution-independent. */
data class Roi(val left: Float, val top: Float, val right: Float, val bottom: Float) {
    init {
        require(left >= 0f && top >= 0f && right <= 1f && bottom <= 1f) { "ROI must lie within 0..1: $this" }
        require(left < right && top < bottom) { "ROI must have positive area: $this" }
    }

    fun toRect(w: Int, h: Int): PixelRect {
        val x0 = (left * w).toInt().coerceIn(0, w - 1)
        val y0 = (top * h).toInt().coerceIn(0, h - 1)
        var x1 = Math.ceil((right * w).toDouble()).toInt().coerceIn(1, w)
        var y1 = Math.ceil((bottom * h).toDouble()).toInt().coerceIn(1, h)
        if (x1 <= x0) x1 = x0 + 1
        if (y1 <= y0) y1 = y0 + 1
        return PixelRect(x0, y0, x1, y1)
    }

    fun format(): String = listOf(left, top, right, bottom).joinToString(",") { fmt(it) }

    companion object {
        val FULL = Roi(0f, 0f, 1f, 1f)

        fun parse(s: String): Roi {
            val v = parseFloats(s, 4)
            return Roi(v[0], v[1], v[2], v[3])
        }
    }
}

internal fun fmt(v: Float): String = String.format(java.util.Locale.ROOT, "%.4f", v)

internal fun parseFloats(s: String, expected: Int): List<Float> {
    val parts = s.split(",").map { it.trim() }
    require(parts.size == expected) { "Expected $expected comma-separated numbers but got '$s'" }
    return parts.map { it.toFloatOrNull() ?: throw IllegalArgumentException("Not a number: '$it' in '$s'") }
}
