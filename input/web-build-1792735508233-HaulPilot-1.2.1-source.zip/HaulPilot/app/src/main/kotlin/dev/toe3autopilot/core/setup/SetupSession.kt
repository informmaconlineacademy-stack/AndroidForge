package dev.toe3autopilot.core.setup

import dev.toe3autopilot.core.Clock
import dev.toe3autopilot.core.calibration.HudAnalyzer
import dev.toe3autopilot.core.capture.FrameClass
import dev.toe3autopilot.core.capture.FrameOrigin
import dev.toe3autopilot.core.capture.FrameStats
import dev.toe3autopilot.core.vision.Frame
import dev.toe3autopilot.core.vision.Roi
import kotlin.math.abs

/** What the person can do to recover from a stopped capture or analysis. */
enum class SetupRecovery(val label: String) {
    CONNECT_SCREEN("Connect the screen"),
    OPEN_GAME("Open the game"),
    CHOOSE_GAME("Choose the game"),
    DRIVE_AND_RETRY("Drive and try again"),
    IMPORT_PICTURES("Use screenshots or a clip"),
    RETRY("Try again"),
}

/** Results of the safe test (step 10). */
data class SetupTestReport(val checks: List<TestCheck>, val atMs: Long) {
    val passed: Boolean get() = checks.all { it.ok || !it.required }

    /** The saved profile is complete (its own check). Says nothing about a live picture. */
    val profileComplete: Boolean get() = checks.firstOrNull { it.title.contains("saved profile") || it.title.startsWith("A saved") }?.ok == true

    /** Every live check that applies passed: the game is in front, a good picture arrived, the driving screen was recognised. */
    val verifiedLive: Boolean get() = passed && checks.any { it.title.startsWith("A live picture") && it.ok } && checks.any { it.title == "The driving screen is recognised" && it.ok }

    /** One honest sentence: what is established and what is not. */
    val summary: String
        get() = when {
            verifiedLive -> "Saved profile complete and recognised on live pictures of the game."
            profileComplete -> "The saved profile is complete, but it is NOT verified on a live picture of the game: " +
                (checks.firstOrNull { !it.ok && it.required }?.title ?: "a live check did not pass") + "."
            else -> "The saved profile is not complete yet."
        }
}

data class TestCheck(val title: String, val ok: Boolean, val detail: String, val required: Boolean = true)

/** Immutable snapshot of a [SetupSession]. */
data class SetupState(
    val phase: SetupPhase = SetupPhase.NOT_STARTED,
    val draft: SetupDraft = SetupDraft.EMPTY,
    val frames: List<FrameEntry> = emptyList(),
    val target: Int = SetupSession.TARGET_FRAMES,
    /** Pictures ignored because they were black, blank or unreadable. */
    val rejectedFrames: Int = 0,
    /** Pictures collected by the current (or last) live collection run; kept pictures of earlier runs are not counted. */
    val runCollected: Int = 0,
    /** What is happening or what to do next, in plain words. */
    val message: String = "Not started.",
    val problem: String? = null,
    val recovery: SetupRecovery? = null,
    /** Findings of the last analysis, in plain words. */
    val analysisNotes: List<String> = emptyList(),
    /** Fixed on-screen elements found by the analysis (candidate regions the editor can snap to). */
    val hudBoxes: List<Roi> = emptyList(),
    /** Issues from the last validation; [validatedCurrent] says whether they describe the current draft. */
    val issues: List<SetupIssue> = emptyList(),
    val validatedCurrent: Boolean = false,
    val canUndo: Boolean = false,
    val canRedo: Boolean = false,
    /** The draft changed since it was last saved (or was never saved). */
    val dirty: Boolean = false,
    val savedProfile: String? = null,
    val test: SetupTestReport? = null,
    /** Monotonic id of the current capture / analysis job; results of older jobs are ignored. */
    val token: Long = 0,
    /** The current (or last) run is Auto-Calibrate: collect while driving, then analyse without further taps. */
    val auto: Boolean = false,
    /** Collection finished in Auto-Calibrate: the host should start the analysis now. Cleared when it starts. */
    val autoAnalyze: Boolean = false,
    /** Pictures with moving scenery collected by the current run (what Auto-Calibrate counts towards [target]). */
    val runMoving: Int = 0,
    /** Still pictures left out by Auto-Calibrate (the truck was standing; they add nothing). */
    val stillSkipped: Int = 0,
    /** Progress of the running analysis (null when none is running). */
    val progress: AnalysisProgress? = null,
    /** What the last analysis was based on, in plain words, and whether it compared many moving pictures. */
    val analysisBasis: String? = null,
    val analysisMultiFrame: Boolean = false,
) {
    val collected: Int get() = frames.size
    val selectedFrame: FrameEntry? get() = frames.firstOrNull { it.id == draft.drivingFrameId }
    val canSave: Boolean get() = validatedCurrent && DraftValidator.canSave(issues) && !phase.busy
}

/** A frozen copy of what an analysis job works on. */
class AnalysisJob(val token: Long, val frames: List<FrameEntry>, val selectedId: Int?, val auto: Boolean = false)

/**
 * The single source of truth for Smart Setup. Thread-safe; every method returns quickly (the analysis itself runs
 * outside, see [beginAnalysis] / [completeAnalysis]). It never touches the game and never writes a profile: saving is
 * done by the host with the result of [DraftApply], and reported back with [markSaved] / [markSaveFailed].
 */
class SetupSession(
    private val clock: Clock,
    private val target: Int = TARGET_FRAMES,
    private val spacingMs: Long = SPACING_MS,
    private val noGameTimeoutMs: Long = NO_GAME_TIMEOUT_MS,
) {
    private val lock = Any()
    private var st = SetupState(target = target)
    private val history = History<SetupDraft>()
    private var nextFrameId = 1
    private var startedAt = 0L
    private var lastTakenAt = Long.MIN_VALUE / 2
    private var lastGameAt = 0L
    private var lastTakenGray: IntArray? = null

    /** Ids of the pictures collected by the current capture run (kept pictures from earlier runs are not counted). */
    private val runIds = HashSet<Int>()
    private var runMoving = 0
    private var runStill = 0
    private var stillSkipped = 0
    private var auto = false

    fun state(): SetupState = synchronized(lock) { st }

    // ---- capture --------------------------------------------------------------------------------------------------

    /**
     * Starts collecting live pictures. Earlier pictures are kept only when [keepPictures] is set; the draft (everything
     * placed or confirmed) is always kept. Returns null when started, otherwise why not.
     */
    fun startCapture(keepPictures: Boolean = false): String? = startRun(keepPictures, auto = false)

    /**
     * Auto-Calibrate: collects pictures while the person drives, counting only pictures in which the scenery MOVED (the
     * evidence that separates the fixed controls from the world), keeps at most [MAX_STILL_AUTO] still ones, stops at
     * [target] moving pictures or after [AUTO_MAX_MS], and then asks the host to analyse ([SetupState.autoAnalyze]).
     * Earlier pictures are dropped; the draft (everything placed or confirmed) is kept. Null when started.
     */
    fun startAuto(): String? = startRun(keepPictures = false, auto = true)

    private fun startRun(keepPictures: Boolean, auto: Boolean): String? = synchronized(lock) {
        if (st.phase.busy) return "${st.phase.label} is already running."
        startedAt = clock.nowMs()
        lastTakenAt = Long.MIN_VALUE / 2
        lastGameAt = 0L
        lastTakenGray = null
        runIds.clear()
        runMoving = 0
        runStill = 0
        stillSkipped = 0
        this.auto = auto
        val frames = if (keepPictures) st.frames else if (auto) emptyList() else keepSelected()
        var d = st.draft
        if (auto && frames.none { it.id == d.drivingFrameId }) d = d.copy(drivingFrameId = null, drivingConfirmed = false)
        st = st.copy(
            phase = SetupPhase.CAPTURING, frames = frames, draft = d, rejectedFrames = 0, runCollected = 0, runMoving = 0, stillSkipped = 0,
            problem = null, recovery = null, token = st.token + 1, auto = auto, autoAnalyze = false, progress = null,
            message = if (auto) "Auto-Calibrate: switch to the game and drive forward normally for about 15 seconds." else
                "Waiting for pictures of the game. Switch to the game and drive normally.",
        )
        null
    }

    /** The picture chosen as the driving screen survives a new capture, so the placed controls keep their picture. */
    private fun keepSelected(): List<FrameEntry> = st.frames.filter { it.id == st.draft.drivingFrameId }

    /**
     * Connection facts while collecting. [linkProblem] non-null = capture is not usable (permission revoked, projection
     * stopped, black pictures...). [origin] = what is in front right now.
     */
    fun onLink(captureOn: Boolean, linkProblem: String?, origin: FrameOrigin?) = synchronized(lock) {
        if (st.phase != SetupPhase.CAPTURING) return
        val now = clock.nowMs()
        if (auto && linkProblem == null && captureOn && autoTimeUp(now)) return
        val newCount = runIds.size
        when {
            linkProblem != null -> fail("Screen capture stopped working: $linkProblem", SetupRecovery.CONNECT_SCREEN)
            !captureOn -> {
                if (now - startedAt > noGameTimeoutMs) fail("The screen was not connected.", SetupRecovery.CONNECT_SCREEN)
                else st = st.copy(message = "Connect the screen first; Android asks for permission.")
            }
            else -> {
                if (newCount == 0) {
                    st = st.copy(
                        message = when (origin) {
                            FrameOrigin.OWN_APP -> if (auto) "Connected. Switch to the game and drive forward for about 15 seconds." else
                                "Connected. Switch to the game and drive normally for about 15 seconds."
                            FrameOrigin.OTHER_APP -> "The app in front is not the selected game, so its pictures are not used. Open the game, or mark the app in front as the game."
                            else -> "Waiting for pictures of the game."
                        },
                    )
                }
                val since = if (lastGameAt == 0L) startedAt else lastGameAt
                if (now - since > noGameTimeoutMs) {
                    val (msg, rec) = when (origin) {
                        FrameOrigin.OTHER_APP -> "No pictures of the selected game arrived: another app was in front." to SetupRecovery.CHOOSE_GAME
                        FrameOrigin.OWN_APP -> "No pictures of the game arrived: HaulPilot stayed in front." to SetupRecovery.OPEN_GAME
                        else -> "No pictures of the game arrived for ${noGameTimeoutMs / 1000} s." to SetupRecovery.OPEN_GAME
                    }
                    fail(msg, rec)
                }
            }
        }
    }

    /**
     * Offers one live picture. Only pictures of the game are kept, at most one every [spacingMs]. [exclusions] are the
     * parts HaulPilot itself drew over the game at that moment (NDS); they are never searched.
     */
    fun offer(frame: Frame, origin: FrameOrigin, exclusions: List<Roi> = emptyList()) = synchronized(lock) {
        if (st.phase != SetupPhase.CAPTURING) return
        if (origin != FrameOrigin.GAME && origin != FrameOrigin.UNKNOWN) return
        val now = clock.nowMs()
        lastGameAt = now
        if (auto && autoTimeUp(now)) return
        if (now - lastTakenAt < spacingMs) return
        val cls = try {
            FrameStats.of(frame).classify()
        } catch (e: RuntimeException) {
            null
        }
        if (cls == null || cls == FrameClass.ALL_BLACK || cls == FrameClass.SOLID_COLOUR) {
            st = st.copy(rejectedFrames = st.rejectedFrames + 1, message = "Black or blank pictures are being ignored (${liveCount()} of $target usable so far).")
            return
        }
        val first = st.frames.firstOrNull { it.id in runIds }
        var frames = st.frames
        var note: String? = null
        if (first != null && (first.frame.width != frame.width || first.frame.height != frame.height)) {
            // Rotation or another capture size: start this run's collection again instead of mixing two layouts.
            frames = frames.filter { it.id !in runIds }
            runIds.clear()
            runMoving = 0
            runStill = 0
            lastTakenGray = null
            note = "The screen size changed (rotation?), so the collection started again."
        }
        lastTakenAt = now
        val gray = frame.toGray().px
        val motion = lastTakenGray?.let { motionBetween(it, gray) }
        lastTakenGray = gray
        val evidence = when {
            cls == FrameClass.PARTLY_BLACK -> ScreenEvidence.PARTLY_BLACK
            motion == null -> ScreenEvidence.SINGLE
            motion < STILL_MOTION -> ScreenEvidence.STILL
            else -> ScreenEvidence.MOVING
        }
        val moving = evidence == ScreenEvidence.MOVING
        if (auto && !moving) {
            // A standing truck gives the same picture again and again; a few are kept (one picture can still be analysed),
            // the rest are left out and the person is asked to drive.
            if (runStill >= MAX_STILL_AUTO) {
                stillSkipped++
                st = st.copy(
                    stillSkipped = stillSkipped,
                    message = note ?: "The picture is not changing. Drive forward so the scenery moves ($runMoving of $target moving pictures so far).",
                )
                return
            }
            runStill++
        }
        if (moving) runMoving++
        val entry = FrameEntry(nextFrameId++, frame, FrameOriginKind.LIVE, motion, evidence, exclusions = exclusions)
        frames = capped(frames + entry)
        runIds += entry.id
        val count = runIds.size
        if (auto) {
            st = st.copy(
                frames = frames, runCollected = count, runMoving = runMoving,
                message = note ?: if (moving || runMoving > 0) "$runMoving of $target pictures with moving scenery. Keep driving forward." else
                    "Got a picture of the game. Now drive forward so the scenery moves.",
            )
            if (runMoving >= target) finishCapture("Collected $runMoving pictures with moving scenery. Analysing them now…")
        } else {
            st = st.copy(frames = frames, runCollected = count, runMoving = runMoving, message = note ?: "$count of $target pictures of the game collected. Keep driving normally.")
            if (count >= target) finishCapture("Collected $count pictures. Choose the picture that shows the normal driving view.")
        }
    }

    /** Auto-Calibrate's time limit: after [AUTO_MAX_MS] it continues with what it has (true when it stopped). */
    private fun autoTimeUp(now: Long): Boolean {
        if (now - startedAt < AUTO_MAX_MS) return false
        val have = runIds.size
        if (have == 0) return false // the no-game timeout reports this case
        finishCapture(
            if (runMoving >= MIN_MOVING_AUTO) "Collected $runMoving pictures with moving scenery in ${AUTO_MAX_MS / 1000} s. Analysing them now…"
            else "Only $runMoving picture(s) with moving scenery in ${AUTO_MAX_MS / 1000} s; analysing what was collected (weaker evidence)…",
        )
        return true
    }

    private fun liveCount() = runIds.size

    /** Drops the oldest pictures beyond [MAX_FRAMES], never the chosen driving screen. */
    private fun capped(frames: List<FrameEntry>): List<FrameEntry> {
        if (frames.size <= MAX_FRAMES) return frames
        val keep = st.draft.drivingFrameId
        val out = ArrayList(frames)
        var i = 0
        while (out.size > MAX_FRAMES && i < out.size) {
            if (out[i].id != keep) {
                runIds.remove(out[i].id)
                out.removeAt(i)
            } else {
                i++
            }
        }
        return out
    }

    /** The person stops collecting early. With at least one picture the setup continues with what was collected. */
    fun stopCapture() = synchronized(lock) {
        if (st.phase != SetupPhase.CAPTURING) return
        if (st.frames.isEmpty()) {
            st = st.copy(phase = SetupPhase.CANCELLED, message = "Stopped before any picture of the game arrived.", token = st.token + 1)
        } else if (liveCount() == 0) {
            finishCapture("Stopped before a new picture arrived; the earlier pictures are still here.")
        } else if (auto) {
            finishCapture("Stopped with ${liveCount()} picture(s) ($runMoving with moving scenery). Analysing them now…")
        } else {
            finishCapture("Stopped with ${liveCount()} new picture(s). Choose the picture that shows the normal driving view.")
        }
    }

    private fun finishCapture(msg: String) {
        st = st.copy(phase = SetupPhase.REVIEW_REQUIRED, message = msg, problem = null, recovery = null, autoAnalyze = auto && runIds.isNotEmpty())
        suggestDrivingFrame()
    }

    /** Adds imported screenshots or clip pictures. Returns null when added, otherwise why not. */
    fun importFrames(frames: List<Frame>, kind: FrameOriginKind): String? = synchronized(lock) {
        if (st.phase.busy) return "Wait until ${st.phase.label.lowercase()} has finished, or cancel it."
        val good = ArrayList<FrameEntry>()
        var rejected = 0
        var prev: IntArray? = null
        var prevSize: Pair<Int, Int>? = null
        for (f in frames) {
            val cls = try {
                FrameStats.of(f).classify()
            } catch (e: RuntimeException) {
                null
            }
            if (cls == null || cls == FrameClass.ALL_BLACK || cls == FrameClass.SOLID_COLOUR) {
                rejected++
                continue
            }
            val gray = f.toGray().px
            val sameSize = prevSize == (f.width to f.height)
            val motion = if (kind == FrameOriginKind.CLIP && sameSize) prev?.let { motionBetween(it, gray) } else null
            prev = gray
            prevSize = f.width to f.height
            val evidence = when {
                cls == FrameClass.PARTLY_BLACK -> ScreenEvidence.PARTLY_BLACK
                motion == null -> ScreenEvidence.SINGLE
                motion < STILL_MOTION -> ScreenEvidence.STILL
                else -> ScreenEvidence.MOVING
            }
            good += FrameEntry(nextFrameId++, f, kind, motion, evidence)
        }
        if (good.isEmpty()) {
            st = st.copy(rejectedFrames = st.rejectedFrames + rejected)
            return if (frames.isEmpty()) "No pictures were given." else "None of the ${frames.size} picture(s) could be used (black, blank or unreadable)."
        }
        auto = false
        st = st.copy(
            phase = SetupPhase.REVIEW_REQUIRED, auto = false, autoAnalyze = false,
            frames = capped(st.frames + good),
            rejectedFrames = st.rejectedFrames + rejected,
            problem = null, recovery = null,
            message = "Added ${good.size} ${kind.label}(s)" + (if (rejected > 0) "; $rejected could not be used" else "") + ". Choose the picture that shows the normal driving view.",
        )
        suggestDrivingFrame()
        null
    }

    /** Without a choice yet, the latest picture with moving scenery (else the latest one) is pre-selected but NOT confirmed. */
    private fun suggestDrivingFrame() {
        if (st.draft.drivingConfirmed && st.selectedFrame != null) return
        // After an analysis: the picture showing most of the fixed controls; before: the latest one with moving scenery.
        val pick = st.frames.filter { it.evidence == ScreenEvidence.DRIVING_LIKELY }.maxByOrNull { it.hudVisible ?: 0f }
            ?: st.frames.lastOrNull { it.evidence == ScreenEvidence.MOVING }
            ?: st.frames.lastOrNull()
            ?: return
        st = st.copy(draft = st.draft.copy(drivingFrameId = pick.id, drivingConfirmed = false))
    }

    // ---- driving screen -------------------------------------------------------------------------------------------

    /** The person confirms picture [id] as the driving screen. */
    fun selectDrivingFrame(id: Int): String? = synchronized(lock) {
        if (st.phase.busy) return "Wait until ${st.phase.label.lowercase()} has finished."
        val e = st.frames.firstOrNull { it.id == id } ?: return "That picture is no longer available."
        edit { DraftEdits.selectDrivingFrame(it, e) }
        null
    }

    /** Removes a picture from the gallery (for example a menu screenshot picked by mistake). */
    fun removeFrame(id: Int) = synchronized(lock) {
        if (st.phase.busy) return
        val frames = st.frames.filter { it.id != id }
        var d = st.draft
        if (d.drivingFrameId == id) d = d.copy(drivingFrameId = null, drivingConfirmed = false)
        st = st.copy(frames = frames, draft = d, validatedCurrent = false)
        suggestDrivingFrame()
    }

    // ---- analysis -------------------------------------------------------------------------------------------------

    /** Freezes what the analysis will work on. Null (with the reason in the state) when it cannot start now. */
    fun beginAnalysis(): AnalysisJob? = synchronized(lock) {
        if (st.phase.busy) return null // prevents duplicate jobs
        if (st.frames.isEmpty()) {
            st = st.copy(message = "There are no pictures to analyse. Capture or import some first.")
            return null
        }
        val token = st.token + 1
        st = st.copy(
            phase = SetupPhase.ANALYZING, token = token, problem = null, recovery = null, autoAnalyze = false,
            progress = AnalysisProgress(0f, "Starting"),
            message = "Separating the fixed controls from the moving scenery…",
        )
        AnalysisJob(token, st.frames, st.draft.drivingFrameId, st.auto)
    }

    /** Progress of [job]; ignored when the job is no longer current. */
    fun reportProgress(job: AnalysisJob, p: AnalysisProgress) = synchronized(lock) {
        if (job.token != st.token || st.phase != SetupPhase.ANALYZING) return
        if (st.progress == p) return
        st = st.copy(progress = p, message = "${p.stage}…")
    }

    /** Applies a finished analysis. Ignored when the job was cancelled or replaced in the meantime (stale result). */
    fun completeAnalysis(job: AnalysisJob, r: AnalysisResult): Boolean = synchronized(lock) {
        if (job.token != st.token || st.phase != SetupPhase.ANALYZING) return false
        val before = st.draft
        // Positions from a screen of another shape (rotation, another phone) mean nothing on these pictures: the analysis
        // starts from an empty setup then. The earlier one stays one undo away.
        val analysed = job.frames.firstOrNull { it.id == job.selectedId } ?: job.frames.lastOrNull()
        val oldLayout = before.layout
        val reshaped = analysed != null && oldLayout != null &&
            abs(oldLayout.aspect - analysed.frame.width.toFloat() / analysed.frame.height) / oldLayout.aspect > 0.03f
        val after = DraftEdits.applyAnalysis(if (reshaped) SetupDraft.EMPTY else before, r)
        if (after != before) history.record(before)
        val notes = if (reshaped) r.notes + "These pictures have a different screen shape from the earlier setup, so its positions were cleared (Undo brings them back)." else r.notes
        val frames = st.frames.map { e ->
            val v = r.hudVisibility[e.id] ?: return@map e
            val ev = when {
                v < 0.3f -> ScreenEvidence.HUD_MISSING
                (e.evidence == ScreenEvidence.MOVING || e.evidence == ScreenEvidence.SINGLE) && v >= 0.6f -> ScreenEvidence.DRIVING_LIKELY
                else -> e.evidence
            }
            e.copy(hudVisible = v, evidence = ev)
        }
        val found = r.detections.values.count { it.status == dev.toe3autopilot.core.calibration.DetectionStatus.NEEDS_CONFIRMATION }
        val weak = if (r.multiFrame) "" else " (from a single picture: weaker evidence)"
        st = st.copy(
            phase = SetupPhase.REVIEW_REQUIRED, draft = after, frames = frames, analysisNotes = notes,
            hudBoxes = (r.outlines + (if (r.hud.ok) r.hud.elements.map { it.box } else emptyList())).distinct(),
            message = when {
                found > 0 && job.auto -> "Found $found control(s)$weak. Check each marker on the picture: drag it if it is off, tap a missing control to place it, then confirm."
                found > 0 -> "Found $found candidate control(s)$weak. Check each one on the picture and confirm, move or reject it."
                job.auto -> "No control could be recognised$weak. Tap each control on the picture to place it."
                else -> "No control could be recognised from these pictures. Place the controls by hand on the chosen picture."
            },
            validatedCurrent = false, dirty = st.dirty || after != before, progress = null,
            analysisBasis = r.basis, analysisMultiFrame = r.multiFrame,
        )
        suggestDrivingFrame()
        refreshHistoryFlags()
        true
    }

    fun failAnalysis(job: AnalysisJob, why: String) = synchronized(lock) {
        if (job.token != st.token || st.phase != SetupPhase.ANALYZING) return
        st = st.copy(phase = SetupPhase.FAILED, problem = "The analysis failed: $why", recovery = SetupRecovery.RETRY, progress = null, message = "You can retry, or place the controls by hand.")
    }

    /** The person goes straight to placing controls by hand. */
    fun skipAnalysis() = synchronized(lock) {
        if (st.phase.busy) return
        st = st.copy(draft = st.draft.copy(analysisSkipped = true), message = "Place the controls by hand on the chosen picture.")
    }

    /** Cancels a running capture or analysis. Pictures and the draft are kept; a late analysis result is ignored. */
    fun cancel() = synchronized(lock) {
        if (!st.phase.busy) return
        st = st.copy(phase = SetupPhase.CANCELLED, token = st.token + 1, autoAnalyze = false, progress = null, message = "Cancelled. Your pictures and placed controls are kept.")
    }

    // ---- editing ----------------------------------------------------------------------------------------------------

    /** Applies a pure edit with undo. Returns false while a job is running (edits then would race with its result). */
    fun edit(transform: (SetupDraft) -> SetupDraft): Boolean = synchronized(lock) {
        if (st.phase.busy && st.phase != SetupPhase.CAPTURING) return false
        val before = st.draft
        val after = transform(before)
        if (after == before) return true
        history.record(before)
        st = st.copy(
            draft = after, validatedCurrent = false, dirty = true,
            phase = if (st.phase == SetupPhase.VALIDATING || st.phase == SetupPhase.CONFIRMED || st.phase == SetupPhase.NOT_STARTED) SetupPhase.REVIEW_REQUIRED else st.phase,
        )
        refreshHistoryFlags()
        true
    }

    fun undo(): Boolean = synchronized(lock) {
        if (st.phase.busy && st.phase != SetupPhase.CAPTURING) return false
        val prev = history.undo(st.draft) ?: return false
        st = st.copy(draft = prev, validatedCurrent = false, dirty = true, phase = afterEditPhase())
        refreshHistoryFlags()
        true
    }

    fun redo(): Boolean = synchronized(lock) {
        if (st.phase.busy && st.phase != SetupPhase.CAPTURING) return false
        val next = history.redo(st.draft) ?: return false
        st = st.copy(draft = next, validatedCurrent = false, dirty = true, phase = afterEditPhase())
        refreshHistoryFlags()
        true
    }

    private fun afterEditPhase(): SetupPhase =
        if (st.phase == SetupPhase.VALIDATING || st.phase == SetupPhase.CONFIRMED) SetupPhase.REVIEW_REQUIRED else st.phase

    private fun refreshHistoryFlags() {
        st = st.copy(canUndo = history.canUndo, canRedo = history.canRedo)
    }

    // ---- validate / save / test --------------------------------------------------------------------------------

    /** Validates the current draft. Without errors the phase becomes VALIDATING (ready to save). */
    fun validate(): List<SetupIssue> = synchronized(lock) {
        if (st.phase.busy) return st.issues
        val issues = DraftValidator.validate(st.draft) + selectionIssues()
        val ok = DraftValidator.canSave(issues)
        st = st.copy(
            issues = issues, validatedCurrent = true,
            phase = if (ok) SetupPhase.VALIDATING else SetupPhase.REVIEW_REQUIRED,
            message = if (ok) "No blocking problems. You can save the profile." else "Fix the problems listed before saving.",
        )
        issues
    }

    private fun selectionIssues(): List<SetupIssue> {
        val out = ArrayList<SetupIssue>()
        val sel = st.selectedFrame
        if (sel == null && st.draft.confirmedCount > 0) {
            out += SetupIssue(IssueSeverity.ERROR, "The picture the controls were placed on is gone. Choose a driving screen again.")
        }
        if (sel != null && !st.draft.drivingConfirmed) {
            out += SetupIssue(IssueSeverity.WARNING, "The driving screen was pre-selected but not confirmed by you.")
        }
        if (sel != null && sel.hudVisible != null && sel.hudVisible < 0.3f) {
            out += SetupIssue(IssueSeverity.WARNING, "The chosen picture shows few of the fixed driving controls; it may not be the driving view.")
        }
        if (sel != null && sel.evidence == ScreenEvidence.PARTLY_BLACK) {
            out += SetupIssue(IssueSeverity.WARNING, "The chosen picture is largely black; it may be a loading screen.")
        }
        return out
    }

    fun markSaved(profileName: String) = synchronized(lock) {
        st = st.copy(phase = SetupPhase.CONFIRMED, dirty = false, savedProfile = profileName, message = "Saved to profile \"$profileName\".", problem = null)
    }

    fun markSaveFailed(why: String) = synchronized(lock) {
        st = st.copy(problem = "Not saved: $why", message = "The profile was not changed.")
    }

    /** A problem outside the session's own work (for example an import that could not be read), shown until the next action. */
    fun reportProblem(why: String) = synchronized(lock) {
        st = st.copy(problem = why)
    }

    fun recordTest(report: SetupTestReport) = synchronized(lock) {
        st = st.copy(test = report)
    }

    // ---- restore / reset ----------------------------------------------------------------------------------------

    /**
     * Restores a draft saved before the app was closed, with its driving picture (other pictures are not kept across a
     * restart). The phase becomes REVIEW_REQUIRED so the person can continue where they stopped.
     */
    fun restore(draft: SetupDraft, picture: Frame?, savedProfile: String?, dirty: Boolean) = synchronized(lock) {
        if (st.phase != SetupPhase.NOT_STARTED || st.frames.isNotEmpty()) return
        var d = draft
        val frames = if (picture != null) {
            val e = FrameEntry(nextFrameId++, picture, FrameOriginKind.SCREENSHOT, null, ScreenEvidence.SINGLE)
            d = d.copy(drivingFrameId = e.id)
            listOf(e)
        } else {
            d = d.copy(drivingFrameId = null, drivingConfirmed = false)
            emptyList()
        }
        st = st.copy(
            phase = if (d == SetupDraft.EMPTY && frames.isEmpty()) SetupPhase.NOT_STARTED else SetupPhase.REVIEW_REQUIRED,
            draft = d, frames = frames, savedProfile = savedProfile, dirty = dirty,
            message = if (frames.isEmpty()) "Your earlier setup was restored without its picture. Capture or import a picture to continue." else "Your earlier setup was restored. Continue where you stopped.",
        )
    }

    /** Starts over completely: pictures, draft and history are cleared. Saved profiles are not touched. */
    fun resetAll() = synchronized(lock) {
        history.clear()
        st = SetupState(target = target, token = st.token + 1, message = "Setup cleared. Saved profiles were not changed.")
    }

    /**
     * Loads the setup of a saved profile for editing (Profiles -> Edit). The pictures stay; the chosen picture stays
     * selected only when it has the profile's screen shape, otherwise a picture of that shape has to be chosen.
     */
    fun loadDraft(draft: SetupDraft, savedProfile: String?) = synchronized(lock) {
        if (st.phase.busy) return
        history.record(st.draft)
        val sel = st.selectedFrame
        val fits = sel != null && draft.layout != null &&
            kotlin.math.abs(sel.frame.width.toFloat() / sel.frame.height - draft.layout.aspect) / draft.layout.aspect <= 0.03f
        st = st.copy(
            draft = draft.copy(drivingFrameId = if (fits) sel?.id else null, drivingConfirmed = fits && st.draft.drivingConfirmed),
            savedProfile = savedProfile, dirty = false, validatedCurrent = false, phase = SetupPhase.REVIEW_REQUIRED,
            message = if (fits) "Editing \"$savedProfile\" on the current picture." else "Editing \"$savedProfile\". Capture or import a picture of the driving screen to see and move its controls.",
        )
        refreshHistoryFlags()
    }

    // ---- internals ----------------------------------------------------------------------------------------------

    private fun fail(why: String, recovery: SetupRecovery) {
        val have = liveCount()
        st = st.copy(
            phase = SetupPhase.FAILED, problem = why, recovery = recovery, token = st.token + 1, autoAnalyze = false,
            message = if (have > 0) "$have picture(s) were collected before it stopped; you can continue with them or try again." else "Nothing was collected.",
        )
        if (have > 0) suggestDrivingFrame()
    }

    private fun motionBetween(a: IntArray, b: IntArray): Float {
        if (a.size != b.size) return 1f
        var c = 0
        var n = 0
        var i = 0
        val step = maxOf(1, a.size / 4000)
        while (i < a.size) {
            if (abs(a[i] - b[i]) > 10) c++
            n++
            i += step
        }
        return c.toFloat() / n
    }

    companion object {
        const val TARGET_FRAMES = 45
        const val SPACING_MS = 330L
        const val NO_GAME_TIMEOUT_MS = 60_000L
        const val MAX_FRAMES = 60
        const val STILL_MOTION = 0.01f

        /** Auto-Calibrate keeps at most this many still pictures per run. */
        const val MAX_STILL_AUTO = 3

        /** Auto-Calibrate stops collecting after this long and analyses what it has. */
        const val AUTO_MAX_MS = 75_000L

        /** Moving pictures below which Auto-Calibrate warns that the evidence is weak. */
        const val MIN_MOVING_AUTO = 6

        /** Enough pictures for the fixed-element analysis. */
        val MIN_FOR_ANALYSIS: Int get() = HudAnalyzer.MIN_FRAMES
    }
}
