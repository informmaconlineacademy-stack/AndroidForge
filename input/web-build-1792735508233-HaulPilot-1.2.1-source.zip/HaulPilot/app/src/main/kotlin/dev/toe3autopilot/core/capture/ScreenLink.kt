package dev.toe3autopilot.core.capture

/** What a captured picture shows, decided from who is in front when it was taken. */
enum class FrameOrigin {
    /** The selected game is in front. */
    GAME,

    /** HaulPilot itself is in front (pictures of our own screens; never analysed). */
    OWN_APP,

    /** Another app (or the launcher / system UI) is in front. */
    OTHER_APP,

    /** Cannot tell: the accessibility service is off. Treated as the game when HaulPilot is not in front. */
    UNKNOWN,
}

/**
 * Decides which captured pictures belong to the game.
 *
 * Root cause this fixes: calibration used to drop every picture whenever the foreground app was not exactly the saved game
 * package. The saved package was an unverified guess, so on phones where it did not match, calibration silently received
 * nothing and the preview never updated. Now the origin is explicit, shown to the person, and a wrong package can be
 * corrected from the app or the floating button ("This is the game").
 */
object FrameGate {
    fun classify(ownAppVisible: Boolean, accessibilityOn: Boolean, foreground: String?, gamePackage: String): FrameOrigin = when {
        ownAppVisible -> FrameOrigin.OWN_APP
        !accessibilityOn || foreground.isNullOrBlank() -> FrameOrigin.UNKNOWN
        gamePackage.isNotBlank() && foreground == gamePackage -> FrameOrigin.GAME
        else -> FrameOrigin.OTHER_APP
    }

    /**
     * Same decision from the tracker's view of the foreground: the selected game must be the app in front AND no helper
     * window (Play services pop-up ...) may be fresh on top of it. Helper windows never count as the game and never replace it.
     */
    fun classify(ownAppVisible: Boolean, view: ForegroundView): FrameOrigin = when {
        ownAppVisible -> FrameOrigin.OWN_APP
        !view.trackerLive -> FrameOrigin.UNKNOWN
        view.helperFresh -> FrameOrigin.OTHER_APP
        view.app == null -> FrameOrigin.UNKNOWN
        view.selected.isNotBlank() && view.app == view.selected -> FrameOrigin.GAME
        else -> FrameOrigin.OTHER_APP
    }

    /** Pictures that may be analysed as the game. */
    fun analysable(o: FrameOrigin): Boolean = o == FrameOrigin.GAME || o == FrameOrigin.UNKNOWN

    /** Launchers, the status bar / shade and keyboards are never the game. */
    fun couldBeGame(pkg: String?, ownPackage: String): Boolean {
        if (pkg.isNullOrBlank() || pkg == ownPackage) return false
        val p = pkg.lowercase()
        return !(p.contains("launcher") || p.contains("systemui") || p.contains("inputmethod") || p.contains("keyboard") ||
            p == "android" || p.endsWith(".home") || p.contains("permissioncontroller") || p.contains("packageinstaller"))
    }

    /** Picks the installed game from launcher entries (label, package), for when the saved package is not installed. */
    fun findInstalledGame(apps: List<Pair<String, String>>): String? =
        apps.firstOrNull { (label, _) -> label.contains("truckers of europe 3", ignoreCase = true) }?.second
            ?: apps.firstOrNull { (label, pkg) -> label.contains("truckers of europe", ignoreCase = true) || pkg.contains("truckersofeurope3", ignoreCase = true) }?.second
}

enum class LinkState(val label: String) {
    NOT_CONNECTED("Screen not connected"),
    WAITING_FOR_PERMISSION("Waiting for permission"),
    CONNECTED("Screen connected"),
    FAILED("Capture failed"),
}

enum class LinkAction { CONNECT, RETRY, OPEN_GAME, USE_GAME_IN_FRONT, CHOOSE_GAME, USE_CLIP, NONE }

data class LinkStatus(
    val state: LinkState,
    val detail: String,
    /** Live pictures of the game are arriving right now. */
    val receivingGame: Boolean,
    val action: LinkAction,
    val actionLabel: String?,
)

/**
 * The one connection status shown everywhere (Dashboard, Smart Setup, floating button). It never says "connected" unless
 * pictures are really arriving, and it says which app they show.
 */
object ScreenLink {
    /** While the game is in front it redraws constantly; no new picture for this long means capture stalled. */
    const val STALE_MS = 6_000L

    fun status(
        awaitingPermission: Boolean,
        captureOn: Boolean,
        diagnosis: CaptureDiagnosis,
        origin: FrameOrigin?,
        /** Age of the newest picture of any kind, null if none since capture started. */
        lastFrameAgeMs: Long?,
        foreground: String?,
    ): LinkStatus {
        if (awaitingPermission) return LinkStatus(
            LinkState.WAITING_FOR_PERMISSION,
            "Android is asking for permission. Choose \"Entire screen\" (not a single app) and tap Start.",
            false, LinkAction.NONE, null,
        )
        if (diagnosis.kind == DiagnosisKind.FAULT) {
            return LinkStatus(LinkState.FAILED, "${diagnosis.title}. ${diagnosis.detail}", false, LinkAction.RETRY, "Try again")
        }
        if (!captureOn) return LinkStatus(
            LinkState.NOT_CONNECTED,
            "Open Truckers of Europe 3 first, then come back and tap Connect. Android asks for permission every time.",
            false, LinkAction.CONNECT, "Connect screen",
        )
        when (diagnosis.kind) {
            DiagnosisKind.WAITING_FOR_FRAMES, DiagnosisKind.NOT_CONNECTED -> return LinkStatus(
                LinkState.NOT_CONNECTED, "Permission granted. Waiting for the first picture…", false, LinkAction.NONE, null,
            )
            DiagnosisKind.NO_FRAMES, DiagnosisKind.PIPELINE_BLACK, DiagnosisKind.GAME_BLACK_SUSPECTED_PROTECTION,
            DiagnosisKind.GAME_PARTLY_BLACK_SUSPECTED_PROTECTION, DiagnosisKind.GAME_BLACK_UNDETERMINED,
            -> return LinkStatus(
                LinkState.FAILED, "${diagnosis.title}. ${diagnosis.detail}", false,
                if (diagnosis.offerVideoCalibration) LinkAction.USE_CLIP else LinkAction.RETRY,
                if (diagnosis.offerVideoCalibration) "Use a screenshot or clip instead" else "Try again",
            )
            else -> {}
        }
        if (lastFrameAgeMs == null) return LinkStatus(
            LinkState.NOT_CONNECTED, "Permission granted. Waiting for the first picture…", false, LinkAction.NONE, null,
        )
        return when (origin) {
            FrameOrigin.GAME, FrameOrigin.UNKNOWN -> {
                if (lastFrameAgeMs > STALE_MS) LinkStatus(
                    LinkState.FAILED,
                    "Pictures stopped updating (${lastFrameAgeMs / 1000} s without a new one) although the game is in front. Reconnect the screen.",
                    false, LinkAction.RETRY, "Reconnect",
                ) else LinkStatus(
                    LinkState.CONNECTED,
                    if (origin == FrameOrigin.GAME) "Receiving live pictures of the game."
                    else "Receiving live pictures. Turn on the accessibility service so HaulPilot can tell the game apart from other apps.",
                    true, LinkAction.NONE, null,
                )
            }
            FrameOrigin.OWN_APP -> LinkStatus(
                LinkState.CONNECTED,
                "Connected. HaulPilot is in front now; switch to the game to give it live pictures.",
                false, LinkAction.OPEN_GAME, "Open the game",
            )
            FrameOrigin.OTHER_APP -> LinkStatus(
                LinkState.CONNECTED,
                "Connected, but the selected game is not in front (in front: ${foreground ?: "unknown"}), so these pictures are not analysed and nothing is sent. Open the game.",
                false, LinkAction.OPEN_GAME, "Open the game",
            )
            null -> LinkStatus(LinkState.CONNECTED, "Connected.", false, LinkAction.NONE, null)
        }
    }
}
