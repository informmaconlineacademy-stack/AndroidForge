package dev.toe3autopilot.app.input

import android.accessibilityservice.AccessibilityService
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.LinearLayout
import android.widget.TextView
import dev.toe3autopilot.app.AutopilotRuntime
import dev.toe3autopilot.app.Brand
import android.view.Choreographer
import dev.toe3autopilot.core.overlay.BoundedPlacement
import dev.toe3autopilot.core.overlay.DockPosition
import dev.toe3autopilot.core.overlay.DragTracker
import dev.toe3autopilot.core.overlay.SingleWindow
import dev.toe3autopilot.core.overlay.UsableBounds
import dev.toe3autopilot.core.overlay.OverlayTone
import dev.toe3autopilot.core.overlay.OverlayUi
import dev.toe3autopilot.core.overlay.OwnUiRegions
import dev.toe3autopilot.core.overlay.TapGuard
import dev.toe3autopilot.core.vision.Roi

/** Callbacks of the floating controls. */
class FloatingActions(
    val onStartDrive: () -> Unit,
    val onStartCalibration: () -> Unit,
    val onCancelCalibration: () -> Unit,
    val onPause: () -> Unit,
    val onResume: () -> Unit,
    val onEnd: () -> Unit,
    val onEmergency: () -> Unit,
    /** Hides the button until the next drive (Settings brings it back). */
    val onHide: () -> Unit = {},
    /** Auto-Calibrate's result waits for review: bring HaulPilot to the front on its review screen. */
    val onOpenReview: () -> Unit = {},
    /**
     * HaulPilot's own windows over the game changed: where they are in the captured picture (normalised display space),
     * and whether they cover the game right now (panel open, button being dragged).
     */
    val onOwnWindows: (regions: List<Roi>, covering: Boolean) -> Unit = { _, _ -> },
)

/** Remembers where the person left the button (side + height fraction, so it survives rotation). */
class DockStore(context: Context) {
    private val prefs = context.getSharedPreferences("floating_controls", Context.MODE_PRIVATE)

    fun load(): DockPosition =
        if (!prefs.contains("right")) DockPosition.DEFAULT
        else DockPosition(prefs.getBoolean("right", true), prefs.getFloat("y", DockPosition.DEFAULT.yFraction))

    fun save(p: DockPosition) {
        prefs.edit().putBoolean("right", p.rightSide).putFloat("y", p.yFraction).apply()
    }
}

fun toneColor(t: OverlayTone): Int = when (t) {
    OverlayTone.ACTIVE -> Brand.SUCCESS
    OverlayTone.DONE -> Brand.INFO
    OverlayTone.DANGER -> Brand.DANGER
    OverlayTone.WARNING -> Brand.WARNING
    OverlayTone.CALIBRATING -> Brand.ACCENT
    OverlayTone.NEUTRAL -> Brand.TEXT_MUTED
}

/**
 * The in-game controls, drawn as accessibility overlay windows:
 *
 * * **Collapsed**: a 52 dp round button with a road-and-chevron mark, a state dot and (while calibrating) a progress ring.
 *   Drag it anywhere; it snaps to the nearer side edge and remembers its place. A tap (not a drag) opens the panel.
 * * **Expanded**: a compact panel beside the button with the state, what is happening, live calibration progress, and
 *   Start Auto Drive / Auto-Calibrate / Pause / Resume / End / Emergency Stop.
 *
 * Every value shown comes from [OverlayUi], which is built from the app's real state; nothing here keeps its own idea of
 * what the automation is doing. Collapsing only hides the panel: a drive or calibration carries on.
 *
 * Emergency Stop acts at once, but only on a deliberate press: it lives in the expanded panel (one tap to open, one to
 * stop), presses during the first 350 ms after opening are ignored, and the end of a drag never counts as a press. The
 * notification's Emergency stop action remains available too.
 *
 * Caveat: these are real windows above the game, so an automated touch aimed at a spot under them would hit them instead.
 * Keep the button away from the calibrated controls.
 *
 * They are also in every captured picture. Their position is reported ([FloatingActions.onOwnWindows]) so the calibration
 * never takes HaulPilot's own button for part of the game's dashboard, and pictures taken while the panel is open or the
 * button is being dragged are not used at all.
 */
class FloatingControls(private val service: AccessibilityService, private val actions: FloatingActions) {
    private val wm: WindowManager = service.getSystemService(WindowManager::class.java)
    private val dp get() = service.resources.displayMetrics.density
    private val store = DockStore(service)
    private val guard = TapGuard(ViewConfiguration.get(service).scaledTouchSlop.toFloat())

    // Exactly one button window and one panel window can exist: SingleWindow refuses to attach a second view.
    private var pendingButtonLp: WindowManager.LayoutParams? = null
    private var pendingPanelLp: WindowManager.LayoutParams? = null
    private val buttonWin = SingleWindow<FloatingButtonView>({ v -> wm.addView(v, pendingButtonLp) }, ::safeRemove)
    private val panelWin = SingleWindow<PanelViews>({ p -> wm.addView(p.root, pendingPanelLp) }, { p -> safeRemove(p.root) })
    private val button: FloatingButtonView? get() = buttonWin.view
    private var buttonLp: WindowManager.LayoutParams? = null
    private val panel: PanelViews? get() = panelWin.view
    private var panelLp: WindowManager.LayoutParams? = null
    private val drag = DragTracker(guard)
    private var framePending = false
    private var lastBounds: UsableBounds? = null
    private var dock: DockPosition = store.load()
    private var last: OverlayUi? = null
    private var snapAnim: ValueAnimator? = null
    private var dragging = false
    private var lastPublished: Pair<List<Roi>, Boolean>? = null

    private fun px(v: Float) = (v * dp).toInt()
    private val buttonSize get() = px(52f)
    private val margin get() = px(8f)
    private val panelDesignW get() = px(272f)

    /**
     * The area a window may occupy, in the window manager's own pixel space (whole display, origin top-left): the real
     * display minus system bars and cut-outs. The old code clamped against `resources.displayMetrics`, which on many phones
     * excludes the navigation bar while window coordinates and the captured picture include it, so the button could hide
     * under a bar or jump when the numbers disagreed after a rotation.
     */
    private fun bounds(): UsableBounds {
        val (rw, rh) = try {
            AutopilotRuntime.realDisplaySize(service)
        } catch (_: Exception) {
            service.resources.displayMetrics.widthPixels to service.resources.displayMetrics.heightPixels
        }
        var l = 0
        var t = 0
        var r = 0
        var b = 0
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            try {
                val ins = wm.currentWindowMetrics.windowInsets.getInsetsIgnoringVisibility(
                    android.view.WindowInsets.Type.systemBars() or android.view.WindowInsets.Type.displayCutout(),
                )
                l = ins.left; t = ins.top; r = ins.right; b = ins.bottom
            } catch (_: Exception) {
            }
        }
        if (l == 0 && t == 0 && r == 0 && b == 0) {
            // Insets unknown (older Android, or a context without them): the status bar height, and whatever the usable
            // display size lacks compared with the real one (the navigation bar).
            val res = service.resources
            val id = res.getIdentifier("status_bar_height", "dimen", "android")
            t = if (id > 0) res.getDimensionPixelSize(id) else 0
            val dm = res.displayMetrics
            r = (rw - dm.widthPixels).coerceAtLeast(0)
            b = (rh - dm.heightPixels).coerceAtLeast(0)
        }
        val left = l.coerceIn(0, maxOf(0, rw - 1))
        val top = t.coerceIn(0, maxOf(0, rh - 1))
        return UsableBounds(left, top, maxOf(left, rw - r), maxOf(top, rh - b))
    }

    private fun panelWidth(): Int = BoundedPlacement.panelWidth(panelDesignW, bounds(), margin)

    val isShown: Boolean get() = button != null

    private fun baseParams(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        // Not focusable (implies not touch-modal): touches outside these small windows go straight to the game.
        // Explicit hardware acceleration: without it some phones draw these windows in software, which shows as flicker,
        // torn edges and a smeared panel while the game renders behind. NOT_TOUCH_MODAL: never swallow touches outside.
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
        PixelFormat.TRANSLUCENT,
    ).apply { gravity = Gravity.TOP or Gravity.START }

    /** Shows or updates the controls. Main thread only. False if the window could not be added. */
    fun show(ui: OverlayUi): Boolean {
        val unchanged = ui == last
        last = ui
        if (!ui.visible) {
            hide()
            return true
        }
        if (button == null) {
            if (!addButton()) return false
        } else {
            // Same state and same screen: nothing to redraw and no window-manager call (this is called on every state change).
            val b = bounds()
            if (b != lastBounds) onScreenChanged() else if (unchanged) return true
        }
        button?.update(ui)
        panel?.let { renderPanel(it, ui) }
        publishWindows()
        return true
    }

    fun hide() {
        snapAnim?.cancel()
        snapAnim = null
        collapse()
        buttonWin.remove()
        buttonLp = null
        drag.cancel()
        dragging = false
        publishWindows()
    }

    /** Closes the panel (the button stays). Used when Auto-Calibrate starts: the panel would hide the game. */
    fun collapsePanel() {
        collapse()
    }

    /**
     * Reports where HaulPilot's windows are, as regions of the captured picture. The captured picture shows the whole
     * display, so window positions are taken on screen (getLocationOnScreen) and divided by the real display size. Until
     * a window has been laid out its layout parameters are used. A small margin covers the shadow and anti-aliasing.
     */
    private fun publishWindows() {
        val (rw, rh) = try {
            AutopilotRuntime.realDisplaySize(service)
        } catch (_: Exception) {
            service.resources.displayMetrics.widthPixels to service.resources.displayMetrics.heightPixels
        }
        val wins = ArrayList<OwnUiRegions.Window>()
        button?.let { v -> windowOf(v, buttonLp, buttonSize, buttonSize)?.let { wins += it } }
        panel?.let { p -> windowOf(p.root, panelLp, panelLp?.width ?: panelWidth(), p.root.measuredHeight)?.let { wins += it } }
        val regions = OwnUiRegions.of(wins, rw, rh, px(4f))
        val covering = panel != null || dragging
        val now = regions to covering
        if (now == lastPublished) return
        lastPublished = now
        actions.onOwnWindows(regions, covering)
    }

    private fun windowOf(v: View, lp: WindowManager.LayoutParams?, w: Int, h: Int): OwnUiRegions.Window? {
        if (v.isAttachedToWindow && v.width > 0 && v.height > 0 && !dragging) {
            val loc = IntArray(2)
            v.getLocationOnScreen(loc)
            return OwnUiRegions.Window(loc[0], loc[1], v.width, v.height)
        }
        val l = lp ?: return null
        return OwnUiRegions.Window(l.x, l.y, w, maxOf(h, 1))
    }

    /** Rotation, a new screen size or changed system bars: put the button back at its remembered side and height. */
    fun onScreenChanged() {
        val v = button ?: return
        val lp = buttonLp ?: return
        snapAnim?.cancel()
        snapAnim = null
        drag.cancel()
        dragging = false
        val b = bounds()
        lastBounds = b
        val (x, y) = BoundedPlacement.place(dock, buttonSize, b, margin)
        lp.x = x
        lp.y = y
        safeUpdate(v, lp)
        panel?.let { p ->
            panelLp?.width = panelWidth()
            last?.let { renderPanel(p, it) }
        }
        v.post { publishWindows() }
    }

    // ---- collapsed button ----------------------------------------------------------------------------------------

    private fun addButton(): Boolean {
        val b = bounds()
        val lp = baseParams(buttonSize, buttonSize)
        val (x, y) = BoundedPlacement.place(dock, buttonSize, b, margin)
        lp.x = x
        lp.y = y
        pendingButtonLp = lp
        val v = buttonWin.ensure {
            FloatingButtonView(service).also { view ->
                view.setOnTouchListener { _, e -> onButtonTouch(view, lp, e) }
                // Also reached by TalkBack's double-tap, which does not produce raw touches.
                view.setOnClickListener { if (panel == null) expand() else collapse() }
            }
        } ?: return false
        buttonLp = lp
        lastBounds = b
        v.post { publishWindows() }
        return true
    }

    private fun onButtonTouch(v: View, lp: WindowManager.LayoutParams, e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                snapAnim?.cancel()
                drag.down(e.rawX, e.rawY, lp.x, lp.y)
                dragging = false
            }
            MotionEvent.ACTION_MOVE -> drag.move(e.rawX, e.rawY, buttonSize, bounds())?.let { step ->
                if (step.started) {
                    dragging = true
                    collapse()
                    publishWindows()
                }
                moveTo(v, lp, step.x, step.y)
            }
            MotionEvent.ACTION_UP -> when (drag.up()) {
                DragTracker.End.DRAG -> settle(v, lp)
                DragTracker.End.TAP -> v.performClick()
                DragTracker.End.NONE -> {}
            }
            MotionEvent.ACTION_CANCEL -> if (drag.cancel() == DragTracker.End.DRAG) settle(v, lp) else {
                dragging = false
                publishWindows()
            }
        }
        return true
    }

    /** Moves the window, at most once per display frame however fast the touch events arrive. */
    private fun moveTo(v: View, lp: WindowManager.LayoutParams, x: Int, y: Int) {
        lp.x = x
        lp.y = y
        if (framePending) return
        framePending = true
        Choreographer.getInstance().postFrameCallback {
            framePending = false
            if (button === v) safeUpdate(v, lp)
        }
    }

    /** The drag ended: snap to the nearer side, remember it. */
    private fun settle(v: View, lp: WindowManager.LayoutParams) {
        val b = bounds()
        dock = BoundedPlacement.snap(lp.x, lp.y, buttonSize, b, margin)
        store.save(dock)
        animateTo(v, lp, BoundedPlacement.place(dock, buttonSize, b, margin))
    }

    private fun animateTo(v: View, lp: WindowManager.LayoutParams, target: Pair<Int, Int>) {
        snapAnim?.cancel()
        val fromX = lp.x
        val fromY = lp.y
        snapAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 180
            interpolator = DecelerateInterpolator()
            addUpdateListener { a ->
                val f = a.animatedValue as Float
                lp.x = (fromX + (target.first - fromX) * f).toInt()
                lp.y = (fromY + (target.second - fromY) * f).toInt()
                if (button === v) safeUpdate(v, lp)
            }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                private var cancelled = false
                override fun onAnimationCancel(animation: android.animation.Animator) {
                    cancelled = true
                }

                override fun onAnimationEnd(animation: android.animation.Animator) {
                    // Cancelled by a new touch or a rotation: that code decides what happens next.
                    if (cancelled) return
                    // The button has settled: pictures may be used again, with its final position left out.
                    dragging = false
                    if (button === v) v.post { publishWindows() }
                }
            })
            start()
        }
    }

    // ---- expanded panel ------------------------------------------------------------------------------------------

    private fun expand() {
        val ui = last ?: return
        if (panel != null) return
        val lp = baseParams(panelWidth(), WindowManager.LayoutParams.WRAP_CONTENT)
        pendingPanelLp = lp
        val views = panelWin.ensure { buildPanel() } ?: return
        panelLp = lp
        guard.panelOpened(SystemClock.uptimeMillis())
        renderPanel(views, ui)
        publishWindows()
    }

    private fun collapse() {
        if (panel == null) return
        panelWin.remove()
        panelLp = null
        publishWindows()
    }

    private class PanelViews(
        val root: LinearLayout,
        val dot: View,
        val state: TextView,
        val linkDot: View,
        val link: TextView,
        val rec: TextView,
        val status: TextView,
        val calBlock: LinearLayout,
        val calStage: TextView,
        val calBar: ProgressBarView,
        val calDetail: TextView,
        val calBlocker: TextView,
        val start: TextView,
        val pause: TextView,
        val resume: TextView,
        val end: TextView,
        val calibrate: TextView,
        val cancelCal: TextView,
        val review: TextView,
        val emergency: TextView,
    ) {
        /** What this panel last showed: an identical state is not drawn again (no needless invalidation). */
        var rendered: OverlayUi? = null
    }

    private fun rounded(fill: Int, stroke: Int = 0, radiusDp: Float = 12f) = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = radiusDp * dp
        setColor(fill)
        if (stroke != 0) setStroke(maxOf(1, px(1f)), stroke)
    }

    private fun text(sizeSp: Float, color: Int, bold: Boolean = false, lines: Int = 1) = TextView(service).apply {
        textSize = sizeSp
        setTextColor(color)
        if (bold) setTypeface(typeface, Typeface.BOLD)
        maxLines = lines
        ellipsize = android.text.TextUtils.TruncateAt.END
    }

    /** Panel buttons ignore presses right after opening and never fire from a drag. */
    private fun action(label: String, fill: Int, textColor: Int, stroke: Int = 0, heightDp: Float = 44f, onClick: () -> Unit) =
        text(13f, textColor, bold = true).apply {
            this.text = label
            gravity = Gravity.CENTER
            minHeight = px(heightDp)
            setPadding(px(10f), px(6f), px(10f), px(6f))
            background = rounded(fill, stroke, 12f)
            contentDescription = label
            setOnClickListener { if (guard.accepts(SystemClock.uptimeMillis())) onClick() }
        }

    private fun lp(weight: Float = 0f, top: Float = 0f) =
        LinearLayout.LayoutParams(if (weight > 0f) 0 else ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, weight).apply {
            topMargin = px(top)
            if (weight > 0f) marginEnd = px(6f)
        }

    private fun buildPanel(): PanelViews {
        val dot = View(service).apply { background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Brand.TEXT_MUTED) } }
        val state = text(15f, Brand.TEXT_PRIMARY, bold = true)
        val rec = text(11f, Brand.DANGER, bold = true).apply { this.text = "● REC"; visibility = View.GONE }
        val close = text(18f, Brand.TEXT_SECONDARY).apply {
            this.text = "✕"
            gravity = Gravity.CENTER
            minWidth = px(44f)
            minHeight = px(44f)
            contentDescription = "Collapse the controls"
            setOnClickListener { collapse() }
        }
        val header = LinearLayout(service).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(dot, LinearLayout.LayoutParams(px(10f), px(10f)).apply { marginEnd = px(8f) })
            addView(state, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(rec, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = px(4f) })
            addView(close)
        }
        val status = text(13f, Brand.TEXT_SECONDARY, lines = 3)
        val linkDot = View(service).apply { background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Brand.TEXT_MUTED) } }
        val linkText = text(12f, Brand.TEXT_SECONDARY)
        val linkRow = LinearLayout(service).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(linkDot, LinearLayout.LayoutParams(px(8f), px(8f)).apply { marginEnd = px(6f) })
            addView(linkText)
        }

        val calStage = text(12f, Brand.ACCENT, bold = true)
        val calBar = ProgressBarView(service)
        val calDetail = text(12f, Brand.TEXT_SECONDARY, lines = 2)
        val calBlocker = text(12f, Brand.WARNING, lines = 3)
        val calBlock = LinearLayout(service).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Brand.RAISED, 0, 10f)
            setPadding(px(10f), px(8f), px(10f), px(8f))
            addView(calStage)
            addView(calBar, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, px(6f)).apply { topMargin = px(6f) })
            addView(calDetail, lp(top = 6f))
            addView(calBlocker, lp(top = 4f))
        }

        val start = action("Start Auto Drive", Brand.PRIMARY, Brand.ON_PRIMARY) { actions.onStartDrive() }
        val pause = action("Pause", Color.TRANSPARENT, Brand.WARNING, Brand.WARNING) { actions.onPause() }
        val resume = action("Resume", Brand.PRIMARY, Brand.ON_PRIMARY) { actions.onResume() }
        val end = action("End drive", Brand.RAISED, Brand.TEXT_PRIMARY, Brand.BORDER) { actions.onEnd() }
        val calibrate = action(OverlayUi.AUTO_CALIBRATE, Color.TRANSPARENT, Brand.ACCENT, Brand.ACCENT) { actions.onStartCalibration() }
        val cancelCal = action("Stop collecting", Color.TRANSPARENT, Brand.TEXT_PRIMARY, Brand.BORDER) { actions.onCancelCalibration() }
        val review = action("Review in HaulPilot", Brand.PRIMARY, Brand.ON_PRIMARY) { actions.onOpenReview() }
        val hide = text(12f, Brand.TEXT_MUTED).apply {
            this.text = "Hide button"
            gravity = Gravity.CENTER
            minHeight = px(40f)
            contentDescription = "Hide the floating button until the next drive"
            setOnClickListener { if (guard.accepts(SystemClock.uptimeMillis())) actions.onHide() }
        }
        val emergency = action("EMERGENCY STOP", Brand.DANGER_FILL, Color.WHITE, heightDp = 48f) { actions.onEmergency() }.apply {
            contentDescription = "Emergency stop: releases all automated inputs now"
        }
        val driveRow = LinearLayout(service).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(pause, lp(weight = 1f))
            addView(resume, lp(weight = 1f))
            addView(end, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        val root = LinearLayout(service).apply {
            orientation = LinearLayout.VERTICAL
            // Opaque enough to read over bright scenery, with a thin border for dark scenes.
            background = rounded(Color.argb(246, Color.red(Brand.SURFACE), Color.green(Brand.SURFACE), Color.blue(Brand.SURFACE)), Brand.BORDER, 16f)
            setPadding(px(12f), px(4f), px(12f), px(10f))
            addView(header)
            addView(linkRow, lp())
            addView(status, lp(top = 4f))
            addView(calBlock, lp(top = 8f))
            addView(start, lp(top = 10f))
            addView(driveRow, lp(top = 8f))
            addView(review, lp(top = 8f))
            addView(calibrate, lp(top = 8f))
            addView(cancelCal, lp(top = 8f))
            // A clear gap separates Emergency Stop from everything else.
            addView(emergency, lp(top = 16f))
            addView(hide, lp(top = 4f))
        }
        return PanelViews(root, dot, state, linkDot, linkText, rec, status, calBlock, calStage, calBar, calDetail, calBlocker, start, pause, resume, end, calibrate, cancelCal, review, emergency)
    }

    private fun renderPanel(p: PanelViews, ui: OverlayUi) {
        if (p.rendered == ui) {
            placePanel(p)
            return
        }
        p.rendered = ui
        (p.dot.background as? GradientDrawable)?.setColor(toneColor(ui.tone))
        setText(p.state, ui.state.label)
        val label = ui.linkLabel
        (p.link.parent as? View)?.visibility = vis(label != null)
        if (label != null) setText(p.link, label)
        (p.linkDot.background as? GradientDrawable)?.setColor(if (ui.linkOk) Brand.SUCCESS else if (label == "Capture failed") Brand.DANGER else Brand.WARNING)
        setText(p.status, ui.status)
        p.rec.visibility = if (ui.recording) View.VISIBLE else View.GONE
        val c = ui.calibration
        if (c == null) {
            p.calBlock.visibility = View.GONE
        } else {
            p.calBlock.visibility = View.VISIBLE
            setText(p.calStage, "${c.stageTitle} · ${c.percent}%")
            p.calBar.setProgress(c.percent / 100f)
            p.calDetail.visibility = if (c.blocker == null) View.VISIBLE else View.GONE
            // Pictures are not used while this panel covers the game; say so instead of letting the count stall unexplained.
            setText(p.calDetail, if (ui.ring != null) "${c.stageDetail} Collection pauses while this panel is open." else c.stageDetail)
            val blocker = c.blocker
            p.calBlocker.visibility = if (blocker == null) View.GONE else View.VISIBLE
            if (blocker != null) setText(p.calBlocker, blocker)
        }
        p.start.visibility = vis(ui.canStartDrive)
        p.pause.visibility = vis(ui.canPause)
        p.resume.visibility = vis(ui.canResume)
        p.end.visibility = vis(ui.canEnd)
        setText(p.end, ui.endLabel)
        (p.end.parent as? View)?.visibility = vis(ui.canPause || ui.canResume || ui.canEnd)
        p.calibrate.visibility = vis(ui.canStartCalibration)
        setText(p.calibrate, ui.calibrateLabel)
        p.calibrate.contentDescription = ui.calibrateLabel
        p.cancelCal.visibility = vis(ui.canCancelCalibration)
        setText(p.cancelCal, ui.cancelLabel)
        p.cancelCal.contentDescription = ui.cancelLabel
        p.review.visibility = vis(ui.canOpenReview)
        p.emergency.visibility = vis(ui.canEmergency)
        placePanel(p)
    }

    private fun placePanel(p: PanelViews) {
        val lp = panelLp ?: return
        val blp = buttonLp ?: return
        val b = bounds()
        val w = lp.width
        p.root.measure(
            View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(b.height, View.MeasureSpec.AT_MOST),
        )
        val (x, y) = BoundedPlacement.panelAnchor(blp.x, blp.y, buttonSize, w, p.root.measuredHeight, b, px(8f))
        if (lp.x != x || lp.y != y) {
            lp.x = x
            lp.y = y
            safeUpdate(p.root, lp)
            p.root.post { publishWindows() }
        }
    }

    private fun vis(b: Boolean) = if (b) View.VISIBLE else View.GONE

    private fun setText(v: TextView, s: String) {
        if (v.text?.toString() != s) v.text = s
    }

    private fun safeUpdate(v: View, lp: WindowManager.LayoutParams) {
        try {
            wm.updateViewLayout(v, lp)
        } catch (_: Exception) {
        }
    }

    private fun safeRemove(v: View) {
        try {
            wm.removeView(v)
        } catch (_: Exception) {
        }
    }
}

/** The collapsed button: graphite disc, road-and-chevron mark, state dot, optional progress ring. */
class FloatingButtonView(context: Context) : View(context) {
    private val d = context.resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Brand.SURFACE }
    private val rim = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.5f * d; color = Brand.BORDER }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 3f * d; strokeCap = Paint.Cap.ROUND; color = Brand.ACCENT }
    private val mark = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2.6f * d; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND; color = Brand.TEXT_PRIMARY }
    private val chevron = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 3f * d; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND; color = Brand.PRIMARY }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val halo = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val arc = RectF()
    private var tone = OverlayTone.NEUTRAL
    private var progress: Float? = null
    private var attention = false

    init {
        contentDescription = "HaulPilot controls"
        isClickable = true
    }

    fun update(ui: OverlayUi) {
        val changed = ui.tone != tone || ui.ring != progress || ui.attention != attention
        tone = ui.tone
        progress = ui.ring
        attention = ui.attention
        contentDescription = "HaulPilot: ${ui.state.label}. Tap to open the controls."
        if (changed) invalidate()
    }

    override fun performClick(): Boolean = super.performClick()

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val cy = h / 2f
        val r = minOf(w, h) / 2f - 2f * d
        c.drawCircle(cx, cy, r, fill)
        c.drawCircle(cx, cy, r, rim)
        progress?.let { p ->
            arc.set(cx - r + 2f * d, cy - r + 2f * d, cx + r - 2f * d, cy + r - 2f * d)
            c.drawArc(arc, -90f, 360f * p.coerceIn(0.02f, 1f), false, ring)
        }
        // Road: two edges converging towards the horizon, with the orange "go" chevron between them.
        val s = r * 0.5f
        path.reset()
        path.moveTo(cx - s, cy + s * 0.9f); path.lineTo(cx - s * 0.28f, cy - s * 0.9f)
        path.moveTo(cx + s, cy + s * 0.9f); path.lineTo(cx + s * 0.28f, cy - s * 0.9f)
        c.drawPath(path, mark)
        path.reset()
        path.moveTo(cx - s * 0.42f, cy + s * 0.35f); path.lineTo(cx, cy - s * 0.15f); path.lineTo(cx + s * 0.42f, cy + s * 0.35f)
        c.drawPath(path, chevron)
        // State dot, top right; a halo when help is needed.
        val dotR = 5f * d
        val dx = cx + r * 0.66f
        val dy = cy - r * 0.66f
        val col = toneColor(tone)
        if (attention) {
            halo.color = Color.argb(90, Color.red(col), Color.green(col), Color.blue(col))
            c.drawCircle(dx, dy, dotR * 2f, halo)
        }
        dotPaint.color = Brand.SURFACE
        c.drawCircle(dx, dy, dotR + 1.5f * d, dotPaint)
        dotPaint.color = col
        c.drawCircle(dx, dy, dotR, dotPaint)
    }
}

/** Thin rounded progress bar for the panel. */
class ProgressBarView(context: Context) : View(context) {
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Brand.BORDER }
    private val bar = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Brand.ACCENT }
    private val rect = RectF()
    private var value = 0f

    fun setProgress(v: Float) {
        val n = v.coerceIn(0f, 1f)
        if (n != value) {
            value = n
            invalidate()
        }
    }

    override fun onDraw(c: Canvas) {
        val h = height.toFloat()
        rect.set(0f, 0f, width.toFloat(), h)
        c.drawRoundRect(rect, h / 2, h / 2, track)
        if (value > 0f) {
            rect.set(0f, 0f, width * value, h)
            c.drawRoundRect(rect, h / 2, h / 2, bar)
        }
    }
}
