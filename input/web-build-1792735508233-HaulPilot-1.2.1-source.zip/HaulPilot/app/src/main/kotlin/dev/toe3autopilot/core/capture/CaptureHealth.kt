package dev.toe3autopilot.core.capture

import dev.toe3autopilot.core.Clock
import dev.toe3autopilot.core.vision.Frame
import kotlin.math.max
import kotlin.math.sqrt

/**
 * What a single captured picture looks like, judged from a coarse sample grid. This is *evidence about the picture*,
 * not a verdict about why it looks that way: a black picture can be protected content, a loading screen, a display
 * that is off, or a broken capture pipeline. [CaptureHealthMonitor] combines this with context to explain which.
 */
enum class FrameClass(val label: String) {
    /** Ordinary picture with visible detail. */
    OK("Normal picture"),

    /** Dark but textured (night driving, tunnel): NOT a sign of blocked capture. */
    DARK_SCENE("Dark scene"),

    /** Essentially every sampled pixel is black. */
    ALL_BLACK("All black"),

    /** One flat non-black colour everywhere. */
    SOLID_COLOUR("One flat colour"),

    /** A large exactly-black area with detail elsewhere: the pattern a protected window leaves, but also a loading screen or letterbox. */
    PARTLY_BLACK("Large black area"),
}

data class FrameStats(
    val meanLuma: Float,
    val lumaStdDev: Float,
    /** Fraction of samples that are black (all channels <= [BLACK_LEVEL]). */
    val blackFraction: Float,
    /** Fraction of 8x8 blocks that contain visible detail. */
    val texturedBlockFraction: Float,
) {
    fun classify(): FrameClass = when {
        blackFraction >= 0.995f -> FrameClass.ALL_BLACK
        lumaStdDev < 2.0f -> FrameClass.SOLID_COLOUR
        blackFraction >= PARTLY_BLACK_FRACTION -> FrameClass.PARTLY_BLACK
        meanLuma < 40f && texturedBlockFraction >= 0.08f -> FrameClass.DARK_SCENE
        else -> FrameClass.OK
    }

    companion object {
        /** Compressed pictures and dithering put noise on black; real "protected" black is exactly 0. A few levels of slack are enough. */
        const val BLACK_LEVEL = 3
        const val PARTLY_BLACK_FRACTION = 0.6f
        private const val GRID_W = 64
        private const val GRID_H = 36
        private const val BLOCKS = 8

        /**
         * Each channel is tested on its own. (An earlier check compared the packed ARGB integer with 0x050505 and therefore
         * called any pixel with a tiny red channel "black", whatever its green and blue values.)
         */
        fun of(f: Frame): FrameStats {
            val gw = minOf(GRID_W, f.width)
            val gh = minOf(GRID_H, f.height)
            var n = 0
            var sum = 0.0
            var sumSq = 0.0
            var black = 0
            val bMin = IntArray(BLOCKS * BLOCKS) { 255 }
            val bMax = IntArray(BLOCKS * BLOCKS) { 0 }
            for (j in 0 until gh) {
                val y = ((j + 0.5f) * f.height / gh).toInt().coerceIn(0, f.height - 1)
                for (i in 0 until gw) {
                    val x = ((i + 0.5f) * f.width / gw).toInt().coerceIn(0, f.width - 1)
                    val p = f.argb[y * f.width + x]
                    val r = (p shr 16) and 0xFF
                    val g = (p shr 8) and 0xFF
                    val b = p and 0xFF
                    val luma = (77 * r + 150 * g + 29 * b) shr 8
                    n++
                    sum += luma
                    sumSq += luma.toDouble() * luma
                    if (max(r, max(g, b)) <= BLACK_LEVEL) black++
                    val bi = (j * BLOCKS / gh) * BLOCKS + (i * BLOCKS / gw)
                    if (luma < bMin[bi]) bMin[bi] = luma
                    if (luma > bMax[bi]) bMax[bi] = luma
                }
            }
            val mean = sum / n
            val variance = max(0.0, sumSq / n - mean * mean)
            var textured = 0
            for (k in bMin.indices) if (bMax[k] >= bMin[k] && bMax[k] - bMin[k] >= 12) textured++
            return FrameStats(mean.toFloat(), sqrt(variance).toFloat(), black.toFloat() / n, textured.toFloat() / bMin.size)
        }
    }
}

/** Failures reported by the Android capture layer itself (not inferred from pictures). */
enum class CaptureFault(val title: String, val detail: String, val offersVideo: Boolean = true) {
    PERMISSION_DENIED(
        "Screen-capture permission was not granted",
        "The Android screen-sharing dialog was cancelled or declined. Press the button again and choose \"Entire screen\" (or \"Start now\").",
        offersVideo = false,
    ),
    TOKEN_INVALID(
        "Android rejected the screen-capture permission",
        "The permission result could not be used (it may have expired or already been used once). Start capture again; Android needs a fresh consent every time.",
    ),
    PROJECTION_STOPPED(
        "Android stopped the screen capture",
        "The system ended the screen sharing (the \"stop sharing\" control, a screen lock, another app starting a capture, or the system reclaiming the service). Start capture again.",
    ),
    SERVICE_START_REJECTED(
        "Android would not start the capture service",
        "The foreground service could not start (missing notification or foreground-service permission, or background-start limits). Open the app and try again.",
    ),
    VIRTUAL_DISPLAY_FAILED(
        "The virtual display for capture could not be created",
        "Android refused to create the capture display. On Android 14+ each permission grant can create one display only; start capture again.",
    ),
    IMAGE_READER_FAILED(
        "The picture receiver failed",
        "Creating or reading the image buffer failed (low memory or an unsupported size). Start capture again; if it repeats, restart the phone.",
    ),
    CONVERSION_FAILED(
        "A captured picture could not be converted",
        "A frame arrived but could not be read. This is a software fault, not game protection.",
    ),
    RECONFIGURE_FAILED(
        "Capture could not follow the screen rotation",
        "The capture display could not be resized after the screen changed orientation. Start capture again.",
    ),
}

enum class DiagnosisKind {
    NOT_CONNECTED,
    FAULT,
    WAITING_FOR_FRAMES,
    NO_FRAMES,
    HEALTHY,
    DARK_BUT_FINE,

    /** Pictures of this app arrive black too: the capture pipeline or display is at fault, not the game. */
    PIPELINE_BLACK,

    /** This app's own screen is captured normally but the game arrives black or mostly black for a while. */
    GAME_BLACK_SUSPECTED_PROTECTION,
    GAME_PARTLY_BLACK_SUSPECTED_PROTECTION,

    /** The game is black but this app's own screen has not been seen yet, so the cause cannot be told apart. */
    GAME_BLACK_UNDETERMINED,
}

data class CaptureDiagnosis(
    val kind: DiagnosisKind,
    val title: String,
    val detail: String,
    /** True when live capture cannot be relied on and importing a recorded gameplay clip is the sensible alternative. */
    val offerVideoCalibration: Boolean,
    /** True for a problem the person can only fix by retrying; false for informational states. */
    val isProblem: Boolean,
    /** The Android-level fault behind a FAULT diagnosis (for example the permission being declined). */
    val fault: CaptureFault? = null,
) {
    val healthy: Boolean get() = kind == DiagnosisKind.HEALTHY || kind == DiagnosisKind.DARK_BUT_FINE
}

/** Where the picture came from, supplied by the host for each frame. */
data class FrameContext(
    /** This app's own screen is in front. */
    val ownAppInFront: Boolean,
    /** true = the game is in front, false = something else, null = cannot tell (no accessibility service). */
    val gameInFront: Boolean?,
)

/**
 * Explains *why* capture is or is not usable, using three kinds of evidence and never guessing beyond them:
 *  1. faults reported by the Android layer (permission, projection stopped, display or image-reader errors);
 *  2. counts and times of frames received;
 *  3. the look of frames, split by what was in front: this app's own screen (a control sample that is known to have
 *     content) versus the game.
 *
 * It does not and cannot prove that the game blocks capture. It can only say "this app's screen arrives fine while the
 * game's does not". It never suggests getting around protected content.
 */
class CaptureHealthMonitor(
    private val clock: Clock,
    private val noFrameAfterMs: Long = NO_FRAMES_MS,
    private val blackConfirmMs: Long = GAME_BLACK_MS,
) {
    private val lock = Any()
    private var startedAt: Long? = null
    private var fault: CaptureFault? = null
    private var faultNote: String? = null
    private var frames = 0
    private var lastFrameAt = 0L
    private var lastClass: FrameClass? = null
    private var ownGoodFrames = 0
    private var ownBlackFrames = 0
    private var gameBlackSince: Long? = null
    private var gameLastBlackClass: FrameClass? = null
    private var gameGoodFrames = 0
    private val history = ArrayDeque<String>()

    /** Short lines for the diagnostic log (kept small; no pictures). */
    fun history(): List<String> = synchronized(lock) { history.toList() }

    fun onCaptureStarted() = synchronized(lock) {
        startedAt = clock.nowMs()
        fault = null
        faultNote = null
        frames = 0
        lastClass = null
        ownGoodFrames = 0
        ownBlackFrames = 0
        gameBlackSince = null
        gameLastBlackClass = null
        gameGoodFrames = 0
        record("capture started")
    }

    fun onCaptureEnded() = synchronized(lock) {
        startedAt = null
        record("capture ended")
    }

    fun onFault(f: CaptureFault, note: String? = null) = synchronized(lock) {
        fault = f
        faultNote = note
        startedAt = null
        record("fault ${f.name}${note?.let { ": $it" } ?: ""}")
    }

    fun onFrame(frame: Frame, ctx: FrameContext) = synchronized(lock) {
        val now = clock.nowMs()
        frames++
        lastFrameAt = now
        val cls = FrameStats.of(frame).classify()
        if (cls != lastClass) record("frame ${cls.label} (own app ${ctx.ownAppInFront}, game ${ctx.gameInFront})")
        lastClass = cls
        val black = cls == FrameClass.ALL_BLACK || cls == FrameClass.PARTLY_BLACK
        val gameFrame = ctx.gameInFront == true && !ctx.ownAppInFront
        if (ctx.ownAppInFront) {
            if (black || cls == FrameClass.SOLID_COLOUR) ownBlackFrames++ else ownGoodFrames++
        }
        if (gameFrame) {
            if (black) {
                if (gameBlackSince == null) gameBlackSince = now
                gameLastBlackClass = cls
            } else {
                gameBlackSince = null
                gameGoodFrames++
            }
        } else if (!ctx.ownAppInFront && ctx.gameInFront == false) {
            gameBlackSince = null
        }
    }

    fun diagnose(): CaptureDiagnosis = synchronized(lock) {
        val now = clock.nowMs()
        fault?.let { f ->
            return CaptureDiagnosis(
                DiagnosisKind.FAULT, f.title, f.detail + (faultNote?.let { " ($it)" } ?: ""),
                offerVideoCalibration = f.offersVideo, isProblem = true, fault = f,
            )
        }
        val t0 = startedAt ?: return CaptureDiagnosis(
            DiagnosisKind.NOT_CONNECTED, "Screen capture is off",
            "Nothing is being captured. Start capture to calibrate or drive.", offerVideoCalibration = false, isProblem = false,
        )
        if (frames == 0) {
            return if (now - t0 < noFrameAfterMs) {
                CaptureDiagnosis(DiagnosisKind.WAITING_FOR_FRAMES, "Waiting for the first picture", "Capture started; no frame has arrived yet.", false, false)
            } else {
                CaptureDiagnosis(
                    DiagnosisKind.NO_FRAMES, "Capture is running but no pictures arrive",
                    "Android accepted the permission and created the display, but delivered no frames for ${(now - t0) / 1000} s. " +
                        "This is a capture-pipeline problem (not necessarily the game). Stop and start capture again.",
                    offerVideoCalibration = true, isProblem = true,
                )
            }
        }
        val blackFor = gameBlackSince?.let { now - it } ?: 0L
        if (gameBlackSince != null && blackFor >= blackConfirmMs) {
            val partly = gameLastBlackClass == FrameClass.PARTLY_BLACK
            return when {
                ownGoodFrames > 0 && partly -> CaptureDiagnosis(
                    DiagnosisKind.GAME_PARTLY_BLACK_SUSPECTED_PROTECTION, "Part of the game picture arrives black",
                    "This app's own screen is captured normally, but a large part of the game's picture has been exactly black for ${blackFor / 1000} s. " +
                        "That is what protected game content looks like, but a loading screen looks the same. Wait for the game to load; if it stays, " +
                        "this app cannot receive the game picture (it will not try to get around that). Use a recorded gameplay clip for calibration.",
                    offerVideoCalibration = true, isProblem = true,
                )
                ownGoodFrames > 0 -> CaptureDiagnosis(
                    DiagnosisKind.GAME_BLACK_SUSPECTED_PROTECTION, "The game picture arrives black",
                    "This app's own screen is captured normally, but the game has arrived completely black for ${blackFor / 1000} s. " +
                        "The game (or Android) may be withholding its picture from apps like this one, even though a different recorder may still work: " +
                        "other recorders use different mechanisms and are not guaranteed to receive the same frames. " +
                        "This app will not try to get around that. If it is only a loading screen, wait. Otherwise import a recorded gameplay clip for calibration.",
                    offerVideoCalibration = true, isProblem = true,
                )
                ownBlackFrames > 0 -> CaptureDiagnosis(
                    DiagnosisKind.PIPELINE_BLACK, "Captured pictures are black even for this app",
                    "Pictures of this app's own screen also arrive black, so the capture pipeline or the display is at fault, not the game. " +
                        "Stop and start capture again, and make sure the screen is on and unlocked.",
                    offerVideoCalibration = true, isProblem = true,
                )
                else -> CaptureDiagnosis(
                    DiagnosisKind.GAME_BLACK_UNDETERMINED, "The game picture is black, cause unknown",
                    "No picture of this app's own screen has been seen yet, so a protected game cannot be told apart from a broken capture. " +
                        "Switch to this app for a few seconds (so it can check its own screen arrives fine), then back to the game.",
                    offerVideoCalibration = true, isProblem = true,
                )
            }
        }
        if (ownBlackFrames >= 3 && ownGoodFrames == 0) {
            return CaptureDiagnosis(
                DiagnosisKind.PIPELINE_BLACK, "Captured pictures are black even for this app",
                "Pictures of this app's own screen also arrive black, so the capture pipeline or the display is at fault, not the game. Stop and start capture again.",
                offerVideoCalibration = true, isProblem = true,
            )
        }
        return if (lastClass == FrameClass.DARK_SCENE) {
            CaptureDiagnosis(DiagnosisKind.DARK_BUT_FINE, "Capture works (dark scene)", "Pictures arrive and show detail; the scene is simply dark.", false, false)
        } else {
            CaptureDiagnosis(DiagnosisKind.HEALTHY, "Capture works", "Pictures arrive normally ($frames so far).", false, false)
        }
    }

    private fun record(s: String) {
        history.addLast("${clock.nowMs()} $s")
        while (history.size > 40) history.removeFirst()
    }

    private companion object {
        const val NO_FRAMES_MS = 6_000L
        const val GAME_BLACK_MS = 10_000L
    }
}

/** Why a calibration analysis rejected pictures that did arrive. Separates this from a capture problem. */
enum class AnalyzerRejection(val title: String) {
    STATIC_SCENE("The picture barely changes"),
    TOO_FEW_FRAMES("Not enough pictures yet"),
    NO_ELEMENTS("No fixed buttons found"),
    SIZE_CHANGED("The screen size changed"),
    OTHER("The analysis could not use these pictures"),
}

object AnalyzerDiagnosis {
    fun classify(problem: String?): AnalyzerRejection? = when {
        problem == null -> null
        problem.contains("barely changes", ignoreCase = true) -> AnalyzerRejection.STATIC_SCENE
        problem.contains("Need at least", ignoreCase = true) -> AnalyzerRejection.TOO_FEW_FRAMES
        problem.contains("No persistent", ignoreCase = true) -> AnalyzerRejection.NO_ELEMENTS
        problem.contains("screen size", ignoreCase = true) -> AnalyzerRejection.SIZE_CHANGED
        else -> AnalyzerRejection.OTHER
    }

    /** Plain-language explanation that makes clear the pictures were received fine and what to do next. */
    fun explain(r: AnalyzerRejection): String = when (r) {
        AnalyzerRejection.STATIC_SCENE ->
            "Pictures are arriving, so capture is working. The analysis needs the scenery to move (drive, or turn the camera) so it can tell fixed buttons from the background."
        AnalyzerRejection.TOO_FEW_FRAMES -> "Pictures are arriving. Keep playing for a few more seconds; the analysis needs about 10 pictures."
        AnalyzerRejection.NO_ELEMENTS ->
            "Pictures are arriving and the scene changes, but no outlines stayed in place. The buttons may be translucent or hidden. Try again while driving, or place the controls by hand."
        AnalyzerRejection.SIZE_CHANGED -> "The picture size changed (rotation or another screen), so earlier analysis was discarded. Keep the phone in one orientation."
        AnalyzerRejection.OTHER -> "Pictures are arriving but could not be used. Try again, or place the controls by hand."
    }
}
