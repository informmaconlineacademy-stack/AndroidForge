package dev.toe3autopilot.core.setup

import dev.toe3autopilot.core.calibration.CalibRole
import dev.toe3autopilot.core.calibration.ControlDetection
import dev.toe3autopilot.core.calibration.DetectionStatus
import dev.toe3autopilot.core.calibration.TapSnap
import dev.toe3autopilot.core.profile.SteeringMode
import dev.toe3autopilot.core.vision.Roi

/** Where the one-action Auto-Calibrate flow is, derived from the setup state (the screen never keeps its own copy). */
enum class AutoStage {
    /** The screen is not connected: Auto-Calibrate cannot see the game. */
    CONNECT,

    /** Connected; nothing collected for Auto-Calibrate yet (or the last run was cancelled). */
    READY,

    /** Collecting pictures while the person drives. */
    COLLECTING,

    /** Collection finished; the analysis is about to start or running. */
    ANALYSING,

    /** Pictures are available (imported or kept) but have not been analysed. */
    ANALYSE_READY,

    /** The analysis ran: markers wait for the person's review (also after confirming, validating and saving). */
    REVIEW,

    /** Collection or analysis stopped with a problem; [SetupState.problem] says what and [SetupState.recovery] what to do. */
    FAILED,
}

/**
 * Pure helpers behind the Auto-Calibrate review: which controls to show, what is still missing, which marker a touch
 * grabs, and where a moved marker lands. Nothing here guesses a position: a control is either where the analysis found
 * it (a candidate), where the person put it, or missing.
 */
object AutoReview {
    fun stage(s: SetupState, captureOn: Boolean): AutoStage = when {
        s.phase == SetupPhase.CAPTURING -> AutoStage.COLLECTING
        s.phase == SetupPhase.ANALYZING || s.autoAnalyze -> AutoStage.ANALYSING
        s.phase == SetupPhase.FAILED && s.problem != null -> AutoStage.FAILED
        s.draft.analysed && s.selectedFrame != null -> AutoStage.REVIEW
        s.frames.isNotEmpty() && s.phase != SetupPhase.CANCELLED -> AutoStage.ANALYSE_READY
        !captureOn -> if (s.frames.isNotEmpty()) AutoStage.ANALYSE_READY else AutoStage.CONNECT
        else -> AutoStage.READY
    }

    /**
     * Steering style to review with: the person's choice, else what the analysis found (a button pair or a wheel, never
     * both), else null (the person is asked; nothing is assumed).
     */
    fun steering(d: SetupDraft): SteeringMode? {
        d.steering?.let { return it }
        val l = d.controls[CalibRole.STEER_LEFT]
        val r = d.controls[CalibRole.STEER_RIGHT]
        val w = d.controls[CalibRole.STEER_WHEEL]
        val buttons = listOfNotNull(l, r).any { it.status.positioned }
        val wheel = w?.status?.positioned == true
        return when {
            buttons && !wheel -> SteeringMode.BUTTONS
            wheel && !buttons -> SteeringMode.SLIDER
            else -> null
        }
    }

    /** Controls shown for [mode]; reverse is always last and optional. Without a steering style only the pedals. */
    fun roles(mode: SteeringMode?): List<CalibRole> = listOf(CalibRole.ACCELERATOR, CalibRole.BRAKE) + when (mode) {
        SteeringMode.BUTTONS -> listOf(CalibRole.STEER_LEFT, CalibRole.STEER_RIGHT)
        SteeringMode.SLIDER -> listOf(CalibRole.STEER_WHEEL)
        null -> emptyList()
    } + CalibRole.GEAR_REVERSE

    fun required(mode: SteeringMode?): List<CalibRole> = roles(mode).filter { it != CalibRole.GEAR_REVERSE }

    /**
     * Fixed elements the analysis measured ([outlines], from the pictures) that no control, the minimap or the screen marker
     * sits on. They are drawn faintly on the review picture so the person can see what was found but not assigned (for example
     * ONE pedal-shaped element when the pair could not be established) and tap one with a control selected. Nothing here is a
     * proposal: no role is attached to them.
     */
    fun unassigned(d: SetupDraft, outlines: List<Roi>, limit: Int = 24): List<Roi> {
        val taken = ArrayList<Roi>()
        d.controls.values.forEach { c -> if (c.status.positioned) c.box?.let { taken += it } }
        d.minimap.box?.let { taken += it }
        d.marker?.let { taken += it }
        fun share(a: Roi, b: Roi): Float {
            val w = minOf(a.right, b.right) - maxOf(a.left, b.left)
            val h = minOf(a.bottom, b.bottom) - maxOf(a.top, b.top)
            if (w <= 0f || h <= 0f) return 0f
            val smaller = minOf((a.right - a.left) * (a.bottom - a.top), (b.right - b.left) * (b.bottom - b.top))
            return w * h / smaller
        }
        return outlines
            .filter { o -> (o.right - o.left) <= 0.3f && (o.bottom - o.top) <= 0.6f && taken.none { share(o, it) > 0.4f } }
            .distinct()
            .take(limit)
    }

    /** True when the control has a position the person can see and judge (a candidate or a confirmed one). */
    fun positioned(d: SetupDraft, role: CalibRole): Boolean = d.controls[role]?.status?.positioned == true

    /** Required controls that have no position yet: the person taps them on the picture. */
    fun stillToPlace(d: SetupDraft, mode: SteeringMode?): List<CalibRole> = required(mode).filter { !positioned(d, it) }

    /** Candidates among [roles] that still wait for the person. */
    fun pending(d: SetupDraft, roles: List<CalibRole>): List<CalibRole> =
        roles.filter { d.controls[it]?.status == DetectionStatus.NEEDS_CONFIRMATION }

    /** The control to work on first: a missing required one, else a candidate, else the first. */
    fun firstUnresolved(d: SetupDraft, mode: SteeringMode?): CalibRole {
        val rs = roles(mode)
        return stillToPlace(d, mode).firstOrNull() ?: pending(d, rs).firstOrNull() ?: rs.first()
    }

    /** The next control after [after] that still needs the person (missing required, or a candidate); null when none. */
    fun nextUnresolved(d: SetupDraft, mode: SteeringMode?, after: CalibRole): CalibRole? {
        val rs = roles(mode)
        val need = rs.filter { r -> (r in required(mode) && !positioned(d, r)) || d.controls[r]?.status == DetectionStatus.NEEDS_CONFIRMATION }
        val i = rs.indexOf(after)
        return need.firstOrNull { rs.indexOf(it) > i } ?: need.firstOrNull { it != after }
    }

    /**
     * The marker a touch at ([x], [y]) grabs: the nearest positioned control among [roles] within [maxDx] / [maxDy]
     * (normalised; the caller converts its finger-sized radius), or null.
     */
    fun hit(d: SetupDraft, roles: List<CalibRole>, x: Float, y: Float, maxDx: Float, maxDy: Float): CalibRole? {
        var best: CalibRole? = null
        var bestD = Float.MAX_VALUE
        for (r in roles) {
            val c = d.controls[r] ?: continue
            if (!c.status.positioned) continue
            val dx = (c.x - x) / maxDx
            val dy = (c.y - y) / maxDy
            val dist = dx * dx + dy * dy
            if (dist <= 1f && dist < bestD) {
                bestD = dist
                best = r
            }
        }
        return best
    }

    /**
     * Region stored with a control the person moved to ([x], [y]): the control's own outline when the point is still
     * inside it (a small correction), else the outline under the point ([outlines], from the analysis), else a square.
     */
    fun regionFor(previous: ControlDetection?, outlines: List<Roi>, x: Float, y: Float, aspect: Float): Roi {
        val own = previous?.box?.takeIf { previous.status.positioned && x in it.left..it.right && y in it.top..it.bottom }
        return own ?: TapSnap.boxFor(outlines, x, y, aspect)
    }

    /** One short line for the selected control. */
    fun describe(c: ControlDetection?): String = when {
        c == null || c.status == DetectionStatus.NONE -> "Not found. Tap it on the picture."
        c.status == DetectionStatus.REJECTED -> "Rejected. Tap the right spot on the picture."
        c.status == DetectionStatus.NEEDS_CONFIRMATION -> "Found (${(c.confidence * 100).toInt()}% evidence). Drag the marker if it is off."
        else -> if (c.evidence.contains("placed by you")) "Placed by you." else "Confirmed."
    }

    private val DetectionStatus.positioned: Boolean
        get() = this == DetectionStatus.NEEDS_CONFIRMATION || usable
}
