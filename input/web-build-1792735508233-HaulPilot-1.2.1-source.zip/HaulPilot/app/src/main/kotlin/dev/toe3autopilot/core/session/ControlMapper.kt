package dev.toe3autopilot.core.session

import dev.toe3autopilot.core.Control
import dev.toe3autopilot.core.DriveCommand
import dev.toe3autopilot.core.Gear
import dev.toe3autopilot.core.Point
import dev.toe3autopilot.core.clampF
import dev.toe3autopilot.core.profile.GameProfile
import dev.toe3autopilot.core.profile.SteeringMode
import kotlin.math.abs

/**
 * @property holds  controls that should be physically held RIGHT NOW, with the exact point to hold at
 * @property taps   one-shot taps (gear changes)
 * @property error  set when a required control is not calibrated
 */
data class MappedOutput(val holds: Map<Control, Point>, val taps: List<Control>, val error: String? = null)

/**
 * Turns a continuous [DriveCommand] into discrete touch operations for the calibrated on-screen controls.
 *
 *  - Partial throttle / brake / steering is produced by duty-cycling a press over [pwmPeriodMs] (profile extra
 *    pwm.periodMs). That suits steady road driving; short manoeuvres use full-press bursts instead (see PulseDriver).
 *  - The throttle is never pressed together with a firm brake.
 *  - A gear change is only tapped when the truck is (visually) stopped; until then the truck is braked.
 */
class ControlMapper(
    private val profile: GameProfile,
    private val pwmPeriodMs: Long = profile.extraFloat("pwm.periodMs", 800f).toLong().coerceIn(200L, 3000L),
    /** Steering may change by at most this much per second (full lock = 1.0), whatever the agents ask for. */
    private val maxSteerRatePerSec: Float = 3.5f,
) {
    private var believedGear = Gear.FORWARD
    private val stoppedMotion = profile.extraFloat("motion.stopped", 0.004f)
    private var lastSteer = 0f
    private var lastSteerAt: Long? = null

    fun reset() {
        believedGear = Gear.FORWARD
        lastSteer = 0f
        lastSteerAt = null
    }

    private fun limitSteer(target: Float, now: Long): Float {
        val at = lastSteerAt
        lastSteerAt = now
        if (at == null) {
            lastSteer = target
            return target
        }
        val dt = clampF((now - at) / 1000f, 0.02f, 0.5f)
        val maxDelta = maxSteerRatePerSec * dt
        lastSteer += clampF(target - lastSteer, -maxDelta, maxDelta)
        return lastSteer
    }

    /** @param observedReverse true/false if the HUD shows the gear, null if unknown. */
    fun map(cmd: DriveCommand, now: Long, motion: Float, observedReverse: Boolean?): MappedOutput {
        if (observedReverse != null) believedGear = if (observedReverse) Gear.REVERSE else Gear.FORWARD
        var throttle = clampF(cmd.throttle, 0f, 1f)
        var brake = clampF(cmd.brake, 0f, 1f)
        val steer = limitSteer(clampF(cmd.steer, -1f, 1f), now)
        val taps = ArrayList<Control>()
        var error: String? = null

        if (cmd.gear != believedGear) {
            throttle = 0f
            if (motion > stoppedMotion) {
                brake = 1f // stop first, tap the gear selector once stationary
            } else {
                val c = if (cmd.gear == Gear.REVERSE) Control.GEAR_REVERSE else Control.GEAR_DRIVE
                if (profile.control(c) == null) {
                    error = "Control ${c.name} is not calibrated"
                } else {
                    taps += c
                    believedGear = cmd.gear
                }
            }
        }
        if (brake > 0.5f) throttle = 0f

        val holds = LinkedHashMap<Control, Point>()
        if (pwm(throttle, now)) put(holds, Control.ACCELERATOR)?.let { error = it }
        if (pwm(brake, now)) put(holds, Control.BRAKE)?.let { error = it }

        when (profile.steeringMode) {
            SteeringMode.SLIDER -> {
                val centre = profile.control(Control.STEER_CENTER)
                if (centre == null) error = "Control STEER_CENTER is not calibrated"
                else holds[Control.STEER_CENTER] = Point(
                    clampF(centre.x + steer * profile.steerRadius, 0f, 1f),
                    centre.y,
                )
            }
            SteeringMode.BUTTONS -> {
                if (abs(steer) > STEER_DEADBAND && pwm(abs(steer), now)) {
                    val c = if (steer < 0) Control.STEER_LEFT else Control.STEER_RIGHT
                    put(holds, c)?.let { error = it }
                }
            }
        }
        return MappedOutput(holds, taps, error)
    }

    private fun put(holds: MutableMap<Control, Point>, c: Control): String? {
        val p = profile.control(c) ?: return "Control ${c.name} is not calibrated"
        holds[c] = p
        return null
    }

    private fun pwm(duty: Float, now: Long): Boolean {
        if (duty >= 0.97f) return true
        if (duty <= 0.03f) return false
        return (now % pwmPeriodMs).toFloat() < duty * pwmPeriodMs
    }

    companion object {
        const val STEER_DEADBAND = 0.08f
    }
}
