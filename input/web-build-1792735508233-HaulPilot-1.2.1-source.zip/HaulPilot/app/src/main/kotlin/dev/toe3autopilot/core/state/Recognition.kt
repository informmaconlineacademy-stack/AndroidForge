package dev.toe3autopilot.core.state

import dev.toe3autopilot.core.calibration.LayoutCheck
import dev.toe3autopilot.core.profile.GameProfile
import dev.toe3autopilot.core.vision.Frame
import dev.toe3autopilot.core.vision.Roi
import dev.toe3autopilot.core.vision.TemplateProvider
import kotlin.math.roundToInt

/**
 * Is this picture a usable picture of a game at all? Separates a capture that really shows nothing (all black: protected
 * content, a dead pipeline; one flat colour) from a valid game picture that is merely DARK (night, tunnel), which must still be
 * looked at: a dark driving picture with its HUD is a good picture.
 *
 * Grey levels are taken from a sampled grid; "black" is every colour channel <= [BLACK_LEVEL] (compression noise on a black
 * picture stays a few levels at most), "flat" is a spread (1st to 99th percentile) of at most [FLAT_SPREAD] grey levels. A
 * dark world with a HUD on it has a spread well above that even when the HUD is faint, because the HUD pixels are a few percent
 * of the picture and the percentiles ignore the rest.
 */
enum class FrameValidity(val label: String, val usable: Boolean) {
    VALID("Normal picture", true),

    /** Dark but with structure (night driving, a tunnel): a valid game picture. */
    VALID_DARK("Dark picture with detail (night or tunnel)", true),

    /** A large exactly-black area with detail elsewhere (letterbox, loading screen or protected window): used, but flagged. */
    VALID_PARTLY_BLACK("Picture with a large black area", true),

    /** Essentially every sample is black: nothing of the game arrived. */
    BLACK("All black", false),

    /** One flat colour everywhere. */
    FLAT("One flat colour", false);
}

object FrameChecks {
    const val BLACK_LEVEL = 3
    const val FLAT_SPREAD = 6
    private const val GW = 96
    private const val GH = 54

    fun assess(f: Frame): FrameValidity {
        val gw = minOf(GW, f.width)
        val gh = minOf(GH, f.height)
        val hist = IntArray(256)
        var n = 0
        var black = 0
        var sum = 0L
        for (j in 0 until gh) {
            val y = ((j + 0.5f) * f.height / gh).toInt().coerceIn(0, f.height - 1)
            for (i in 0 until gw) {
                val x = ((i + 0.5f) * f.width / gw).toInt().coerceIn(0, f.width - 1)
                val p = f.argb[y * f.width + x]
                val r = (p shr 16) and 0xFF
                val g = (p shr 8) and 0xFF
                val b = p and 0xFF
                val l = (77 * r + 150 * g + 29 * b) shr 8
                hist[l]++
                sum += l
                n++
                if (maxOf(r, g, b) <= BLACK_LEVEL) black++
            }
        }
        if (n == 0) return FrameValidity.BLACK
        val blackFraction = black.toFloat() / n
        if (blackFraction >= 0.995f) return FrameValidity.BLACK
        val p1 = percentile(hist, n, 0.01f)
        val p99 = percentile(hist, n, 0.99f)
        if (p99 - p1 <= FLAT_SPREAD) return FrameValidity.FLAT
        if (blackFraction >= 0.6f) return FrameValidity.VALID_PARTLY_BLACK
        return if (sum.toFloat() / n < 40f) FrameValidity.VALID_DARK else FrameValidity.VALID
    }

    private fun percentile(hist: IntArray, n: Int, q: Float): Int {
        val target = (n * q).toInt()
        var acc = 0
        for (v in hist.indices) {
            acc += hist[v]
            if (acc > target) return v
        }
        return 255
    }
}

/** How well one rule item (a template that must be present, or absent when [negated]) matched on the newest picture. */
data class RuleScore(
    val template: String,
    val negated: Boolean,
    /** Best match score found anywhere in its search area, whatever the threshold; null when the template picture is missing. */
    val best: Float?,
    val needed: Float,
    val roi: Roi?,
    /** Matched over the steady pixels only (see TemplateMatcher.allMasked). */
    val masked: Boolean,
) {
    val ok: Boolean get() = if (negated) best == null || best < needed else best != null && best >= needed
}

/**
 * Why the driving screen was not recognised, from the pictures that actually arrived. Shown when the recognition timeout runs
 * out, together with the last picture, so the person sees what HaulPilot saw instead of a bare message.
 */
data class RecognitionReport(
    /** The newest picture that was looked at (null when none arrived). */
    val frame: Frame?,
    val validity: FrameValidity?,
    val candidate: GameState,
    val confidence: Float,
    val items: List<RuleScore>,
    /** Of the last [seen] usable pictures, in how many the driving screen was recognised. */
    val hits: Int,
    val seen: Int,
    /** Pictures that were unusable (black / flat) while waiting. */
    val unusable: Int,
    val gameInFront: Boolean?,
    /** One sentence: the most likely reason. */
    val reason: String,
    /** What to do, in order. */
    val advice: List<String>,
    val atMs: Long,
) {
    /** Plain lines under the reason: what each check saw. */
    fun evidenceLines(): List<String> {
        val out = ArrayList<String>()
        validity?.let { out += "Newest picture: ${it.label}." }
        for (i in items) {
            val b = i.best?.let { "${(it * 100).roundToInt()} %" } ?: "template missing"
            out += if (i.negated) "\"${i.template}\" must be absent: best match $b (${if (i.ok) "absent, fine" else "present"})."
            else "\"${i.template}\": best match $b, needs ${(i.needed * 100).roundToInt()} %${if (i.masked) " (steady pixels only)" else ""}."
        }
        if (seen > 0) out += "Recognised in $hits of the last $seen usable picture(s)."
        if (unusable > 0) out += "$unusable picture(s) were black or one flat colour and were not used."
        return out
    }
}

object RecognitionDiagnosis {
    /**
     * @param frames the newest pictures looked at, oldest first (may be empty)
     * @param hits / seen / unusable running counts kept by the session while it waited
     */
    fun explain(
        profile: GameProfile,
        templates: TemplateProvider,
        frames: List<Frame>,
        candidate: GameState,
        confidence: Float,
        hits: Int,
        seen: Int,
        unusable: Int,
        gameInFront: Boolean?,
        minConfidence: Float,
        nowMs: Long,
    ): RecognitionReport {
        val last = frames.lastOrNull()
        val validity = last?.let { FrameChecks.assess(it) }
        val items = ArrayList<RuleScore>()
        if (last != null) {
            val gray = last.toGray()
            for (item in profile.stateRules[GameState.DRIVING].orEmpty()) {
                val name = item.removePrefix("!")
                val spec = profile.templates[name] ?: continue
                val useMask = profile.templates.containsKey(name + TemplateProvider.MASK_SUFFIX)
                val m = templates.best(gray, name, last.width, spec.roi, masked = useMask)
                items += RuleScore(name, item.startsWith("!"), m?.score, spec.minScore, spec.roi, useMask && templates.isMasked(name, last.width))
            }
        }
        val advice = ArrayList<String>()
        val reason: String
        val layout = last?.let { LayoutCheck.layoutProblem(profile, it.width, it.height) }
        val failing = items.firstOrNull { !it.ok }
        when {
            last == null -> {
                reason = "No picture of the game arrived while waiting."
                advice += "Check that screen sharing is still on (the chip at the top) and that the game is in front."
            }
            gameInFront == false -> {
                reason = "The selected game was not in front."
                advice += "Open the game (the button below), wait for the driving view, then try again."
            }
            validity == FrameValidity.BLACK || validity == FrameValidity.FLAT -> {
                reason = if (validity == FrameValidity.BLACK) "The captured picture is completely black, so this is a capture problem, not the driving view."
                else "The captured picture is one flat colour, so this is a capture problem, not the driving view."
                advice += "Black pictures mean the game window is protected, still loading, or screen sharing stopped. Reconnect the screen and check Settings → Diagnostics."
            }
            layout != null -> {
                reason = layout
                advice += "Hold the phone the way it was when you set up, or run Auto-Calibrate again for this screen."
            }
            profile.stateRules[GameState.DRIVING].isNullOrEmpty() -> {
                reason = "This profile has no driving-screen marker."
                advice += "Run Auto-Calibrate and confirm the controls, or mark a steady dashboard part in Smart Setup."
            }
            candidate == GameState.UNEXPECTED_DIALOG || candidate == GameState.CRASH_OR_PENALTY || candidate == GameState.DELIVERY_COMPLETE || candidate == GameState.LOADING -> {
                reason = "The game shows \"${candidate.label}\", not the driving view."
                advice += "Get back to the normal driving view, then try again."
            }
            failing != null && failing.negated -> {
                reason = "\"${failing.template}\" is visible, which is not the normal driving view."
                advice += "Leave the parking / special view, then try again."
            }
            failing != null -> {
                val pct = failing.best?.let { (it * 100).roundToInt() }
                reason = if (failing.best == null) "The saved picture \"${failing.template}\" is missing from the profile."
                else "The saved driving-screen marker is only $pct % similar to what is on screen (it needs ${(failing.needed * 100).roundToInt()} %)."
                if (failing.best != null && failing.best >= 0.5f) {
                    advice += "It is partly similar: the scenery behind see-through controls, a different time of day or a changed HUD can cause this."
                }
                if (validity == FrameValidity.VALID_DARK) advice += "The picture is dark (night or a tunnel) but valid; try again in daylight or recalibrate at night."
                advice += "Make sure the normal driving view is showing (no menu, map or pop-up), then try again."
                advice += "If it keeps failing: run Auto-Calibrate again while driving. It saves only the steady pixels, so the scenery behind the controls stops mattering."
            }
            else -> {
                reason = "The driving view was seen only in $hits of the last $seen pictures (confidence ${(confidence * 100).roundToInt()} %, needs ${(minConfidence * 100).roundToInt()} %)."
                advice += "Try again with the normal driving view showing."
            }
        }
        return RecognitionReport(last, validity, candidate, confidence, items, hits, seen, unusable, gameInFront, reason, advice, nowMs)
    }
}
