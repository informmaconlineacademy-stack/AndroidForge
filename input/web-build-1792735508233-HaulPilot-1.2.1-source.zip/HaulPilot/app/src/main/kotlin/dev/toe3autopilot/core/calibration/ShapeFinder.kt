package dev.toe3autopilot.core.calibration

import dev.toe3autopilot.core.vision.Roi
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

enum class ShapeKind { DISC, RECT }

/**
 * A closed outline found in the picture: a disc (round button, steering wheel, gauge) or a (rounded) rectangle (pedal,
 * square button, map). Pixel coordinates of the analysed picture, [x0,x1) x [y0,y1); [roi] gives NDS.
 *
 * Every number is measured, nothing is assumed:
 *  - [consistency]: share of the outline where the inside is darker (or lighter, [darkInside]) than just outside;
 *  - [sharpness]: how much that contrast is concentrated exactly on this outline (a real button edge) rather than spread
 *    out (a bush, a shadow, a smooth gradient);
 *  - [persistence] (many pictures only): share of the individual pictures in which the outline is there, i.e. it is fixed on
 *    the screen while the scenery moves;
 *  - [seeThrough] (many pictures only): how much the scenery keeps changing INSIDE compared with around it; translucent
 *    on-screen controls let the moving scenery through, a solid object such as the truck in a chase camera does not.
 */
data class Shape(
    val kind: ShapeKind,
    val x0: Int,
    val y0: Int,
    val x1: Int,
    val y1: Int,
    val darkInside: Boolean,
    val consistency: Float,
    val sharpness: Float,
    /** Median grey-level step across the outline. */
    val contrast: Float,
    /** Part of the outline lies outside the game area (cut off by the screen edge). */
    val cut: Boolean,
    val persistence: Float? = null,
    val seeThrough: Float? = null,
    /** Fine detail inside compared with around it (grip dots, arrows, symbols): > 1 means more detail inside. */
    val detail: Float = 0f,
    /** Discs only: radius in pixels. */
    val radius: Float = 0f,
) {
    val cx: Float get() = (x0 + x1) / 2f
    val cy: Float get() = (y0 + y1) / 2f
    val w: Int get() = x1 - x0
    val h: Int get() = y1 - y0

    /** Ordering score of the outline itself (not of any role). */
    val quality: Float get() = consistency + 0.5f * sharpness + min(contrast, 40f) / 200f

    fun roi(fw: Int, fh: Int): Roi {
        val l = (max(0, x0).toFloat() / fw).coerceIn(0f, 0.999f)
        val t = (max(0, y0).toFloat() / fh).coerceIn(0f, 0.999f)
        val r = (min(fw, x1).toFloat() / fw).coerceIn(l + 0.001f, 1f)
        val b = (min(fh, y1).toFloat() / fh).coerceIn(t + 0.001f, 1f)
        return Roi(l, t, r, b)
    }

    fun describe(): String {
        val what = if (kind == ShapeKind.DISC) "round outline" else "rectangular outline"
        val side = if (darkInside) "darker inside" else "lighter inside"
        return "$what (${w}x$h px, $side, ${pct(consistency)}% of the outline, sharpness ${pct(sharpness)}%)"
    }
}

/**
 * Finds closed outlines in [PictureEvidence.ref]. Pure, deterministic, no position rules: a shape is found wherever it is.
 *
 * Discs: every centre (every 2nd pixel) and radius from 3.5% to 32% of the game height is scored by looking at 16 sectors
 * around the circle; in each, the grey level just inside is compared with just outside. A translucent dark button over a
 * light road is darker inside in nearly every sector; road texture or grass is in about half of them.
 *
 * Rectangles: the same inside/outside test along the four sides (rounded corners are skipped), evaluated for every position
 * and size with running sums. A side lying on the edge of the game area may be missing (a pedal cut off by the screen edge).
 */
object ShapeFinder {
    const val MIN_CONSISTENCY = 0.80f
    const val MIN_RECT_SCORE = 0.72f
    const val MIN_SHARPNESS = 0.25f

    private const val SECTORS = 16

    private const val COARSE_CONSISTENCY = 0.68f

    /** Coarse rectangle grid: a little below [MIN_RECT_SCORE], the refinement decides. */
    private const val COARSE_RECT_SCORE = 0.66f

    /** Rectangle cells refined (the best per position/size cell). */
    private const val RECT_CANDIDATES = 1500

    /** Strongest peaks kept per radius before refinement (textured scenes produce many). */
    private const val PEAKS_PER_RADIUS = 900

    fun radii(viewportHeight: Int): List<Int> {
        val out = ArrayList<Int>()
        var r = max(7, (0.035f * viewportHeight).roundToInt())
        while (r <= 0.32f * viewportHeight) {
            out += r
            r = max(r + 1, (r * 1.12f).roundToInt())
        }
        return out
    }

    // ---------------------------------------------------------------------------------------------------------------
    // Discs
    // ---------------------------------------------------------------------------------------------------------------

    /** Precomputed sample offsets for one radius: per sector two points just inside and two just outside. */
    private class Ring(val r: Float) {
        val d = (0.08f * r).coerceIn(1.5f, 3f)
        val inX = IntArray(SECTORS * 2)
        val inY = IntArray(SECTORS * 2)
        val outX = IntArray(SECTORS * 2)
        val outY = IntArray(SECTORS * 2)

        init {
            for (k in 0 until SECTORS) for (j in 0..1) {
                val a = 2.0 * PI * (k + 0.5) / SECTORS + (if (j == 0) -0.1 else 0.1)
                val c = cos(a)
                val s = sin(a)
                inX[k * 2 + j] = ((r - d) * c).roundToInt()
                inY[k * 2 + j] = ((r - d) * s).roundToInt()
                outX[k * 2 + j] = ((r + d) * c).roundToInt()
                outY[k * 2 + j] = ((r + d) * s).roundToInt()
            }
        }
    }

    private class RingResult {
        var valid = 0
        var dark = 0
        var light = 0
        var cut = false
        val diffs = FloatArray(SECTORS)
    }

    private fun ring(ev: PictureEvidence, img: FloatArray, ring: Ring, cx: Int, cy: Int, out: RingResult, step: Float = ev.step) {
        val w = ev.width
        val h = ev.height
        out.valid = 0
        out.dark = 0
        out.light = 0
        out.cut = false
        for (k in 0 until SECTORS) {
            var si = 0f
            var so = 0f
            var ok = true
            for (j in 0..1) {
                val ix = cx + ring.inX[k * 2 + j]
                val iy = cy + ring.inY[k * 2 + j]
                val ox = cx + ring.outX[k * 2 + j]
                val oy = cy + ring.outY[k * 2 + j]
                if (ix < 0 || iy < 0 || ox < 0 || oy < 0 || ix >= w || iy >= h || ox >= w || oy >= h) {
                    ok = false
                    break
                }
                val ii = iy * w + ix
                val oi = oy * w + ox
                if (ev.blocked[ii] || ev.blocked[oi]) {
                    ok = false
                    break
                }
                si += img[ii]
                so += img[oi]
            }
            if (!ok) {
                out.cut = true
                continue
            }
            val diff = (si - so) / 2f
            out.diffs[out.valid] = diff
            out.valid++
            if (diff < -step) out.dark++ else if (diff > step) out.light++
        }
    }

    /** Consistency of a disc outline with the given polarity on [img], or 0 when too little of it is visible. */
    private fun discConsistency(ev: PictureEvidence, img: FloatArray, cx: Int, cy: Int, r: Float, dark: Boolean, tmp: RingResult, step: Float = ev.step): Float {
        ring(ev, img, Ring(r), cx, cy, tmp, step)
        if (tmp.valid < SECTORS * 3 / 4) return 0f
        return (if (dark) tmp.dark else tmp.light).toFloat() / tmp.valid
    }

    /** Diagnostics: (dark share, light share, valid sectors, median step) of the circle at ([cx],[cy]) with radius [r]. */
    fun probeDisc(ev: PictureEvidence, cx: Int, cy: Int, r: Float): List<Float> {
        val tmp = RingResult()
        ring(ev, ev.ref, Ring(r), cx, cy, tmp)
        if (tmp.valid == 0) return listOf(0f, 0f, 0f, 0f)
        return listOf(tmp.dark.toFloat() / tmp.valid, tmp.light.toFloat() / tmp.valid, tmp.valid.toFloat(), median(tmp.diffs, tmp.valid))
    }

    fun discs(ev: PictureEvidence, limit: Int = 60): List<Shape> {
        val w = ev.width
        val vp = ev.viewport
        val radii = radii(vp.height)
        val rings = radii.map { Ring(it.toFloat()) }
        val gw = (vp.width + 1) / 2
        val gh = (vp.height + 1) / 2
        val grid = FloatArray(gw * gh)
        val pol = BooleanArray(gw * gh)
        val tmp = RingResult()
        data class Raw(val cx: Int, val cy: Int, val ri: Int, val dark: Boolean, val cons: Float)
        val raw = ArrayList<Raw>()
        for ((ri, rg) in rings.withIndex()) {
            java.util.Arrays.fill(grid, 0f)
            for (gy in 0 until gh) for (gx in 0 until gw) {
                val cx = vp.x0 + gx * 2
                val cy = vp.y0 + gy * 2
                if (cx >= vp.x1 || cy >= vp.y1 || ev.blocked[cy * w + cx]) continue
                ring(ev, ev.ref, rg, cx, cy, tmp)
                if (tmp.valid < SECTORS * 3 / 4) continue
                val dk = tmp.dark.toFloat() / tmp.valid
                val lt = tmp.light.toFloat() / tmp.valid
                var mean = 0f
                for (k in 0 until tmp.valid) mean += tmp.diffs[k]
                mean = abs(mean / tmp.valid)
                // Consistency first; the mean step only breaks ties (it never lifts a shape over the threshold).
                grid[gy * gw + gx] = max(dk, lt) + min(mean, 60f) / 6000f
                pol[gy * gw + gx] = dk >= lt
            }
            val perRadius = ArrayList<Raw>()
            for (gy in 0 until gh) for (gx in 0 until gw) {
                val v = grid[gy * gw + gx]
                // The coarse grid can sit up to a pixel off a true centre; the refinement below asks for MIN_CONSISTENCY.
                if (v < COARSE_CONSISTENCY) continue
                var peak = true
                loop@ for (dy in -1..1) for (dx in -1..1) {
                    if (dx == 0 && dy == 0) continue
                    val nx = gx + dx
                    val ny = gy + dy
                    if (nx < 0 || ny < 0 || nx >= gw || ny >= gh) continue
                    if (grid[ny * gw + nx] > v) {
                        peak = false
                        break@loop
                    }
                }
                if (peak) perRadius += Raw(vp.x0 + gx * 2, vp.y0 + gy * 2, ri, pol[gy * gw + gx], v)
            }
            perRadius.sortByDescending { it.cons }
            raw += perRadius.take(PEAKS_PER_RADIUS)
        }

        // Refine each raw peak (centre +-1, radius +-1 step), then measure sharpness and contrast.
        val refined = ArrayList<Shape>()
        for (c in raw) {
            var best: Triple<Int, Int, Float>? = null
            var bestCons = -1f
            var bestContrast = 0f
            for (ri in max(0, c.ri - 1)..min(radii.size - 1, c.ri + 1)) {
                val rr = radii[ri].toFloat()
                for (dy in -1..1) for (dx in -1..1) {
                    val cx = c.cx + dx
                    val cy = c.cy + dy
                    if (!ev.inViewport(cx, cy)) continue
                    ring(ev, ev.ref, rings[ri], cx, cy, tmp)
                    if (tmp.valid < SECTORS * 3 / 4) continue
                    val cons = (if (c.dark) tmp.dark else tmp.light).toFloat() / tmp.valid
                    val med = median(tmp.diffs, tmp.valid) * (if (c.dark) -1f else 1f)
                    if (cons > bestCons + 1e-4f || (abs(cons - bestCons) <= 1e-4f && med > bestContrast)) {
                        bestCons = cons
                        bestContrast = med
                        best = Triple(cx, cy, rr)
                    }
                }
            }
            val b = best ?: continue
            if (bestCons < MIN_CONSISTENCY || bestContrast < ev.step) continue
            val (cx, cy, r) = b
            val inner = discConsistency(ev, ev.ref, cx, cy, r * 0.78f, c.dark, tmp)
            val outer = discConsistency(ev, ev.ref, cx, cy, r * 1.28f, c.dark, tmp)
            val sharp = bestCons - max(inner, outer)
            if (sharp < MIN_SHARPNESS) continue
            ring(ev, ev.ref, Ring(r), cx, cy, tmp)
            val ri = r.roundToInt()
            val x0 = cx - ri
            val y0 = cy - ri
            val x1 = cx + ri
            val y1 = cy + ri
            if (ev.touchesOwnUi(x0, y0, x1, y1, 2)) continue
            refined += Shape(ShapeKind.DISC, x0, y0, x1, y1, c.dark, bestCons, sharp, bestContrast, tmp.cut, radius = r)
        }
        return decorate(ev, nmsDiscs(refined), limit)
    }

    private fun nmsDiscs(all: List<Shape>): List<Shape> {
        val sorted = all.sortedByDescending { it.quality }
        val keep = ArrayList<Shape>()
        for (s in sorted) {
            // Concentric edges with OPPOSITE contrast are different edges (a rim's inner and outer edge), not duplicates.
            val dup = keep.any { k ->
                k.darkInside == s.darkInside && hypot(k.cx - s.cx, k.cy - s.cy) < 0.6f * max(k.radius, s.radius) &&
                    max(k.radius, s.radius) / min(k.radius, s.radius) < 1.5f
            }
            if (!dup) keep += s
        }
        return keep
    }

    /** A ring (a band with an inner and an outer edge of opposite contrast): how clear it is, and its outer radius. */
    data class RingFit(val score: Float, val outerRadius: Float, val innerRadius: Float)

    /**
     * For a disc edge: whether a second, concentric edge with the OPPOSITE contrast lies just inside or just outside it.
     * A steering-wheel rim is a band: lighter than the outside at its outer edge and lighter than the inside at its inner
     * edge. A filled button or gauge face has no such second edge. Returns the best fit (score 0 when none).
     */
    fun rim(ev: PictureEvidence, s: Shape): RingFit {
        if (s.kind != ShapeKind.DISC) return RingFit(0f, 0f, 0f)
        val tmp = RingResult()
        var best = RingFit(0f, s.radius, s.radius)
        var f = 0.62f
        while (f <= 0.93f) {
            val c = discConsistency(ev, ev.ref, s.cx.roundToInt(), s.cy.roundToInt(), s.radius * f, !s.darkInside, tmp)
            if (c > best.score) best = RingFit(c, s.radius, s.radius * f)
            f += 0.03f
        }
        f = 1.07f
        while (f <= 1.62f) {
            val c = discConsistency(ev, ev.ref, s.cx.roundToInt(), s.cy.roundToInt(), s.radius * f, !s.darkInside, tmp)
            if (c > best.score) best = RingFit(c, s.radius * f, s.radius)
            f += 0.05f
        }
        return best
    }

    // ---------------------------------------------------------------------------------------------------------------
    // Rectangles
    // ---------------------------------------------------------------------------------------------------------------

    private const val D = 2

    /** Running sums of the four "darker on one side" maps. */
    private class SideMaps(ev: PictureEvidence, img: FloatArray, step: Float = ev.step) {
        val w = ev.width
        val h = ev.height

        /** Per column, along y: darker to the right of x (A) / darker to the left (B). */
        val colA = IntArray(w * (h + 1))
        val colB = IntArray(w * (h + 1))

        /** Per row, along x: darker below y (C) / darker above (E). */
        val rowC = IntArray(h * (w + 1))
        val rowE = IntArray(h * (w + 1))

        init {
            val bl = ev.blocked
            for (x in 0 until w) {
                var a = 0
                var b = 0
                for (y in 0 until h) {
                    if (x - D >= 0 && x + D < w) {
                        val l = y * w + x - D
                        val r = y * w + x + D
                        if (!bl[l] && !bl[r]) {
                            val d = img[l] - img[r]
                            if (d > step) a++ else if (d < -step) b++
                        }
                    }
                    colA[x * (h + 1) + y + 1] = a
                    colB[x * (h + 1) + y + 1] = b
                }
            }
            for (y in 0 until h) {
                var c = 0
                var e = 0
                for (x in 0 until w) {
                    if (y - D >= 0 && y + D < h) {
                        val u = (y - D) * w + x
                        val dn = (y + D) * w + x
                        if (!bl[u] && !bl[dn]) {
                            val d = img[u] - img[dn]
                            if (d > step) c++ else if (d < -step) e++
                        }
                    }
                    rowC[y * (w + 1) + x + 1] = c
                    rowE[y * (w + 1) + x + 1] = e
                }
            }
        }

        fun col(arr: IntArray, x: Int, ya: Int, yb: Int): Int = arr[x * (h + 1) + yb] - arr[x * (h + 1) + ya]
        fun row(arr: IntArray, y: Int, xa: Int, xb: Int): Int = arr[y * (w + 1) + xb] - arr[y * (w + 1) + xa]
    }

    /** Per-side consistency of a rectangle; NaN for a side lying on the edge of the game area. */
    private fun rectSides(m: SideMaps, vp: dev.toe3autopilot.core.geometry.IntRect, x0: Int, y0: Int, x1: Int, y1: Int, dark: Boolean, out: FloatArray) {
        val wd = x1 - x0
        val ht = y1 - y0
        // Skip only the rounded corners: their radius is a fraction of the SMALLER side, so a long side is checked over
        // nearly its full length (an outline that borrows an unrelated edge, e.g. the horizon, as its top then fails).
        val corner = cornerSkip(wd, ht)
        val ey = min(corner, ht / 4)
        val ex = min(corner, wd / 4)
        val nv = (ht - 2 * ey).toFloat()
        val nh = (wd - 2 * ex).toFloat()
        val leftCut = x0 - D < vp.x0
        val rightCut = x1 - 1 + D >= vp.x1
        val topCut = y0 - D < vp.y0
        val bottomCut = y1 - 1 + D >= vp.y1
        out[0] = if (leftCut || nv <= 0) Float.NaN else m.col(if (dark) m.colA else m.colB, x0, y0 + ey, y1 - ey) / nv
        out[1] = if (rightCut || nv <= 0) Float.NaN else m.col(if (dark) m.colB else m.colA, x1 - 1, y0 + ey, y1 - ey) / nv
        out[2] = if (topCut || nh <= 0) Float.NaN else m.row(if (dark) m.rowC else m.rowE, y0, x0 + ex, x1 - ex) / nh
        out[3] = if (bottomCut || nh <= 0) Float.NaN else m.row(if (dark) m.rowE else m.rowC, y1 - 1, x0 + ex, x1 - ex) / nh
    }

    /** Mean over measured sides, or -1 when fewer than 3 sides can be measured or one side is weak. */
    private fun rectScore(s: FloatArray): Float {
        var n = 0
        var sum = 0f
        var mn = 1f
        for (v in s) {
            if (v.isNaN()) continue
            n++
            sum += v
            mn = min(mn, v)
        }
        if (n < 3 || mn < 0.5f) return -1f
        return sum / n
    }

    /** Diagnostics: per-side consistency (NaN = side on the edge of the game area) and sharpness of a rectangle. */
    fun probeRect(ev: PictureEvidence, x0: Int, y0: Int, x1: Int, y1: Int, dark: Boolean): List<Float> {
        val m = SideMaps(ev, ev.ref)
        val sides = FloatArray(4)
        rectSides(m, ev.viewport, x0, y0, x1, y1, dark, sides)
        return sides.toList() + rectScore(sides) + rectSharpness(m, ev.viewport, x0, y0, x1, y1, dark, sides.copyOf()) +
            rectContrast(ev, ev.ref, x0, y0, x1, y1, dark)
    }

    private fun cornerSkip(wd: Int, ht: Int): Int = max(1, (0.22f * min(wd, ht)).roundToInt())

    private class RawRect(val x0: Int, val y0: Int, val x1: Int, val y1: Int, val dark: Boolean, val score: Float)

    fun rects(ev: PictureEvidence, limit: Int = 60): List<Shape> {
        val vp = ev.viewport
        val vw = vp.width
        val vh = vp.height
        val m = SideMaps(ev, ev.ref)
        val sides = FloatArray(4)
        val wMin = max(8, (0.03f * vw).roundToInt())
        val wMax = max(wMin, (0.32f * vw).roundToInt())
        val hMin = max(10, (0.08f * vh).roundToInt())
        val hMax = max(hMin, (0.65f * vh).roundToInt())
        val sizeStep = max(3, vw / 120)
        val posStep = max(2, vw / 160)
        // Best candidate per cell (centre position and size class), so a heavily textured object (the truck, a building)
        // cannot crowd every other place out of the candidate list.
        val cells = HashMap<Long, RawRect>()
        var wd = wMin
        while (wd <= wMax) {
            var ht = hMin
            while (ht <= hMax) {
                val aspect = ht.toFloat() / wd
                if (aspect in 0.4f..4.5f) {
                    val xs = positions(vp.x0, vp.x1 - wd, posStep)
                    val ys = positions(vp.y0, vp.y1 - ht, posStep)
                    for (y0 in ys) for (x0 in xs) {
                        for (dark in BOOLS) {
                            rectSides(m, vp, x0, y0, x0 + wd, y0 + ht, dark, sides)
                            val sc = rectScore(sides)
                            if (sc < COARSE_RECT_SCORE) continue
                            val key = ((((x0 + wd / 2) / 6).toLong() * 512 + (y0 + ht / 2) / 6) * 64 + wd / 8) * 64 * 2 + (ht / 8) * 2 + (if (dark) 1 else 0)
                            val old = cells[key]
                            if (old == null || sc > old.score) cells[key] = RawRect(x0, y0, x0 + wd, y0 + ht, dark, sc)
                        }
                    }
                }
                ht += sizeStep
            }
            wd += sizeStep
        }
        val heap = cells.values.sortedByDescending { it.score }.take(RECT_CANDIDATES)

        // Refine: move each side by up to 2 px.
        val refined = ArrayList<Shape>()
        val seen = HashSet<Long>()
        for (c in heap) {
            var bx0 = c.x0
            var by0 = c.y0
            var bx1 = c.x1
            var by1 = c.y1
            var best = c.score
            for (d0 in -2..2) for (d1 in -2..2) for (d2 in -2..2) for (d3 in -2..2) {
                val x0 = c.x0 + d0
                val y0 = c.y0 + d1
                val x1 = c.x1 + d2
                val y1 = c.y1 + d3
                if (x0 < vp.x0 || y0 < vp.y0 || x1 > vp.x1 || y1 > vp.y1 || x1 - x0 < wMin || y1 - y0 < hMin) continue
                rectSides(m, vp, x0, y0, x1, y1, c.dark, sides)
                val sc = rectScore(sides)
                if (sc > best + 1e-4f) {
                    best = sc
                    bx0 = x0
                    by0 = y0
                    bx1 = x1
                    by1 = y1
                }
            }
            if (best < MIN_RECT_SCORE) continue
            val key = (((bx0.toLong() * 4096 + by0) * 4096 + bx1) * 4096 + by1) * 2 + (if (c.dark) 1 else 0)
            if (!seen.add(key)) continue
            if (ev.touchesOwnUi(bx0, by0, bx1, by1, 2)) continue
            rectSides(m, vp, bx0, by0, bx1, by1, c.dark, sides)
            val base = sides.copyOf()
            val sharp = rectSharpness(m, vp, bx0, by0, bx1, by1, c.dark, base)
            if (sharp < MIN_SHARPNESS) continue
            val contrast = rectContrast(ev, ev.ref, bx0, by0, bx1, by1, c.dark)
            if (contrast < ev.step) continue
            val cut = base.any { it.isNaN() }
            refined += Shape(ShapeKind.RECT, bx0, by0, bx1, by1, c.dark, best, sharp, contrast, cut)
        }
        return decorate(ev, nmsRects(refined), limit)
    }

    private val BOOLS = booleanArrayOf(true, false)

    private fun positions(from: Int, to: Int, step: Int): IntArray {
        if (to < from) return IntArray(0)
        val out = ArrayList<Int>()
        var p = from
        while (p <= to) {
            out += p
            p += step
        }
        if (out.last() != to) out += to
        return out.toIntArray()
    }

    /** Mean, over the measured sides, of how much the side's contrast drops when the side is moved in or out. */
    private fun rectSharpness(m: SideMaps, vp: dev.toe3autopilot.core.geometry.IntRect, x0: Int, y0: Int, x1: Int, y1: Int, dark: Boolean, base: FloatArray): Float {
        val tmp = FloatArray(4)
        var sum = 0f
        var n = 0
        for (k in 0..3) {
            if (base[k].isNaN()) continue
            val len = if (k < 2) y1 - y0 else x1 - x0
            val s = max(3, (0.12f * len).roundToInt())
            var worst = 0f
            for (dir in intArrayOf(-1, 1)) {
                var a0 = x0
                var b0 = y0
                var a1 = x1
                var b1 = y1
                when (k) {
                    0 -> a0 -= dir * s
                    1 -> a1 += dir * s
                    2 -> b0 -= dir * s
                    else -> b1 += dir * s
                }
                if (a1 - a0 < 4 || b1 - b0 < 4) continue
                rectSides(m, vp, a0, b0, a1, b1, dark, tmp)
                val v = tmp[k]
                if (!v.isNaN()) worst = max(worst, v)
            }
            sum += base[k] - worst
            n++
        }
        return if (n == 0) 0f else sum / n
    }

    /** Median step (outside minus inside for a dark shape) along the measured sides. */
    private fun rectContrast(ev: PictureEvidence, img: FloatArray, x0: Int, y0: Int, x1: Int, y1: Int, dark: Boolean): Float {
        val w = ev.width
        val h = ev.height
        val v = ArrayList<Float>()
        val sign = if (dark) 1f else -1f
        fun sample(ix: Int, iy: Int, ox: Int, oy: Int) {
            if (ix < 0 || iy < 0 || ox < 0 || oy < 0 || ix >= w || ox >= w || iy >= h || oy >= h) return
            if (ev.blocked[iy * w + ix] || ev.blocked[oy * w + ox]) return
            v += (img[oy * w + ox] - img[iy * w + ix]) * sign
        }
        val corner = cornerSkip(x1 - x0, y1 - y0)
        val ey = min(corner, (y1 - y0) / 4)
        val ex = min(corner, (x1 - x0) / 4)
        for (y in y0 + ey until y1 - ey) {
            sample(x0 + D, y, x0 - D, y)
            sample(x1 - 1 - D, y, x1 - 1 + D, y)
        }
        for (x in x0 + ex until x1 - ex) {
            sample(x, y0 + D, x, y0 - D)
            sample(x, y1 - 1 - D, x, y1 - 1 + D)
        }
        if (v.isEmpty()) return 0f
        v.sort()
        return v[v.size / 2]
    }

    /**
     * Removes near-duplicates. A shape NESTED inside another (an element's outline and the grip ribs or symbol inside it)
     * is kept: both are real outlines, and the role logic decides which one is the element.
     */
    private fun nmsRects(all: List<Shape>): List<Shape> {
        val sorted = all.sortedByDescending { it.quality }
        val keep = ArrayList<Shape>()
        for (s in sorted) {
            val dup = keep.any { k ->
                val iou = iouPx(k, s)
                iou > 0.75f || (iou > 0.4f && !nested(k, s) && !nested(s, k))
            }
            if (!dup) keep += s
        }
        return keep
    }

    /** [inner] lies inside [outer] (2 px tolerance) and is clearly smaller. */
    fun nested(outer: Shape, inner: Shape): Boolean =
        inner.x0 >= outer.x0 - 2 && inner.x1 <= outer.x1 + 2 && inner.y0 >= outer.y0 - 2 && inner.y1 <= outer.y1 + 2 &&
            inner.w.toFloat() * inner.h < 0.85f * outer.w * outer.h

    fun iouPx(a: Shape, b: Shape): Float {
        val l = max(a.x0, b.x0)
        val t = max(a.y0, b.y0)
        val r = min(a.x1, b.x1)
        val bt = min(a.y1, b.y1)
        if (r <= l || bt <= t) return 0f
        val i = (r - l).toFloat() * (bt - t)
        return i / (a.w.toFloat() * a.h + b.w.toFloat() * b.h - i)
    }

    // ---------------------------------------------------------------------------------------------------------------
    // Extra measurements (many pictures)
    // ---------------------------------------------------------------------------------------------------------------

    /**
     * Adds persistence, see-through and detail measurements and keeps the best [limit] shapes. With many pictures the
     * fixed ones come first (moving scenery outlines on the averaged picture would otherwise crowd them out).
     */
    private fun decorate(ev: PictureEvidence, shapes: List<Shape>, limit: Int): List<Shape> {
        if (!ev.multiFrame) return shapes.take(limit).map { it.copy(detail = detail(ev, it)) }
        val measured = shapes.map { it.copy(persistence = persistence(ev, it)) }
        val fixed = measured.filter { (it.persistence ?: 0f) >= FIXED_SHARE }
        val moving = measured.filter { (it.persistence ?: 0f) < FIXED_SHARE }
        return (fixed.take(limit) + moving.take(max(0, limit - fixed.size))).map {
            it.copy(seeThrough = seeThrough(ev, it), detail = detail(ev, it))
        }
    }

    /** Share of the individual pictures an outline must appear in to count as fixed on the screen. */
    const val FIXED_SHARE = 0.5f

    /** Share of the individual moving pictures in which the outline holds (consistency >= 0.6). */
    fun persistence(ev: PictureEvidence, s: Shape): Float {
        if (ev.frames.isEmpty()) return 0f
        var ok = 0
        val tmp = RingResult()
        for (img in ev.frames) {
            val c = if (s.kind == ShapeKind.DISC) {
                discConsistency(ev, img, s.cx.roundToInt(), s.cy.roundToInt(), s.radius, s.darkInside, tmp, ev.frameStep)
            } else {
                rectConsistencyDirect(ev, img, s, ev.frameStep)
            }
            if (c >= 0.6f) ok++
        }
        return ok.toFloat() / ev.frames.size
    }

    private fun rectConsistencyDirect(ev: PictureEvidence, img: FloatArray, s: Shape, step: Float): Float {
        val w = ev.width
        val h = ev.height
        var good = 0
        var n = 0
        fun side(ix: Int, iy: Int, ox: Int, oy: Int) {
            if (ix < 0 || iy < 0 || ox < 0 || oy < 0 || ix >= w || ox >= w || iy >= h || oy >= h) return
            if (ev.blocked[iy * w + ix] || ev.blocked[oy * w + ox]) return
            val d = img[oy * w + ox] - img[iy * w + ix]
            n++
            if ((if (s.darkInside) d else -d) > step) good++
        }
        val corner = cornerSkip(s.w, s.h)
        val ey = min(corner, s.h / 4)
        val ex = min(corner, s.w / 4)
        for (y in s.y0 + ey until s.y1 - ey) {
            side(s.x0 + D, y, s.x0 - D, y)
            side(s.x1 - 1 - D, y, s.x1 - 1 + D, y)
        }
        for (x in s.x0 + ex until s.x1 - ex) {
            side(x, s.y0 + D, x, s.y0 - D)
            side(x, s.y1 - 1 - D, x, s.y1 - 1 + D)
        }
        return if (n == 0) 0f else good.toFloat() / n
    }

    /**
     * Change over time inside (shrunk by a quarter, away from the outline) divided by the change just around the shape.
     * Null when the surroundings hardly change (then nothing can be said).
     */
    fun seeThrough(ev: PictureEvidence, s: Shape): Float? {
        if (ev.temporalStd == null) return null
        val mx = max(1, s.w / 4)
        val my = max(1, s.h / 4)
        val inside = ev.medianStd(s.x0 + mx, s.y0 + my, s.x1 - mx, s.y1 - my)
        val band = max(3, min(s.w, s.h) / 6)
        val around = medianBand(ev, s, band)
        if (around < 4f) return null
        return (inside / around).coerceIn(0f, 2f)
    }

    private fun medianBand(ev: PictureEvidence, s: Shape, band: Int): Float {
        val std = ev.temporalStd ?: return 0f
        val w = ev.width
        val v = ArrayList<Float>()
        val gap = 2
        for (y in s.y0 - gap - band until s.y1 + gap + band) {
            if (y < 0 || y >= ev.height) continue
            for (x in s.x0 - gap - band until s.x1 + gap + band) {
                if (x < 0 || x >= w) continue
                val inner = x >= s.x0 - gap && x < s.x1 + gap && y >= s.y0 - gap && y < s.y1 + gap
                if (inner || ev.blocked[y * w + x]) continue
                v += std[y * w + x]
            }
        }
        if (v.isEmpty()) return 0f
        v.sort()
        return v[v.size / 2]
    }

    /** Mean absolute Laplacian inside (shrunk) relative to a band around the shape, on the analysed picture. */
    fun detail(ev: PictureEvidence, s: Shape): Float {
        val w = ev.width
        val h = ev.height
        val img = ev.ref
        fun lap(x: Int, y: Int): Float = abs(4 * img[y * w + x] - img[y * w + x - 1] - img[y * w + x + 1] - img[(y - 1) * w + x] - img[(y + 1) * w + x])
        val mx = max(2, s.w / 5)
        val my = max(2, s.h / 5)
        var si = 0f
        var ni = 0
        for (y in max(1, s.y0 + my) until min(h - 1, s.y1 - my)) for (x in max(1, s.x0 + mx) until min(w - 1, s.x1 - mx)) {
            if (ev.blocked[y * w + x]) continue
            si += lap(x, y)
            ni++
        }
        var so = 0f
        var no = 0
        val band = max(3, min(s.w, s.h) / 5)
        for (y in max(1, s.y0 - 2 - band) until min(h - 1, s.y1 + 2 + band)) for (x in max(1, s.x0 - 2 - band) until min(w - 1, s.x1 + 2 + band)) {
            if (x >= s.x0 - 2 && x < s.x1 + 2 && y >= s.y0 - 2 && y < s.y1 + 2) continue
            if (ev.blocked[y * w + x]) continue
            so += lap(x, y)
            no++
        }
        if (ni == 0 || no == 0) return 0f
        return (si / ni) / (so / no + 2f)
    }

    /**
     * Normalised cross-correlation of the insides of [a] and [b] on the analysed picture (both resampled to 16x16); with
     * [mirror] the second one is flipped left-right first. -1..1; 0 when either is flat.
     */
    fun ncc(ev: PictureEvidence, a: Shape, b: Shape, mirror: Boolean): Float {
        val n = 16
        val pa = patch(ev, a, n) ?: return 0f
        val pb = patch(ev, b, n) ?: return 0f
        var ma = 0.0
        var mb = 0.0
        for (i in 0 until n * n) {
            ma += pa[i]
            mb += pb[i]
        }
        ma /= n * n
        mb /= n * n
        var sab = 0.0
        var saa = 0.0
        var sbb = 0.0
        for (y in 0 until n) for (x in 0 until n) {
            val va = pa[y * n + x] - ma
            val vb = pb[y * n + (if (mirror) n - 1 - x else x)] - mb
            sab += va * vb
            saa += va * va
            sbb += vb * vb
        }
        if (saa < 1e-6 || sbb < 1e-6) return 0f
        return (sab / sqrt(saa * sbb)).toFloat()
    }

    private fun patch(ev: PictureEvidence, s: Shape, n: Int): FloatArray? {
        val w = ev.width
        val h = ev.height
        val mx = s.w * 0.12f
        val my = s.h * 0.12f
        val x0 = s.x0 + mx
        val y0 = s.y0 + my
        val sw = s.w - 2 * mx
        val sh = s.h - 2 * my
        if (sw < 3 || sh < 3) return null
        val out = FloatArray(n * n)
        for (j in 0 until n) for (i in 0 until n) {
            val x = (x0 + (i + 0.5f) * sw / n).toInt().coerceIn(0, w - 1)
            val y = (y0 + (j + 0.5f) * sh / n).toInt().coerceIn(0, h - 1)
            out[j * n + i] = ev.ref[y * w + x]
        }
        return out
    }

    private fun median(v: FloatArray, n: Int): Float {
        if (n == 0) return 0f
        val c = v.copyOf(n)
        c.sort()
        return c[n / 2]
    }

}

private fun pct(v: Float) = (v * 100).roundToInt()
