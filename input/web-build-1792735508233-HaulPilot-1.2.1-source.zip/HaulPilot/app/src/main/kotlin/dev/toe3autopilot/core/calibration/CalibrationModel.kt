package dev.toe3autopilot.core.calibration

import dev.toe3autopilot.core.Control
import dev.toe3autopilot.core.vision.Roi

/**
 * Things the self-calibration tries to find on screen. Only roles that map to a [Control] can ever drive the
 * automation; the rest are informational (their position is stored in the profile's `extra.calib.*` keys).
 */
enum class CalibRole(val label: String, val control: Control?, val measuresTiming: Boolean, val prompt: String) {
    ACCELERATOR("Accelerator", Control.ACCELERATOR, true, "press and HOLD the accelerator"),
    BRAKE("Brake", Control.BRAKE, true, "press and HOLD the brake"),
    STEER_LEFT("Steer left", Control.STEER_LEFT, false, "press and HOLD the steer-left control (or turn the wheel fully left)"),
    STEER_RIGHT("Steer right", Control.STEER_RIGHT, false, "press and HOLD the steer-right control (or turn the wheel fully right)"),
    STEER_WHEEL("Steering wheel", Control.STEER_CENTER, false, "turn the wheel and hold it"),
    GEAR_REVERSE("Reverse gear", Control.GEAR_REVERSE, false, "press and HOLD the reverse-gear control"),

    /** A HUD element whose content keeps changing while accelerating. We do NOT read the number (no OCR). */
    SPEED_READOUT("Speed indicator", null, false, "");

    /** Roles the user can demonstrate (the speed indicator is a by-product of the accelerator demo). */
    val demonstrable: Boolean get() = this != SPEED_READOUT && this != STEER_WHEEL
}

enum class DetectionStatus {
    /** Nothing found. */
    NONE,

    /** Found, but not trusted: waits for the user. NEVER used by the automation. */
    NEEDS_CONFIRMATION,

    /** Demonstrated by the user with strong, unambiguous evidence. Shown in the UI and revocable. */
    AUTO_CONFIRMED,

    /** The user said yes, or placed it by hand. */
    CONFIRMED,

    /** The user said no. */
    REJECTED;

    /** The only statuses the automation may rely on. */
    val usable: Boolean get() = this == AUTO_CONFIRMED || this == CONFIRMED
}

enum class DetectionSource {
    /** The person demonstrated the action live and the before/after pictures were compared. */
    DEMONSTRATION,

    /** The person placed or chose it. */
    USER,

    /** A typical-layout position guess. */
    PRIOR,

    /** Inferred from an imported gameplay clip. Never auto-confirmed and never above [ControlDetection.VIDEO_MAX_CONFIDENCE]. */
    VIDEO,

    /**
     * Proposed from the shape and arrangement of a fixed on-screen element (see ControlCandidateDetector). Never
     * auto-confirmed and never above [ControlDetection.SHAPE_MAX_CONFIDENCE].
     */
    SHAPE,
}

/**
 * Another place the analysis considered for a control, with its own (capped) evidence score, a one-line [note] and the
 * full [evidence] for showing it as the proposal instead (Auto-Calibrate's "next candidate").
 */
data class Alternative(val x: Float, val y: Float, val box: Roi?, val score: Float, val note: String, val evidence: List<String> = emptyList())

data class ControlDetection(
    val role: CalibRole,
    val x: Float,
    val y: Float,
    val box: Roi?,
    /** 0..1. Honest evidence strength, not a probability. */
    val confidence: Float,
    val status: DetectionStatus,
    val source: DetectionSource,
    val evidence: List<String>,
    val alternatives: List<Alternative> = emptyList(),
) {
    init {
        require(confidence in 0f..1f) { "confidence out of range" }
        if (status == DetectionStatus.AUTO_CONFIRMED) {
            require(source == DetectionSource.DEMONSTRATION && confidence >= AUTO_CONFIRM_MIN) {
                "A detection can only be auto-confirmed from a demonstration with confidence >= $AUTO_CONFIRM_MIN"
            }
        }
        if (source == DetectionSource.PRIOR) require(confidence <= PRIOR_MAX_CONFIDENCE) { "position guesses can never be confident" }
        if (source == DetectionSource.VIDEO) require(confidence <= VIDEO_MAX_CONFIDENCE) { "a recorded clip can never give high confidence" }
        if (source == DetectionSource.SHAPE) require(confidence <= SHAPE_MAX_CONFIDENCE) { "a shape match can never give high confidence" }
    }

    companion object {
        const val AUTO_CONFIRM_MIN = 0.85f
        const val PRIOR_MAX_CONFIDENCE = 0.45f
        const val VIDEO_MAX_CONFIDENCE = 0.7f
        const val SHAPE_MAX_CONFIDENCE = 0.6f

        fun none(role: CalibRole, why: String, alternatives: List<Alternative> = emptyList()) =
            ControlDetection(role, 0f, 0f, null, 0f, DetectionStatus.NONE, DetectionSource.DEMONSTRATION, listOf(why), alternatives)
    }
}

/** A persistent on-screen element found by [HudAnalyzer]. */
data class HudElement(
    val box: Roi,
    val cx: Float,
    val cy: Float,
    /** Mean fraction of frames in which this element's edge pixels were present (0..1). */
    val persistence: Float,
    val aspect: Float,
    val areaFraction: Float,
    /** Ordering score only. */
    val score: Float,
    /** Share of the outline lying on the ellipse inscribed in the box: about 1 for a ring or wheel, about 0.45 for a rectangle. */
    val ringness: Float = 0f,
    /** Share of the outline near the centre of the box (an icon or hub inside the element). */
    val centerFill: Float = 0f,
    /** Persistent outline pixels per box pixel. */
    val edgeDensity: Float = 0f,
    /** The element was separated from a larger connected shape (two elements joined by a thin persistent line). */
    val splitFromLarger: Boolean = false,
)

data class HudAnalysis(
    val frameWidth: Int,
    val frameHeight: Int,
    val framesUsed: Int,
    /** How much of the picture changed between frames (0..1). Low = static scene: HUD cannot be separated. */
    val sceneChange: Float,
    val elements: List<HudElement>,
    val ok: Boolean,
    val problem: String?,
)

data class MinimapSuggestion(val box: Roi, val routeColorRgb: Int?, val note: String)

data class TimingEstimate(
    /** Suggested `extra.motion.stopped`: motion below this = "truck has stopped". Null if rest/moving could not be separated. */
    val stoppedThreshold: Float?,
    val restLevel: Float,
    val movingLevel: Float,
    /** Upper bound only: includes the person's reaction time to the on-screen cue. */
    val startLatencyMsUpperBound: Long?,
    /** Time from the "release" cue until motion dropped below the threshold (includes reaction time). */
    val stopMs: Long?,
    val suggestedSettleMs: Long?,
    val notes: List<String>,
)

/** Frame size the calibration was made for. */
data class LayoutSignature(val width: Int, val height: Int) {
    val aspect: Float get() = width.toFloat() / height
}
