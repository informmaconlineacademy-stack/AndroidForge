package dev.toe3autopilot.core.session

import dev.toe3autopilot.core.Control
import dev.toe3autopilot.core.Point
import dev.toe3autopilot.core.state.GameState
import dev.toe3autopilot.core.vision.Frame

/** Source of screenshots. */
interface FrameSource {
    /** False once capture has stopped (projection revoked, service destroyed, ...). */
    val isActive: Boolean

    /** Newest frame, or null if none has arrived yet. NOTE: on a static screen no new frames arrive, so age alone is not a fault. */
    fun latest(): Frame?
}

/** Knows which app is in the foreground. */
interface GameMonitor {
    /** true = the game is in front, false = something else is, null = cannot tell (e.g. accessibility service not connected). */
    fun isGameForeground(): Boolean?

    /**
     * Both facts in plain words (the selected game and what is actually in front) and how to get back to the game; empty when
     * unknown. Appended to pause messages and the log so a wrong package is never hidden behind "not in the foreground".
     */
    fun foregroundNote(): String = ""
}

enum class InputKind { INJECTED, ASSISTED }

/** Delivers touches to the game, or (ASSISTED) only tells the user what to do. Implementations must be thread-safe. */
interface InputController {
    val kind: InputKind

    /** True when the channel is connected and usable. */
    val isReady: Boolean

    /** False after repeated dispatch failures; the session pauses when this turns false. */
    val isHealthy: Boolean

    /** Replace the set of controls that are being held down, each at the given normalised point. Empty = release everything. */
    fun setHolds(holds: Map<Control, Point>)

    fun tapAt(point: Point)

    fun releaseAll()
}

enum class SessionStatus(val label: String) {
    IDLE("Idle"),
    STARTING("Starting: verifying recognition"),
    RUNNING("Running"),
    PAUSED("Paused"),
    NEEDS_ASSIST("Needs your help"),
    EMERGENCY_STOPPED("Emergency stop"),
    FINISHED("Finished"),
    ERROR("Error");

    val isActiveLoop: Boolean get() = this == STARTING || this == RUNNING
}

/** Which part of the trip the automation is in. */
enum class DrivePhase(val label: String) {
    DRIVING("Driving"),

    /** Display only: the session is still driving, but the route ahead bends sharply or ends. Never stored as the internal phase. */
    APPROACHING_TURN("Approaching Turn"),
    APPROACHING("Approaching Delivery"),
    PARKING("Parking"),
    PARKED("Parked"),
}

data class SessionSnapshot(
    val status: SessionStatus = SessionStatus.IDLE,
    val gameState: GameState = GameState.UNKNOWN,
    val confidence: Float = 0f,
    val task: String = "Idle",
    val lastError: String? = null,
    val recovery: String? = null,
    val phase: DrivePhase? = null,
    /** Short description of how well the road is being tracked, for the status display. */
    val road: String? = null,
    val inputKind: InputKind? = null,
    val assistHint: String? = null,
    val ticks: Long = 0,
    /** Why the last stop asked for help; null while running or after a normal stop. */
    val helpKind: dev.toe3autopilot.core.HelpKind? = null,
)

/** What the person sees as "current state". */
enum class UserState(val label: String) {
    READY("Ready"),
    CALIBRATING("Calibrating"),
    STARTING("Starting"),
    DRIVING("Driving"),
    APPROACHING_TURN("Approaching Turn"),
    APPROACHING_DELIVERY("Approaching Delivery"),
    PARKING("Parking"),
    PARKED("Parked"),
    PAUSED("Paused"),
    NEEDS_ASSISTANCE("Needs Assistance"),
    EMERGENCY_STOP("Emergency Stop"),
}

/** @param calibrating the calibration engine is observing or running a demonstration (only shown when no session is live) */
fun SessionSnapshot.userState(calibrating: Boolean): UserState = when (status) {
    SessionStatus.STARTING -> UserState.STARTING
    SessionStatus.RUNNING -> when (phase) {
        DrivePhase.APPROACHING_TURN -> UserState.APPROACHING_TURN
        DrivePhase.APPROACHING -> UserState.APPROACHING_DELIVERY
        DrivePhase.PARKING -> UserState.PARKING
        DrivePhase.PARKED -> UserState.PARKED
        else -> UserState.DRIVING
    }
    SessionStatus.PAUSED -> UserState.PAUSED
    SessionStatus.NEEDS_ASSIST, SessionStatus.ERROR -> UserState.NEEDS_ASSISTANCE
    SessionStatus.EMERGENCY_STOPPED -> UserState.EMERGENCY_STOP
    SessionStatus.FINISHED -> UserState.PARKED
    SessionStatus.IDLE -> if (calibrating) UserState.CALIBRATING else UserState.READY
}

enum class LogLevel { INFO, WARN, ERROR }

data class LogEntry(val timeMs: Long, val level: LogLevel, val message: String, val repeat: Int = 1)

/** Bounded in-memory log. Collapses consecutive duplicates. Only states and actions are logged, never screen content. */
class SessionLog(private val capacity: Int = 500, private val sink: ((LogEntry) -> Unit)? = null) {
    private val entries = ArrayDeque<LogEntry>()

    @Synchronized
    fun add(timeMs: Long, level: LogLevel, message: String) {
        val last = entries.lastOrNull()
        val entry = if (last != null && last.level == level && last.message == message) {
            entries.removeLast()
            last.copy(timeMs = timeMs, repeat = last.repeat + 1)
        } else {
            LogEntry(timeMs, level, message)
        }
        entries.addLast(entry)
        while (entries.size > capacity) entries.removeFirst()
        sink?.invoke(entry)
    }

    @Synchronized
    fun entries(): List<LogEntry> = entries.toList()

    @Synchronized
    fun clear() = entries.clear()
}

data class StartResult(val ok: Boolean, val problems: List<String>)
