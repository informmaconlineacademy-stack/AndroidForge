# HaulPilot 1.2.0 — Known limitations

## New in 1.2.0 — what is not known
* **The failing run was not reproduced.** The 46 pictures and the full log from the phone were not available; the causes of
  the wrong selected game, the pause and the "could not recognise" timeouts were traced in code from the log lines you
  quoted. Whether Auto-Calibrate now finds your pedals and steering on **your** HUD is unknown. Please send a 10–20 s screen
  recording of driving and the Diagnostics log after a failed run.
* **The weighted matching is demonstrated on synthetic scenes.** With strong, high-contrast control outlines the old
  matching already worked; the new one helps when scenery shows through the controls. Not shown on the real game.
* **Pop-up windows from Play services**: Android sends no event when they close. HaulPilot assumes one may still cover the
  game for 6 s and sends no touch during that time; if the game is then still not seen as in front, use "Open the game".
* **While the game is not in front, HaulPilot sends nothing at all, not even the safe brake** after a pause. That is the
  point (never a touch into another app), but the truck keeps rolling until the game is back; use the game's own controls.
* **Without the accessibility service the foreground app cannot be known**, so Start and Resume are refused (Assisted mode
  excepted) and the profile test reports the game as not confirmed.
* A single pedal-shaped element is never given a role (a pair is needed); it is only drawn faintly so you can use it.
* "Ready to drive" now also needs a healthy capture. A game that arrives mostly black (protected window) will keep it at
  "Not ready" and the reason is shown.

## Verification
* **No APK was built in the development environment (1.2.0 included).** Google's Maven repository and the Android SDK servers were not
  reachable there, so Gradle could not resolve AGP, Compose or AndroidX. The first real compile is your GitHub Actions run
  (`.github/workflows/build.yml` or the one-file workflow); a debug APK exists only if that run is green.
* The Android and Compose code was type-checked against hand-written stand-ins of the AndroidX APIs (checked against the
  published API signature files). That catches wrong names, types and calls, but not resource/manifest errors, dependency
  resolution, lint findings or anything at run time.
* **Nothing was run on an emulator, a phone or in Truckers of Europe 3.** Detection was checked on two REAL pictures of
  the game (cut out of your screenshots of HaulPilot, 480 px, one picture each) and on synthetic driving scenes modelled
  on them. **Auto-Calibrate's main path — many live pictures while driving — has not been demonstrated on real gameplay**;
  it is shown on synthetic scenes only. A short screen recording of you driving (imported as a clip, or added to
  `fixtures/toe3` as numbered frames) would let that path be checked on the real game.
* No release APK: no signing key is configured, and none was created or invented.

## Detection and calibration
* Candidates come from shapes and arrangement (closed outlines, pairs, rings, mirror-image arrows, matching fills), with
  screen position only as a small, stated extra weight. A layout with unusual shapes may yield no candidates; every control
  can always be tapped on the picture in the review, and the ten manual steps remain.
* Evidence scores are capped at 60 % (45 % from a single picture) and are not probabilities. Nothing is used until you
  confirm it.
* **Single pictures (a screenshot, or a truck that stood still) are weaker evidence.** On your 0.9 screenshot the faint
  pedals over grass are found, but close to the decision bar: in a strongly blurred copy they are not found (honestly
  "not found", no wrong marker). The minimap is not searched in a single picture, and no driving-screen marker is chosen
  from one (that needs moving scenery). Driving forward while Auto-Calibrate collects is what gives strong evidence.
* The pedal rules follow how Truckers of Europe 3 draws them: two (rounded) rectangles close together, bottoms aligned,
  alike inside. Pedals moved far apart in the game's layout editor are not recognised as a pair (tap them instead).
  Steering buttons must be two equal shapes on one line; a wheel must show an inner and an outer rim edge.
* A gauge or another round element is ignored as a container only when its whole outline is visible; part of the rule was
  checked on synthetic gauges only.
* Reverse gear is never proposed; place it by hand if parking by reversing is wanted.
* HaulPilot leaves its own floating button out of live pictures because it knows where the button is. In **imported
  screenshots** that show the button, it does not know its position. On your 0.9 screenshot it was not used even
  without being told where it is (a test checks this), but in imported pictures it is not masked.
* The other places the analysis considered ("Next spot") are kept while the app runs, not across a restart.
* The minimap must be heading-up (the truck always points up). North-up maps are not supported.
* Positions are stored as fractions of the whole display. They stay valid in both landscape directions but not after
  switching between portrait and landscape or to another screen shape; HaulPilot detects that and asks for a new setup
  instead of stretching positions.
* The destination marker can be set up (step 7, optional). The other optional cues of 0.9 (parking area, "parked" cue,
  obstacle cue, pop-up marker) **cannot be set up** in this version; profiles that already have them keep them when
  updated on the same screen shape. Without a parking area the truck stops near the destination and asks you to park.

## Automation
* HaulPilot is a driving **assistant**. It follows the minimap's route line, stops and asks for help whenever it is unsure,
  and cannot read hidden game state (speed, traffic, damage). It is not a reliable self-driving system; stay with the
  phone.
* Emergency Stop releases every automated touch immediately. It cannot stop the truck by itself (it deliberately presses
  nothing, not even the brake), so the game's own physics decide how the truck rolls out.
* Touches use Android's documented accessibility gesture API. Android itself may cancel gestures (for example when a
  system dialog appears); HaulPilot then stops and reports it.
* Watchdog times are configurable within safe limits; very short values can make the automation stop often.

## Platform
* Screen sharing needs Android's consent dialog each time and stops when the phone locks or the system ends it. Some
  manufacturers stop background services aggressively; battery settings may need "no restrictions".
* Play Protect or store policies may warn about apps that use the Accessibility API without being accessibility tools.
  The in-app disclosure is in place; store approval is not guaranteed.
* Tablets, foldables and multi-window were not considered in testing.
* Notification permission is asked right before the first screen-sharing dialog (Android 13+). Without it the
  notification's Emergency Stop is not shown; the in-app bar and the floating button still work.

## Interface
* The new interface has not been seen on a real screen yet; spacing, contrast and touch comfort need a device pass.
* No Compose UI tests or screenshot tests exist; the interface logic that decides what is shown (readiness, setup steps,
  status advice, overlay, editor geometry) is unit-tested as plain Kotlin.
* English only.
