# Brand assets — HaulPilot

**HaulPilot — Drive smarter. Deliver better.**

All artwork is original and made for this app: a heavy tractor-trailer cresting a curved road, with a cyan navigation arrow, on midnight navy with an electric-orange cab and lane marks. Credit line: **Made by Praju (praju_12)**.

| Asset | File | Notes |
|---|---|---|
| Adaptive launcher icon | `app/src/main/res/mipmap-anydpi-v26/ic_launcher.xml` (+ `_round`) | Background, foreground and monochrome (themed icon) layers are vector drawables in `res/drawable/`. |
| Notification icon | `res/drawable/ic_stat_truck.xml` | One-colour version of the icon. |
| Splash (Android 12+) | `res/values-v31/themes.xml`, `res/drawable/splash_branding.xml` | System splash with the launcher icon; the name, tagline and credit are vector outlines. |
| Launch window (Android 8–11) | `res/drawable/splash_legacy.xml` | |
| Store icon / feature graphic | `docs/store/` | Rendered from the same vectors. |

## Regenerating
The icon geometry lives in `tools/icon/art.py`. `python3 tools/icon/gen.py <out>` writes the vector drawables;
`tools/icon/branding.py` writes the splash wordmark, tagline and credit; `tools/icon/store.js` (Node + Playwright/Chromium) renders the PNGs.

## Licences
* Icon, splash and store graphics: original artwork, free for commercial use by the app's owner.
* Splash lettering and store graphic text: Poppins typeface, SIL Open Font License 1.1 (converted to outlines/images; no
  font file ships in the app).
* No third-party logos, game artwork or trademarks are used.
