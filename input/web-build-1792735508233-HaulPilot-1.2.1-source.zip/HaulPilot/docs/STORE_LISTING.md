# Store listing draft — HaulPilot

Honest wording only. Do not add claims that real gameplay has not demonstrated.

**App name:** HaulPilot
**Tagline:** Drive smarter. Deliver better.
**Developer credit:** Made by Praju (praju_12)
**Category suggestion:** Tools (a helper for a game, not a game)

## Short description (max 80 characters)
Driving assistant for truck sims: Smart Setup, road tracking, careful parking.

## Full description
HaulPilot — Drive smarter. Deliver better.

HaulPilot is a driving assistant for Truckers of Europe 3 on Android.

You pick the job and attach the trailer. Then press Start Auto Drive: HaulPilot follows the route line on the game's minimap,
slows down for bends and, when the destination marker is set up, near the destination, where it stops. When it is
unsure, it stops and asks you. You handle delivery, payment and the next job yourself.

• Smart Setup in ten guided steps, from live play, screenshots or a short screen recording
• Proposed controls show their evidence; nothing is used until you confirm it, and every control can be placed by hand
  with a zoomable crosshair editor
• Several profiles, with undo and export
• Emergency Stop on every screen, on a small movable floating button and in the notification
• Clear explanations when something goes wrong, with the next step to take
• Private by design: no internet permission, no analytics, no ads, nothing uploaded

Important:
• It works only from what is visible on screen. It cannot read hidden game data.
• It is not fully autonomous. Successful delivery or parking is not guaranteed; stay ready to take over.
• It needs Android's screen capture (you allow it each time) and, to press controls, the Accessibility service (optional; Assisted mode works without it).
• HaulPilot is an independent app, not affiliated with or endorsed by the makers of Truckers of Europe 3. Using automation in a game may be against that game's terms; check them first.

## Graphics in this folder
* `store/icon-512.png` — 512 x 512 store icon (full square; the store applies its own mask).
* `store/feature-graphic-1024x500.png` — feature graphic.
* `store/icon-preview.png` — the icon on light and dark wallpapers, masks, small sizes and the themed version (for review).

**No screenshots are included on purpose.** Stores require screenshots of the real app. Take them on a phone after the
first successful build (Dashboard, Smart Setup with a preview, the floating button over the game, About).

## What Google Play will ask for
* **Accessibility declaration** (Play Console → App content): HaulPilot is *not* an accessibility tool. It uses the API for app
  functionality (performing the driving inputs the user set up), collects no personal data through it, and you must upload a
  video showing the app opening, the in-app disclosure, accepting and declining, and the feature that uses it.
* **Data safety form:** no data collected or shared (screen pictures are processed on the device, not stored or sent).
* **Privacy policy URL:** host `PRIVACY.md` publicly after adding your contact details.
* Approval is not guaranteed. Google Play's Accessibility policy restricts apps that "autonomously initiate, plan and execute
  actions"; it allows deterministic, rule-based automation the user sets up. Read the current policy before submitting:
  https://support.google.com/googleplay/android-developer/answer/10964491
