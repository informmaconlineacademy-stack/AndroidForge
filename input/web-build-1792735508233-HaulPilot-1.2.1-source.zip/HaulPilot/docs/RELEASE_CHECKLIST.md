# Release checklist — HaulPilot

Nothing below is done yet unless it is ticked after a real check.

## Build
- [ ] GitHub Actions "Tests and debug APK" job is green (unit tests + debug compile).
- [ ] "Release build configuration check" job is green (unsigned `assembleRelease`, release lint).
- [ ] Lint report reviewed (Actions → run → `reports` artifact).
- [ ] Optional: "On-device tests (emulator)" run (Run workflow → tick *device_tests*).

## On a real phone (none of this has been done yet)
- [ ] Install the debug APK. Launcher icon, themed icon (Android 13+), splash screen and name "HaulPilot" and the tagline "Drive smarter. Deliver better." on the splash look right.
- [ ] Accessibility disclosure appears before Android's accessibility settings; "Not now" keeps the app usable.
- [ ] Screen capture: grant, deny (app explains), stop from the notification (app explains, nothing resumes by itself).
- [ ] Smart Setup from screenshots, from a clip recorded with this phone's screen recorder, and from live play in the real game: proposals, confirm/edit/reject, save. Uncertain controls are not saved.
- [ ] Smart Setup steps 1–10 as in `DEVICE_TEST_CHECKLIST.md`; the driving screen is then recognised in a real drive (step 10 and a real start).
- [ ] Profiles: create, rename, duplicate, export/import, delete with Undo, Undo last change.
- [ ] Floating button: drag, edge snap, position kept after rotation and restart, panel opens beside it, nothing hidden off-screen.
- [ ] Emergency Stop from the panel, the notification and the red in-app bar releases all inputs at once (and presses nothing).
- [ ] Assisted mode drive, then a short real drive with a finger near Emergency Stop.
- [ ] Road tracking lost / layout change / screen lock: the app stops and explains.
- [ ] Take store screenshots now (real app, real game).

## Signing and IDs
- [ ] Application id `com.praju12.haulpilot` is final (it can never change after publishing).
- [ ] `tools/make-keystore.sh` run on your own computer; keystore and passwords kept **out of git** and backed up.
- [ ] `versionCode` increased for every upload.

## Store
- [ ] Privacy policy hosted with contact details (see `PRIVACY.md`).
- [ ] Accessibility declaration + video, data safety form (see `docs/STORE_LISTING.md`).
- [ ] Listing text checked: no promise of autonomous driving, guaranteed parking or delivery; non-affiliation stated.
- [ ] Game terms of service checked for automation rules.
