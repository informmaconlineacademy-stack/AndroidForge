# HaulPilot 1.2.0

**Drive smarter. Deliver better.**
*Made by Praju (praju_12)*

HaulPilot is a native Kotlin / Jetpack Compose driving assistant for *Truckers of Europe 3*. It watches the screen (with
your permission), follows the route line on the minimap, slows for bends (and near the destination when its marker is set
up), and stops and asks you whenever it is unsure. **You** choose the job, attach the trailer, unload, collect payment and pick the next job.
Touches go through Android's documented accessibility gesture API, or use **Assisted mode**, which only shows what it
would do. It is an assistant, not a reliable self-driving system.

HaulPilot is an independent app, not affiliated with or endorsed by the developer or publisher of Truckers of Europe 3.

> ## Read this first: what has and has not been verified (1.2.0)
>
> * **No APK has been built from this version in the development environment.** Gradle could not download Android
>   dependencies (Google's Maven returned 403). Your GitHub Actions run is the first real compile; a debug APK exists only
>   if that run is green. (1.0.0 did build: your `AndroidForge-app-debug.apk` is a Gradle build of it.) No release APK:
>   no signing key is configured and none was invented.
> * **All 441 JVM unit tests pass** (also with Gradle's embedded Kotlin) and the Android/Compose layer type-checks with 0
>   errors against API-checked stand-ins. Neither is a build.
> * **Everything new in 1.2.0 was tested on synthetic pictures and fakes only.** The 46 pictures and the log of the failing
>   run on your phone were not available, so the failures were traced in the code, not reproduced. **Nothing has run on a
>   phone, an emulator or in the game.** `DEVICE_TEST_CHECKLIST.md` lists what to check, starting with "1.2.0".

## What is new in 1.2.0: game identity, recognition, readiness
Details: `ROOT_CAUSE_REPORT.md` (section 1.2.0, B1–B8), `TEST_REPORT.md` (section 00), `KNOWN_LIMITATIONS.md`.
* **The selected game never changes by itself.** The floating button used to make "the app last in front" the game, so a
  Google Play services window became "the game". Now the game changes only when you choose it in Settings, and Google/system
  helpers, launchers and HaulPilot cannot be chosen. A wrong value saved earlier is repaired at start-up. Default:
  `com.WandaSoftware.TruckersofEurope3`.
* **Selected game and app in front are two facts**, logged together. A pop-up from Play services is tracked apart from the
  app below it. Not in front: HaulPilot pauses, names both packages and how to return; resume works only once the game is
  confirmed in front. No touch is ever sent to another app (a last gate in the input layer).
* **Driving-screen recognition** compares against the *steady* parts of all collected pictures (translucent controls over
  moving scenery no longer flicker), needs 3 of the last 5 pictures, and tells a black / one-colour capture from a dark
  game picture. After the 15 s limit you see **the last picture, the area looked for, the reason and Try again / Open the
  game / Auto-Calibrate again**, not a bare message.
* **Saved profile ≠ live picture.** The profile test judges several recent pictures of the selected game and says in one
  line whether the profile is "recognised on live pictures" or "complete but NOT verified on a live picture". "Ready to
  drive" needs a capture that delivers usable pictures; starting waits for a fresh usable picture of the game.
* **Review**: fixed elements that were found but not assigned (for example a single pedal-shaped element) are drawn faintly
  on the picture; pick a control and tap one to use it. Nothing is assigned for you. Reverse stays optional; the minimap is
  found independently of pedals and steering.

## What is new in 1.1.0: Auto-Calibrate fixed
Details: `ROOT_CAUSE_REPORT.md` (section 1.1.0: what was wrong, A1–A11), `TEST_REPORT.md`, `KNOWN_LIMITATIONS.md`.
* **One action.** Smart Setup → Auto-Calibrate (or the floating button in the game): connect, drive forward ~15 s, the
  analysis starts by itself with real progress, then every found control appears as a **marker on the picture**.
* **Review on the picture.** Drag a marker if it is off, tap a missing control onto the picture, "Next spot" for other
  places the analysis considered, zoom; then Confirm → check → Save → safe test. Steering style is taken from what was
  found (arrows or wheel), never assumed.
* **Detection rebuilt** on outlines measured in the time-averaged picture (translucent controls stay sharp, scenery blurs
  away), with persistence and see-through checks; pedals, arrow pairs and wheels from shape and arrangement.
* **HaulPilot's own button is never analysed** (it was being picked as the "Screen marker"); black cut-out bands are
  left out; only pictures with moving scenery count; a single picture works too, as weaker evidence.
* **Regression fixtures from your screenshots** (`app/src/test/resources/fixtures/toe3`) with a harness for adding more.

## What was new in 1.0.0

## What is new in 1.0.0
Details: `ROOT_CAUSE_REPORT.md` (what was wrong and how it was fixed), `UI_REDESIGN.md`, `KNOWN_LIMITATIONS.md`,
`ACCEPTANCE_CHECKLIST.md`.
* **Calibration rebuilt from the evidence up.** Candidates come only from shapes and arrangement (pedal pair, mirrored
  arrow buttons, wheel ring, changing minimap), never from screen corners or from assuming a control changes when pressed;
  evidence is capped at 60 % and nothing is used until you confirm it.
* **One coordinate system** (fractions of the whole display) with tested transforms from capture to editor; captured
  frames are cropped to the mirrored display, so picture, markers and touches line up.
* **Smart Setup in ten steps** with one real state model (capturing, analysing, review, validated, saved, failed,
  cancelled), duplicate-job protection, cancel, recovery actions, undo/redo and a draft that survives restarts.
* **Placement editor**: crosshair, trackpad-style drag, loupe, one-pixel nudges, 8× zoom, control switcher, per-control
  reset, confirm.
* **Profiles**: several profiles, crash-safe saves, undo last change, delete with undo, export/import.
* **Safety**: "Ready" only when every prerequisite holds; Emergency Stop releases all touches and presses nothing; held
  touches are released if the automation stalls; configurable watchdogs; red Emergency Stop bar on every screen.
* **New interface**: Dashboard, Smart Setup, Profiles, Settings (dark charcoal-navy, amber primary, cyan accent).

## Using it (once built and installed)
1. **Smart Setup → Auto-Calibrate**: connect the screen, drive forward for about 15 seconds, check the markers on the
   picture (drag / tap to correct), confirm, save, run the safe test. Then mark the minimap (Smart Setup step 7). The ten
   manual steps remain for doing everything by hand.
2. Settings → Permissions: turn on the accessibility service (after reading HaulPilot's explanation), or switch on
   Assisted mode in Settings → Touch & coordinates. Start with Assisted mode.
3. In the game: take a job, attach the trailer, drive to a safe start. On the Dashboard, **Start Auto Drive** appears only
   when everything is ready; it switches to the game and counts down.
4. Pause / Resume / Emergency Stop: the red bar in the app, the floating button, or the notification.

## Background operation and storage

* Capture runs in a foreground service (type *mediaProjection*) with a persistent notification (Pause/Resume, End, Emergency stop).
  A small floating button (accessibility overlay, no branding on it) can be dragged to a screen edge and remembers its place; tap it for the
  state, picture-collection progress, Start / Pause / Resume / End and Emergency Stop. Keep it off the calibrated controls.
* The service is not sticky. If Android ends capture the session stops and you must start again (Android asks consent each time).
  Some phones (MIUI/HyperOS, Oppo, Vivo, Huawei, Samsung "sleeping apps") need *No restrictions* in battery settings.
* Frames are analysed in memory at ~480 px and discarded. **No video is recorded.** Stored pictures: small control pictures
  in saved profiles, the one driving picture of an unfinished Smart Setup, and optional low-rate sample snapshots (off by
  default, capped, deletable). Imported clips are read in place and never copied. The app has no `INTERNET` permission.

## Building from a phone (GitHub Actions)

Easiest: the single file **`.github/one-file-build/haulpilot-build.yml`** contains the whole project (regenerate it with
`tools/make-one-file-workflow.py` after changes). Put it in any GitHub repository
as `.github/workflows/haulpilot-build.yml`; GitHub unpacks the project, runs the tests, compiles and offers
**haulpilot-debug-apk** under *Artifacts* only if everything succeeded (otherwise a `build-log`).

This project also contains the regular workflows in `.github/workflows/` (`build.yml`: tests, debug APK, lint report, release
configuration check, optional emulator tests; `unpack-zip.yml`: unpacks an uploaded `project.zip`).

With a computer: JDK 17 + Android SDK 36, then `./gradlew testDebugUnitTest assembleDebug`. Release signing:
`tools/make-keystore.sh`, then `./gradlew assembleRelease` (keystore and passwords stay out of git).

## Permissions

| Permission / capability | Why |
|---|---|
| Screen capture (MediaProjection, consent each time) | See the game screen. In memory only. |
| `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_MEDIA_PROJECTION` | Required to capture while the game is in front. |
| `POST_NOTIFICATIONS` (optional, asked right before the first screen-sharing dialog) | State notification with Emergency Stop, and alerts when a drive stops. |
| `VIBRATE` (optional) | Countdown and alert buzz. |
| Accessibility service (you enable it) | `dispatchGesture` touches, foreground package name, floating panel. Window content is **not** read. |
| Photo Picker / file picker | Chosen videos and screenshots are read once through Android's own pickers; no storage permission. |
| Launcher `<queries>` | List launchable apps to choose the game. |

## Privacy and store publishing
* `PRIVACY.md` — privacy policy (add contact details and host it publicly before publishing).
* `docs/STORE_LISTING.md` — honest listing text, graphics, and what Google Play asks for (Accessibility declaration with a video,
  data safety form). Approval by any store is **not** guaranteed; Play Protect may warn about sideloaded apps using accessibility.
* `docs/RELEASE_CHECKLIST.md`, `docs/ASSETS.md` (icon sources and licences).
* Supported Android versions: 8.0 (API 26) to 16 (API 36). Phone screens; tablets untested.
* Dependencies (Apache 2.0): AndroidX Core, Activity Compose, Lifecycle runtime-compose, Compose BOM 2025.09.00, kotlinx-coroutines; JUnit 4 and AndroidX Test.
  Pinned in `gradle/libs.versions.toml`; not checked against vulnerability databases from the sandbox. Dependabot proposes updates.

## Tests: simulated versus real
See `TEST_REPORT.md` for every command and result (373 JVM tests passing, app layer type-checked, nothing run on a
device). Instrumented tests in `app/src/androidTest` (settings, profile PNG round trip, unfinished-setup restore,
floating-button position, disclosure consent) exist but were never run. **Real-device validation is still required** for
everything Android-specific and for behaviour in the real game.

## Layout
```
app/src/main/kotlin/dev/toe3autopilot/
  core/   Android-free logic: geometry/ (coordinate system), setup/ (Smart Setup state, edits, validation, save),
          calibration/ (fixed-element analysis, candidate detection), profile/ (repository), session/, status/,
          vision/, agents/, capture/, overlay/
  app/    Android layer: MainActivity, AutopilotRuntime, setup/ (SetupController), capture/, input/, data/,
          ui/ (Theme, Icons, Components, AppRoot, Dashboard, Smart Setup + steps, PlacementEditor, Profiles, Settings)
app/src/main/res/   icon, splash, themes, strings
app/src/test/       JVM unit + simulation tests
docs/               store listing, release checklist, assets, store graphics
tools/              offline core tests, offline type-check (not a build), one-file workflow generator, keystore script
.github/            workflows, one-file build, dependabot
```
