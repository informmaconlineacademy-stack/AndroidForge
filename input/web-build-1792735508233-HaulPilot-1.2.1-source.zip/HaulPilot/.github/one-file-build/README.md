# One-file build

`haulpilot-build.yml` contains this whole project in one file. To build from a phone without uploading the project:
put it in any GitHub repository as `.github/workflows/haulpilot-build.yml`, open the Actions tab, and download
`haulpilot-debug-apk` from the run when it is green. (It is not in `workflows/` here, so it does not run in this repository.)
